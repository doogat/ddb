
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.ps1, original lines 1072-1539, segment 3/8. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.ps1:1006: DONE; targets=integration_rest_pgwire::integration_20_compact_custom_backup_path, integration_rest_pgwire::integration_20_maintenance_mutation, integration_rest_pgwire::integration_20_nosql_endpoints, integration_rest_pgwire::integration_20_pgwire_boolean_type, integration_rest_pgwire::integration_20_sql_engine_error_descriptive, rest::rest_get_unknown_id_returns_404, serve::graphql_introspection_hides_internal_tables, server_mutations::compact_force_mutation, server_mutations::compact_mutation_returns_result, server_mutations::compact_no_backup_mutation, server_mutations::sync_mutation_no_remote_returns_error
tests/integration.ps1:1100: DONE (pre-existing, no port needed); targets=subscriptions::ws_payload_auth_subscribe_receive
tests/integration.ps1:1105: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:1189']
tests/integration.ps1:1118: DONE (REST-references half only; test passes); targets=integration_graphql_refs::integration_38b_rest_structured_references_object
tests/integration.ps1:1136: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:1222']
tests/integration.ps1:1161: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:1248']
tests/integration.ps1:1192: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:1283']
tests/integration.ps1:1202: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:1293']
tests/integration.ps1:1224: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:1316']
tests/integration.ps1:1231: DONE (boolean-coercion half only; test passes); targets=integration_graphql_refs::integration_38c2_boolean_coercion
tests/integration.ps1:1255: DONE (test passes); targets=integration_graphql_refs::integration_38d_distinct_typed_query
tests/integration.ps1:1267: DONE (test passes); targets=integration_graphql_refs::integration_38e_groupby_aggregate
tests/integration.ps1:1286: DONE (test passes); targets=integration_graphql_batch::integration_38f_execute_batch_multi_statement
tests/integration.ps1:1309: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:1407']
tests/integration.ps1:1334: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:1429']
tests/integration.ps1:1361: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:1457']
tests/integration.ps1:1403: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:1498']
tests/integration.ps1:1432: DONE; targets=integration_orderby_base_fields::integration_42b_orderby_base_fields_deterministic_pagination
tests/integration.ps1:1507: DONE; targets=integration_sql_writes::integration_43_sql_insert_defaults_date_graphql
tests/integration.ps1:1526: DONE; targets=integration_sql_writes::integration_43_d_sql_constraint_enforcement

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.ps1 b/tests/integration.ps1
deleted file mode 100644
index 2f21127..0000000
--- a/tests/integration.ps1
+++ /dev/null
@@ -1072,468 +0,0 @@
-if ($result -notmatch "backupPath") { throw "compact(force:true) missing backupPath" }
-pass "serve: compact(force: true) mutation"
-
-# compact(noBackup: true)
-$result = gqlq 'mutation { compact(force: true, noBackup: true) { gcSuccess backupPath } }'
-if ($result -notmatch "gcSuccess") { throw "compact(noBackup:true) failed" }
-if ($result -notmatch '"backupPath":null') { throw "compact(noBackup:true) should have null backupPath" }
-pass "serve: compact(noBackup: true) mutation"
-
-# compact(backupPath: custom)
-$gqlBackup = Join-Path $env:TEMP "gql-backup.bundle.tar"
-$gqlBackupEsc = $gqlBackup -replace '\\', '\\\\'
-$result = gqlq "mutation { compact(force: true, backupPath: `"$gqlBackupEsc`") { gcSuccess backupPath } }"
-if ($result -notmatch "gcSuccess") { throw "compact(backupPath) failed" }
-if ($result -notmatch "backupPath") { throw "compact(backupPath) missing backupPath" }
-if (-not (Test-Path $gqlBackup)) { throw "compact(backupPath) file not created" }
-pass "serve: compact(backupPath) mutation"
-
-# maintenance mutation
-$result = gqlq 'mutation { maintenance { success durationMs fallbackUsed tasksRun } }'
-if ($result -notmatch "success") { throw "maintenance mutation failed" }
-pass "serve: maintenance mutation"
-
-# sync mutation — no remote configured, expect error not panic
-$result = gqlq 'mutation { sync { direction commitsTransferred conflictsResolved resurrected } }'
-if ($result -notmatch "errors") { throw "sync should have errored without remote" }
-pass "serve: sync mutation (no remote)"
-
-# 37. WebSocket payload auth (browser-style, no Authorization header)
-# Skipped in PowerShell — requires websocat or native WebSocket client.
-# Full coverage provided by e2e tests (ws_payload_auth_subscribe_receive etc.)
-pass "ws: payload auth (skipped in ps1 — see e2e tests)"
-
-# 38. read-under-write: concurrent read + write
-$writeJob = Start-Job -ScriptBlock {
-    param($url, $token)
-    $headers = @{ "Authorization" = "Bearer $token"; "Content-Type" = "application/json" }
-    Invoke-RestMethod -Uri $url -Method Post -Headers $headers -Body '{"query":"mutation { createDoogat(input: { title: \"ReadPoolWrite\" }) { id } }"}'
-} -ArgumentList $GQL_URL, $TOKEN
-$readResult = gqlq '{ doogats { id title } }'
-if ($readResult -notmatch "doogats") { throw "read-under-write: read failed" }
-$writeResult = Receive-Job -Job $writeJob -Wait | ConvertTo-Json
-if ($writeResult -notmatch "id") { throw "read-under-write: write failed" }
-Remove-Job $writeJob
-pass "serve: read-under-write (concurrent read + write)"
-
-# 38b. multi-value references via GraphQL + REST
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation{executeSql(sql:"CREATE TABLE mvcategory (name VARCHAR(100))"){message}}' | Out-Null
-gqlq 'mutation{executeSql(sql:"CREATE TABLE mvbookmark (mvcategory TEXT REFERENCES mvcategory)"){message}}' | Out-Null
-waitSchemaReload $ver
-$mvCat1 = (gqlq 'mutation{executeSql(sql:"INSERT INTO mvcategory (name) VALUES (''Science'')"){message}}') -replace '.*"message":"(\d+)".*','$1'
-$mvCat2 = (gqlq 'mutation{executeSql(sql:"INSERT INTO mvcategory (name) VALUES (''Math'')"){message}}') -replace '.*"message":"(\d+)".*','$1'
-$mvBm = (gqlq "mutation{executeSql(sql:`"INSERT INTO mvbookmark (mvcategory) VALUES ('$mvCat1')`"){message}}") -replace '.*"message":"(\d+)".*','$1'
-gqlq "mutation{executeSql(sql:`"INSERT INTO mvbookmark_mvcategory (mvbookmark_id, mvcategory_id) VALUES ('$mvBm', '$mvCat2')`"){message}}" | Out-Null
-$mvResult = gqlq '{ mvbookmarks { items { id mvcategories { id } } } }'
-if ($mvResult -notmatch $mvCat1) { throw "multi-value ref: cat1 not in graphql list field" }
-if ($mvResult -notmatch $mvCat2) { throw "multi-value ref: cat2 not in graphql list field" }
-pass "serve: graphql multi-value ref list field"
-$mvRest = rest "/doogats/$mvBm"
-if ($mvRest -notmatch '"references"') { throw "multi-value ref: no references in rest json" }
-if ($mvRest -notmatch '"mvcategory"') { throw "multi-value ref: no category key in references" }
-pass "serve: rest multi-value ref structured json"
-
-# 38b2. REFERENCES relation resolution
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation { executeSql(sql: "CREATE TABLE smokecat (label TEXT)") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "CREATE TABLE smokebm (url TEXT, smokecat TEXT REFERENCES smokecat)") { message } }' | Out-Null
-waitSchemaReload $ver
-$scat = gqlq "mutation { executeSql(sql: `"INSERT INTO smokecat (title, label) VALUES ('Tech', 'tech')`") { message } }"
-$SCAT_ID = if ($scat -match '"message":"([^"]+)"') { $Matches[1] }
-$sbm = gqlq "mutation { executeSql(sql: `"INSERT INTO smokebm (title, url) VALUES ('Example', 'https://example.com')`") { message } }"
-$SBM_ID = if ($sbm -match '"message":"([^"]+)"') { $Matches[1] }
-gqlq "mutation { executeSql(sql: `"INSERT INTO smokebm_smokecat (smokebm_id, smokecat_id) VALUES ('$SBM_ID', '$SCAT_ID')`") { message } }" | Out-Null
-$result = gqlq '{ smokebms { items { smokecat { id label } } } }'
-if ($result -notmatch '"label":"tech"') { throw "singular relation resolution failed: $result" }
-pass "serve: relation singular resolves object"
-$result = gqlq '{ smokebms { items { smokecats { id label } } } }'
-if ($result -notmatch '"label":"tech"') { throw "plural relation resolution failed: $result" }
-pass "serve: relation plural resolves object list"
-Start-Sleep -Seconds 1
-gqlq "mutation { executeSql(sql: `"INSERT INTO smokebm (title, url) VALUES ('No Cat', 'https://nocat.com')`") { message } }" | Out-Null
-$result = gqlq '{ smokebms { items { id smokecat { id } smokecats { id } } } }'
-if ($result -notmatch '"smokecat":null') { throw "null relation failed: $result" }
-if ($result -notmatch '"smokecats":\[\]') { throw "empty plural relation failed: $result" }
-pass "serve: relation null returns null and empty list"
-gqlq 'mutation { executeSql(sql: "DROP TABLE smokebm CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE smokecat CASCADE") { message } }' | Out-Null
-
-# 38b2b. raw ID scalar + orderBy/limit on plural references
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation { executeSql(sql: "CREATE TABLE rlcat (label TEXT)") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "CREATE TABLE rlbm (url TEXT, rlcat TEXT REFERENCES rlcat)") { message } }' | Out-Null
-waitSchemaReload $ver
-$rlC1 = (gqlq 'mutation { executeSql(sql: "INSERT INTO rlcat (label) VALUES (\"cherry\")") { message } }') -replace '.*"message":"([^"]+)".*','$1'
-$rlC2 = (gqlq 'mutation { executeSql(sql: "INSERT INTO rlcat (label) VALUES (\"apple\")") { message } }') -replace '.*"message":"([^"]+)".*','$1'
-Start-Sleep -Seconds 1
-$rlC3 = (gqlq 'mutation { executeSql(sql: "INSERT INTO rlcat (label) VALUES (\"banana\")") { message } }') -replace '.*"message":"([^"]+)".*','$1'
-Start-Sleep -Seconds 1
-$rlBm = (gqlq 'mutation { executeSql(sql: "INSERT INTO rlbm (url) VALUES (\"https://example.com\")") { message } }') -replace '.*"message":"([^"]+)".*','$1'
-foreach ($cid in @($rlC1, $rlC2, $rlC3)) {
-    gqlq "mutation { executeSql(sql: `"INSERT INTO rlbm_rlcat (rlbm_id, rlcat_id) VALUES ('$rlBm', '$cid')`") { message } }" | Out-Null
-}
-# raw ID scalar
-$result = gqlq '{ rlbms { items { rlcat_id rlcat { id label } } } }'
-if ($result -notmatch "rlcat_id`":`"$rlC1") { throw "raw ID scalar missing: $result" }
-if ($result -notmatch '"label":"cherry"') { throw "object resolver missing label: $result" }
-pass "serve: relation raw ID scalar coexists with object resolver"
-# orderBy ASC
-$result = gqlq '{ rlbms { items { rlcats(orderBy: "label") { label } } } }'
-if ($result -notmatch '"apple".*"banana".*"cherry"') { throw "orderBy ASC wrong: $result" }
-pass "serve: relation plural orderBy ASC"
-# orderBy DESC + limit
-$result = gqlq '{ rlbms { items { rlcats(orderBy: "label", orderDir: "DESC", limit: 2) { label } } } }'
-if ($result -notmatch '"cherry".*"banana"') { throw "orderBy DESC wrong: $result" }
-if ($result -match '"apple"') { throw "limit not applied: $result" }
-pass "serve: relation plural orderBy DESC + limit"
-gqlq 'mutation { executeSql(sql: "DROP TABLE rlbm CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE rlcat CASCADE") { message } }' | Out-Null
-
-# 38b3. typed connection includes tags
-gqlq 'mutation { executeSql(sql: "CREATE TABLE tagarticle (topic TEXT)") { message } }' | Out-Null
-$taId = (gqlq 'mutation { executeSql(sql: "INSERT INTO tagarticle (topic) VALUES (\"rust\")") { message } }') -replace '.*"message":"(\d+)".*','$1'
-gqlq "mutation { updateDoogat(input: { id: `"$taId`", tags: [`"coding`", `"systems`"] }) { id } }" | Out-Null
-$result = gqlq '{ tagarticles { items { id tags topic } } }'
-if ($result -notmatch '"coding"') { throw "typed connection tags: missing coding tag: $result" }
-if ($result -notmatch '"systems"') { throw "typed connection tags: missing systems tag: $result" }
-pass "serve: typed connection includes tags"
-gqlq 'mutation { executeSql(sql: "DROP TABLE tagarticle CASCADE") { message } }' | Out-Null
-
-# 38b4. tagEntries query with filters
-$te1 = (gqlq 'mutation { createDoogat(input: { title: "TagEntry A", tags: ["te-rust", "te-cli"] }) { id } }') -replace '.*"id":"(\d+)".*','$1'
-Start-Sleep -Seconds 1
-$te2 = (gqlq 'mutation { createDoogat(input: { title: "TagEntry B", tags: ["te-rust"] }) { id } }') -replace '.*"id":"(\d+)".*','$1'
-$result = gqlq "{ tagEntries(where: { doogatId: { eq: `"$te1`" } }) { items { doogatId tag } totalCount } }"
-if ($result -notmatch '"totalCount":2') { throw "tagEntries doogatId eq: expected 2, got: $result" }
-pass "serve: tagEntries filter by doogatId eq"
-
-$result = gqlq '{ tagEntries(where: { tag: { eq: "te-rust" } }) { items { tag } totalCount } }'
-if ($result -notmatch '"te-rust"') { throw "tagEntries tag eq: missing te-rust: $result" }
-$teCount = if ($result -match '"totalCount":(\d+)') { [int]$Matches[1] } else { 0 }
-if ($teCount -lt 2) { throw "tagEntries tag eq: expected >=2, got $teCount" }
-pass "serve: tagEntries filter by tag eq"
-
-$result = gqlq '{ tagEntries(where: { tag: { contains: "te-" } }) { totalCount } }'
-$teCount = if ($result -match '"totalCount":(\d+)') { [int]$Matches[1] } else { 0 }
-if ($teCount -lt 3) { throw "tagEntries tag contains: expected >=3, got $teCount" }
-pass "serve: tagEntries filter by tag contains"
-
-gqlq "mutation { deleteDoogat(id: `"$te1`") { id } }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$te2`") { id } }" | Out-Null
-
-# 38c. sql-materialization (columns, boolean normalization, core fields)
-$result = gqlq '{ sql(query: "SELECT id, title FROM doogats") { columns rows } }'
-if ($result -notmatch '"columns"') { throw "sql columns: missing columns field" }
-if ($result -notmatch '"id"') { throw "sql columns: missing id column" }
-if ($result -notmatch '"title"') { throw "sql columns: missing title column" }
-pass "serve: sql columns in response"
-
-# 38c2. sql format:objects returns keyed rows
-$result = gqlq '{ sql(query: "SELECT id, title FROM doogats", format: "objects") { columns rows } }'
-if ($result -notmatch '\\"id\\":') { throw "sql format objects: missing id key in row object" }
-if ($result -notmatch '\\"title\\":') { throw "sql format objects: missing title key in row object" }
-pass "serve: sql format objects returns keyed rows"
-
-ddl 'mutation{executeSql(sql:"CREATE TABLE smokepin (pinned BOOLEAN)"){message}}'
-$smokepinId = (gqlq "mutation{executeSql(sql:`"INSERT INTO smokepin (title, pinned) VALUES ('PinTest', true)`"){message}}") -replace '.*"message":"(\d+)".*','$1'
-if (-not $smokepinId) { throw "smokepin insert failed" }
-$result = gqlq "{ sql(query: `"SELECT pinned FROM smokepin WHERE pinned = 1`") { rows } }"
-if ($result -notmatch '[\\"]true[\\"]') { throw "boolean not coerced to true" }
-pass "serve: boolean coerced to true/false"
-
-# Boolean false
-Start-Sleep -Seconds 1
-gqlq "mutation{executeSql(sql:`"INSERT INTO smokepin (title, pinned) VALUES ('FalseTest', false)`"){message}}" | Out-Null
-$result = gqlq "{ sql(query: `"SELECT pinned FROM smokepin WHERE pinned = 0`") { rows } }"
-if ($result -notmatch '[\\"]false[\\"]') { throw "boolean false not coerced" }
-pass "serve: boolean false coerced"
-
-$result = gqlq '{ sql(query: "SELECT title FROM smokepin") { rows } }'
-if ($result -notmatch 'PinTest') { throw "core fields: title missing from type table" }
-pass "serve: core fields in type table"
-
-# 38d. DISTINCT on typed connection queries
-gqlq "mutation{executeSql(sql:`"INSERT INTO foo (title, bar, baz) VALUES ('dup1', 'val', 2)`"){message}}" | Out-Null
-gqlq "mutation{executeSql(sql:`"INSERT INTO foo (title, bar, baz) VALUES ('uniq', 'other', 3)`"){message}}" | Out-Null
-Start-Sleep -Seconds 1
-$result = gqlq '{ foos(distinct: "bar") { items { bar } totalCount } }'
-if ($result -notmatch '"totalCount":2') { throw "distinct totalCount: $result" }
-pass "serve: distinct deduplicates and totalCount reflects unique count"
-
-$result = gqlq '{ foos(distinct: "bar", where: { baz: { gte: 2 } }) { totalCount } }'
-if ($result -notmatch '"totalCount":2') { throw "distinct with where: $result" }
-pass "serve: distinct with where filter"
-
-# 38e. GROUP BY on typed aggregate queries
-$result = gqlq '{ foosAggregate(groupBy: "bar") { groups { key count } } }'
-if ($result -notmatch '"key":"val"') { throw "groupBy missing val: $result" }
-if ($result -notmatch '"key":"other"') { throw "groupBy missing other: $result" }
-pass "serve: groupBy returns per-group counts"
-
-$result = gqlq '{ foosAggregate(groupBy: "bar") { groups { key count minBaz maxBaz } } }'
-if ($result -notmatch '"minBaz"') { throw "groupBy missing minBaz: $result" }
-if ($result -notmatch '"maxBaz"') { throw "groupBy missing maxBaz: $result" }
-pass "serve: groupBy with numeric aggregates"
-
-$result = gqlq '{ foosAggregate(groupBy: "bar", where: { baz: { gte: 2 } }) { groups { key count } } }'
-if ($result -notmatch '"key"') { throw "groupBy with where: $result" }
-pass "serve: groupBy with where filter"
-
-$result = gqlq '{ foosAggregate { count } }'
-if ($result -notmatch '"count":3') { throw "aggregate without groupBy: $result" }
-pass "serve: aggregate without groupBy still works"
-
-# 38f. executeBatch mutation
-$result = gqlq 'mutation { executeBatch(statements: ["INSERT INTO foo (title, bar, baz) VALUES (''batch1'', ''b1'', 10)", "INSERT INTO foo (title, bar, baz) VALUES (''batch2'', ''b2'', 20)"]) { message affected } }'
-if ($result -match '"errors"') { throw "executeBatch errors: $result" }
-pass "serve: executeBatch multiple INSERTs"
-
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-$result = gqlq 'mutation { executeBatch(statements: ["CREATE TABLE batchtest (col1 TEXT)"]) { message } }'
-if ($result -notmatch '"message"') { throw "executeBatch DDL: $result" }
-waitSchemaReload $ver
-$result = gqlq '{ batchtests { totalCount } }'
-if ($result -notmatch '"totalCount":0') { throw "executeBatch schema reload: $result" }
-pass "serve: executeBatch DDL triggers schema reload"
-
-# executeBatch failure rolls back
-$preCount = (gqlq '{ foosAggregate { count } }') -replace '.*"count":(\d+).*','$1'
-try { gqlq 'mutation { executeBatch(statements: ["INSERT INTO foo (title, bar, baz) VALUES (''rollback_test'', ''rb'', 99)", "INSERT INTO no_such_table (title) VALUES (''bad'')"]) { message } }' } catch {}
-Start-Sleep -Seconds 1
-$postCount = (gqlq '{ foosAggregate { count } }') -replace '.*"count":(\d+).*','$1'
-if ($preCount -ne $postCount) { throw "executeBatch rollback failed: pre=$preCount post=$postCount" }
-pass "serve: executeBatch failure rolls back all statements"
-
-gqlq 'mutation { executeSql(sql: "DROP TABLE batchtest CASCADE") { message } }' | Out-Null
-
-# 38g. batchUpdate mutation
-$bu1 = gqlq 'mutation { createDoogat(input: { title: "BatchUp Alpha" }) { id } }'
-$BU1_ID = if ($bu1 -match '"id":"([^"]+)"') { $Matches[1] } else { throw "no bu1 id" }
-$bu2 = gqlq 'mutation { createDoogat(input: { title: "BatchUp Beta" }) { id } }'
-$BU2_ID = if ($bu2 -match '"id":"([^"]+)"') { $Matches[1] } else { throw "no bu2 id" }
-$bu3 = gqlq 'mutation { createDoogat(input: { title: "BatchUp Gamma" }) { id } }'
-$BU3_ID = if ($bu3 -match '"id":"([^"]+)"') { $Matches[1] } else { throw "no bu3 id" }
-
-$result = gqlq "mutation { batchUpdate(updates: [{id: `"$BU1_ID`", title: `"Updated Alpha`"}, {id: `"$BU2_ID`", title: `"Updated Beta`"}, {id: `"$BU3_ID`", title: `"Updated Gamma`"}]) { id title } }"
-$parsed = $result | ConvertFrom-Json
-if ($parsed.data.batchUpdate.Count -ne 3) { throw "batchUpdate expected 3 items, got $($parsed.data.batchUpdate.Count)" }
-pass "serve: batchUpdate returns 3 items"
-
-$item1 = $parsed.data.batchUpdate | Where-Object { $_.id -eq $BU1_ID }
-$item2 = $parsed.data.batchUpdate | Where-Object { $_.id -eq $BU2_ID }
-$item3 = $parsed.data.batchUpdate | Where-Object { $_.id -eq $BU3_ID }
-if ($item1.title -ne "Updated Alpha") { throw "batchUpdate item1 title: $($item1.title)" }
-if ($item2.title -ne "Updated Beta") { throw "batchUpdate item2 title: $($item2.title)" }
-if ($item3.title -ne "Updated Gamma") { throw "batchUpdate item3 title: $($item3.title)" }
-pass "serve: batchUpdate correct titles"
-
-gqlq "mutation { deleteDoogat(id: `"$BU1_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$BU2_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$BU3_ID`") }" | Out-Null
-
-# 38h. createMany mutation
-$result = gqlq 'mutation { createMany(inputs: [{title: "Bulk A"}, {title: "Bulk B"}, {title: "Bulk C"}]) { id title } }'
-$parsed = $result | ConvertFrom-Json
-if ($parsed.data.createMany.Count -ne 3) { throw "createMany expected 3, got $($parsed.data.createMany.Count)" }
-if ($parsed.data.createMany[0].title -ne "Bulk A") { throw "createMany[0] title: $($parsed.data.createMany[0].title)" }
-if ($parsed.data.createMany[1].title -ne "Bulk B") { throw "createMany[1] title: $($parsed.data.createMany[1].title)" }
-if ($parsed.data.createMany[2].title -ne "Bulk C") { throw "createMany[2] title: $($parsed.data.createMany[2].title)" }
-pass "serve: createMany returns 3 items in order"
-
-$CM_ID0 = $parsed.data.createMany[0].id
-$verify = gqlq "{ doogat(id: `"$CM_ID0`") { title } }"
-$vp = $verify | ConvertFrom-Json
-if ($vp.data.doogat.title -ne "Bulk A") { throw "createMany persistence check failed" }
-pass "serve: createMany persists records"
-
-$emptyResult = gqlq 'mutation { createMany(inputs: []) { id } }'
-$ep = $emptyResult | ConvertFrom-Json
-if ($ep.data.createMany.Count -ne 0) { throw "createMany empty expected 0, got $($ep.data.createMany.Count)" }
-pass "serve: createMany empty input"
-
-# cleanup
-$CM_ID1 = $parsed.data.createMany[1].id
-$CM_ID2 = $parsed.data.createMany[2].id
-gqlq "mutation { deleteDoogat(id: `"$CM_ID0`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$CM_ID1`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$CM_ID2`") }" | Out-Null
-
-# 38i. typed field updates via GraphQL (updateDoogat fields/unsetFields, deleteDoogat cleanup)
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-$output = gqlq 'mutation { executeSql(sql: "CREATE TABLE tfubookmark (url VARCHAR(200))") { message } }'
-if ($output -notmatch "table tfubookmark created") { throw "create tfubookmark failed: $output" }
-waitSchemaReload $ver
-$output = gqlq 'mutation { executeSql(sql: "INSERT INTO tfubookmark (title, url) VALUES (\"TFU Test\", \"https://old.com\")") { message } }'
-$TFU_ID = if ($output -match '"message":"(\d{14})"') { $Matches[1] } else { throw "insert tfubookmark bad id: $output" }
-# Verify initial materialized row
-$output = gqlq "mutation { executeSql(sql: `"SELECT url FROM tfubookmark WHERE id = '$TFU_ID'`", format: `"objects`") { rows } }"
-if ($output -notmatch "https://old.com") { throw "initial url not found: $output" }
-# updateDoogat with fields to change url
-$output = gqlq "mutation { updateDoogat(input: { id: `"$TFU_ID`", fields: `"{\`"url\`":\`"https://updated.com\`"}`" }) { id } }"
-if ($output -notmatch $TFU_ID) { throw "updateDoogat fields failed: $output" }
-# Verify via SQL SELECT that materialized row has updated url
-$output = gqlq "mutation { executeSql(sql: `"SELECT url FROM tfubookmark WHERE id = '$TFU_ID'`", format: `"objects`") { rows } }"
-if ($output -notmatch "https://updated.com") { throw "url not updated: $output" }
-pass "serve: typed field update via GraphQL updateDoogat"
-# updateDoogat with unsetFields to remove url
-$output = gqlq "mutation { updateDoogat(input: { id: `"$TFU_ID`", unsetFields: [`"url`"] }) { id } }"
-if ($output -notmatch $TFU_ID) { throw "updateDoogat unsetFields failed: $output" }
-# Verify url is gone (NULL)
-$output = gqlq "mutation { executeSql(sql: `"SELECT url FROM tfubookmark WHERE id = '$TFU_ID'`", format: `"objects`") { rows } }"
-if ($output -match "https://") { throw "url should be unset after unsetFields: $output" }
-pass "serve: typed field unset via GraphQL updateDoogat"
-# Delete the doogat and verify materialized row is gone
-gqlq "mutation { deleteDoogat(id: `"$TFU_ID`") }" | Out-Null
-$output = gqlq "mutation { executeSql(sql: `"SELECT COUNT(*) FROM tfubookmark WHERE id = '$TFU_ID'`") { rows } }"
-if ($output -notmatch '\[\\"0\\"\]') { throw "materialized row not cleaned after delete: $output" }
-pass "serve: deleteDoogat cleans materialized type table row"
-# Clean up typedef
-gqlq 'mutation { executeSql(sql: "DROP TABLE tfubookmark CASCADE") { message } }' | Out-Null
-
-# Hyphenated type names in GraphQL
-ddl "mutation { executeSql(sql: `"CREATE TABLE \`"test-widget\`" (status TEXT, priority INTEGER)`") { message } }"
-gqlq "mutation { executeSql(sql: `"INSERT INTO \`"test-widget\`" (status, priority) VALUES ('active', 1)`") { message } }" | Out-Null
-$result = gqlq "{ testWidgets { items { id status priority } totalCount } }"
-$parsed = $result | ConvertFrom-Json
-if ($parsed.data.testWidgets.totalCount -ne 1) { throw "testWidgets expected 1 item, got $($parsed.data.testWidgets.totalCount)" }
-if ($parsed.data.testWidgets.items[0].status -ne "active") { throw "status expected active, got $($parsed.data.testWidgets.items[0].status)" }
-if ($parsed.data.testWidgets.items[0].priority -ne 1) { throw "priority expected 1, got $($parsed.data.testWidgets.items[0].priority)" }
-pass "serve: hyphenated type typed query"
-
-# 42. base field filters on typed queries (id, title)
-gqlq "mutation { executeSql(sql: `"INSERT INTO \`"test-widget\`" (title, status, priority) VALUES ('FilterTarget', 'pending', 5)`") { message } }" | Out-Null
-Start-Sleep -Seconds 1
-
-$result = gqlq "{ testWidgets(where: { title: { eq: `"FilterTarget`" } }) { items { id title } totalCount } }"
-$parsed = $result | ConvertFrom-Json
-if ($parsed.data.testWidgets.totalCount -ne 1) { throw "title eq filter expected 1, got $($parsed.data.testWidgets.totalCount)" }
-$BF_ID = $parsed.data.testWidgets.items[0].id
-pass "serve: base field title eq filter"
-
-$result = gqlq "{ testWidgets(where: { id: { eq: `"$BF_ID`" } }) { items { id title } totalCount } }"
-$parsed = $result | ConvertFrom-Json
-if ($parsed.data.testWidgets.totalCount -ne 1) { throw "id eq filter expected 1, got $($parsed.data.testWidgets.totalCount)" }
-if ($parsed.data.testWidgets.items[0].id -ne $BF_ID) { throw "id mismatch" }
-pass "serve: base field id eq filter"
-
-$result = gqlq "{ testWidgets(where: { title: { contains: `"Target`" } }) { items { id } totalCount } }"
-$parsed = $result | ConvertFrom-Json
-if ($parsed.data.testWidgets.totalCount -ne 1) { throw "title contains filter expected 1, got $($parsed.data.testWidgets.totalCount)" }
-pass "serve: base field title contains filter"
-
-$result = gqlq "{ testWidgets(where: { id: { eq: `"99999999999999`" } }) { items { id } totalCount } }"
-$parsed = $result | ConvertFrom-Json
-if ($parsed.data.testWidgets.totalCount -ne 0) { throw "nonexistent id expected 0, got $($parsed.data.testWidgets.totalCount)" }
-pass "serve: base field id nonexistent returns empty"
-
-gqlq "mutation { deleteDoogat(id: `"$BF_ID`") }" | Out-Null
-gqlq "mutation { executeSql(sql: `"DROP TABLE \`"test-widget\`"`") { message } }" | Out-Null
-
-# 42b. base-field orderBy (created_at/updated_at/id) + deterministic pagination
-# (PRD 00158). Mirrors ddb-server/tests/graphql_orderby_base_fields_t158.rs
-# through the live GraphQL server. Rows are inserted with DISTINCT dates
-# scrambled relative to insertion order so that created_at ASC, created_at DESC,
-# and id ASC each produce a different ordering -- binding the sort direction.
-#
-#   subject | date       | insertion order (id ASC)
-#   n0      | 2026-03-01 | 1st  (renamed to n0e after update)
-#   n1      | 2026-01-01 | 2nd
-#   n2      | 2026-04-01 | 3rd
-#   n3      | 2026-02-01 | 4th
-#
-#   id ASC          = [n0e, n1, n2, n3]
-#   created_at ASC  = [n1, n3, n0e, n2]   (Jan < Feb < Mar < Apr)
-#   created_at DESC = [n2, n0e, n3, n1]   (Apr > Mar > Feb > Jan)
-#   updated_at ASC  = [n1, n2, n3, n0e]   (n0e re-indexed last = newest)
-#   updated_at DESC = [n0e, n3, n2, n1]
-$obVer = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-$obResult = gqlq "mutation { executeSql(sql: `"CREATE TABLE obnote (subject TEXT NOT NULL)`") { message } }"
-if ($obResult -notmatch 'table obnote created') { throw "CREATE TABLE obnote failed: $obResult" }
-waitSchemaReload $obVer
-gqlq "mutation { executeSql(sql: `"INSERT INTO obnote (subject, date) VALUES ('n0', '2026-03-01')`") { message } }" | Out-Null
-Start-Sleep -Seconds 1
-gqlq "mutation { executeSql(sql: `"INSERT INTO obnote (subject, date) VALUES ('n1', '2026-01-01')`") { message } }" | Out-Null
-Start-Sleep -Seconds 1
-gqlq "mutation { executeSql(sql: `"INSERT INTO obnote (subject, date) VALUES ('n2', '2026-04-01')`") { message } }" | Out-Null
-Start-Sleep -Seconds 1
-gqlq "mutation { executeSql(sql: `"INSERT INTO obnote (subject, date) VALUES ('n3', '2026-02-01')`") { message } }" | Out-Null
-Start-Sleep -Seconds 1
-gqlq "mutation { executeSql(sql: `"UPDATE obnote SET subject = 'n0e' WHERE subject = 'n0'`") { message } }" | Out-Null
-
-# created_at ASC: date order Jan < Feb < Mar < Apr = [n1, n3, n0e, n2].
-# Differs from id ASC [n0e,n1,n2,n3] -- proves date sort, not insertion order.
-$obParsed = (gqlq "{ obnotes(orderBy: { created_at: ASC }) { items { subject } totalCount } }") | ConvertFrom-Json
-$obOrder = @($obParsed.data.obnotes.items | ForEach-Object { $_.subject }) -join ','
-if ($obOrder -ne 'n1,n3,n0e,n2') { throw "created_at ASC order wrong: $obOrder" }
-if ($obParsed.data.obnotes.totalCount -ne 4) { throw "obnotes totalCount expected 4, got $($obParsed.data.obnotes.totalCount)" }
-pass "serve: orderBy created_at ASC"
-
-# created_at DESC: date order Apr > Mar > Feb > Jan = [n2, n0e, n3, n1].
-# Differs from ASC -- proves direction matters.
-$obOrder = @(((gqlq "{ obnotes(orderBy: { created_at: DESC }) { items { subject } } }") | ConvertFrom-Json).data.obnotes.items | ForEach-Object { $_.subject }) -join ','
-if ($obOrder -ne 'n2,n0e,n3,n1') { throw "created_at DESC order wrong: $obOrder" }
-pass "serve: orderBy created_at DESC"
-
-# updated_at DESC: n0e was re-indexed last (UPDATE), so it is newest.
-$obOrder = @(((gqlq "{ obnotes(orderBy: { updated_at: DESC }) { items { subject } } }") | ConvertFrom-Json).data.obnotes.items | ForEach-Object { $_.subject }) -join ','
-if ($obOrder -ne 'n0e,n3,n2,n1') { throw "updated_at DESC order wrong: $obOrder" }
-pass "serve: orderBy updated_at DESC"
-
-# updated_at ASC: n1 has the oldest updated_at, n0e the newest.
-$obOrder = @(((gqlq "{ obnotes(orderBy: { updated_at: ASC }) { items { subject } } }") | ConvertFrom-Json).data.obnotes.items | ForEach-Object { $_.subject }) -join ','
-if ($obOrder -ne 'n1,n2,n3,n0e') { throw "updated_at ASC order wrong: $obOrder" }
-pass "serve: orderBy updated_at ASC"
-
-# id ASC: insertion order.
-$obOrder = @(((gqlq "{ obnotes(orderBy: { id: ASC }) { items { subject } } }") | ConvertFrom-Json).data.obnotes.items | ForEach-Object { $_.subject }) -join ','
-if ($obOrder -ne 'n0e,n1,n2,n3') { throw "id ASC order wrong: $obOrder" }
-pass "serve: orderBy id ASC"
-
-# id DESC: reverse insertion order.
-$obOrder = @(((gqlq "{ obnotes(orderBy: { id: DESC }) { items { subject } } }") | ConvertFrom-Json).data.obnotes.items | ForEach-Object { $_.subject }) -join ','
-if ($obOrder -ne 'n3,n2,n1,n0e') { throw "id DESC order wrong: $obOrder" }
-pass "serve: orderBy id DESC"
-
-# Deterministic pagination over created_at ASC: page1 + page2 reconstruct the
-# full order with no gaps or dupes (the id tiebreaker guarantees a total order).
-$obP1 = @(((gqlq "{ obnotes(orderBy: { created_at: ASC }, limit: 2, offset: 0) { items { subject } } }") | ConvertFrom-Json).data.obnotes.items | ForEach-Object { $_.subject }) -join ','
-$obP2 = @(((gqlq "{ obnotes(orderBy: { created_at: ASC }, limit: 2, offset: 2) { items { subject } } }") | ConvertFrom-Json).data.obnotes.items | ForEach-Object { $_.subject }) -join ','
-if ($obP1 -ne 'n1,n3') { throw "pagination page 1 wrong: $obP1" }
-if ($obP2 -ne 'n0e,n2') { throw "pagination page 2 wrong: $obP2" }
-pass "serve: orderBy created_at ASC deterministic pagination (no gaps/dupes)"
-
-gqlq "mutation { executeSql(sql: `"DROP TABLE obnote CASCADE`") { message } }" | Out-Null
-
-# 43. SQL INSERT via executeSql defaults date, created_at non-null
-gqlq "mutation{executeSql(sql:`"CREATE TABLE datecheck (name TEXT)`"){message}}" | Out-Null
-$dcResult = gqlq "mutation{executeSql(sql:`"INSERT INTO datecheck (name) VALUES (\`"DateTest\`")`"){message}}"
-$dcId = ($dcResult | ConvertFrom-Json).data.executeSql.message
-$dcExpected = "$($dcId.Substring(0,4))-$($dcId.Substring(4,2))-$($dcId.Substring(6,2))"
-$dcQuery = gqlq "{ datechecks { items { id created_at } } }"
-$dcCreated = ($dcQuery | ConvertFrom-Json).data.datechecks.items[0].created_at
-if ($dcCreated -ne $dcExpected) { throw "created_at '$dcCreated' != expected '$dcExpected'" }
-pass "serve: SQL INSERT defaults date, created_at matches ID"
-
-# executeBatch also defaults date
-$ebResult = gqlq "mutation{executeBatch(statements:[`"INSERT INTO datecheck (name) VALUES (\`"BatchTest\`")`"]){message}}"
-$ebId = ($ebResult | ConvertFrom-Json).data.executeBatch[0].message
-$ebExpected = "$($ebId.Substring(0,4))-$($ebId.Substring(4,2))-$($ebId.Substring(6,2))"
-$ebQuery = gqlq "{ doogat(id: `"$ebId`") { created_at } }"
-$ebCreated = ($ebQuery | ConvertFrom-Json).data.doogat.created_at
-if ($ebCreated -ne $ebExpected) { throw "executeBatch created_at '$ebCreated' != expected '$ebExpected'" }
-pass "serve: executeBatch INSERT defaults date, created_at matches ID"
-
-# 43.D SQL constraint enforcement on executeSql write path (PRD 00122 / issue #7)
-# Six checks (D1-D6) extending the existing INSERT-validation neighborhood.
-
-# Setup: NOT NULL link table for D1-D5 and a numeric table for D3.
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq "mutation{executeSql(sql:`"CREATE TABLE link_d1 (title VARCHAR(255) NOT NULL, url VARCHAR(255) NOT NULL)`"){message}}" | Out-Null
-gqlq "mutation{executeSql(sql:`"CREATE TABLE numeric_d3 (title VARCHAR(255) NOT NULL, count INTEGER)`"){message}}" | Out-Null
-waitSchemaReload $ver
-
-# D1. NOT NULL: INSERT with NULL title is rejected and no row is created.
-$d1Result = gqlq "mutation{executeSql(sql:`"INSERT INTO link_d1 (title, url) VALUES (NULL, \`"https://n.com\`")`"){message}}"
-if ($d1Result -notmatch 'NOT NULL constraint violated: link_d1.title') {
-    throw "D1: expected NOT NULL error, got: $d1Result"
-}

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


