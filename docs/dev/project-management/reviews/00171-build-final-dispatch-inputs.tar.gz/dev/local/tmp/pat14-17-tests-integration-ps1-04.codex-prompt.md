
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.ps1, original lines 1540-1973, segment 4/8. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.ps1:1526: DONE; targets=integration_sql_writes::integration_43_d_sql_constraint_enforcement
tests/integration.ps1:1600: DONE; targets=integration_junction_sync::integration_44_e1_join_pin_graphql
tests/integration.ps1:1615: DONE; targets=integration_junction_sync::integration_44_j_auto_junction_atomic_graphql
tests/integration.ps1:1648: DONE; targets=integration_junction_sync::integration_44_k_create_doogat_auto_junction
tests/integration.ps1:1669: DONE; targets=integration_junction_sync::integration_44_m_parent_junction_cleanup_graphql
tests/integration.ps1:1703: DONE; targets=integration_typed_write_polish::integration_44_ddl_response_consistency
tests/integration.ps1:1743: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:1848']
tests/integration.ps1:1768: DONE; targets=integration_typed_write_polish::integration_45_g13_title_template_omit
tests/integration.ps1:1788: DONE; targets=integration_typed_write_polish::integration_45_g12_intra_batch_ignore_surviving_id
tests/integration.ps1:1814: DONE; targets=integration_tags_filter::integration_45_g11_tags_filter_nullable_operators
tests/integration.ps1:1861: DONE; targets=integration_write_recovery::integration_45_a1_cross_mutation_parity_after_unique_failure
tests/integration.ps1:1881: DONE; targets=integration_write_recovery::integration_45_a3_cross_table_isolation_after_unique_failure
tests/integration.ps1:1900: DONE; targets=integration_write_recovery::integration_45_r10_restrict_blocks_sql_and_graphql_delete
tests/integration.ps1:1934: DONE; targets=integration_write_recovery::integration_45_a2_ghost_row_survives_server_restart
tests/integration.ps1:1964: DONE (pre-existing, no port needed) <!-- banner-only line, nothing to port; see 49.1-49.4 -->; targets=; fixture/scaffolding
tests/integration.ps1:1971: DONE; targets=integration_error_codes::integration_49_1_unique_violation_extensions_code

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.ps1 b/tests/integration.ps1
deleted file mode 100644
index 2f21127..0000000
--- a/tests/integration.ps1
+++ /dev/null
@@ -1540,434 +0,0 @@
-$d1Count = gqlq "mutation{executeSql(sql:`"SELECT COUNT(*) FROM link_d1`"){rows}}"
-if ($d1Count -notmatch '\[\\"0\\"\]') { throw "D1: expected zero rows, got: $d1Count" }
-pass "serve: D1 INSERT NULL on NOT NULL is rejected, no row created"
-
-# D2. VARCHAR(N) overflow: 300-char title against VARCHAR(255) is rejected.
-$long = 'x' * 300
-$d2Result = gqlq "mutation{executeSql(sql:`"INSERT INTO link_d1 (title, url) VALUES (\`"$long\`", \`"https://v.com\`")`"){message}}"
-if ($d2Result -notmatch 'value too long for link_d1.title') {
-    throw "D2: expected length error, got: $d2Result"
-}
-$d2Count = gqlq "mutation{executeSql(sql:`"SELECT COUNT(*) FROM link_d1`"){rows}}"
-if ($d2Count -notmatch '\[\\"0\\"\]') { throw "D2: expected zero rows, got: $d2Count" }
-pass "serve: D2 VARCHAR(N) overflow is rejected, no row created"
-
-# D3. INTEGER type mismatch: non-numeric value into INTEGER column is rejected.
-$d3Result = gqlq "mutation{executeSql(sql:`"INSERT INTO numeric_d3 (title, count) VALUES (\`"a\`", \`"not_a_number\`")`"){message}}"
-if ($d3Result -notmatch 'type mismatch for numeric_d3.count: expected INTEGER') {
-    throw "D3: expected type-mismatch error, got: $d3Result"
-}
-$d3Count = gqlq "mutation{executeSql(sql:`"SELECT COUNT(*) FROM numeric_d3`"){rows}}"
-if ($d3Count -notmatch '\[\\"0\\"\]') { throw "D3: expected zero rows, got: $d3Count" }
-pass "serve: D3 INTEGER type mismatch is rejected, no row created"
-
-# D4. Unknown column on INSERT: column not in schema is rejected.
-$d4Result = gqlq "mutation{executeSql(sql:`"INSERT INTO link_d1 (title, url, unknown_col) VALUES (\`"t\`", \`"https://u.com\`", \`"dropped\`")`"){message}}"
-if ($d4Result -notmatch 'unknown column: link_d1.unknown_col') {
-    throw "D4: expected unknown-column error, got: $d4Result"
-}
-$d4Count = gqlq "mutation{executeSql(sql:`"SELECT COUNT(*) FROM link_d1`"){rows}}"
-if ($d4Count -notmatch '\[\\"0\\"\]') { throw "D4: expected zero rows, got: $d4Count" }
-pass "serve: D4 unknown column on INSERT is rejected, no row created"
-
-# D5. Unknown column on UPDATE: insert one valid row, then UPDATE with bogus
-# column. The original row's title must be unchanged after the rejection.
-$d5Valid = gqlq "mutation{executeSql(sql:`"INSERT INTO link_d1 (title, url) VALUES (\`"keep\`", \`"https://k.com\`")`"){message}}"
-$d5Id = ($d5Valid | ConvertFrom-Json).data.executeSql.message
-$d5Result = gqlq "mutation{executeSql(sql:`"UPDATE link_d1 SET unknown_col = 'x' WHERE id = '$d5Id'`"){message}}"
-if ($d5Result -notmatch 'unknown column: link_d1.unknown_col') {
-    throw "D5: expected unknown-column error, got: $d5Result"
-}
-$d5Title = gqlq "mutation{executeSql(sql:`"SELECT title FROM link_d1 WHERE id = '$d5Id'`"){rows}}"
-if ($d5Title -notmatch 'keep') { throw "D5: row mutated unexpectedly, got: $d5Title" }
-pass "serve: D5 unknown column on UPDATE is rejected, row unchanged"
-
-# D6. Silent title fallback removed: title NOT NULL with no template, INSERT
-# omitting title now fails instead of coercing url/description into title.
-ddl "mutation{executeSql(sql:`"CREATE TABLE link_d6 (title VARCHAR(255) NOT NULL, url VARCHAR(255), description TEXT)`"){message}}"
-$d6Result = gqlq "mutation{executeSql(sql:`"INSERT INTO link_d6 (url) VALUES (\`"https://notitle.com\`")`"){message}}"
-if ($d6Result -notmatch 'NOT NULL constraint violated: link_d6.title') {
-    throw "D6: expected NOT NULL error, got: $d6Result"
-}
-$d6Count = gqlq "mutation{executeSql(sql:`"SELECT COUNT(*) FROM link_d6`"){rows}}"
-if ($d6Count -notmatch '\[\\"0\\"\]') { throw "D6: expected zero rows, got: $d6Count" }
-pass "serve: D6 silent title fallback removed, missing title rejected"
-
-# Cleanup D-tables
-gqlq "mutation{executeSql(sql:`"DROP TABLE link_d1 CASCADE`"){message}}" | Out-Null
-gqlq "mutation{executeSql(sql:`"DROP TABLE numeric_d3 CASCADE`"){message}}" | Out-Null
-gqlq "mutation{executeSql(sql:`"DROP TABLE link_d6 CASCADE`"){message}}" | Out-Null
-
-# 44.E1 - Pin JOIN as working (#8 group E1, PRD 00123 archived as obsolete).
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation { executeSql(sql: "CREATE TABLE e1_link (url VARCHAR(255))") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "CREATE TABLE e1_num (count INTEGER)") { message } }' | Out-Null
-waitSchemaReload $ver
-gqlq 'mutation { executeSql(sql: "INSERT INTO e1_link (title, url) VALUES (''a'', ''https://a.com'')") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "INSERT INTO e1_num (title, count) VALUES (''a'', 1)") { message } }' | Out-Null
-$e1Join = gqlq '{ sql(query: "SELECT l.title, n.count FROM e1_link l JOIN e1_num n ON l.title = n.title") { rows } }'
-assertGqlOk $e1Join "E1 JOIN"
-if ($e1Join -notmatch '\\"a\\"') { throw "44.E1: JOIN response missing a: $e1Join" }
-if ($e1Join -notmatch '\\"1\\"') { throw "44.E1: JOIN response missing 1: $e1Join" }
-gqlq 'mutation { executeSql(sql: "DROP TABLE e1_link CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE e1_num CASCADE") { message } }' | Out-Null
-pass "issue-8-E1: SELECT ... JOIN returns joined rows (PRD 00123 archived as obsolete)"
-
-# 44.J - Auto-junction tables populated atomically on SQL INSERT and UPDATE
-# (PRD 00134). Mirrors the bash section 44.J in tests/integration.sh.
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation { executeSql(sql: "CREATE TABLE j134_cat (label VARCHAR(100))") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "CREATE TABLE j134_bm (url TEXT, category TEXT REFERENCES j134_cat)") { message } }' | Out-Null
-waitSchemaReload $ver
-
-$j134CatA = extractId (gqlq 'mutation { executeSql(sql: "INSERT INTO j134_cat (label) VALUES (''alpha'')") { message } }')
-if (-not $j134CatA) { throw "44.J: failed to capture cat_a id" }
-$j134CatB = extractId (gqlq 'mutation { executeSql(sql: "INSERT INTO j134_cat (label) VALUES (''beta'')") { message } }')
-if (-not $j134CatB) { throw "44.J: failed to capture cat_b id" }
-if ($j134CatA -eq $j134CatB) { throw "44.J: categories must have distinct ids" }
-
-# T1's INSERT-side fix: bookmark INSERT must populate j134_bm_category.
-$j134BmResp = gqlq "mutation { executeSql(sql: `"INSERT INTO j134_bm (url, category) VALUES ('https://j134.example', '$j134CatA')`") { message } }"
-$j134Bm = extractId $j134BmResp
-if (-not $j134Bm) { throw "44.J: failed to capture bookmark id: $j134BmResp" }
-
-$j134J1 = gqlq "mutation { executeSql(sql: `"SELECT category_id FROM j134_bm_category WHERE j134_bm_id = '$j134Bm'`") { rows } }"
-if ($j134J1 -notmatch [regex]::Escape($j134CatA)) { throw "44.J: junction missing cat_a after INSERT: $j134J1" }
-pass "PRD 00134: SQL INSERT populates auto-junction atomically (no rebuild)"
-
-# T2's UPDATE-side fix: re-pointing the REFERENCES column must drop the old
-# junction row and insert the new one.
-gqlq "mutation { executeSql(sql: `"UPDATE j134_bm SET category = '$j134CatB' WHERE id = '$j134Bm'`") { message } }" | Out-Null
-
-$j134JOld = gqlq "mutation { executeSql(sql: `"SELECT COUNT(*) FROM j134_bm_category WHERE j134_bm_id = '$j134Bm' AND category_id = '$j134CatA'`") { rows } }"
-if ($j134JOld -notmatch '\\"0\\"') { throw "44.J: stale junction row to cat_a not removed after UPDATE: $j134JOld" }
-
-$j134JNew = gqlq "mutation { executeSql(sql: `"SELECT COUNT(*) FROM j134_bm_category WHERE j134_bm_id = '$j134Bm' AND category_id = '$j134CatB'`") { rows } }"
-if ($j134JNew -notmatch '\\"1\\"') { throw "44.J: new junction row to cat_b not inserted after UPDATE: $j134JNew" }
-pass "PRD 00134: SQL UPDATE syncs auto-junction (old removed, new inserted)"
-
-# 44.K - GraphQL createDoogat typed-create populates auto-junction atomically
-# (PRD 00134 cycle-1 review C1 task #4). Mirrors bash section 44.K. Drives
-# the full GraphQL -> service -> indexer pipeline; unit tests cover the
-# service layer in detail (see service::tests::create_doogat_with_extra_*).
-$j134kCat = extractId (gqlq "mutation { executeSql(sql: `"INSERT INTO j134_cat (label) VALUES ('gamma')`") { message } }")
-if (-not $j134kCat) { throw "44.K: failed to capture cat id" }
-$j134kFields = "{\`"url\`":\`"https://k.example\`",\`"category\`":\`"$j134kCat\`"}"
-$j134kResp = gqlq "mutation { createDoogat(input: { type: `"j134_bm`", title: `"K`", fields: `"$j134kFields`" }) { id } }"
-# `createDoogat` returns the id under `data.createDoogat.id`, not `message`,
-# so extractId (which scans for "message") would yield empty. Match the id
-# field directly.
-$j134kBm = if ($j134kResp -match '"id":"([^"]+)"') { $Matches[1] } else { "" }
-if (-not $j134kBm) { throw "44.K: failed to capture bookmark id from createDoogat: $j134kResp" }
-$j134kJ = gqlq "mutation { executeSql(sql: `"SELECT COUNT(*) FROM j134_bm_category WHERE j134_bm_id = '$j134kBm' AND category_id = '$j134kCat'`") { rows } }"
-if ($j134kJ -notmatch '\\"1\\"') { throw "44.K: createDoogat did not populate auto-junction: $j134kJ" }
-pass "PRD 00134: GraphQL createDoogat populates auto-junction for REFERENCES column (44.K)"
-
-# Cleanup
-gqlq 'mutation { executeSql(sql: "DROP TABLE j134_bm CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE j134_cat CASCADE") { message } }' | Out-Null
-
-# 44.M - Auto-junction parent-direction cleanup on DELETE (PRD 00137).
-# `cascade_junction_cleanup` previously swept only the reverse direction
-# (junctions pointing at the deleted target). The parent-direction sweep
-# (junctions OWNED by the deleted row) is added by PRD 00137 - deleting
-# the bookmark must remove its `pdc_bm_pdc_cat` row in the same transaction.
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation { executeSql(sql: "CREATE TABLE pdc_cat (label VARCHAR(100))") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "CREATE TABLE pdc_bm (url TEXT, pdc_cat TEXT REFERENCES pdc_cat)") { message } }' | Out-Null
-waitSchemaReload $ver
-
-$pdcCat = extractId (gqlq "mutation { executeSql(sql: `"INSERT INTO pdc_cat (label) VALUES ('alpha')`") { message } }")
-if (-not $pdcCat) { throw "44.M: failed to capture cat id" }
-$pdcBm = extractId (gqlq "mutation { executeSql(sql: `"INSERT INTO pdc_bm (url, pdc_cat) VALUES ('https://pdc.example', '$pdcCat')`") { message } }")
-if (-not $pdcBm) { throw "44.M: failed to capture bookmark id" }
-
-# Sanity: parent-direction junction row exists post-INSERT.
-$pdcPre = gqlq "mutation { executeSql(sql: `"SELECT COUNT(*) FROM pdc_bm_pdc_cat WHERE pdc_bm_id = '$pdcBm'`") { rows } }"
-if ($pdcPre -notmatch '\\"1\\"') { throw "44.M: parent-direction junction not populated post-INSERT: $pdcPre" }
-
-# Delete the bookmark (parent direction). Junction row must be cleaned.
-gqlq "mutation { executeSql(sql: `"DELETE FROM pdc_bm WHERE id = '$pdcBm'`") { message } }" | Out-Null
-
-$pdcPost = gqlq "mutation { executeSql(sql: `"SELECT COUNT(*) FROM pdc_bm_pdc_cat WHERE pdc_bm_id = '$pdcBm'`") { rows } }"
-if ($pdcPost -notmatch '\\"0\\"') { throw "44.M: owner-side junction not cleaned by parent DELETE: $pdcPost" }
-# Stronger assertion (mirrors smoke + e2e): the only row in the junction was
-# the deleted parent's, so the whole junction table must be empty.
-$pdcPostAll = gqlq 'mutation { executeSql(sql: "SELECT COUNT(*) FROM pdc_bm_pdc_cat") { rows } }'
-if ($pdcPostAll -notmatch '\\"0\\"') { throw "44.M: junction table not empty after parent DELETE: $pdcPostAll" }
-pass "PRD 00137: parent-delete clears owned auto-junction rows (44.M)"
-
-# Cleanup
-gqlq 'mutation { executeSql(sql: "DROP TABLE pdc_bm CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE pdc_cat CASCADE") { message } }' | Out-Null
-
-# 44. DDL response consistency (no spurious errors)
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-$result = gqlq 'mutation { executeSql(sql: "CREATE TABLE ddltest (name VARCHAR(100))") { columns rows message } }'
-if ($result -match '"errors"') { throw "CREATE TABLE has errors: $result" }
-if ($result -notmatch '"columns":\[\]') { throw "CREATE TABLE columns not empty: $result" }
-if ($result -notmatch '"rows":\[\]') { throw "CREATE TABLE rows not empty: $result" }
-if ($result -notmatch '"message"') { throw "CREATE TABLE missing message: $result" }
-pass "serve: CREATE TABLE response has no errors"
-waitSchemaReload $ver
-
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-$result = gqlq 'mutation { executeSql(sql: "ALTER TABLE ddltest ADD COLUMN age INTEGER") { columns rows message } }'
-if ($result -match '"errors"') { throw "ALTER TABLE has errors: $result" }
-if ($result -notmatch '"columns":\[\]') { throw "ALTER TABLE columns not empty: $result" }
-if ($result -notmatch '"rows":\[\]') { throw "ALTER TABLE rows not empty: $result" }
-pass "serve: ALTER TABLE response has no errors"
-waitSchemaReload $ver
-
-$result = gqlq 'mutation { executeSql(sql: "DROP TABLE ddltest") { columns rows message } }'
-if ($result -match '"errors"') { throw "DROP TABLE has errors: $result" }
-if ($result -notmatch '"columns":\[\]') { throw "DROP TABLE columns not empty: $result" }
-if ($result -notmatch '"rows":\[\]') { throw "DROP TABLE rows not empty: $result" }
-pass "serve: DROP TABLE response has no errors"
-
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-$result = gqlq 'mutation { executeBatch(statements: ["CREATE TABLE ddlbatch1 (name VARCHAR)", "CREATE TABLE ddlbatch2 (val INTEGER)"]) { columns rows message } }'
-if ($result -match '"errors"') { throw "executeBatch DDL has errors: $result" }
-if ($result -notmatch '"columns":\[\]') { throw "executeBatch DDL columns not empty: $result" }
-if ($result -notmatch '"rows":\[\]') { throw "executeBatch DDL rows not empty: $result" }
-pass "serve: executeBatch DDL responses have no errors"
-waitSchemaReload $ver
-
-gqlq 'mutation { executeSql(sql: "DROP TABLE ddlbatch1 CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE ddlbatch2 CASCADE") { message } }' | Out-Null
-
-$dmlResult = gqlq 'mutation { executeSql(sql: "INSERT INTO datecheck (name) VALUES (\"DmlRegression\")") { affected message } }'
-if ($dmlResult -match '"errors"') { throw "DML INSERT has errors: $dmlResult" }
-if ($dmlResult -notmatch '"message"') { throw "DML INSERT missing message: $dmlResult" }
-pass "serve: DML INSERT response unchanged"
-
-# 45. createMany onConflict: IGNORE (upsert via GraphQL)
-ddl 'mutation { executeSql(sql: "CREATE TABLE upsertgql (code TEXT, label TEXT)") { message } }'
-Push-Location $TMPDIR
-$utFile = Get-ChildItem -Path ddb/_typedef -Filter *.md | Where-Object {
-    (Get-Content $_.FullName -Raw) -match "title: upsertgql"
-} | Select-Object -First 1
-$utContent = Get-Content $utFile.FullName -Raw
-$utContent = $utContent -replace "type: _typedef", "type: _typedef`nunique_together:`n  - - code"
-Set-Content -Path $utFile.FullName -Value $utContent -NoNewline
-git add -A | Out-Null
-git commit -m "add unique_together to upsertgql" --quiet | Out-Null
-ddb reindex | Out-Null
-$cm1 = gqlq 'mutation { createMany(inputs: [{title: "UpsertA", type: "upsertgql", fields: "{\"code\":\"X1\",\"label\":\"first\"}"}]) { id title } }'
-$cm1Id = ($cm1 | ConvertFrom-Json).data.createMany[0].id
-if (-not $cm1Id) { throw "upsert seed failed: $cm1" }
-$cm2 = gqlq 'mutation { createMany(inputs: [{title: "UpsertA Dup", type: "upsertgql", fields: "{\"code\":\"X1\",\"label\":\"second\"}"}], onConflict: IGNORE) { id title } }'
-$cm2Obj = ($cm2 | ConvertFrom-Json).data.createMany[0]
-if ($cm2Obj.id -ne $cm1Id) { throw "upsert IGNORE should return existing ID: got $($cm2Obj.id) expected $cm1Id" }
-if ($cm2Obj.title -ne "UpsertA") { throw "upsert IGNORE should return original title: got $($cm2Obj.title)" }
-pass "serve: createMany onConflict IGNORE returns existing"
-gqlq 'mutation { executeSql(sql: "DROP TABLE upsertgql CASCADE") { message } }' | Out-Null
-Pop-Location
-
-# === PRD 00130: GraphQL typed-write polish (issues #11/#12/#13) ===
-
-# 45.G13 - issue #13: createDoogat must omit `title` when the typedef has a
-# title_template, rendering it server-side. Pre-PRD-00130 the schema marked
-# title NON_NULL so the template never fired through GraphQL.
-ddl 'mutation { executeSql(sql: "CREATE TABLE g13link (title TEXT, url VARCHAR(255))") { message } }'
-ddl "mutation { executeSql(sql: ""ALTER TABLE g13link SET TITLE TEMPLATE 'link-{url}'"") { message } }"
-$g13Omit = gqlq 'mutation { createDoogat(input: {type: "g13link", fields: "{\"url\":\"https://example.com\"}"}) { id title } }'
-assertGqlOk $g13Omit "G13 omit title"
-$g13Title = ($g13Omit | ConvertFrom-Json).data.createDoogat.title
-if ($g13Title -ne "link-https://example.com") { throw "issue-13: expected link-https://example.com, got $g13Title" }
-pass "issue-13: createDoogat omits title when typedef has title_template"
-
-ddl 'mutation { executeSql(sql: "CREATE TABLE g13plain (title TEXT, url VARCHAR(255))") { message } }'
-$g13Null = gqlq 'mutation { createDoogat(input: {type: "g13plain", fields: "{\"url\":\"https://x\"}"}) { id } }'
-assertGqlErrors $g13Null "G13 plain rejection"
-if ($g13Null -notmatch 'NOT NULL constraint violated: g13plain\.title') { throw "issue-13: expected NOT_NULL_VIOLATION on g13plain.title, got $g13Null" }
-pass "issue-13: createDoogat without title or template rejects with NOT_NULL_VIOLATION"
-
-gqlq 'mutation { executeSql(sql: "DROP TABLE g13link CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE g13plain CASCADE") { message } }' | Out-Null
-
-# 45.G12 - issue #12: createMany(onConflict: IGNORE) returns the surviving
-# row's ID for skipped rows when both duplicates appear in the same batch.
-ddl 'mutation { executeSql(sql: "CREATE TABLE g12item (code TEXT, label TEXT)") { message } }'
-Push-Location $TMPDIR
-$g12File = Get-ChildItem -Path ddb/_typedef -Filter *.md | Where-Object {
-    (Get-Content $_.FullName -Raw) -match "title: g12item"
-} | Select-Object -First 1
-$g12Content = Get-Content $g12File.FullName -Raw
-$g12Content = $g12Content -replace "type: _typedef", "type: _typedef`nunique_together:`n  - - code"
-Set-Content -Path $g12File.FullName -Value $g12Content -NoNewline
-git add -A | Out-Null
-git commit -m "add unique_together to g12item" --quiet | Out-Null
-ddb reindex | Out-Null
-$g12Batch = gqlq 'mutation { createMany(inputs: [{title: "A", type: "g12item", fields: "{\"code\":\"K1\",\"label\":\"first\"}"}, {title: "A Dup", type: "g12item", fields: "{\"code\":\"K1\",\"label\":\"second\"}"}], onConflict: IGNORE) { id title } }'
-assertGqlOk $g12Batch "G12 batch"
-$g12Items = ($g12Batch | ConvertFrom-Json).data.createMany
-if (-not $g12Items[0].id) { throw "issue-12: empty surviving id" }
-if ($g12Items[0].id -ne $g12Items[1].id) { throw "issue-12: intra-batch duplicate must return same surviving id, got $($g12Items[0].id) vs $($g12Items[1].id)" }
-if ($g12Items[1].title -ne "A") { throw "issue-12: duplicate payload must carry surviving title 'A', got $($g12Items[1].title)" }
-$g12CountResp = gqlq 'mutation { executeSql(sql: "SELECT COUNT(*) FROM g12item") { rows } }'
-$g12Count = (($g12CountResp | ConvertFrom-Json).data.executeSql.rows[0] | ConvertFrom-Json)[0]
-if ($g12Count -ne "1") { throw "issue-12: expected exactly 1 row in g12item, got $g12Count" }
-pass "issue-12: createMany IGNORE returns surviving ID for intra-batch duplicate"
-Pop-Location
-gqlq 'mutation { executeSql(sql: "DROP TABLE g12item CASCADE") { message } }' | Out-Null
-
-# 45.G11 - issue #11: TagsFilter operators are nullable; contains-only
-# filter parses; empty filter and empty arrays are rejected at resolve time.
-ddl 'mutation { executeSql(sql: "CREATE TABLE g11link (title TEXT, url VARCHAR(255))") { message } }'
-$g11Create = gqlq 'mutation { createDoogat(input: {title: "Tagged", type: "g11link", tags: ["rust", "sql"], fields: "{\"url\":\"https://example.com\"}"}) { id } }'
-assertGqlOk $g11Create "G11 create"
-
-$g11Contains = gqlq '{ g11links(where: {tags: {contains: "rust"}}) { totalCount } }'
-assertGqlOk $g11Contains "G11 contains-only"
-$g11ContainsCount = ($g11Contains | ConvertFrom-Json).data.g11links.totalCount
-if ($g11ContainsCount -ne 1) { throw "issue-11: contains-only expected 1 row, got $g11ContainsCount" }
-pass "issue-11: TagsFilter contains-only filter parses and matches"
-
-$g11All = gqlq '{ g11links(where: {tags: {containsAll: ["rust", "sql"]}}) { totalCount } }'
-assertGqlOk $g11All "G11 containsAll-only"
-if ((($g11All | ConvertFrom-Json).data.g11links.totalCount) -ne 1) { throw "issue-11: containsAll-only count mismatch" }
-pass "issue-11: TagsFilter containsAll-only filter parses"
-
-$g11Any = gqlq '{ g11links(where: {tags: {containsAny: ["rust", "go"]}}) { totalCount } }'
-assertGqlOk $g11Any "G11 containsAny-only"
-if ((($g11Any | ConvertFrom-Json).data.g11links.totalCount) -ne 1) { throw "issue-11: containsAny-only count mismatch" }
-pass "issue-11: TagsFilter containsAny-only filter parses"
-
-$g11Empty = gqlq '{ g11links(where: {tags: {}}) { totalCount } }'
-assertGqlErrors $g11Empty "G11 empty filter"
-if ($g11Empty -notmatch "tags filter requires at least one of") { throw "issue-11: empty filter wrong error: $g11Empty" }
-pass "issue-11: empty TagsFilter rejected with clear error"
-
-$g11EmptyAll = gqlq '{ g11links(where: {tags: {containsAll: []}}) { totalCount } }'
-assertGqlErrors $g11EmptyAll "G11 empty containsAll"
-if ($g11EmptyAll -notmatch "containsAll cannot be empty") { throw "issue-11: empty containsAll wrong error: $g11EmptyAll" }
-pass "issue-11: empty containsAll rejected with clear error"
-
-$g11EmptyAny = gqlq '{ g11links(where: {tags: {containsAny: []}}) { totalCount } }'
-assertGqlErrors $g11EmptyAny "G11 empty containsAny"
-if ($g11EmptyAny -notmatch "containsAny cannot be empty") { throw "issue-11: empty containsAny wrong error: $g11EmptyAny" }
-pass "issue-11: empty containsAny rejected with clear error"
-
-$g11Sdl = gqlq '{ __type(name: "TagsFilter") { inputFields { name type { kind ofType { kind name ofType { kind name } } } } } }'
-$g11SdlFields = ($g11Sdl | ConvertFrom-Json).data.__type.inputFields
-$g11AllField = $g11SdlFields | Where-Object { $_.name -eq "containsAll" }
-$g11AnyField = $g11SdlFields | Where-Object { $_.name -eq "containsAny" }
-if ($g11AllField.type.kind -ne "LIST") { throw "issue-11: containsAll must be nullable LIST at top level, got $($g11AllField.type.kind)" }
-if ($g11AnyField.type.kind -ne "LIST") { throw "issue-11: containsAny must be nullable LIST at top level, got $($g11AnyField.type.kind)" }
-pass "issue-11: TagsFilter introspection confirms containsAll/containsAny are nullable lists"
-
-gqlq 'mutation { executeSql(sql: "DROP TABLE g11link CASCADE") { message } }' | Out-Null
-
-# 45.A1 - Cross-mutation parity after a failed UNIQUE INSERT (#4 group A1).
-ddl 'mutation { executeSql(sql: "CREATE TABLE a1item (title VARCHAR(255) NOT NULL, name VARCHAR(255) NOT NULL, UNIQUE(name))") { message } }'
-$a1Valid = gqlq 'mutation { executeSql(sql: "INSERT INTO a1item (title, name) VALUES (''a'', ''unique1'')") { message } }'
-$A1_VALID_ID = extractId $a1Valid
-if (-not $A1_VALID_ID) { throw "45.A1: could not extract A1_VALID_ID" }
-$a1Dup = gqlq 'mutation { executeSql(sql: "INSERT INTO a1item (title, name) VALUES (''b'', ''unique1'')") { message } }'
-assertGqlErrors $a1Dup "A1 duplicate"
-if ($a1Dup -notmatch 'UNIQUE') { throw "45.A1: duplicate did not report UNIQUE: $a1Dup" }
-$a1Upd = gqlq "mutation { updateDoogat(input: { id: `"$A1_VALID_ID`", tags: [`"a1-recovered`"] }) { id tags } }"
-assertGqlOk $a1Upd "A1 updateDoogat recovery"
-if ($a1Upd -notmatch 'a1-recovered') { throw "45.A1: updateDoogat did not surface tag: $a1Upd" }
-$a1Create = gqlq 'mutation { createDoogat(input: { type: "a1item", title: "created-after-rollback", fields: "{\"name\":\"unique2\"}" }) { id title } }'
-assertGqlOk $a1Create "A1 createDoogat recovery"
-$A1_CREATE_ID = if ($a1Create -match '"id":"([^"]+)"') { $Matches[1] } else { throw "45.A1: no id from createDoogat" }
-$a1Del = gqlq "mutation { deleteDoogat(id: `"$A1_CREATE_ID`") }"
-assertGqlOk $a1Del "A1 deleteDoogat recovery"
-if ($a1Del -notmatch 'true') { throw "45.A1: deleteDoogat did not return true: $a1Del" }
-gqlq 'mutation { executeSql(sql: "DROP TABLE a1item CASCADE") { message } }' | Out-Null
-pass "issue-4-A1: failed UNIQUE INSERT does not break update/create/delete mutations"
-
-# 45.A3 - Cross-table isolation (#4 group A3).
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation { executeSql(sql: "CREATE TABLE a3thing (title VARCHAR(255) NOT NULL)") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "CREATE TABLE a3item (title VARCHAR(255) NOT NULL, name VARCHAR(255) NOT NULL, UNIQUE(name))") { message } }' | Out-Null
-waitSchemaReload $ver
-$a3Thing = gqlq 'mutation { executeSql(sql: "INSERT INTO a3thing (title) VALUES (''t1'')") { message } }'
-$A3_THING_ID = extractId $a3Thing
-if (-not $A3_THING_ID) { throw "45.A3: could not extract A3_THING_ID" }
-gqlq 'mutation { executeSql(sql: "INSERT INTO a3item (title, name) VALUES (''a'', ''u1'')") { message } }' | Out-Null
-$a3Dup = gqlq 'mutation { executeSql(sql: "INSERT INTO a3item (title, name) VALUES (''b'', ''u1'')") { message } }'
-assertGqlErrors $a3Dup "A3 duplicate"
-if ($a3Dup -notmatch 'UNIQUE') { throw "45.A3: duplicate did not report UNIQUE: $a3Dup" }
-$a3Upd = gqlq "mutation { updateDoogat(input: { id: `"$A3_THING_ID`", tags: [`"a3-isolated`"] }) { id tags } }"
-assertGqlOk $a3Upd "A3 updateDoogat a3thing recovery"
-if ($a3Upd -notmatch 'a3-isolated') { throw "45.A3: a3thing update tag missing: $a3Upd" }
-gqlq 'mutation { executeSql(sql: "DROP TABLE a3thing CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE a3item CASCADE") { message } }' | Out-Null
-pass "issue-4-A3: failed INSERT on a3item does not corrupt a3thing"
-
-# 45.R10 - RESTRICT on NOT NULL REFERENCES blocks delete via SQL and
-# deleteDoogat (#10). Mirrors the Bash scenario.
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation { executeSql(sql: "CREATE TABLE r10link (url VARCHAR(255) NOT NULL)") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "CREATE TABLE r10cat (name VARCHAR(255) NOT NULL)") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "CREATE TABLE \"r10-mem\" (link_id VARCHAR(255) NOT NULL REFERENCES r10link(id), cat_id VARCHAR(255) NOT NULL REFERENCES r10cat(id), UNIQUE(link_id, cat_id))") { message } }' | Out-Null
-waitSchemaReload $ver
-$r10L = gqlq 'mutation { executeSql(sql: "INSERT INTO r10link (title, url) VALUES (''L'', ''https://r10.example'')") { message } }'
-$R10_L_ID = extractId $r10L
-if (-not $R10_L_ID) { throw "45.R10: could not extract R10_L_ID" }
-$r10C = gqlq 'mutation { executeSql(sql: "INSERT INTO r10cat (title, name) VALUES (''C'', ''c'')") { message } }'
-$R10_C_ID = extractId $r10C
-if (-not $R10_C_ID) { throw "45.R10: could not extract R10_C_ID" }
-gqlq "mutation { executeSql(sql: ""INSERT INTO \""r10-mem\"" (title, link_id, cat_id) VALUES ('M', '$R10_L_ID', '$R10_C_ID')"") { message } }" | Out-Null
-$r10SqlErr = gqlq "mutation { executeSql(sql: ""DELETE FROM r10link WHERE id = '$R10_L_ID'"") { message } }"
-assertGqlErrors $r10SqlErr "R10 SQL DELETE"
-if ($r10SqlErr -notmatch "NOT NULL REFERENCES") { throw "45.R10: SQL DELETE error missing 'NOT NULL REFERENCES': $r10SqlErr" }
-if ($r10SqlErr -notmatch "r10-mem") { throw "45.R10: SQL DELETE error missing blocking table 'r10-mem': $r10SqlErr" }
-$r10GqlErr = gqlq "mutation { deleteDoogat(id: `"$R10_L_ID`") }"
-assertGqlErrors $r10GqlErr "R10 deleteDoogat"
-if ($r10GqlErr -notmatch "NOT NULL REFERENCES") { throw "45.R10: deleteDoogat error missing 'NOT NULL REFERENCES': $r10GqlErr" }
-$r10Parent = gqlq "mutation { executeSql(sql: ""SELECT COUNT(*) FROM r10link WHERE id = '$R10_L_ID'"") { rows } }"
-if ($r10Parent -notmatch '"rows":\["\[\\"1\\"\]"\]') { throw "45.R10: parent row missing after blocked delete: $r10Parent" }
-$r10Child = gqlq "mutation { executeSql(sql: ""SELECT COUNT(*) FROM \""r10-mem\"" WHERE link_id = '$R10_L_ID'"") { rows } }"
-if ($r10Child -notmatch '"rows":\["\[\\"1\\"\]"\]') { throw "45.R10: child row missing after blocked delete: $r10Child" }
-gqlq "mutation { executeSql(sql: ""DELETE FROM \""r10-mem\"" WHERE link_id = '$R10_L_ID'"") { message } }" | Out-Null
-$r10Ok = gqlq "mutation { executeSql(sql: ""DELETE FROM r10link WHERE id = '$R10_L_ID'"") { affected } }"
-assertGqlOk $r10Ok "R10 final DELETE"
-if ($r10Ok -notmatch '"affected":1') { throw "45.R10: expected affected:1 after child removed, got: $r10Ok" }
-gqlq 'mutation { executeSql(sql: "DROP TABLE \"r10-mem\" CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE r10link CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE r10cat CASCADE") { message } }' | Out-Null
-pass "issue-10: RESTRICT blocks delete via SQL and deleteDoogat"
-
-# 45.A2 - Ghost-row fix persists across server restart (#4 group A2).
-ddl 'mutation { executeSql(sql: "CREATE TABLE a2persist (title VARCHAR(255) NOT NULL, name VARCHAR(255) NOT NULL, UNIQUE(name))") { message } }'
-$a2Valid = gqlq 'mutation { executeSql(sql: "INSERT INTO a2persist (title, name) VALUES (''seed'', ''uniq_a2'')") { message } }'
-$A2_VALID_ID = extractId $a2Valid
-if (-not $A2_VALID_ID) { throw "45.A2: could not extract A2_VALID_ID" }
-$a2Dup = gqlq 'mutation { executeSql(sql: "INSERT INTO a2persist (title, name) VALUES (''dup'', ''uniq_a2'')") { message } }'
-assertGqlErrors $a2Dup "A2 duplicate"
-
-# Kill + restart the server on the same $TMPDIR.
-Stop-Process -Id $serverProc.Id -Force -ErrorAction SilentlyContinue
-Start-Sleep -Milliseconds 500
-$serverProc = Start-Process -FilePath $DDB -ArgumentList @("serve", "--port", "$SERVER_PORT", "--pg-port", "$PG_PORT") -NoNewWindow -PassThru
-for ($i = 0; $i -lt 20; $i++) {
-    try {
-        $null = Invoke-WebRequest -Uri $GQL_URL -Method POST -ContentType "application/json" `
-            -Headers @{ Authorization = "Bearer $TOKEN" } -Body '{"query":"{ typeDefs { name } }"}' -ErrorAction Stop
-        break
-    } catch {
-        Start-Sleep -Milliseconds 200
-    }
-}
-
-$a2Upd = gqlq "mutation { updateDoogat(input: { id: `"$A2_VALID_ID`", tags: [`"restart-survived`"] }) { id tags } }"
-assertGqlOk $a2Upd "A2 updateDoogat after restart"
-if ($a2Upd -notmatch 'restart-survived') { throw "45.A2: tags missing after restart: $a2Upd" }
-$a2Fresh = gqlq 'mutation { executeSql(sql: "INSERT INTO a2persist (title, name) VALUES (''fresh'', ''uniq_a2_post'')") { message } }'
-assertGqlOk $a2Fresh "A2 fresh insert after restart"
-gqlq 'mutation { executeSql(sql: "DROP TABLE a2persist CASCADE") { message } }' | Out-Null
-pass "issue-4-A2: ghost-row fix persists across server restart"
-
-# 49. PRD 00131: structured-error code propagation through typed mutations.
-# Mirrors tests/integration.sh §49. Asserts `extensions.code` returns
-# UNIQUE_VIOLATION / NOT_NULL_VIOLATION on createDoogat and createMany.
-# Placed here while the GraphQL server is still running (it shuts down
-# below before sections 46-48, which use the CLI).
-Write-Host "=== PRD 00131: structured-error code propagation ==="
-
-# 49.1 - createDoogat UNIQUE violation carries extensions.code.
-ddl 'mutation { executeSql(sql: "CREATE TABLE puv_link (title VARCHAR(255), slug VARCHAR(255) NOT NULL, space VARCHAR(255) NOT NULL, UNIQUE(slug, space))") { message } }'
-

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is GREEN on exact deletion SHA; both test and coverage jobs succeeded. Final Clippy passed (2m04s); cargo test-ci passed42CLI +1555core +222server, no failed/ignored tests. Three actual generic adversarial mutants were caught (two by focused tests, one by the full suite); final real-binary five-test control passed. All facades are neutralized. Task completion awaits this per-task review. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


