
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.sh, original lines 2114-2613, segment 5/7. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.sh:2109: DONE (pre-existing, no port needed) <!-- banner-only line, nothing to port; see 49.1-49.4 -->; targets=; fixture/scaffolding
tests/integration.sh:2120: DONE; targets=integration_error_codes::integration_49_1_unique_violation_extensions_code
tests/integration.sh:2133: DONE; targets=integration_error_codes::integration_49_2_not_null_violation_extensions_code
tests/integration.sh:2142: DONE; targets=integration_error_codes::integration_49_3_createmany_error_extensions_code
tests/integration.sh:2148: DONE; targets=integration_error_codes::integration_49_4_createmany_intra_batch_error_extensions_code
tests/integration.sh:2159: DONE (pre-existing, no port needed) <!-- banner-only line, nothing to port; see 50a/50b/50c -->; targets=; fixture/scaffolding
tests/integration.sh:2160: DONE; targets=integration_alter_rename::integration_50a_alter_rename_graphql
tests/integration.sh:2169: DONE; targets=alter_table_rename::cli_mysql_rename_table_alias_rejected_with_clear_message, integration_alter_rename::integration_50b_mysql_rename_alias_rejected_graphql
tests/integration.sh:2174: DONE; targets=integration_alter_rename::integration_50c_alter_rename_pgwire, pgwire::pgwire_ddl_create_table
tests/integration.sh:2188: DONE (banner; assertions under 51.A); targets=; fixture/scaffolding
tests/integration.sh:2192: DONE; targets=integration_singleton_flow::integration_51_a_singleton_graphql_flow
tests/integration.sh:2242: DONE; targets=alter_singleton::set_singleton_rejects_multi_row_typedef_with_count, integration_singleton_flow::integration_52_b_graphql_alter_set_drop_singleton_reload
tests/integration.sh:2273: DONE; targets=integration_singleton_flow::integration_53_c_singleton_default_values_auto_seed
tests/integration.sh:2282: DONE; targets=alter_singleton::after_set_singleton_second_insert_rejects_with_constraint, integration_singleton_parity::integration_54_d_cross_protocol_singleton_duplicate_parity, pgwire_singleton::pgwire_singleton_duplicate_insert_keeps_connection_healthy
tests/integration.sh:2366: DONE (pre-existing, no port needed); targets=; fixture/scaffolding
tests/integration.sh:2376: DONE (pre-existing, no port needed); targets=singleton_cross_process_create::two_concurrent_ddb_create_on_singleton_converge_on_one_row
tests/integration.sh:2400: DONE; targets=integration_singleton_races::integration_55_b_graphql_execute_sql_singleton_insert_race, singleton_cross_process_upsert::two_concurrent_graphql_upserts_on_singleton_converge_on_one_row
tests/integration.sh:2428: DONE; targets=integration_singleton_races::integration_55_c_graphql_create_doogat_singleton_insert_race, server_mutations::sync_during_writes_serialized_through_actor
tests/integration.sh:2454: DONE; targets=integration_singleton_races::integration_55_d_cli_vs_pgwire_singleton_insert_race, singleton_cross_process_upsert::two_concurrent_pgwire_inserts_on_singleton_one_wins_one_gets_singleton_error
tests/integration.sh:2516: DONE; targets=integration_singleton_races::integration_55_b_graphql_execute_sql_singleton_insert_race, integration_singleton_races::integration_55_c_graphql_create_doogat_singleton_insert_race, integration_singleton_races::integration_55_d_cli_vs_pgwire_singleton_insert_race, singleton_cross_process_create::two_concurrent_ddb_create_on_singleton_converge_on_one_row
tests/integration.sh:2538: DONE (pre-existing, no port needed); targets=integration_warnings_update::integration_56_a_rest_create_titled_warnings_empty, integration_warnings_update::integration_56_b_rest_create_omitted_title_title_from_template_warning
tests/integration.sh:2548: DONE; targets=integration_warnings_update::integration_56_a_rest_create_titled_warnings_empty
tests/integration.sh:2558: DONE; targets=integration_warnings_update::integration_56_b_rest_create_omitted_title_title_from_template_warning
tests/integration.sh:2572: DONE (pre-existing, no port needed); targets=; fixture/scaffolding
tests/integration.sh:2579: DONE; targets=integration_warnings_update::integration_57_a_graphql_create_titled_extensions_warnings_empty
tests/integration.sh:2586: DONE; targets=integration_warnings_update::integration_57_b_graphql_create_omitted_title_title_from_template_warning
tests/integration.sh:2606: DONE (pre-existing, no port needed); targets=; fixture/scaffolding

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.sh b/tests/integration.sh
deleted file mode 100755
index 6942304..0000000
--- a/tests/integration.sh
+++ /dev/null
@@ -2114,500 +0,0 @@
-# `Validation` strings; PRD 00131 swaps both flatten sites
-# (validation.rs:234, crud.rs:499) back to `DoogatError::unique_violation`.
-# Placed here while the GraphQL server is still running (it shuts down
-# below before sections 46-48, which use the CLI).
-echo "=== PRD 00131: structured-error code propagation ==="
-
-# 49.1 — GraphQL UNIQUE violation on createDoogat carries extensions.code.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE puv_link (title VARCHAR(255), slug VARCHAR(255) NOT NULL, space VARCHAR(255) NOT NULL, UNIQUE(slug, space))\") { message } }"}'
-
-SE_FIRST=$(gql '{"query":"mutation { createDoogat(input: {type: \"puv_link\", title: \"first\", fields: \"{\\\"slug\\\":\\\"hn\\\",\\\"space\\\":\\\"news\\\"}\"}) { id } }"}')
-assert_gql_ok "$SE_FIRST"
-
-SE_DUP=$(gql '{"query":"mutation { createDoogat(input: {type: \"puv_link\", title: \"dup\", fields: \"{\\\"slug\\\":\\\"hn\\\",\\\"space\\\":\\\"news\\\"}\"}) { id } }"}')
-assert_gql_errors "$SE_DUP"
-echo "$SE_DUP" | jq -e '.errors[0].extensions.code == "UNIQUE_VIOLATION"' >/dev/null
-echo "$SE_DUP" | jq -e '.errors[0].extensions.columns == ["slug", "space"]' >/dev/null
-echo "$SE_DUP" | jq -e '.errors[0].extensions.values | type == "array" and length == 2' >/dev/null
-pass "49.1: createDoogat UNIQUE violation carries extensions.code = UNIQUE_VIOLATION"
-
-# 49.2 — GraphQL NOT NULL violation on createDoogat carries extensions.code.
-# Sanity-locks the structured-shape audit so a future flatten can't slip
-# in for NOT_NULL while still passing 49.1.
-SE_NN=$(gql '{"query":"mutation { createDoogat(input: {type: \"puv_link\", title: \"missing-slug\", fields: \"{\\\"space\\\":\\\"news\\\"}\"}) { id } }"}')
-assert_gql_errors "$SE_NN"
-echo "$SE_NN" | jq -e '.errors[0].extensions.code == "NOT_NULL_VIOLATION"' >/dev/null
-echo "$SE_NN" | jq -e '.errors[0].extensions.column == "slug"' >/dev/null
-pass "49.2: createDoogat NOT NULL violation carries extensions.code = NOT_NULL_VIOLATION"
-
-# 49.3 — createMany single-input duplicate under ERROR carries extensions.code.
-SE_CM=$(gql '{"query":"mutation { createMany(inputs: [{type: \"puv_link\", title: \"cm-dup\", fields: \"{\\\"slug\\\":\\\"hn\\\",\\\"space\\\":\\\"news\\\"}\"}], onConflict: ERROR) { id } }"}')
-assert_gql_errors "$SE_CM"
-echo "$SE_CM" | jq -e '.errors[0].extensions.code == "UNIQUE_VIOLATION"' >/dev/null
-pass "49.3: createMany ERROR UNIQUE violation carries extensions.code = UNIQUE_VIOLATION"
-
-# 49.4 — createMany multi-input intra-batch duplicate under ERROR carries
-# extensions.code. Exercises the batch_create intra-batch flatten site
-# fixed by PRD 00131 (crud.rs:499).
-SE_CM_INTRA=$(gql '{"query":"mutation { createMany(inputs: [{type: \"puv_link\", title: \"cm-a\", fields: \"{\\\"slug\\\":\\\"twin\\\",\\\"space\\\":\\\"news\\\"}\"}, {type: \"puv_link\", title: \"cm-b\", fields: \"{\\\"slug\\\":\\\"twin\\\",\\\"space\\\":\\\"news\\\"}\"}], onConflict: ERROR) { id } }"}')
-assert_gql_errors "$SE_CM_INTRA"
-echo "$SE_CM_INTRA" | jq -e '.errors[0].extensions.code == "UNIQUE_VIOLATION"' >/dev/null
-pass "49.4: createMany intra-batch ERROR carries extensions.code = UNIQUE_VIOLATION"
-
-# Cleanup: drop the typedef so subsequent runs start clean.
-ddl '{"query":"mutation { executeSql(sql: \"DROP TABLE puv_link\") { message } }"}'
-
-# 50. PRD 00132: ALTER TABLE foo RENAME TO bar across protocols.
-# 50a. via GraphQL executeSql
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE rngql_src (title VARCHAR(64))\") { message } }"}'
-ddl '{"query":"mutation { executeSql(sql: \"ALTER TABLE rngql_src RENAME TO rngql_dst\") { message } }"}'
-RNGQL_COUNT=$(gql '{"query":"mutation { executeSql(sql: \"SELECT count(*) FROM rngql_dst\") { message } }"}')
-echo "$RNGQL_COUNT" | grep -q '"data"'
-RNGQL_OLD=$(gql '{"query":"mutation { executeSql(sql: \"SELECT count(*) FROM rngql_src\") { message } }"}')
-echo "$RNGQL_OLD" | grep -q '"errors"'
-pass "50a: ALTER TABLE RENAME TO via GraphQL executeSql succeeds; old name no longer resolves"
-
-# 50b. MySQL alias rejected with explicit message (no internal error leak).
-RNGQL_ALIAS=$(gql '{"query":"mutation { executeSql(sql: \"RENAME TABLE rngql_dst TO rngql_dst2\") { message } }"}')
-echo "$RNGQL_ALIAS" | jq -e '.errors[0].message | contains("RENAME TABLE not supported")' >/dev/null
-pass "50b: MySQL RENAME TABLE alias rejected with explicit ALTER TABLE hint"
-
-# 50c. via PgWire when psql is available.
-if command -v psql >/dev/null 2>&1; then
-  PGPASSWORD="$TOKEN" psql -h 127.0.0.1 -p "$PG_PORT" -U ddb -d ddb -c "CREATE TABLE rnpg_src (title VARCHAR(64))" >/dev/null
-  PGPASSWORD="$TOKEN" psql -h 127.0.0.1 -p "$PG_PORT" -U ddb -d ddb -c "ALTER TABLE rnpg_src RENAME TO rnpg_dst" >/dev/null
-  PGPASSWORD="$TOKEN" psql -h 127.0.0.1 -p "$PG_PORT" -U ddb -d ddb -tAc "SELECT count(*) FROM rnpg_dst" | grep -q "0"
-  pass "50c: ALTER TABLE RENAME TO via PgWire succeeds"
-fi
-
-# Cleanup the rename-test typedefs so subsequent runs start clean.
-ddl '{"query":"mutation { executeSql(sql: \"DROP TABLE rngql_dst\") { message } }"}'
-if command -v psql >/dev/null 2>&1; then
-  ddl '{"query":"mutation { executeSql(sql: \"DROP TABLE rnpg_dst\") { message } }"}'
-fi
-
-# 51. SINGLETON GraphQL flow + ALTER + parity (PRD 00139 T20/T22).
-# Reuse the GraphQL/PgWire server started in section 17; it stays up until the
-# existing clean shutdown immediately below.
-
-# 51.A. GraphQL singleton flow (T20 §A)
-VER=$(gql '{"query":"{ schemaVersion }"}' | jq -r '.data.schemaVersion // 0')
-# Route DDL through GraphQL executeSql so the running server's schema reload
-# fires; a raw `ddb query` mutates the repo but never wakes the server (see
-# the section 52.B note below).
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE ig_app_config (theme TEXT) SINGLETON\") { message } }"}' | jq -e '.data.executeSql.message | contains("ig_app_config")' >/dev/null
-wait_schema_reload "$VER"
-
-IG_APP_EMPTY=$(gql '{"query":"{ ig_app_config { id theme } }"}')
-assert_gql_ok "$IG_APP_EMPTY"
-printf '%s' "$IG_APP_EMPTY" | jq -e '.data.ig_app_config == null' >/dev/null
-pass "51.A: ig_app_config singular query returns null before first row"
-
-IG_APP_UPDATE_EMPTY=$(gql '{"query":"mutation { update_ig_app_config(input: \"{\\\"theme\\\":\\\"dark\\\"}\") { id theme } }"}')
-assert_gql_errors "$IG_APP_UPDATE_EMPTY"
-printf '%s' "$IG_APP_UPDATE_EMPTY" | jq -e '.errors[0].extensions.code == "SINGLETON_NOT_FOUND"' >/dev/null
-pass "51.A: update_ig_app_config rejects empty table with SINGLETON_NOT_FOUND"
-
-IG_APP_UPSERT_CREATE=$(gql '{"query":"mutation { upsert_ig_app_config(input: \"{\\\"theme\\\":\\\"dark\\\"}\") { id created } }"}')
-assert_gql_ok "$IG_APP_UPSERT_CREATE"
-IG_APP_ID=$(printf '%s' "$IG_APP_UPSERT_CREATE" | jq -r '.data.upsert_ig_app_config.id')
-[ -n "$IG_APP_ID" ]
-printf '%s' "$IG_APP_UPSERT_CREATE" | jq -e '.data.upsert_ig_app_config.created == true' >/dev/null
-pass "51.A: upsert_ig_app_config creates the first singleton row"
-
-IG_APP_AFTER_CREATE=$(gql '{"query":"{ ig_app_config { theme } }"}')
-assert_gql_ok "$IG_APP_AFTER_CREATE"
-printf '%s' "$IG_APP_AFTER_CREATE" | jq -e '.data.ig_app_config.theme == "dark"' >/dev/null
-pass "51.A: ig_app_config singular query returns theme dark after upsert"
-
-IG_APP_UPSERT_UPDATE=$(gql '{"query":"mutation { upsert_ig_app_config(input: \"{\\\"theme\\\":\\\"light\\\"}\") { id created } }"}')
-assert_gql_ok "$IG_APP_UPSERT_UPDATE"
-printf '%s' "$IG_APP_UPSERT_UPDATE" | jq -e --arg id "$IG_APP_ID" '.data.upsert_ig_app_config.created == false and .data.upsert_ig_app_config.id == $id' >/dev/null
-pass "51.A: upsert_ig_app_config returns created=false once the row exists"
-
-IG_APP_UPDATE_OK=$(gql '{"query":"mutation { update_ig_app_config(input: \"{\\\"theme\\\":\\\"auto\\\"}\") { id theme } }"}')
-assert_gql_ok "$IG_APP_UPDATE_OK"
-printf '%s' "$IG_APP_UPDATE_OK" | jq -e --arg id "$IG_APP_ID" '.data.update_ig_app_config.id == $id and .data.update_ig_app_config.theme == "auto"' >/dev/null
-pass "51.A: update_ig_app_config updates the singleton row in place"
-
-IG_APP_CREATE_FAIL=$(gql '{"query":"mutation { createDoogat(input: { type: \"ig_app_config\", title: \"x\", fields: \"{\\\"theme\\\":\\\"system\\\"}\" }) { id } }"}')
-assert_gql_errors "$IG_APP_CREATE_FAIL"
-printf '%s' "$IG_APP_CREATE_FAIL" | jq -e '.errors[0].extensions.code == "SINGLETON_VIOLATION"' >/dev/null
-pass "51.A: createDoogat rejects a second ig_app_config row with SINGLETON_VIOLATION"
-
-VER=$(gql '{"query":"{ schemaVersion }"}' | jq -r '.data.schemaVersion // 0')
-# DROP via GraphQL executeSql so the server reloads its schema (see 51.A note).
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE ig_app_config CASCADE\") { message } }"}' | jq -e '.data.executeSql.message | contains("dropped")' >/dev/null
-wait_schema_reload "$VER"
-
-# 52.B. ALTER TABLE SET/DROP SINGLETON (T20 §B)
-$DDB query "CREATE TABLE ig_alter_cfg (theme TEXT)" | grep -q "table ig_alter_cfg created"
-$DDB query "INSERT INTO ig_alter_cfg (title, theme) VALUES ('cfg-a', 'dark'), ('cfg-b', 'light')" | grep -qE '^[0-9]{14},[0-9]{14}$'
-
-IG_ALTER_SET_FAIL=$($DDB query "ALTER TABLE ig_alter_cfg SET SINGLETON" 2>&1 || true)
-printf '%s' "$IG_ALTER_SET_FAIL" | grep -q "typedef holds 2 rows"
-pass "52.B: ALTER TABLE ... SET SINGLETON rejects a typedef holding 2 rows"
-
-$DDB query "DELETE FROM ig_alter_cfg WHERE title = 'cfg-b'" | grep -q "1 row"
-VER=$(gql '{"query":"{ schemaVersion }"}' | jq -r '.data.schemaVersion // 0')
-# Route ALTER through GraphQL executeSql so the running server's schema
-# reload triggers (mutations.rs::executeSql at lines ~411-418 fires
-# trigger_reload_and_wait on every "ALTER TABLE"). Going through the CLI
-# would mutate the repo but never wake the server.
-gql '{"query":"mutation { executeSql(sql: \"ALTER TABLE ig_alter_cfg SET SINGLETON\") { message } }"}' | jq -e '.data.executeSql.message' >/dev/null
-wait_schema_reload "$VER"
-IG_ALTER_INTRO=$(gql '{"query":"{ __schema { queryType { fields { name } } } }"}')
-assert_gql_ok "$IG_ALTER_INTRO"
-printf '%s' "$IG_ALTER_INTRO" | jq -e '([.data.__schema.queryType.fields[].name] | index("ig_alter_cfg")) != null' >/dev/null
-pass "52.B: ALTER TABLE ... SET SINGLETON adds the ig_alter_cfg singular query field"
-
-VER=$(gql '{"query":"{ schemaVersion }"}' | jq -r '.data.schemaVersion // 0')
-gql '{"query":"mutation { executeSql(sql: \"ALTER TABLE ig_alter_cfg DROP SINGLETON\") { message } }"}' | jq -e '.data.executeSql.message' >/dev/null
-wait_schema_reload "$VER"
-IG_ALTER_DROP_INTRO=$(gql '{"query":"{ __schema { queryType { fields { name } } } }"}')
-assert_gql_ok "$IG_ALTER_DROP_INTRO"
-printf '%s' "$IG_ALTER_DROP_INTRO" | jq -e '([.data.__schema.queryType.fields[].name] | index("ig_alter_cfg")) == null' >/dev/null
-pass "52.B: ALTER TABLE ... DROP SINGLETON removes the ig_alter_cfg singular query field"
-
-$DDB query "DROP TABLE ig_alter_cfg CASCADE" | grep -q "dropped"
-
-# 53.C. SINGLETON DEFAULT VALUES auto-seed (T20 §C)
-$DDB query "CREATE TABLE ig_seed_cfg (theme TEXT DEFAULT 'system', schema_version INTEGER DEFAULT 1) SINGLETON DEFAULT VALUES" | grep -q "table ig_seed_cfg created"
-$DDB query "SELECT COUNT(*) FROM ig_seed_cfg" | grep -q "^1$"
-IG_SEED_VALUES=$($DDB query "SELECT theme, schema_version FROM ig_seed_cfg")
-printf '%s' "$IG_SEED_VALUES" | grep -q "system"
-printf '%s' "$IG_SEED_VALUES" | grep -q "1"
-pass "53.C: SINGLETON DEFAULT VALUES auto-seeds one ig_seed_cfg row with defaults"
-$DDB query "DROP TABLE ig_seed_cfg CASCADE" | grep -q "dropped"
-
-# 54.D. Cross-protocol parity (T22)
-$DDB query "CREATE TABLE ig_parity_cfg (theme TEXT) SINGLETON" | grep -q "table ig_parity_cfg created"
-IG_PARITY_ID=$($DDB query "INSERT INTO ig_parity_cfg (title, theme) VALUES ('seed', 'p1')" | tr -d '[:space:]')
-echo "$IG_PARITY_ID" | grep -qE '^[0-9]{14}$'
-
-set +e
-IG_PARITY_CLI_OUT=$($DDB query "INSERT INTO ig_parity_cfg (title, theme) VALUES ('x', 'p2')" 2>&1)
-IG_PARITY_CLI_EXIT=$?
-set -e
-[ "$IG_PARITY_CLI_EXIT" -ne 0 ]
-printf '%s' "$IG_PARITY_CLI_OUT" | grep -q "SINGLETON constraint"
-pass "54.D: raw ddb query duplicate INSERT surfaces the SINGLETON constraint message"
-
-IG_PARITY_GQL_SQL=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO ig_parity_cfg (title, theme) VALUES (\\\"x\\\", \\\"p2\\\")\") { message affected rows } }"}')
-assert_gql_errors "$IG_PARITY_GQL_SQL"
-printf '%s' "$IG_PARITY_GQL_SQL" | jq -e '.errors[0].extensions.code == "SINGLETON_VIOLATION" and .errors[0].extensions.table == "ig_parity_cfg"' >/dev/null
-pass "54.D: GraphQL executeSql duplicate INSERT carries SINGLETON_VIOLATION + table"
-
-IG_PARITY_GQL_TYPED=$(gql '{"query":"mutation { createDoogat(input: { type: \"ig_parity_cfg\", title: \"x\", fields: \"{\\\"theme\\\":\\\"p3\\\"}\" }) { id } }"}')
-assert_gql_errors "$IG_PARITY_GQL_TYPED"
-printf '%s' "$IG_PARITY_GQL_TYPED" | jq -e '.errors[0].extensions.code == "SINGLETON_VIOLATION" and .errors[0].extensions.table == "ig_parity_cfg"' >/dev/null
-pass "54.D: GraphQL createDoogat duplicate INSERT carries SINGLETON_VIOLATION + table"
-
-IG_PARITY_GQL_SQL_CODE=$(printf '%s' "$IG_PARITY_GQL_SQL" | jq -r '.errors[0].extensions.code')
-IG_PARITY_GQL_SQL_TABLE=$(printf '%s' "$IG_PARITY_GQL_SQL" | jq -r '.errors[0].extensions.table')
-IG_PARITY_GQL_TYPED_CODE=$(printf '%s' "$IG_PARITY_GQL_TYPED" | jq -r '.errors[0].extensions.code')
-IG_PARITY_GQL_TYPED_TABLE=$(printf '%s' "$IG_PARITY_GQL_TYPED" | jq -r '.errors[0].extensions.table')
-[ "$IG_PARITY_GQL_SQL_CODE" = "$IG_PARITY_GQL_TYPED_CODE" ]
-[ "$IG_PARITY_GQL_SQL_TABLE" = "$IG_PARITY_GQL_TYPED_TABLE" ]
-pass "54.D: GraphQL executeSql and createDoogat return identical singleton error extensions"
-
-IG_PARITY_REST_BODY="$TMPDIR/ig-parity-rest.json"
-IG_PARITY_REST_CODE=$(curl -sS -o "$IG_PARITY_REST_BODY" -w "%{http_code}" "$REST_URL/doogats" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -d '{"title":"x","type":"ig_parity_cfg"}')
-# PRD 00139 cycle-3 #2: client errors must land in 4xx, not 5xx. Previously
-# this asserted ">= 400" which masked the rest_error catch-all that returned
-# HTTP 500 for every DoogatError::Structured variant. SINGLETON_VIOLATION is
-# specifically a 409 Conflict per the new mapping in ddb-server/src/rest.rs.
-[ "$IG_PARITY_REST_CODE" = "409" ]
-jq -e --arg existing_id "$IG_PARITY_ID" \
-  '.error == "SINGLETON_VIOLATION"
-   and (.message | contains("ig_parity_cfg"))
-   and (.message | contains($existing_id))' \
-  "$IG_PARITY_REST_BODY" >/dev/null
-pass "54.D: REST POST /doogats duplicate create returns 409 + SINGLETON_VIOLATION + table/id in the error envelope"
-
-# NoSQL HTTP is read-only today: ddb-server/src/nosql_api.rs exposes only GET
-# scan/get/backlinks routes, so SINGLETON write parity is N/A until the surface
-# grows a typed write route. The follow-up is tracked in
-# dev/local/autopilot/deferred/00139-cycle-1-deferred.json instead of silently
-# skipping coverage.
-IG_PARITY_NOSQL_CODE=$(curl -sS -o /dev/null -w "%{http_code}" "$NOSQL_URL" \
-  -X POST \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -d '{"title":"x","type":"ig_parity_cfg"}')
-[ "$IG_PARITY_NOSQL_CODE" = "404" ] || [ "$IG_PARITY_NOSQL_CODE" = "405" ]
-pass "54.D: NoSQL HTTP exposes no typed write route for singleton parity; deferred gap recorded"
-
-# CLI and PgWire expose human-readable SQL-style messages rather than the
-# GraphQL `extensions` envelope, so parity here is asserted on the stable
-# message fragment instead of byte-identical structured JSON.
-if command -v psql >/dev/null 2>&1; then
-  set +e
-  IG_PARITY_PG_OUT=$(PGPASSWORD="$TOKEN" psql -h 127.0.0.1 -p "$PG_PORT" -U ddb -d ddb -c "INSERT INTO ig_parity_cfg (title, theme) VALUES ('x', 'p4')" 2>&1)
-  IG_PARITY_PG_EXIT=$?
-  set -e
-  [ "$IG_PARITY_PG_EXIT" -ne 0 ]
-  printf '%s' "$IG_PARITY_PG_OUT" | grep -q "SINGLETON constraint"
-  pass "54.D: PgWire duplicate INSERT surfaces the SINGLETON constraint message"
-else
-  # psql absent (e.g. the macOS CI runner): PgWire singleton parity is covered by
-  # the un-skippable e2e test (pgwire_singleton) in this same run, so degrade to a
-  # pass instead of a hard fail — mirrors tests/integration.ps1 section 54.D.
-  pass "54.D: PgWire parity covered by cargo test -p ddb-e2e --test e2e -- pgwire_singleton (no psql on host)"
-fi
-
-$DDB query "SELECT COUNT(*) FROM ig_parity_cfg" | grep -q "^1$"
-$DDB query "SELECT theme FROM ig_parity_cfg" | grep -q "p1"
-pass "54.D: duplicate INSERT parity leaves the singleton end state unchanged"
-$DDB query "DROP TABLE ig_parity_cfg CASCADE" | grep -q "dropped"
-
-# 55. Cross-process SINGLETON write race + structured-error parity (PRD 00140).
-RACE_CLI_1="$TMPDIR/ig_race_cli_1"
-RACE_CLI_2="$TMPDIR/ig_race_cli_2"
-RACE_SQL_1="$TMPDIR/ig_race_sql_1"
-RACE_SQL_2="$TMPDIR/ig_race_sql_2"
-RACE_TYPED_1="$TMPDIR/ig_race_typed_1"
-RACE_TYPED_2="$TMPDIR/ig_race_typed_2"
-RACE_PG_CLI="$TMPDIR/ig_race_pg_cli"
-RACE_PG_SQL="$TMPDIR/ig_race_pg_sql"
-
-# 55.A — CLI `ddb create` race
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE ig_race_cli (theme TEXT) SINGLETON\") { message } }"}'
-set +e
-$DDB create --type ig_race_cli --title x --set theme=dark >"$RACE_CLI_1" 2>&1 &
-PID_CLI_1=$!
-$DDB create --type ig_race_cli --title x --set theme=dark >"$RACE_CLI_2" 2>&1 &
-PID_CLI_2=$!
-wait "$PID_CLI_1"; EXIT_CLI_1=$?
-wait "$PID_CLI_2"; EXIT_CLI_2=$?
-set -e
-# Exactly one must succeed and one must fail
-CLI_OK=$(( (EXIT_CLI_1 == 0 ? 1 : 0) + (EXIT_CLI_2 == 0 ? 1 : 0) ))
-CLI_FAIL=$(( (EXIT_CLI_1 != 0 ? 1 : 0) + (EXIT_CLI_2 != 0 ? 1 : 0) ))
-[ "$CLI_OK" -eq 1 ] || fail "55.A: expected exactly 1 CLI winner, got $CLI_OK"
-[ "$CLI_FAIL" -eq 1 ] || fail "55.A: expected exactly 1 CLI loser, got $CLI_FAIL"
-# Pick the loser's temp file
-if [ "$EXIT_CLI_1" -ne 0 ]; then CLI_LOSER_FILE="$RACE_CLI_1"; else CLI_LOSER_FILE="$RACE_CLI_2"; fi
-grep -q "SINGLETON constraint violated: ig_race_cli already holds row " "$CLI_LOSER_FILE" \
-  || fail "55.A: loser output missing SINGLETON constraint message"
-grep -q "UNIQUE constraint failed" "$CLI_LOSER_FILE" \
-  && fail "55.A: loser output leaked raw UNIQUE constraint failed" || true
-$DDB query "SELECT COUNT(*) FROM ig_race_cli" | grep -q "^1$"
-pass "55.A: concurrent ddb create on a SINGLETON typedef converges on one row; loser carries the structured SINGLETON message"
-
-# 55.B — GraphQL `executeSql` INSERT race
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE ig_race_sql (theme TEXT) SINGLETON\") { message } }"}'
-# `set +e` so a backgrounded `gql` (curl -sf) that hits a transport-level
-# non-200 does not abort the script via `wait`; winner/loser is detected by
-# response content below, exit codes are unused.
-set +e
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO ig_race_sql (title, theme) VALUES (\\\"x\\\", \\\"dark\\\")\") { message } }"}' \
-  >"$RACE_SQL_1" 2>&1 &
-PID_SQL_1=$!
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO ig_race_sql (title, theme) VALUES (\\\"x\\\", \\\"dark\\\")\") { message } }"}' \
-  >"$RACE_SQL_2" 2>&1 &
-PID_SQL_2=$!
-wait "$PID_SQL_1"
-wait "$PID_SQL_2"
-set -e
-SQL_VIOLATIONS=$(grep -l "SINGLETON_VIOLATION" "$RACE_SQL_1" "$RACE_SQL_2" | wc -l | tr -d ' ')
-SQL_ERRORS=$(grep -l '"errors"' "$RACE_SQL_1" "$RACE_SQL_2" | wc -l | tr -d ' ')
-[ "$SQL_VIOLATIONS" -eq 1 ] || fail "55.B: expected exactly 1 SINGLETON_VIOLATION, got $SQL_VIOLATIONS"
-[ "$SQL_ERRORS" -eq 1 ] || fail "55.B: expected exactly 1 errors response, got $SQL_ERRORS"
-grep -q "UNIQUE constraint failed" "$RACE_SQL_1" \
-  && fail "55.B: race_sql_1 leaked raw UNIQUE constraint failed" || true
-grep -q "UNIQUE constraint failed" "$RACE_SQL_2" \
-  && fail "55.B: race_sql_2 leaked raw UNIQUE constraint failed" || true
-gql '{"query":"{ ig_race_sql { theme } }"}' \
-  | jq -e '.data.ig_race_sql != null' >/dev/null
-$DDB query "SELECT COUNT(*) FROM ig_race_sql" | grep -q "^1$"
-pass "55.B: concurrent executeSql INSERT race — loser carries SINGLETON_VIOLATION"
-
-# 55.C — GraphQL typed `createDoogat` race
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE ig_race_typed (theme TEXT) SINGLETON\") { message } }"}'
-# `set +e` so a backgrounded `gql` (curl -sf) that hits a transport-level
-# non-200 does not abort the script via `wait`; winner/loser is detected by
-# response content below, exit codes are unused.
-set +e
-gql '{"query":"mutation { createDoogat(input: { type: \"ig_race_typed\", title: \"x\", fields: \"{\\\"theme\\\":\\\"dark\\\"}\" }) { id } }"}' \
-  >"$RACE_TYPED_1" 2>&1 &
-PID_TYPED_1=$!
-gql '{"query":"mutation { createDoogat(input: { type: \"ig_race_typed\", title: \"x\", fields: \"{\\\"theme\\\":\\\"dark\\\"}\" }) { id } }"}' \
-  >"$RACE_TYPED_2" 2>&1 &
-PID_TYPED_2=$!
-wait "$PID_TYPED_1"
-wait "$PID_TYPED_2"
-set -e
-TYPED_VIOLATIONS=$(grep -l "SINGLETON_VIOLATION" "$RACE_TYPED_1" "$RACE_TYPED_2" | wc -l | tr -d ' ')
-TYPED_ERRORS=$(grep -l '"errors"' "$RACE_TYPED_1" "$RACE_TYPED_2" | wc -l | tr -d ' ')
-[ "$TYPED_VIOLATIONS" -eq 1 ] || fail "55.C: expected exactly 1 SINGLETON_VIOLATION, got $TYPED_VIOLATIONS"
-[ "$TYPED_ERRORS" -eq 1 ] || fail "55.C: expected exactly 1 errors response, got $TYPED_ERRORS"
-grep -q "UNIQUE constraint failed" "$RACE_TYPED_1" \
-  && fail "55.C: race_typed_1 leaked raw UNIQUE constraint failed" || true
-grep -q "UNIQUE constraint failed" "$RACE_TYPED_2" \
-  && fail "55.C: race_typed_2 leaked raw UNIQUE constraint failed" || true
-$DDB query "SELECT COUNT(*) FROM ig_race_typed" | grep -q "^1$"
-pass "55.C: concurrent createDoogat race — loser carries SINGLETON_VIOLATION"
-
-# 55.D — CLI-vs-PgWire concurrent INSERT race.
-#
-# Determinism contract (PRD 00157, root-caused 2026-06-16; see
-# docs/src/technical/sql-engine.md "Cross-process SINGLETON write safety").
-# This is the ONLY truly cross-process race in §55: a separate `ddb` CLI
-# process (service path, holds BEGIN IMMEDIATE) racing the server's PgWire
-# INSERT (dml.rs path — no IMMEDIATE window: Layer-2 pre-check + Layer-3
-# `<table>_singleton_lock` UNIQUE backstop). §55.A/B/C are serialized within a
-# single process (A shares the SQLite write lock; B/C share the server actor's
-# single-threaded loop), so their loser deterministically carries the
-# structured SINGLETON message. §55.D cannot promise that wording: the two
-# processes do not share one lock discipline and additionally contend on git
-# (`.git/index.lock`, ref updates) outside SQLite's lock, so a loser that
-# collides on git (or waits out the winner's held write lock) before reaching a
-# singleton enforcement layer surfaces a transient contention error instead.
-# Closing that window would need a cross-process git lock — out of PRD 00157
-# scope. The DETERMINISTIC promise is therefore: (1) exactly one winner and one
-# loser; (2) exactly one materialized row survives (Layer-3 UNIQUE — hard);
-# (3) no raw `UNIQUE constraint failed` ever leaks; (4) the loser surfaces a
-# RECOGNIZED failure — the structured SINGLETON message OR a transient
-# cross-process contention error — never an unrecognized error, never a second
-# row. No retry loop: the assertion encodes the real promise (PRD Risk #2).
-#
-# psql-absent handling mirrors section 54.D and tests/integration.ps1: SINGLETON
-# PgWire parity is covered by the un-skippable e2e test (pgwire_singleton) in the
-# same run, so a host without psql (e.g. the macOS CI runner) degrades to a pass
-# rather than a hard fail. ig_race_pg is created only when the race actually runs,
-# so section 55.E skips it when psql is absent (see PG_RAN).
-PG_RAN=0
-if command -v psql >/dev/null 2>&1; then
-  ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE ig_race_pg (theme TEXT) SINGLETON\") { message } }"}'
-  PG_RAN=1
-  set +e
-  $DDB create --type ig_race_pg --title x --set theme=dark >"$RACE_PG_CLI" 2>&1 &
-  PID_PG_CLI=$!
-  PGPASSWORD="$TOKEN" psql -h 127.0.0.1 -p "$PG_PORT" -U ddb -d ddb \
-    -c "INSERT INTO ig_race_pg (title, theme) VALUES ('x', 'dark')" \
-    >"$RACE_PG_SQL" 2>&1 &
-  PID_PG_SQL=$!
-  wait "$PID_PG_CLI"; EXIT_PG_CLI=$?
-  wait "$PID_PG_SQL"; EXIT_PG_SQL=$?
-  set -e
-  PG_OK=$(( (EXIT_PG_CLI == 0 ? 1 : 0) + (EXIT_PG_SQL == 0 ? 1 : 0) ))
-  PG_FAIL=$(( (EXIT_PG_CLI != 0 ? 1 : 0) + (EXIT_PG_SQL != 0 ? 1 : 0) ))
-  [ "$PG_OK" -eq 1 ] || fail "55.D: expected exactly 1 winner, got $PG_OK"
-  [ "$PG_FAIL" -eq 1 ] || fail "55.D: expected exactly 1 loser, got $PG_FAIL"
-  if [ "$EXIT_PG_CLI" -ne 0 ]; then PG_LOSER_FILE="$RACE_PG_CLI"; else PG_LOSER_FILE="$RACE_PG_SQL"; fi
-  # Promise (3): a raw UNIQUE leak is always a bug, whichever layer caught it.
-  grep -q "UNIQUE constraint failed" "$PG_LOSER_FILE" \
-    && fail "55.D: loser leaked raw UNIQUE constraint failed" || true
-  # Promise (4): the loser must surface a RECOGNIZED failure — the structured
-  # SINGLETON message, or a transient cross-process contention error (git lock
-  # / SQLite busy). An unrecognized error means a new failure mode to triage.
-  grep -Eqi "SINGLETON constraint|locked|busy|index\.lock|cannot lock|unable to create|File exists|another git process" "$PG_LOSER_FILE" \
-    || fail "55.D: loser surfaced an unrecognized error (expected structured SINGLETON message or a transient cross-process contention error): $(cat "$PG_LOSER_FILE")"
-  # Promise (2): convergence — exactly one materialized row survives.
-  $DDB query "SELECT COUNT(*) FROM ig_race_pg" | grep -q "^1$"
-  pass "55.D: concurrent CLI-vs-PgWire INSERT race on a SINGLETON typedef — converges on one row; loser carries the structured SINGLETON message or a transient cross-process contention error, never a raw UNIQUE leak"
-else
-  pass "55.D: PgWire race covered by cargo test -p ddb-e2e --test e2e -- pgwire_singleton (no psql on host)"
-fi
-
-# 55.E — convergence parity: every protocol's race left exactly one row.
-for t in ig_race_cli ig_race_sql ig_race_typed; do
-  $DDB query "SELECT COUNT(*) FROM $t" | grep -q "^1$" \
-    || fail "55.E: $t did not converge on exactly one row"
-done
-# ig_race_pg exists only when the PgWire race ran (psql present) — see PG_RAN.
-if [ "$PG_RAN" -eq 1 ]; then
-  $DDB query "SELECT COUNT(*) FROM ig_race_pg" | grep -q "^1$" \
-    || fail "55.E: ig_race_pg did not converge on exactly one row"
-fi
-pass "55.E: CLI, executeSql, createDoogat, and PgWire races each converged on exactly one row (A/B/C losers carry the structured SINGLETON violation; the cross-process PgWire loser carries a recognized SINGLETON-or-contention failure, never a raw UNIQUE leak)"
-
-# Cleanup
-$DDB query "DROP TABLE ig_race_cli CASCADE" | grep -q "dropped"
-$DDB query "DROP TABLE ig_race_sql CASCADE" | grep -q "dropped"
-$DDB query "DROP TABLE ig_race_typed CASCADE" | grep -q "dropped"
-if [ "$PG_RAN" -eq 1 ]; then
-  $DDB query "DROP TABLE ig_race_pg CASCADE" | grep -q "dropped"
-fi
-rm -f "$RACE_CLI_1" "$RACE_CLI_2" "$RACE_SQL_1" "$RACE_SQL_2" \
-       "$RACE_TYPED_1" "$RACE_TYPED_2" "$RACE_PG_CLI" "$RACE_PG_SQL"
-
-# 56. REST warnings envelope (PRD 00147 doubt-review follow-up). Pins the
-# AppOutput.warnings surface that ddb-server/src/rest.rs:create_doogat exposes:
-# the response body always carries a `warnings` array (empty when none) and a
-# template-rendered title fires a TITLE_FROM_TEMPLATE entry. Unit tests cover
-# the JSON shape directly; this scenario exercises the live REST endpoint so
-# AGENTS.md's per-PRD integration-deliverable requirement for server-endpoint
-# behavior changes is satisfied.
-$DDB query "CREATE TABLE ig_warn_demo (note TEXT)" | grep -q "table ig_warn_demo created"
-$DDB query "ALTER TABLE ig_warn_demo SET TITLE TEMPLATE 'auto-warn'" | grep -q "title template"
-
-# 56.A — caller-supplied title yields warnings: [] (still present, never skipped).
-IG_WARN_TITLED_BODY="$TMPDIR/ig-warn-titled.json"
-IG_WARN_TITLED_CODE=$(curl -sS -o "$IG_WARN_TITLED_BODY" -w "%{http_code}" "$REST_URL/doogats" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -d '{"title":"explicit","type":"ig_warn_demo"}')
-[ "$IG_WARN_TITLED_CODE" = "201" ]
-jq -e '.warnings == []' "$IG_WARN_TITLED_BODY" >/dev/null
-pass "56.A: REST POST /doogats with title returns 201 + warnings: []"
-
-# 56.B — omitted title with a title_template typedef yields a TITLE_FROM_TEMPLATE
-# warning entry carrying code + message.
-IG_WARN_AUTO_BODY="$TMPDIR/ig-warn-auto.json"
-IG_WARN_AUTO_CODE=$(curl -sS -o "$IG_WARN_AUTO_BODY" -w "%{http_code}" "$REST_URL/doogats" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -d '{"type":"ig_warn_demo"}')
-[ "$IG_WARN_AUTO_CODE" = "201" ]
-jq -e '.warnings | length == 1
-       and (.[0].code == "TITLE_FROM_TEMPLATE")
-       and (.[0].message | test("title_template"))' \
-  "$IG_WARN_AUTO_BODY" >/dev/null
-pass "56.B: REST POST /doogats with omitted title surfaces TITLE_FROM_TEMPLATE warning"
-
-# 57. GraphQL warnings envelope (PRD 00154). Pins the WarningExtension contract:
-# every GraphQL response carries `extensions.warnings` as an array; createDoogat
-# drains AppOutput.warnings into it so a template-rendered title surfaces a
-# TITLE_FROM_TEMPLATE entry. REST parity is asserted in section 56 above; this
-# scenario proves the same warnings reach GraphQL clients via the response
-# extensions envelope, not the data payload.
-
-# 57.A — caller-supplied title yields extensions.warnings: [] (always present).
-IG_GQL_WARN_TITLED=$(gql '{"query":"mutation { createDoogat(input: { title: \"gql-explicit\", type: \"ig_warn_demo\" }) { id title } }"}')
-assert_gql_ok "$IG_GQL_WARN_TITLED"
-printf '%s' "$IG_GQL_WARN_TITLED" | jq -e '.extensions.warnings == []' >/dev/null
-IG_GQL_WARN_TITLED_ID=$(printf '%s' "$IG_GQL_WARN_TITLED" | jq -r '.data.createDoogat.id')
-pass "57.A: GraphQL createDoogat with title returns extensions.warnings: []"
-
-# 57.B — omitted title with a title_template typedef fires TITLE_FROM_TEMPLATE
-# under extensions.warnings (NOT under data).
-IG_GQL_WARN_AUTO=$(gql '{"query":"mutation { createDoogat(input: { type: \"ig_warn_demo\" }) { id title } }"}')
-assert_gql_ok "$IG_GQL_WARN_AUTO"
-printf '%s' "$IG_GQL_WARN_AUTO" | jq -e '.extensions.warnings | length == 1
-       and (.[0].code == "TITLE_FROM_TEMPLATE")
-       and (.[0].message | test("title_template"))' >/dev/null
-IG_GQL_WARN_AUTO_ID=$(printf '%s' "$IG_GQL_WARN_AUTO" | jq -r '.data.createDoogat.id')
-pass "57.B: GraphQL createDoogat with omitted title surfaces TITLE_FROM_TEMPLATE warning in extensions"
-
-# Cleanup
-IG_WARN_TITLED_ID=$(jq -r '.data.id' "$IG_WARN_TITLED_BODY")
-IG_WARN_AUTO_ID=$(jq -r '.data.id' "$IG_WARN_AUTO_BODY")
-curl -sf "$REST_URL/doogats/$IG_WARN_TITLED_ID" -H "Authorization: Bearer $TOKEN" -X DELETE >/dev/null
-curl -sf "$REST_URL/doogats/$IG_WARN_AUTO_ID" -H "Authorization: Bearer $TOKEN" -X DELETE >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$IG_GQL_WARN_TITLED_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$IG_GQL_WARN_AUTO_ID\\\") }\"}" >/dev/null
-$DDB query "DROP TABLE ig_warn_demo CASCADE" | grep -q "dropped"
-rm -f "$IG_WARN_TITLED_BODY" "$IG_WARN_AUTO_BODY"
-
-# 58. Update warning/error shape (PRD 00149). The update workflow now routes
-# through DoogatService::update -> AppOutput on GraphQL, CLI, and REST, mirroring
-# the create slice. This pins two app-semantic contracts on the migrated update
-# slice: (a) the warnings channel is wired end-to-end and the array is always
-# present (empty today, since update emits no warnings), and (b) a not-found
-# update surfaces the structured NOT_FOUND app-error code, not an untyped
-# string. Parallels the create-side §56 (REST) / §57 (GraphQL) envelopes.
-# Typedef registered via the GraphQL DDL path (ddl waits for the in-process

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


