
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.ps1, original lines 2457-3095, segment 6/8. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.ps1:2449: DONE (pre-existing, no port needed); targets=; fixture/scaffolding
tests/integration.ps1:2460: DONE; targets=integration_warnings_update::integration_56_a_rest_create_titled_warnings_empty
tests/integration.ps1:2469: DONE; targets=integration_warnings_update::integration_56_b_rest_create_omitted_title_title_from_template_warning
tests/integration.ps1:2485: DONE (pre-existing, no port needed); targets=; fixture/scaffolding
tests/integration.ps1:2491: DONE; targets=integration_warnings_update::integration_57_a_graphql_create_titled_extensions_warnings_empty
tests/integration.ps1:2503: DONE; targets=integration_warnings_update::integration_57_b_graphql_create_omitted_title_title_from_template_warning
tests/integration.ps1:2526: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2606']
tests/integration.ps1:2534: DONE; targets=integration_warnings_update::integration_58_a_graphql_update_warnings_empty
tests/integration.ps1:2549: DONE; targets=integration_warnings_update::integration_58_b_graphql_update_missing_id_not_found
tests/integration.ps1:2558: DONE; targets=integration_warnings_update::integration_58_c_rest_update_warnings_empty
tests/integration.ps1:2570: DONE; targets=integration_warnings_update::integration_58_d_rest_update_missing_id_not_found
tests/integration.ps1:2578: DONE (pre-existing, no port needed); targets=; fixture/scaffolding
tests/integration.ps1:2584: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2667']
tests/integration.ps1:2592: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2680']
tests/integration.ps1:2606: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2698']
tests/integration.ps1:2649: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2739']
tests/integration.ps1:2660: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2750']
tests/integration.ps1:2671: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2761']
tests/integration.ps1:2683: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2772']
tests/integration.ps1:2689: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2778']
tests/integration.ps1:2700: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2789']
tests/integration.ps1:2713: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2800']
tests/integration.ps1:2732: DONE (pre-existing, no port needed); targets=; fixture/scaffolding
tests/integration.ps1:2741: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2826']
tests/integration.ps1:2767: DONE; targets=integration_write_lock_races::integration_61_b_concurrent_cli_and_graphql_write_lock
tests/integration.ps1:2809: DONE; targets=integration_sync::integration_21_clone_reindex_reads_pushed_note
tests/integration.ps1:2823: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2900']
tests/integration.ps1:2842: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2918']
tests/integration.ps1:2861: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2937']
tests/integration.ps1:2880: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2956']
tests/integration.ps1:2900: DONE; targets=integration_crdt_conflicts::integration_26_reference_section_conflict
tests/integration.ps1:2926: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3002']
tests/integration.ps1:2953: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3028']
tests/integration.ps1:2983: DONE; targets=integration_crdt_conflicts::integration_27c_three_way_conflicted_merge
tests/integration.ps1:3026: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3097']
tests/integration.ps1:3081: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3155']

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.ps1 b/tests/integration.ps1
deleted file mode 100644
index 2f21127..0000000
--- a/tests/integration.ps1
+++ /dev/null
@@ -2457,639 +0,0 @@
-$warnAlter = ddb query "ALTER TABLE ig_warn_demo SET TITLE TEMPLATE 'auto-warn'"
-if ($warnAlter -notmatch "title template") { throw "56: ig_warn_demo alter failed: $warnAlter" }
-
-# 56.A - caller-supplied title yields warnings: [] (still present, never skipped).
-$warnTitledResp = rest "/doogats" "POST" '{"title":"explicit","type":"ig_warn_demo"}'
-if ($warnTitledResp.StatusCode -ne 201) { throw "56.A: expected 201, got $($warnTitledResp.StatusCode)" }
-$warnTitledObj = (content $warnTitledResp) | ConvertFrom-Json
-if ($warnTitledObj.warnings.Count -ne 0) {
-    throw "56.A: expected warnings: [], got: $($warnTitledObj.warnings | ConvertTo-Json -Compress)"
-}
-pass "56.A: REST POST /doogats with title returns 201 + warnings: []"
-
-# 56.B - omitted title with a title_template typedef yields a TITLE_FROM_TEMPLATE
-# warning entry carrying code + message.
-$warnAutoResp = rest "/doogats" "POST" '{"type":"ig_warn_demo"}'
-if ($warnAutoResp.StatusCode -ne 201) { throw "56.B: expected 201, got $($warnAutoResp.StatusCode)" }
-$warnAutoObj = (content $warnAutoResp) | ConvertFrom-Json
-if ($warnAutoObj.warnings.Count -ne 1) {
-    throw "56.B: expected one warning, got: $($warnAutoObj.warnings | ConvertTo-Json -Compress)"
-}
-if ($warnAutoObj.warnings[0].code -ne "TITLE_FROM_TEMPLATE") {
-    throw "56.B: expected code TITLE_FROM_TEMPLATE, got: $($warnAutoObj.warnings[0].code)"
-}
-if ($warnAutoObj.warnings[0].message -notmatch "title_template") {
-    throw "56.B: expected message to mention 'title_template', got: $($warnAutoObj.warnings[0].message)"
-}
-pass "56.B: REST POST /doogats with omitted title surfaces TITLE_FROM_TEMPLATE warning"
-
-# 57. GraphQL warnings envelope (PRD 00154). Pins the WarningExtension contract:
-# every GraphQL response carries `extensions.warnings` as an array; createDoogat
-# drains AppOutput.warnings into it so a template-rendered title surfaces a
-# TITLE_FROM_TEMPLATE entry. Mirrors the bash scenario added at the same time
-# so cross-platform CI exercises the same contract.
-
-# 57.A - caller-supplied title yields extensions.warnings: [] (always present).
-$gqlWarnTitled = gql '{"query":"mutation { createDoogat(input: { title: \"gql-explicit\", type: \"ig_warn_demo\" }) { id title } }"}'
-assertGqlOk $gqlWarnTitled "57.A GraphQL createDoogat with title"
-$gqlWarnTitledObj = $gqlWarnTitled | ConvertFrom-Json
-if ($null -eq $gqlWarnTitledObj.extensions -or $null -eq $gqlWarnTitledObj.extensions.warnings) {
-    throw "57.A: response missing extensions.warnings: $gqlWarnTitled"
-}
-if ($gqlWarnTitledObj.extensions.warnings.Count -ne 0) {
-    throw "57.A: expected extensions.warnings: [], got: $($gqlWarnTitledObj.extensions.warnings | ConvertTo-Json -Compress)"
-}
-pass "57.A: GraphQL createDoogat with title returns extensions.warnings: []"
-
-# 57.B - omitted title with a title_template typedef fires TITLE_FROM_TEMPLATE
-# under extensions.warnings (NOT under data).
-$gqlWarnAuto = gql '{"query":"mutation { createDoogat(input: { type: \"ig_warn_demo\" }) { id title } }"}'
-assertGqlOk $gqlWarnAuto "57.B GraphQL createDoogat with omitted title"
-$gqlWarnAutoObj = $gqlWarnAuto | ConvertFrom-Json
-if ($gqlWarnAutoObj.extensions.warnings.Count -ne 1) {
-    throw "57.B: expected one warning, got: $($gqlWarnAutoObj.extensions.warnings | ConvertTo-Json -Compress)"
-}
-if ($gqlWarnAutoObj.extensions.warnings[0].code -ne "TITLE_FROM_TEMPLATE") {
-    throw "57.B: expected code TITLE_FROM_TEMPLATE, got: $($gqlWarnAutoObj.extensions.warnings[0].code)"
-}
-if ($gqlWarnAutoObj.extensions.warnings[0].message -notmatch "title_template") {
-    throw "57.B: expected message to mention 'title_template', got: $($gqlWarnAutoObj.extensions.warnings[0].message)"
-}
-pass "57.B: GraphQL createDoogat with omitted title surfaces TITLE_FROM_TEMPLATE warning in extensions"
-
-# Cleanup
-rest "/doogats/$($warnTitledObj.data.id)" "DELETE" | Out-Null
-rest "/doogats/$($warnAutoObj.data.id)" "DELETE" | Out-Null
-gql "{`"query`":`"mutation { deleteDoogat(id: \`"$($gqlWarnTitledObj.data.createDoogat.id)\`") }`"}" | Out-Null
-gql "{`"query`":`"mutation { deleteDoogat(id: \`"$($gqlWarnAutoObj.data.createDoogat.id)\`") }`"}" | Out-Null
-ddb query "DROP TABLE ig_warn_demo CASCADE" | Out-Null
-
-# 58. Update warning/error shape (PRD 00149). Mirrors the bash §58 scenario so
-# cross-platform CI exercises the same contract: the migrated update slice
-# routes through DoogatService::update -> AppOutput on GraphQL/CLI/REST, the
-# warnings channel is always present (empty today), and a not-found update
-# surfaces the structured NOT_FOUND app-error code. Typedef registered via the
-# GraphQL DDL path (ddl waits for the in-process schema reload).
-ddl 'mutation { executeSql(sql: "CREATE TABLE ig_upd_demo (note TEXT)") { message } }'
-
-# 58.A - GraphQL updateDoogat carries extensions.warnings: [] and applies the change.
-$updCreate = gql '{"query":"mutation { createDoogat(input: { title: \"upd-orig\", type: \"ig_upd_demo\" }) { id } }"}'
-assertGqlOk $updCreate "58.A create"
-$updId = ($updCreate | ConvertFrom-Json).data.createDoogat.id
-$updGql = gql "{`"query`":`"mutation { updateDoogat(input: { id: \`"$updId\`", title: \`"upd-changed\`" }) { id title } }`"}"
-assertGqlOk $updGql "58.A update"
-$updGqlObj = $updGql | ConvertFrom-Json
-if ($updGqlObj.extensions.warnings.Count -ne 0) {
-    throw "58.A: expected extensions.warnings: [], got: $($updGqlObj.extensions.warnings | ConvertTo-Json -Compress)"
-}
-if ($updGqlObj.data.updateDoogat.title -ne "upd-changed") {
-    throw "58.A: expected title upd-changed, got: $($updGqlObj.data.updateDoogat.title)"
-}
-pass "58.A: GraphQL updateDoogat returns extensions.warnings: [] and applies the change"
-
-# 58.B - GraphQL updateDoogat on a missing id surfaces extensions.code = NOT_FOUND.
-$updMiss = gql '{"query":"mutation { updateDoogat(input: { id: \"99990101000000\", title: \"nope\" }) { id } }"}'
-assertGqlErrors $updMiss "58.B updateDoogat missing id"
-$updMissObj = $updMiss | ConvertFrom-Json
-if ($updMissObj.errors[0].extensions.code -ne "NOT_FOUND") {
-    throw "58.B: expected NOT_FOUND, got: $($updMissObj.errors[0].extensions.code)"
-}
-pass "58.B: GraphQL updateDoogat on missing id carries extensions.code = NOT_FOUND"
-
-# 58.C - REST PUT /doogats/{id} update response carries warnings: [] and applies the change.
-$updRest = rest "/doogats/$updId" "PUT" '{"title":"upd-rest"}'
-if ($updRest.StatusCode -ne 200) { throw "58.C: expected 200, got $($updRest.StatusCode)" }
-$updRestObj = (content $updRest) | ConvertFrom-Json
-if ($updRestObj.warnings.Count -ne 0) {
-    throw "58.C: expected warnings: [], got: $($updRestObj.warnings | ConvertTo-Json -Compress)"
-}
-if ($updRestObj.data.title -ne "upd-rest") {
-    throw "58.C: expected title upd-rest, got: $($updRestObj.data.title)"
-}
-pass "58.C: REST PUT /doogats update response carries warnings: [] and applies the change"
-
-# 58.D - REST PUT on a missing id surfaces the structured NOT_FOUND envelope (404).
-$updMissRest = Invoke-WebRequest -Uri "$REST_URL/doogats/99990101000000" -Method PUT -ContentType "application/json" `
-    -Headers @{ Authorization = "Bearer $TOKEN" } -Body '{"title":"nope"}' -SkipHttpErrorCheck
-if ([int]$updMissRest.StatusCode -ne 404) { throw "58.D: expected 404, got $($updMissRest.StatusCode)" }
-$updMissRestObj = (content $updMissRest) | ConvertFrom-Json
-if ($updMissRestObj.error -ne "NOT_FOUND") { throw "58.D: expected NOT_FOUND, got: $($updMissRestObj.error)" }
-pass "58.D: REST PUT /doogats on missing id returns 404 + NOT_FOUND envelope"
-
-# 59. REST typed create via the `fields` body member (PRD 00149). Mirrors the
-# bash §59 scenario: task 6 added CreateBody.fields, so REST typed create is now
-# expressible. Pins that typed columns are populated and that a malformed fields
-# payload is rejected with the structured VALIDATION_ERROR (400).
-ddl 'mutation { executeSql(sql: "CREATE TABLE ig_rest_typed (slug VARCHAR(64))") { message } }'
-
-# 59.A - POST /doogats with type + fields populates the typed column (read back via CLI).
-$rtResp = rest "/doogats" "POST" '{"title":"typed-rest","type":"ig_rest_typed","fields":"{\"slug\":\"hello-rest\"}"}'
-if ($rtResp.StatusCode -ne 201) { throw "59.A: expected 201, got $($rtResp.StatusCode)" }
-$rtId = ((content $rtResp) | ConvertFrom-Json).data.id
-$rtSel = ddb query "SELECT slug FROM ig_rest_typed WHERE id = '$rtId'"
-if ($rtSel -notmatch "hello-rest") { throw "59.A: expected slug hello-rest, got: $rtSel" }
-pass "59.A: REST POST /doogats with fields populates the typed column"
-
-# 59.B - malformed fields JSON is rejected with 400 + VALIDATION_ERROR.
-$rtBadResp = Invoke-WebRequest -Uri "$REST_URL/doogats" -Method POST -ContentType "application/json" `
-    -Headers @{ Authorization = "Bearer $TOKEN" } -Body '{"title":"typed-bad","type":"ig_rest_typed","fields":"{not valid json"}' -SkipHttpErrorCheck
-if ([int]$rtBadResp.StatusCode -ne 400) { throw "59.B: expected 400, got $($rtBadResp.StatusCode)" }
-$rtBadObj = (content $rtBadResp) | ConvertFrom-Json
-if ($rtBadObj.error -ne "VALIDATION_ERROR") { throw "59.B: expected VALIDATION_ERROR, got: $($rtBadObj.error)" }
-pass "59.B: REST POST /doogats with malformed fields returns 400 + VALIDATION_ERROR"
-
-# Cleanup §58/§59
-rest "/doogats/$updId" "DELETE" | Out-Null
-rest "/doogats/$rtId" "DELETE" | Out-Null
-ddb query "DROP TABLE ig_upd_demo CASCADE" | Out-Null
-ddb query "DROP TABLE ig_rest_typed CASCADE" | Out-Null
-
-# 60. Typed where-filter completeness (PRD 00159)
-# Tests negation/null ops, forward relation sub-filters, reverse membership,
-# and totalCount correlation with pagination.
-
-# --- Fixture ---
-$gqlVer = gqlq '{ schemaVersion }'
-$ver = if ($gqlVer -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-
-gqlq 'mutation { executeSql(sql: "CREATE TABLE relcat (title TEXT, slug TEXT)") { message } }' | Out-Null
-waitSchemaReload $ver
-$gqlVer = gqlq '{ schemaVersion }'
-$ver = if ($gqlVer -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation { executeSql(sql: "CREATE TABLE rellink (url TEXT, category TEXT REFERENCES relcat)") { message } }' | Out-Null
-waitSchemaReload $ver
-
-# Seed relcat rows (capture ids)
-$r1 = gqlq 'mutation { executeSql(sql: "INSERT INTO relcat (title, slug) VALUES (''Rust'', ''rust'')") { message } }'
-$CAT_RUST_ID = extractId $r1
-if (-not $CAT_RUST_ID) { throw "60: failed to seed relcat Rust" }
-
-$r2 = gqlq 'mutation { executeSql(sql: "INSERT INTO relcat (title, slug) VALUES (''Python'', ''py'')") { message } }'
-$CAT_PY_ID = extractId $r2
-if (-not $CAT_PY_ID) { throw "60: failed to seed relcat Python" }
-
-$r3 = gqlq 'mutation { executeSql(sql: "INSERT INTO relcat (title, slug) VALUES (''Empty'', ''empty'')") { message } }'
-$CAT_EMPTY_ID = extractId $r3
-if (-not $CAT_EMPTY_ID) { throw "60: failed to seed relcat Empty" }
-
-# Seed rellink rows
-$rl1 = gqlq "mutation { executeSql(sql: `"INSERT INTO rellink (url, category) VALUES ('https://rust.example', '$CAT_RUST_ID')`") { message } }"
-$LINK1_ID = extractId $rl1
-if (-not $LINK1_ID) { throw "60: failed to seed rellink 1" }
-
-$rl2 = gqlq "mutation { executeSql(sql: `"INSERT INTO rellink (url, category) VALUES ('https://py.example', '$CAT_PY_ID')`") { message } }"
-$LINK2_ID = extractId $rl2
-if (-not $LINK2_ID) { throw "60: failed to seed rellink 2" }
-
-$rl3 = gqlq 'mutation { executeSql(sql: "INSERT INTO rellink (title) VALUES (''orphan-link'')") { message } }'
-$LINK3_ID = extractId $rl3
-if (-not $LINK3_ID) { throw "60: failed to seed rellink 3" }
-
-Start-Sleep -Seconds 1
-
-# 60.A — Negation: notIn / nin
-$rl = gqlq "{ rellinks(where: { id: { notIn: [`"$LINK1_ID`"] } }) { totalCount } }"
-$rlCnt = ($rl | ConvertFrom-Json).data.rellinks.totalCount
-if ($rlCnt -ne 2) { throw "60.A notIn: expected 2, got $rlCnt" }
-pass "serve: rellinks where id notIn returns 2"
-
-$rl = gqlq "{ rellinks(where: { id: { nin: [`"$LINK1_ID`"] } }) { totalCount } }"
-$rlCnt = ($rl | ConvertFrom-Json).data.rellinks.totalCount
-if ($rlCnt -ne 2) { throw "60.A nin: expected 2, got $rlCnt" }
-pass "serve: rellinks where id nin (alias) returns 2"
-
-# 60.B — Null operators
-$rl = gqlq '{ rellinks(where: { url: { isNull: true } }) { totalCount } }'
-$rlCnt = ($rl | ConvertFrom-Json).data.rellinks.totalCount
-if ($rlCnt -ne 1) { throw "60.B isNull true: expected 1, got $rlCnt" }
-pass "serve: rellinks where url isNull true returns 1"
-
-$rl = gqlq '{ rellinks(where: { url: { isNull: false } }) { totalCount } }'
-$rlCnt = ($rl | ConvertFrom-Json).data.rellinks.totalCount
-if ($rlCnt -ne 2) { throw "60.B isNull false: expected 2, got $rlCnt" }
-pass "serve: rellinks where url isNull false returns 2"
-
-# 60.C — Forward relation sub-filter (inlined target columns)
-$rl = gqlq "{ rellinks(where: { category: { title: { eq: `"Rust`" } } }) { items { url } totalCount } }"
-$rlObj = $rl | ConvertFrom-Json
-if ($rlObj.data.rellinks.totalCount -ne 1) { throw "60.C title eq: expected 1, got $($rlObj.data.rellinks.totalCount)" }
-if ($rlObj.data.rellinks.items[0].url -ne 'https://rust.example') { throw "60.C title eq: url mismatch" }
-pass "serve: rellinks where category.title eq Rust returns 1"
-
-$rl = gqlq "{ rellinks(where: { category: { slug: { eq: `"py`" } } }) { totalCount } }"
-$rlCnt = ($rl | ConvertFrom-Json).data.rellinks.totalCount
-if ($rlCnt -ne 1) { throw "60.C slug eq: expected 1, got $rlCnt" }
-pass "serve: rellinks where category.slug eq py returns 1"
-
-# 60.D — Forward id-ops (back-compatible)
-$rl = gqlq "{ rellinks(where: { category: { eq: `"$CAT_RUST_ID`" } }) { totalCount } }"
-$rlCnt = ($rl | ConvertFrom-Json).data.rellinks.totalCount
-if ($rlCnt -ne 1) { throw "60.D category eq: expected 1, got $rlCnt" }
-pass "serve: rellinks where category eq returns 1"
-
-# 60.E — none / some
-$rl = gqlq '{ rellinks(where: { category: { none: {} } }) { totalCount } }'
-$rlCnt = ($rl | ConvertFrom-Json).data.rellinks.totalCount
-if ($rlCnt -ne 1) { throw "60.E none: expected 1, got $rlCnt" }
-pass "serve: rellinks where category none returns 1 (orphan)"
-
-$rl = gqlq '{ rellinks(where: { category: { some: {} } }) { totalCount } }'
-$rlCnt = ($rl | ConvertFrom-Json).data.rellinks.totalCount
-if ($rlCnt -ne 2) { throw "60.E some: expected 2, got $rlCnt" }
-pass "serve: rellinks where category some returns 2"
-
-# 60.F — Reverse membership
-$rc = gqlq "{ relcats(where: { rellinks: { some: { url: { contains: `"rust`" } } } }) { items { title } totalCount } }"
-$rcObj = $rc | ConvertFrom-Json
-if ($rcObj.data.relcats.totalCount -ne 1) { throw "60.F reverse some: expected 1, got $($rcObj.data.relcats.totalCount)" }
-if ($rcObj.data.relcats.items[0].title -ne 'Rust') { throw "60.F reverse some: title mismatch" }
-pass "serve: relcats where rellinks some url contains rust returns 1"
-
-$rc = gqlq '{ relcats(where: { rellinks: { none: {} } }) { items { title } totalCount } }'
-$rcObj = $rc | ConvertFrom-Json
-if ($rcObj.data.relcats.totalCount -ne 1) { throw "60.F reverse none: expected 1, got $($rcObj.data.relcats.totalCount)" }
-if ($rcObj.data.relcats.items[0].title -ne 'Empty') { throw "60.F reverse none: title mismatch" }
-pass "serve: relcats where rellinks none returns 1 (Empty category)"
-
-# 60.G — Relation filter + orderBy + pagination + totalCount correlation
-$rl = gqlq "{ rellinks(where: { category: { some: {} } }, orderBy: { id: ASC }, limit: 1, offset: 0) { items { url } totalCount } }"
-$rlObj = $rl | ConvertFrom-Json
-if ($rlObj.data.rellinks.items.Count -ne 1) { throw "60.G page0: expected 1 item" }
-if ($rlObj.data.rellinks.totalCount -ne 2) { throw "60.G page0 totalCount: expected 2, got $($rlObj.data.rellinks.totalCount)" }
-$rl0Url = $rlObj.data.rellinks.items[0].url
-
-$rl = gqlq "{ rellinks(where: { category: { some: {} } }, orderBy: { id: ASC }, limit: 1, offset: 1) { items { url } totalCount } }"
-$rlObj = $rl | ConvertFrom-Json
-if ($rlObj.data.rellinks.items.Count -ne 1) { throw "60.G page1: expected 1 item" }
-if ($rlObj.data.rellinks.totalCount -ne 2) { throw "60.G page1 totalCount: expected 2, got $($rlObj.data.rellinks.totalCount)" }
-$rl1Url = $rlObj.data.rellinks.items[0].url
-if ($rl0Url -eq $rl1Url) { throw "60.G pagination: dupes across pages" }
-pass "serve: rellinks pagination with relation filter (totalCount=2, no dupes)"
-
-# Cleanup
-gqlq 'mutation { executeSql(sql: "DROP TABLE rellink CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE relcat CASCADE") { message } }' | Out-Null
-
-# 61. Cross-process write lock: no lost commit under concurrent writers (PRD 00162).
-# The advisory lock on .git/ddb-write.lock serializes every git commit critical
-# section across processes, so concurrent writers can't drop each other's
-# commits via a stale-parent HEAD force-update. Both sub-scenarios target
-# DISTINCT doogat ids (so the still-open id-mint race, PRD 00164, can't confound
-# the result) and assert durability against HEAD with `git show`, not the work
-# tree — a lost commit leaves its file on disk but absent from HEAD.
-Set-Location $TMPDIR
-
-# 61.A - N concurrent CLI `ddb update` writers on distinct doogats must all land.
-$wlIds = @()
-for ($i = 1; $i -le 6; $i++) {
-    $wlIds += (ddb create --title "WL seed $i" --body "wl-original-$i")
-}
-$wlJobs = @()
-for ($i = 1; $i -le 6; $i++) {
-    $wlJobs += Start-Job -ScriptBlock {
-        param($ddb, $id, $body)
-        & $ddb update $id --body $body 2>&1 | Out-Null
-        @{ exit = $LASTEXITCODE }
-    } -ArgumentList $DDB, $wlIds[$i - 1], "wl-landed-$i"
-}
-$wlFail = 0
-foreach ($job in $wlJobs) {
-    $res = Receive-Job -Job $job -Wait
-    Remove-Job $job
-    if ([int]$res.exit -ne 0) { $wlFail++ }
-}
-if ($wlFail -ne 0) { throw "61.A: $wlFail concurrent CLI update(s) exited non-zero" }
-for ($i = 1; $i -le 6; $i++) {
-    $committed = & git show "HEAD:ddb/$($wlIds[$i - 1]).md" 2>&1 | Out-String
-    if ($committed -notmatch "wl-landed-$i") { throw "61.A: concurrent update $i is not durable in HEAD (lost commit)" }
-}
-pass "61.A: 6 concurrent CLI updates all landed in HEAD (no lost commit)"
-
-# 61.B - a `ddb serve` (GraphQL) write concurrent with a CLI write; both must land.
-# The PRD's headline deployment: a downstream app runs `ddb serve` while the
-# user runs the CLI against the same repo. Seed both rows via GraphQL so the
-# running server already indexes them, then race one GraphQL update (server
-# process) against one CLI update (separate process).
-$wlServeSeed = gqlq 'mutation { createDoogat(input: { title: "WL serve seed" }) { id } }'
-$wlGid = ([regex]::Match($wlServeSeed, '"id":"([^"]+)"')).Groups[1].Value
-$wlCliSeed = gqlq 'mutation { createDoogat(input: { title: "WL cli seed" }) { id } }'
-$wlCid = ([regex]::Match($wlCliSeed, '"id":"([^"]+)"')).Groups[1].Value
-if (-not $wlGid) { throw "61.B: GraphQL seed returned no id" }
-if (-not $wlCid) { throw "61.B: CLI seed returned no id" }
-$wlCliJob = Start-Job -ScriptBlock {
-    param($ddb, $id)
-    & $ddb update $id --body "wl-cli-landed" 2>&1 | Out-Null
-    @{ exit = $LASTEXITCODE }
-} -ArgumentList $DDB, $wlCid
-$wlServeUpd = gqlq "mutation { updateDoogat(input: { id: `"$wlGid`", title: `"wl-serve-landed`" }) { id } }"
-$wlCliRes = Receive-Job -Job $wlCliJob -Wait
-Remove-Job $wlCliJob
-if ([int]$wlCliRes.exit -ne 0) { throw "61.B: concurrent CLI write exited non-zero" }
-if ($wlServeUpd -notmatch '"id"') { throw "61.B: concurrent GraphQL write failed: $wlServeUpd" }
-$gCommitted = & git show "HEAD:ddb/$wlGid.md" 2>&1 | Out-String
-if ($gCommitted -notmatch "wl-serve-landed") { throw "61.B: serve write not durable in HEAD" }
-$cCommitted = & git show "HEAD:ddb/$wlCid.md" 2>&1 | Out-String
-if ($cCommitted -notmatch "wl-cli-landed") { throw "61.B: CLI write not durable in HEAD" }
-pass "61.B: concurrent ddb serve + CLI writes both landed in HEAD (cross-process lock)"
-
-Stop-Process -Id $serverProc.Id -Force -ErrorAction SilentlyContinue
-Start-Sleep -Milliseconds 500
-pass "serve: clean shutdown"
-
-Write-Host "=== sync conflict scenarios ==="
-
-# --- Two-node setup ---
-git init --bare $REMOTE_DIR 2>&1 | Out-Null
-
-# node1: init + push
-Push-Location $NODE1_DIR
-ddb init . | Out-Null
-git remote add origin $REMOTE_DIR
-ddb register-node "Laptop" | Out-Null
-
-# 21. fast-forward sync
-$SYNC_ID = ddb create --title "Shared note" --tags "shared" --body "Original body"
-git push -u origin master 2>&1 | Out-Null
-
-# clone to node2
-git clone $REMOTE_DIR $NODE2_DIR 2>&1 | Out-Null
-Push-Location $NODE2_DIR
-ddb reindex | Out-Null
-ddb register-node "Desktop" | Out-Null
-
-$output = ddb read $SYNC_ID
-if ($output -notmatch "Shared note") { throw "fast-forward failed" }
-pass "fast-forward sync"
-
-# 22. non-overlapping edits
-Pop-Location  # back to NODE1_DIR
-ddb update $SYNC_ID --title "Updated Title" --tags "shared,laptop"
-
-Push-Location $NODE2_DIR
-ddb update $SYNC_ID --body "Modified body"
-
-Pop-Location  # back to NODE1_DIR
-ddb sync origin master | Out-Null
-
-Push-Location $NODE2_DIR
-$output = ddb sync origin master
-if ($output -notmatch "conflicts resolved: 0") { throw "expected 0 conflicts" }
-
-$output = ddb read $SYNC_ID
-if ($output -notmatch "Updated Title") { throw "title not merged" }
-if ($output -notmatch "Modified body") { throw "body not merged" }
-pass "non-overlapping edits (clean merge)"
-
-# 23. frontmatter scalar conflict (title)
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-ddb update $SYNC_ID --title "Laptop Title"
-
-Push-Location $NODE2_DIR
-ddb update $SYNC_ID --title "Desktop Title"
-
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-
-Push-Location $NODE2_DIR
-$output = ddb sync origin master
-if ($output -notmatch "conflicts resolved: 1") { throw "expected 1 conflict" }
-
-$title = ((ddb read $SYNC_ID) -split "\r?\n") | Select-String "^title:"
-if ($title -notmatch "(Laptop Title|Desktop Title)") { throw "title not resolved" }
-pass "frontmatter scalar conflict (CRDT)"
-
-# 24. frontmatter list conflict (tags)
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-ddb update $SYNC_ID --tags "base,alpha"
-
-Push-Location $NODE2_DIR
-ddb update $SYNC_ID --tags "base,beta"
-
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-
-Push-Location $NODE2_DIR
-ddb sync origin master | Out-Null
-
-$output = ddb read $SYNC_ID
-if ($output -notmatch "alpha") { throw "alpha tag missing" }
-if ($output -notmatch "beta") { throw "beta tag missing" }
-pass "frontmatter list conflict (tag union)"
-
-# 25. body conflict
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-ddb update $SYNC_ID --body "Line one LAPTOP.`nLine two.`nLine three."
-
-Push-Location $NODE2_DIR
-ddb update $SYNC_ID --body "Line one.`nLine two DESKTOP.`nLine three."
-
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-
-Push-Location $NODE2_DIR
-$output = ddb sync origin master
-if ($output -notmatch "conflicts resolved: 1") { throw "expected 1 conflict" }
-
-$output = ddb read $SYNC_ID
-if ($output -notmatch "LAPTOP") { throw "LAPTOP missing" }
-if ($output -notmatch "DESKTOP") { throw "DESKTOP missing" }
-pass "body conflict (CRDT text merge)"
-
-# 26. reference section conflict
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-
-$DOOGAT_FILE = "ddb/${SYNC_ID}.md"
-
-$content = Get-Content $DOOGAT_FILE -Raw
-Set-Content $DOOGAT_FILE -Value "$content`n---`n- laptop note:: Added from laptop`n" -NoNewline
-git add $DOOGAT_FILE
-git commit -m "node1 add reference" 2>&1 | Out-Null
-git push origin master 2>&1 | Out-Null
-
-Push-Location $NODE2_DIR
-$content = Get-Content $DOOGAT_FILE -Raw
-Set-Content $DOOGAT_FILE -Value "$content`n---`n- desktop note:: Added from desktop`n" -NoNewline
-git add $DOOGAT_FILE
-git commit -m "node2 add reference" 2>&1 | Out-Null
-
-$output = ddb sync origin master
-if ($output -notmatch "conflicts resolved: 1") { throw "expected 1 conflict" }
-
-$output = ddb read $SYNC_ID
-if ($output -notmatch "laptop note") { throw "laptop note missing" }
-if ($output -notmatch "desktop note") { throw "desktop note missing" }
-pass "reference section conflict (CRDT union)"
-
-# 26b. deterministic CRDT convergence smoke — both nodes reach the SAME title after a real conflict resolution (independent-resolution determinism is unit-tested in crdt_determinism.rs) (PRD 00165)
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-ddb update $SYNC_ID --title "Converge Laptop"
-
-Push-Location $NODE2_DIR
-ddb update $SYNC_ID --title "Converge Desktop"
-
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-
-Push-Location $NODE2_DIR
-$RESOLVE_OUT = ddb sync origin master
-if (-not ($RESOLVE_OUT | Select-String '^sync:.*conflicts resolved: [1-9]')) { throw "expected a resolved conflict on NODE2's merge sync: $RESOLVE_OUT" }
-
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-
-$T1 = ddb read $SYNC_ID | Select-String "^title:" | Select-Object -First 1
-Push-Location $NODE2_DIR
-$T2 = ddb read $SYNC_ID | Select-String "^title:" | Select-Object -First 1
-if (-not $T1) { throw "title missing on node1" }
-if (-not $T2) { throw "title missing on node2" }
-if ($T1.ToString() -ne $T2.ToString()) { throw "titles differ: node1=$T1 node2=$T2" }
-if ($T1.ToString() -notmatch "(Converge Laptop|Converge Desktop)") { throw "unexpected title: $T1" }
-pass "deterministic CRDT convergence smoke (both nodes same title after real conflict resolution, PRD 00165)"
-
-# 27b. delete-vs-edit conflict
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-$DEL_ID = ddb create --title "To be deleted" --body "Original content"
-ddb sync origin master | Out-Null
-
-Push-Location $NODE2_DIR
-ddb sync origin master | Out-Null
-$output = ddb read $DEL_ID
-if ($output -notmatch "To be deleted") { throw "pre-delete read failed" }
-
-# node1 deletes, node2 edits
-Pop-Location  # NODE1_DIR
-ddb delete $DEL_ID
-
-Push-Location $NODE2_DIR
-ddb update $DEL_ID --body "Edited on desktop"
-
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-
-Push-Location $NODE2_DIR
-ddb sync origin master | Out-Null
-
-$output = ddb read $DEL_ID
-if ($output -notmatch "Edited on desktop") { throw "edit-wins failed" }
-$output = ddb status
-if ($output -notmatch "resurrected") { throw "resurrected missing" }
-pass "delete-vs-edit conflict (edit wins, resurrected)"
-
-# 27c. three-way conflicted merge preserves deletion + local edit (PRD 00200)
-$THREE_REMOTE = New-Item -ItemType Directory -Path "$env:TEMP\ddb-three-remote-$(Get-Random)" -Force
-git init --bare $THREE_REMOTE 2>&1 | Out-Null
-
-# Node "ours": init, add remote, register, create three doogats, push
-$THREE_OURS = New-Item -ItemType Directory -Path "$env:TEMP\ddb-three-ours-$(Get-Random)" -Force
-Push-Location $THREE_OURS
-ddb init . | Out-Null
-git remote add origin $THREE_REMOTE
-ddb register-node "Ours" | Out-Null
-$THREE_A = ddb create --title "Conflict doogat" --body "base A"
-$THREE_X = ddb create --title "Doomed doogat" --body "base X"
-$THREE_Y = ddb create --title "Survivor doogat" --body "base Y"
-git push -u origin master 2>&1 | Out-Null
-
-# Node "theirs": clone, register, edit A + delete X, sync (pushes theirs)
-$THREE_THEIRS = New-Item -ItemType Directory -Path "$env:TEMP\ddb-three-theirs-$(Get-Random)" -Force
-git clone $THREE_REMOTE $THREE_THEIRS 2>&1 | Out-Null
-Push-Location $THREE_THEIRS
-ddb reindex | Out-Null
-ddb register-node "Theirs" | Out-Null
-ddb update $THREE_A --title "Theirs A" | Out-Null
-ddb delete $THREE_X | Out-Null
-ddb sync origin master | Out-Null
-
-# Back on "ours": collide on A, non-conflicting edit on Y, then sync (conflicted merge)
-Pop-Location  # back to THREE_OURS
-ddb update $THREE_A --title "Ours A" | Out-Null
-ddb update $THREE_Y --body "ours Y edit" | Out-Null
-$SYNC_OUT = ddb sync origin master
-
-# Assertions
-if ($SYNC_OUT -notmatch "conflicts resolved: 1") { throw "conflict count wrong" }
-if (Test-Path "ddb/$THREE_X.md") { throw "deletion resurrected (W2)" }
-$output = ddb read $THREE_Y
-if ($output -notmatch "ours Y edit") { throw "local edit lost (W1)" }
-$output = ddb read $THREE_A
-if ($output -notmatch "Theirs A|Ours A") { throw "CRDT resolution missing" }
-Pop-Location  # back to NODE2_DIR
-pass "three-way conflicted merge preserves deletion + local edit (PRD 00200)"
-
-Write-Host "=== id collision detection ==="
-
-# 27a. add-add collision: both doogats survive
-$COLL_REMOTE = New-Item -ItemType Directory -Path "$env:TEMP\ddb-coll-remote-$(Get-Random)" -Force
-git init --bare $COLL_REMOTE 2>&1 | Out-Null
-
-$COLL_A = New-Item -ItemType Directory -Path "$env:TEMP\ddb-coll-a-$(Get-Random)" -Force
-Push-Location $COLL_A
-ddb init . | Out-Null
-git remote add origin $COLL_REMOTE
-ddb register-node "CollA" | Out-Null
-git push -u origin master 2>&1 | Out-Null
-
-$COLL_B_PARENT = "$env:TEMP\ddb-coll-b-$(Get-Random)"
-git clone $COLL_REMOTE $COLL_B_PARENT 2>&1 | Out-Null
-Push-Location $COLL_B_PARENT
-ddb reindex | Out-Null
-ddb register-node "CollB" | Out-Null
-git push origin master 2>&1 | Out-Null
-
-# Sync A to pick up B's node
-Pop-Location  # back to COLL_A
-ddb sync origin master | Out-Null
-
-# Both create same-ID doogat independently
-$COLL_ID = "20260101120000"
-$collContent = "---`nid: $COLL_ID`ntitle: From A`ndate: 2026-01-01`n---`nBody A`n"
-New-Item -ItemType Directory -Path "ddb" -Force | Out-Null
-Set-Content -Path "ddb/$COLL_ID.md" -Value $collContent -NoNewline
-git add "ddb/$COLL_ID.md" 2>&1 | Out-Null
-git commit -m "A creates $COLL_ID" 2>&1 | Out-Null
-git push origin master 2>&1 | Out-Null
-
-Push-Location $COLL_B_PARENT
-$collContentB = "---`nid: $COLL_ID`ntitle: From B`ndate: 2026-01-01`n---`nBody B`n"
-New-Item -ItemType Directory -Path "ddb" -Force | Out-Null
-Set-Content -Path "ddb/$COLL_ID.md" -Value $collContentB -NoNewline
-git add "ddb/$COLL_ID.md" 2>&1 | Out-Null
-git commit -m "B creates $COLL_ID" 2>&1 | Out-Null
-
-# B syncs — collision detected and resolved (single commit, atomic)
-$collBHeadBefore = git rev-parse HEAD
-$collOut = ddb sync origin master
-if ($collOut -notmatch "collisions reassigned: 1") { throw "collision not detected: $collOut" }
-$collFiles = @(Get-ChildItem "ddb/*.md" | Where-Object { $_.Name -notmatch "^_" })
-if ($collFiles.Count -ne 2) { throw "expected 2 doogats after collision, got $($collFiles.Count)" }
-$collBHeadAfter = git rev-parse HEAD
-# sync() always appends one more single-parent "update sync state" commit
-# (finalize_sync -> update_sync_state) after resolution, so the resolution
-# itself landing atomically means exactly 2 new commits here, not 1 — the
-# two-parent winner+loser merge commit, then the trailing state commit.
-# --first-parent is required: a plain range also walks the merge's other
-# parent (the peer's fetched commits), which isn't part of this node's own chain.
-$collCommitCount = [int](git rev-list --first-parent --count "$collBHeadBefore..$collBHeadAfter")
-if ($collCommitCount -ne 2) { throw "expected 2 commits after collision sync, got $collCommitCount" }
-pass "add-add collision: both doogats survive"
-
-# 27a2. add-add collision: single commit + both nodes converge
-git push origin master 2>&1 | Out-Null
-Push-Location $COLL_A
-ddb sync origin master 2>&1 | Out-Null
-$collAFiles = @(Get-ChildItem "ddb/*.md" | Where-Object { $_.Name -notmatch "^_" } | Sort-Object Name | Select-Object -ExpandProperty Name)
-Pop-Location
-$collBFiles = @(Get-ChildItem "ddb/*.md" | Where-Object { $_.Name -notmatch "^_" } | Sort-Object Name | Select-Object -ExpandProperty Name)
-if (($collAFiles -join ",") -ne ($collBFiles -join ",")) { throw "nodes did not converge: A=[$($collAFiles -join ',')] B=[$($collBFiles -join ',')]" }
-pass "add-add collision: single commit + both nodes converge"
-Pop-Location  # leave COLL_B
-
-Pop-Location  # leave COLL_A
-
-Write-Host "=== bundle sync ==="
-

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


