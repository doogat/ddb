
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.sh, original lines 1130-1648, segment 3/7. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.sh:1067: DONE; targets=integration_rest_pgwire::integration_20_compact_custom_backup_path, integration_rest_pgwire::integration_20_maintenance_mutation, integration_rest_pgwire::integration_20_nosql_endpoints, integration_rest_pgwire::integration_20_pgwire_boolean_type, integration_rest_pgwire::integration_20_sql_engine_error_descriptive, pgwire::pgwire_auth_rejected, pgwire::pgwire_connect_auth_ok, pgwire::pgwire_pg_catalog_hides_internal_tables, pgwire::pgwire_select_with_columns, rest::rest_get_unknown_id_returns_404, serve::graphql_introspection_hides_internal_tables, server_mutations::compact_force_mutation, server_mutations::compact_mutation_returns_result, server_mutations::compact_no_backup_mutation, server_mutations::sync_mutation_no_remote_returns_error
tests/integration.sh:1179: DONE (pre-existing, no port needed); targets=subscriptions::ws_payload_auth_subscribe_receive
tests/integration.sh:1189: DONE (pre-existing, no port needed); targets=read_pool::concurrent_reads_during_write
tests/integration.sh:1199: DONE (REST-references half only; test passes); targets=integration_graphql_refs::integration_38b_rest_structured_references_object, relation_resolution::batch_plural_references_multiple_items
tests/integration.sh:1222: DONE (pre-existing, no port needed); targets=relation_resolution::null_reference_returns_null, relation_resolution::plural_reference_resolves_as_typed_object_list, relation_resolution::singular_reference_resolves_as_typed_object
tests/integration.sh:1248: DONE (pre-existing, no port needed); targets=reference_raw_id::plural_resolver_with_limit, reference_raw_id::plural_resolver_with_order_by, reference_raw_id::plural_resolver_with_order_by_and_limit, reference_raw_id::plural_resolver_with_order_by_desc, reference_raw_id::raw_id_coexists_with_object_resolver
tests/integration.sh:1283: DONE (pre-existing, no port needed); targets=relation_resolution::typed_connection_includes_tags
tests/integration.sh:1293: DONE (pre-existing, no port needed); targets=tag_entries::tag_entries_filter_by_doogat_id, tag_entries::tag_entries_filter_by_tag_contains, tag_entries::tag_entries_filter_by_tag_eq
tests/integration.sh:1316: DONE (pre-existing, no port needed); targets=serve::sql_columns_aliased, serve::sql_columns_star_select, serve::sql_default_format_returns_arrays
tests/integration.sh:1323: DONE (boolean-coercion half only; test passes); targets=integration_graphql_refs::integration_38c2_boolean_coercion, serve::execute_sql_format_objects, serve::sql_format_objects_returns_keyed_rows
tests/integration.sh:1347: DONE (test passes); targets=integration_graphql_refs::integration_38d_distinct_typed_query
tests/integration.sh:1360: DONE (test passes); targets=integration_graphql_refs::integration_38e_groupby_aggregate, serve::aggregate_query, serve::aggregate_with_filter
tests/integration.sh:1380: DONE (test passes); targets=integration_graphql_batch::integration_38f_execute_batch_multi_statement, serve::execute_batch_format_objects
tests/integration.sh:1407: DONE (pre-existing, no port needed); targets=server_mutations::batch_update_via_graphql
tests/integration.sh:1429: DONE (pre-existing, no port needed); targets=server_mutations::create_many_basic, server_mutations::create_many_empty
tests/integration.sh:1457: DONE (pre-existing, no port needed); targets=hyphenated_types::hyphenated_type_typed_query, typed_field_mutations::delete_doogat_cleans_materialized_row, typed_field_mutations::update_doogat_with_fields_updates_materialized_row, typed_field_mutations::update_doogat_with_unset_fields_removes_field
tests/integration.sh:1498: DONE (pre-existing, no port needed); targets=serve::filter_base_field_id_eq, serve::filter_base_field_id_nonexistent, serve::filter_base_field_title_contains, serve::filter_base_field_title_eq
tests/integration.sh:1529: DONE; targets=integration_orderby_base_fields::integration_42b_orderby_base_fields_deterministic_pagination
tests/integration.sh:1603: DONE; targets=date_default::insert_with_explicit_date_preserves_value, date_default::insert_without_date_derives_from_id, integration_sql_writes::integration_43_sql_insert_defaults_date_graphql
tests/integration.sh:1622: DONE; targets=integration_sql_writes::integration_43_d_sql_constraint_enforcement

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.sh b/tests/integration.sh
deleted file mode 100755
index 6942304..0000000
--- a/tests/integration.sh
+++ /dev/null
@@ -1130,519 +0,0 @@
-echo "$RESULT" | grep -qi "parse:"
-pass "serve: sql engine error is descriptive"
-
-# error sanitization — not-found returns descriptive message
-HTTP_CODE=$(curl -so /dev/null -w "%{http_code}" "$REST_URL/doogats/99990101000000" \
-  -H "Authorization: Bearer $TOKEN")
-[ "$HTTP_CODE" = "404" ]
-pass "serve: not-found returns 404"
-
-# GraphQL introspection hides internal tables
-INTRO=$(gql '{"query":"{ __schema { queryType { fields { name } } } }"}')
-! echo "$INTRO" | grep -q "_ddb_"
-pass "serve: introspection hides internal tables"
-
-# compact mutation
-RESULT=$(gql '{"query":"mutation { compact { filesRemoved crdtDocsCompacted gcSuccess crdtTempBytesBefore crdtTempBytesAfter crdtTempFilesBefore crdtTempFilesAfter repoBytesBefore repoBytesAfter backupPath } }"}')
-echo "$RESULT" | grep -q '"gcSuccess"'
-pass "serve: compact mutation"
-
-# compact(force: true)
-RESULT=$(gql '{"query":"mutation { compact(force: true) { filesRemoved crdtDocsCompacted gcSuccess crdtTempBytesBefore crdtTempBytesAfter repoBytesBefore repoBytesAfter backupPath } }"}')
-echo "$RESULT" | grep -q '"gcSuccess"'
-echo "$RESULT" | grep -q '"backupPath"'
-pass "serve: compact(force: true) mutation"
-
-# compact(noBackup: true)
-RESULT=$(gql '{"query":"mutation { compact(force: true, noBackup: true) { gcSuccess backupPath } }"}')
-echo "$RESULT" | grep -q '"gcSuccess"'
-echo "$RESULT" | grep -q '"backupPath":null'
-pass "serve: compact(noBackup: true) mutation"
-
-# compact(backupPath: custom)
-GQL_BACKUP="$TMPDIR/gql-backup.bundle.tar"
-RESULT=$(gql "{\"query\":\"mutation { compact(force: true, backupPath: \\\"$GQL_BACKUP\\\") { gcSuccess backupPath } }\"}")
-echo "$RESULT" | grep -q '"gcSuccess"'
-echo "$RESULT" | grep -q '"backupPath"'
-[ -f "$GQL_BACKUP" ]
-pass "serve: compact(backupPath) mutation"
-
-# maintenance mutation
-RESULT=$(gql '{"query":"mutation { maintenance { success durationMs fallbackUsed tasksRun } }"}')
-echo "$RESULT" | grep -q '"success"'
-pass "serve: maintenance mutation"
-
-# sync mutation — no remote configured for this repo, expect error not panic
-RESULT=$(gql '{"query":"mutation { sync { direction commitsTransferred conflictsResolved resurrected } }"}')
-echo "$RESULT" | grep -q '"errors"'
-pass "serve: sync mutation (no remote → error)"
-
-# 37. WebSocket payload auth (browser-style, no Authorization header)
-if command -v websocat >/dev/null 2>&1; then
-  REPLY=$(echo '{"type":"connection_init","payload":{"Authorization":"Bearer '"$TOKEN"'"}}' | \
-    websocat --protocol graphql-transport-ws -1 "ws://127.0.0.1:$SERVER_PORT/ws" 2>/dev/null || true)
-  echo "$REPLY" | grep -q "connection_ack"
-  pass "ws: payload auth (connection_init)"
-else
-  pass "ws: payload auth (skipped, no websocat — see e2e tests)"
-fi
-
-# 38. read-under-write: concurrent read + write
-WRITE_TMP="$TMPDIR/write_result.json"
-gql '{"query":"mutation { createDoogat(input: { title: \"ReadPoolWrite\" }) { id } }"}' > "$WRITE_TMP" &
-WRITE_PID=$!
-READ_RESULT=$(gql '{"query":"{ doogats { id title } }"}')
-echo "$READ_RESULT" | grep -q '"doogats"'
-wait "$WRITE_PID"
-grep -q '"id"' "$WRITE_TMP"
-pass "serve: read-under-write (concurrent read + write)"
-
-# 38b. multi-value references via GraphQL + REST
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation{executeSql(sql:\"CREATE TABLE mvcategory (name VARCHAR(100))\"){message}}"}'
-gql '{"query":"mutation{executeSql(sql:\"CREATE TABLE mvbookmark (mvcategory TEXT REFERENCES mvcategory)\"){message}}"}'
-wait_schema_reload "$VER"
-MV_CAT1=$(gql '{"query":"mutation{executeSql(sql:\"INSERT INTO mvcategory (name) VALUES (\\\"Science\\\")\"){message}}"}' | sed -n 's/.*"message":"\([0-9]*\)".*/\1/p')
-MV_CAT2=$(gql '{"query":"mutation{executeSql(sql:\"INSERT INTO mvcategory (name) VALUES (\\\"Math\\\")\"){message}}"}' | sed -n 's/.*"message":"\([0-9]*\)".*/\1/p')
-[ -n "$MV_CAT1" ] && [ -n "$MV_CAT2" ]
-MV_BM=$(gql "{\"query\":\"mutation{executeSql(sql:\\\"INSERT INTO mvbookmark (mvcategory) VALUES ('$MV_CAT1')\\\"){message}}\"}" | sed -n 's/.*"message":"\([0-9]*\)".*/\1/p')
-[ -n "$MV_BM" ]
-gql "{\"query\":\"mutation{executeSql(sql:\\\"INSERT INTO mvbookmark_mvcategory (mvbookmark_id, mvcategory_id) VALUES ('$MV_BM', '$MV_CAT2')\\\"){message}}\"}" >/dev/null
-# GraphQL typed query — pluralized list field returns both categories
-RESULT=$(gql '{"query":"{ mvbookmarks { items { id mvcategories { id } } } }"}')
-echo "$RESULT" | grep -q "$MV_CAT1"
-echo "$RESULT" | grep -q "$MV_CAT2"
-pass "serve: graphql multi-value ref list field"
-# REST — structured references object
-RESULT=$(rest "/doogats/$MV_BM")
-echo "$RESULT" | grep -q '"references"'
-echo "$RESULT" | grep -q '"mvcategory"'
-pass "serve: rest multi-value ref structured json"
-
-# 38b2. REFERENCES relation resolution
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE smokecat (label TEXT)\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE smokebm (url TEXT, smokecat TEXT REFERENCES smokecat)\") { message } }"}' >/dev/null
-wait_schema_reload "$VER"
-SCAT=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO smokecat (title, label) VALUES ('Tech', 'tech')\\\") { message } }\"}")
-SCAT_ID=$(echo "$SCAT" | sed -n 's/.*"message":"\([^"]*\)".*/\1/p')
-SBM=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO smokebm (title, url) VALUES ('Example', 'https://example.com')\\\") { message } }\"}")
-SBM_ID=$(echo "$SBM" | sed -n 's/.*"message":"\([^"]*\)".*/\1/p')
-gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO smokebm_smokecat (smokebm_id, smokecat_id) VALUES ('$SBM_ID', '$SCAT_ID')\\\") { message } }\"}" >/dev/null
-RESULT=$(gql '{"query":"{ smokebms { items { smokecat { id label } } } }"}')
-echo "$RESULT" | grep -q "\"label\":\"tech\""
-pass "serve: relation singular resolves object"
-RESULT=$(gql '{"query":"{ smokebms { items { smokecats { id label } } } }"}')
-echo "$RESULT" | grep -q "\"label\":\"tech\""
-pass "serve: relation plural resolves object list"
-sleep 1
-gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO smokebm (title, url) VALUES ('No Cat', 'https://nocat.com')\\\") { message } }\"}" >/dev/null
-RESULT=$(gql '{"query":"{ smokebms { items { id smokecat { id } smokecats { id } } } }"}')
-echo "$RESULT" | grep -q '"smokecat":null'
-echo "$RESULT" | grep -q '"smokecats":\[\]'
-pass "serve: relation null returns null and empty list"
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE smokebm CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE smokecat CASCADE\") { message } }"}' >/dev/null
-
-# 38b2b. raw ID scalar + orderBy/limit on plural references
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE rlcat (label TEXT)\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE rlbm (url TEXT, rlcat TEXT REFERENCES rlcat)\") { message } }"}' >/dev/null
-wait_schema_reload "$VER"
-RL_C1=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO rlcat (label) VALUES (\\\"cherry\\\")\") { message } }"}' | sed -n 's/.*"message":"\([^"]*\)".*/\1/p')
-RL_C2=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO rlcat (label) VALUES (\\\"apple\\\")\") { message } }"}' | sed -n 's/.*"message":"\([^"]*\)".*/\1/p')
-sleep 1
-RL_C3=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO rlcat (label) VALUES (\\\"banana\\\")\") { message } }"}' | sed -n 's/.*"message":"\([^"]*\)".*/\1/p')
-sleep 1
-RL_BM=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO rlbm (url) VALUES (\\\"https://example.com\\\")\") { message } }"}' | sed -n 's/.*"message":"\([^"]*\)".*/\1/p')
-for CID in "$RL_C1" "$RL_C2" "$RL_C3"; do
-  gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO rlbm_rlcat (rlbm_id, rlcat_id) VALUES ('$RL_BM', '$CID')\\\") { message } }\"}" >/dev/null
-done
-# raw ID scalar
-RESULT=$(gql '{"query":"{ rlbms { items { rlcat_id rlcat { id label } } } }"}')
-echo "$RESULT" | grep -q "\"rlcat_id\":\"$RL_C1\""
-echo "$RESULT" | grep -q "\"label\":\"cherry\""
-pass "serve: relation raw ID scalar coexists with object resolver"
-# orderBy ASC
-RESULT=$(gql '{"query":"{ rlbms { items { rlcats(orderBy: \"label\") { label } } } }"}')
-LABELS=$(echo "$RESULT" | sed -n 's/.*"rlcats":\[\(.*\)\].*/\1/p')
-echo "$LABELS" | grep -q '"apple".*"banana".*"cherry"'
-pass "serve: relation plural orderBy ASC"
-# orderBy DESC + limit
-RESULT=$(gql '{"query":"{ rlbms { items { rlcats(orderBy: \"label\", orderDir: \"DESC\", limit: 2) { label } } } }"}')
-LABELS=$(echo "$RESULT" | sed -n 's/.*"rlcats":\[\(.*\)\].*/\1/p')
-echo "$LABELS" | grep -q '"cherry".*"banana"'
-# make sure only 2 items (no "apple")
-echo "$LABELS" | grep -qv '"apple"'
-pass "serve: relation plural orderBy DESC + limit"
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE rlbm CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE rlcat CASCADE\") { message } }"}' >/dev/null
-
-# 38b3. typed connection includes tags
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE tagarticle (topic TEXT)\") { message } }"}' >/dev/null
-TA_ID=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO tagarticle (topic) VALUES (\\\"rust\\\")\") { message } }"}' | sed -n 's/.*"message":"\([^"]*\)".*/\1/p')
-gql "{\"query\":\"mutation { updateDoogat(input: { id: \\\"$TA_ID\\\", tags: [\\\"coding\\\", \\\"systems\\\"] }) { id } }\"}" >/dev/null
-RESULT=$(gql '{"query":"{ tagarticles { items { id tags topic } } }"}')
-echo "$RESULT" | grep -q '"coding"'
-echo "$RESULT" | grep -q '"systems"'
-pass "serve: typed connection includes tags"
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE tagarticle CASCADE\") { message } }"}' >/dev/null
-
-# 38b4. tagEntries query with filters
-TE1=$(gql '{"query":"mutation { createDoogat(input: { title: \"TagEntry A\", tags: [\"te-rust\", \"te-cli\"] }) { id } }"}' | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-sleep 1
-TE2=$(gql '{"query":"mutation { createDoogat(input: { title: \"TagEntry B\", tags: [\"te-rust\"] }) { id } }"}' | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-RESULT=$(gql "{\"query\":\"{ tagEntries(where: { doogatId: { eq: \\\"$TE1\\\" } }) { items { doogatId tag } totalCount } }\"}")
-echo "$RESULT" | grep -q '"totalCount":2'
-pass "serve: tagEntries filter by doogatId eq"
-
-RESULT=$(gql '{"query":"{ tagEntries(where: { tag: { eq: \"te-rust\" } }) { items { tag } totalCount } }"}')
-echo "$RESULT" | grep -q '"te-rust"'
-TECOUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$TECOUNT" -ge 2 ]
-pass "serve: tagEntries filter by tag eq"
-
-RESULT=$(gql '{"query":"{ tagEntries(where: { tag: { contains: \"te-\" } }) { totalCount } }"}')
-TECOUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$TECOUNT" -ge 3 ]
-pass "serve: tagEntries filter by tag contains"
-
-# cleanup
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$TE1\\\") { id } }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$TE2\\\") { id } }\"}" >/dev/null
-
-# 38c. sql-materialization (columns, boolean normalization, core fields)
-RESULT=$(gql '{"query":"{ sql(query: \"SELECT id, title FROM doogats\") { columns rows } }"}')
-echo "$RESULT" | grep -q '"columns"'
-echo "$RESULT" | grep -q '"id"'
-echo "$RESULT" | grep -q '"title"'
-pass "serve: sql columns in response"
-
-# 38c2. sql format:objects returns keyed rows
-RESULT=$(gql '{"query":"{ sql(query: \"SELECT id, title FROM doogats\", format: \"objects\") { columns rows } }"}')
-echo "$RESULT" | grep -qF '\"id\":'
-echo "$RESULT" | grep -qF '\"title\":'
-pass "serve: sql format objects returns keyed rows"
-
-ddl '{"query":"mutation{executeSql(sql:\"CREATE TABLE smokepin (pinned BOOLEAN)\"){message}}"}'
-SMOKEPIN_ID=$(gql "{\"query\":\"mutation{executeSql(sql:\\\"INSERT INTO smokepin (title, pinned) VALUES ('PinTest', true)\\\"){message}}\"}" | sed -n 's/.*"message":"\([0-9]*\)".*/\1/p')
-[ -n "$SMOKEPIN_ID" ]
-RESULT=$(gql "{\"query\":\"{ sql(query: \\\"SELECT pinned FROM smokepin WHERE pinned = 1\\\") { rows } }\"}")
-echo "$RESULT" | grep -q '\\"true\\"'
-pass "serve: boolean coerced to true/false"
-
-# Boolean false
-sleep 1
-gql "{\"query\":\"mutation{executeSql(sql:\\\"INSERT INTO smokepin (title, pinned) VALUES ('FalseTest', false)\\\"){message}}\"}" >/dev/null
-RESULT=$(gql "{\"query\":\"{ sql(query: \\\"SELECT pinned FROM smokepin WHERE pinned = 0\\\") { rows } }\"}")
-echo "$RESULT" | grep -q '\\"false\\"'
-pass "serve: boolean false coerced"
-
-RESULT=$(gql '{"query":"{ sql(query: \"SELECT title FROM smokepin\") { rows } }"}')
-echo "$RESULT" | grep -q 'PinTest'
-pass "serve: core fields in type table"
-
-# 38d. DISTINCT on typed connection queries
-# foo table already has one row with bar='val', baz=1. Add more.
-gql "{\"query\":\"mutation{executeSql(sql:\\\"INSERT INTO foo (title, bar, baz) VALUES ('dup1', 'val', 2)\\\"){message}}\"}" >/dev/null
-gql "{\"query\":\"mutation{executeSql(sql:\\\"INSERT INTO foo (title, bar, baz) VALUES ('uniq', 'other', 3)\\\"){message}}\"}" >/dev/null
-sleep 1
-RESULT=$(gql '{"query":"{ foos(distinct: \"bar\") { items { bar } totalCount } }"}')
-echo "$RESULT" | grep -q '"totalCount":2'
-pass "serve: distinct deduplicates and totalCount reflects unique count"
-
-RESULT=$(gql '{"query":"{ foos(distinct: \"bar\", where: { baz: { gte: 2 } }) { totalCount } }"}')
-echo "$RESULT" | grep -q '"totalCount":2'
-pass "serve: distinct with where filter"
-
-# 38e. GROUP BY on typed aggregate queries
-RESULT=$(gql '{"query":"{ foosAggregate(groupBy: \"bar\") { groups { key count } } }"}')
-echo "$RESULT" | grep -q '"key":"val"'
-echo "$RESULT" | grep -q '"key":"other"'
-pass "serve: groupBy returns per-group counts"
-
-RESULT=$(gql '{"query":"{ foosAggregate(groupBy: \"bar\") { groups { key count minBaz maxBaz } } }"}')
-echo "$RESULT" | grep -q '"minBaz"'
-echo "$RESULT" | grep -q '"maxBaz"'
-pass "serve: groupBy with numeric aggregates"
-
-RESULT=$(gql '{"query":"{ foosAggregate(groupBy: \"bar\", where: { baz: { gte: 2 } }) { groups { key count } } }"}')
-echo "$RESULT" | grep -q '"key"'
-pass "serve: groupBy with where filter"
-
-# Non-grouped still works
-RESULT=$(gql '{"query":"{ foosAggregate { count } }"}')
-echo "$RESULT" | grep -q '"count":3'
-pass "serve: aggregate without groupBy still works"
-
-# 38f. executeBatch mutation
-RESULT=$(gql '{"query":"mutation { executeBatch(statements: [\"INSERT INTO foo (title, bar, baz) VALUES ('"'"'batch1'"'"', '"'"'b1'"'"', 10)\", \"INSERT INTO foo (title, bar, baz) VALUES ('"'"'batch2'"'"', '"'"'b2'"'"', 20)\"]) { message affected } }"}')
-echo "$RESULT" | grep -qv '"errors"'
-pass "serve: executeBatch multiple INSERTs"
-
-# executeBatch with DDL triggers schema reload
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-RESULT=$(gql '{"query":"mutation { executeBatch(statements: [\"CREATE TABLE batchtest (col1 TEXT)\"]) { message } }"}')
-echo "$RESULT" | grep -q '"message"'
-wait_schema_reload "$VER"
-RESULT=$(gql '{"query":"{ batchtests { totalCount } }"}')
-echo "$RESULT" | grep -q '"totalCount":0'
-pass "serve: executeBatch DDL triggers schema reload"
-
-# executeBatch failure rolls back: second INSERT targets non-existent table, first should not persist
-PRE_COUNT=$(gql '{"query":"{ foosAggregate { count } }"}' | sed -n 's/.*"count":\([0-9]*\).*/\1/p')
-RESULT=$(gql '{"query":"mutation { executeBatch(statements: [\"INSERT INTO foo (title, bar, baz) VALUES ('"'"'rollback_test'"'"', '"'"'rb'"'"', 99)\", \"INSERT INTO no_such_table (title) VALUES ('"'"'bad'"'"')\"]) { message } }"}' || true)
-echo "$RESULT" | grep -q '"errors"'
-sleep 1
-POST_COUNT=$(gql '{"query":"{ foosAggregate { count } }"}' | sed -n 's/.*"count":\([0-9]*\).*/\1/p')
-[ "$PRE_COUNT" = "$POST_COUNT" ]
-pass "serve: executeBatch failure rolls back all statements"
-
-# cleanup
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE batchtest CASCADE\") { message } }"}' >/dev/null
-
-# 38g. batchUpdate mutation
-BU1=$(gql '{"query":"mutation { createDoogat(input: { title: \"BatchUp Alpha\" }) { id } }"}')
-BU1_ID=$(echo "$BU1" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-BU2=$(gql '{"query":"mutation { createDoogat(input: { title: \"BatchUp Beta\" }) { id } }"}')
-BU2_ID=$(echo "$BU2" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-BU3=$(gql '{"query":"mutation { createDoogat(input: { title: \"BatchUp Gamma\" }) { id } }"}')
-BU3_ID=$(echo "$BU3" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-
-RESULT=$(gql "{\"query\":\"mutation { batchUpdate(updates: [{id: \\\"$BU1_ID\\\", title: \\\"Updated Alpha\\\"}, {id: \\\"$BU2_ID\\\", title: \\\"Updated Beta\\\"}, {id: \\\"$BU3_ID\\\", title: \\\"Updated Gamma\\\"}]) { id title } }\"}")
-COUNT=$(echo "$RESULT" | jq '.data.batchUpdate | length')
-[ "$COUNT" = "3" ]
-pass "serve: batchUpdate returns 3 items"
-
-echo "$RESULT" | jq -e '.data.batchUpdate[] | select(.id == "'"$BU1_ID"'" and .title == "Updated Alpha")' >/dev/null
-echo "$RESULT" | jq -e '.data.batchUpdate[] | select(.id == "'"$BU2_ID"'" and .title == "Updated Beta")' >/dev/null
-echo "$RESULT" | jq -e '.data.batchUpdate[] | select(.id == "'"$BU3_ID"'" and .title == "Updated Gamma")' >/dev/null
-pass "serve: batchUpdate correct titles"
-
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$BU1_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$BU2_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$BU3_ID\\\") }\"}" >/dev/null
-
-# 38h. createMany mutation
-CM_RESULT=$(gql '{"query":"mutation { createMany(inputs: [{title: \"Bulk A\"}, {title: \"Bulk B\"}, {title: \"Bulk C\"}]) { id title } }"}')
-COUNT=$(echo "$CM_RESULT" | jq '.data.createMany | length')
-[ "$COUNT" = "3" ]
-echo "$CM_RESULT" | jq -e '.data.createMany[0].title == "Bulk A"' >/dev/null
-echo "$CM_RESULT" | jq -e '.data.createMany[1].title == "Bulk B"' >/dev/null
-echo "$CM_RESULT" | jq -e '.data.createMany[2].title == "Bulk C"' >/dev/null
-pass "serve: createMany returns 3 items in order"
-
-# verify persistence
-CM_ID0=$(echo "$CM_RESULT" | jq -r '.data.createMany[0].id')
-VERIFY=$(gql "{\"query\":\"{ doogat(id: \\\"$CM_ID0\\\") { title } }\"}")
-echo "$VERIFY" | jq -e '.data.doogat.title == "Bulk A"' >/dev/null
-pass "serve: createMany persists records"
-
-# createMany empty
-RESULT=$(gql '{"query":"mutation { createMany(inputs: []) { id } }"}')
-COUNT=$(echo "$RESULT" | jq '.data.createMany | length')
-[ "$COUNT" = "0" ]
-pass "serve: createMany empty input"
-
-# cleanup
-CM_ID1=$(echo "$CM_RESULT" | jq -r '.data.createMany[1].id')
-CM_ID2=$(echo "$CM_RESULT" | jq -r '.data.createMany[2].id')
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$CM_ID0\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$CM_ID1\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$CM_ID2\\\") }\"}" >/dev/null
-
-# 38i. typed field updates via GraphQL (updateDoogat fields/unsetFields, deleteDoogat cleanup)
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE tfubookmark (url VARCHAR(200))\") { message } }"}' | grep -q "table tfubookmark created"
-wait_schema_reload "$VER"
-TFU_ID=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO tfubookmark (title, url) VALUES (\\\"TFU Test\\\", \\\"https://old.com\\\")\") { message } }"}' | sed -n 's/.*"message":"\([^"]*\)".*/\1/p')
-echo "$TFU_ID" | grep -qE "^[0-9]{14}$"
-# Verify initial materialized row
-gql "{\"query\":\"mutation { executeSql(sql: \\\"SELECT url FROM tfubookmark WHERE id = '$TFU_ID'\\\", format: \\\"objects\\\") { rows } }\"}" | grep -q "https://old.com"
-# updateDoogat with fields to change url
-TFU_UPD=$(gql "{\"query\":\"mutation { updateDoogat(input: { id: \\\"$TFU_ID\\\", fields: \\\"{\\\\\\\"url\\\\\\\":\\\\\\\"https://updated.com\\\\\\\"}\\\" }) { id } }\"}")
-echo "$TFU_UPD" | grep -q "$TFU_ID"
-# Verify via SQL SELECT that materialized row has updated url
-gql "{\"query\":\"mutation { executeSql(sql: \\\"SELECT url FROM tfubookmark WHERE id = '$TFU_ID'\\\", format: \\\"objects\\\") { rows } }\"}" | grep -q "https://updated.com"
-pass "serve: typed field update via GraphQL updateDoogat"
-# updateDoogat with unsetFields to remove url
-TFU_UNSET=$(gql "{\"query\":\"mutation { updateDoogat(input: { id: \\\"$TFU_ID\\\", unsetFields: [\\\"url\\\"] }) { id } }\"}")
-echo "$TFU_UNSET" | grep -q "$TFU_ID"
-# Verify url is gone (NULL)
-TFU_AFTER=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"SELECT url FROM tfubookmark WHERE id = '$TFU_ID'\\\", format: \\\"objects\\\") { rows } }\"}")
-if echo "$TFU_AFTER" | grep -q "https://"; then
-  echo "FAIL: url should be unset after unsetFields" >&2; exit 1
-fi
-pass "serve: typed field unset via GraphQL updateDoogat"
-# Delete the doogat and verify materialized row is gone
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$TFU_ID\\\") }\"}" >/dev/null
-TFU_COUNT=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"SELECT COUNT(*) FROM tfubookmark WHERE id = '$TFU_ID'\\\") { rows } }\"}")
-echo "$TFU_COUNT" | grep -qF '[\"0\"]'
-pass "serve: deleteDoogat cleans materialized type table row"
-# Clean up typedef
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE tfubookmark CASCADE\") { message } }"}' >/dev/null
-
-# Hyphenated type names in GraphQL
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE \\\"test-widget\\\" (status TEXT, priority INTEGER)\") { message } }"}'
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO \\\"test-widget\\\" (status, priority) VALUES ('"'"'active'"'"', 1)\") { message } }"}' >/dev/null
-RESULT=$(gql '{"query":"{ testWidgets { items { id status priority } totalCount } }"}')
-echo "$RESULT" | jq -e '.data.testWidgets.totalCount == 1' >/dev/null
-echo "$RESULT" | jq -e '.data.testWidgets.items[0].status == "active"' >/dev/null
-echo "$RESULT" | jq -e '.data.testWidgets.items[0].priority == 1' >/dev/null
-pass "serve: hyphenated type typed query"
-
-# 42. base field filters on typed queries (id, title)
-# Insert a row with known title into the existing test-widget type
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO \\\"test-widget\\\" (title, status, priority) VALUES ('"'"'FilterTarget'"'"', '"'"'pending'"'"', 5)\") { message } }"}' >/dev/null
-sleep 1
-
-# Get the ID of the row we just inserted
-BF_RESULT=$(gql '{"query":"{ testWidgets(where: { title: { eq: \"FilterTarget\" } }) { items { id title } totalCount } }"}')
-echo "$BF_RESULT" | jq -e '.data.testWidgets.totalCount == 1' >/dev/null
-BF_ID=$(echo "$BF_RESULT" | jq -r '.data.testWidgets.items[0].id')
-pass "serve: base field title eq filter"
-
-# Filter by id eq
-BF_RESULT=$(gql "{\"query\":\"{ testWidgets(where: { id: { eq: \\\"$BF_ID\\\" } }) { items { id title } totalCount } }\"}")
-echo "$BF_RESULT" | jq -e '.data.testWidgets.totalCount == 1' >/dev/null
-echo "$BF_RESULT" | jq -e ".data.testWidgets.items[0].id == \"$BF_ID\"" >/dev/null
-pass "serve: base field id eq filter"
-
-# Filter by title contains
-BF_RESULT=$(gql '{"query":"{ testWidgets(where: { title: { contains: \"Target\" } }) { items { id } totalCount } }"}')
-echo "$BF_RESULT" | jq -e '.data.testWidgets.totalCount == 1' >/dev/null
-pass "serve: base field title contains filter"
-
-# Nonexistent ID returns empty
-BF_RESULT=$(gql '{"query":"{ testWidgets(where: { id: { eq: \"99999999999999\" } }) { items { id } totalCount } }"}')
-echo "$BF_RESULT" | jq -e '.data.testWidgets.totalCount == 0' >/dev/null
-pass "serve: base field id nonexistent returns empty"
-
-# Cleanup
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$BF_ID\\\") }\"}" >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE \\\"test-widget\\\"\") { message } }"}' >/dev/null
-
-# 42b. base-field orderBy (created_at/updated_at/id) + deterministic pagination
-# (PRD 00158). Mirrors ddb-server/tests/graphql_orderby_base_fields_t158.rs
-# through the live GraphQL server. Rows are inserted with DISTINCT dates
-# scrambled relative to insertion order so that created_at ASC, created_at DESC,
-# and id ASC each produce a different ordering -- binding the sort direction.
-#
-#   subject | date       | insertion order (id ASC)
-#   n0      | 2026-03-01 | 1st  (renamed to n0e after update)
-#   n1      | 2026-01-01 | 2nd
-#   n2      | 2026-04-01 | 3rd
-#   n3      | 2026-02-01 | 4th
-#
-#   id ASC          = [n0e, n1, n2, n3]
-#   created_at ASC  = [n1, n3, n0e, n2]   (Jan < Feb < Mar < Apr)
-#   created_at DESC = [n2, n0e, n3, n1]   (Apr > Mar > Feb > Jan)
-#   updated_at ASC  = [n1, n2, n3, n0e]   (n0e re-indexed last = newest)
-#   updated_at DESC = [n0e, n3, n2, n1]
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE obnote (subject TEXT NOT NULL)\") { message } }"}' | grep -q "table obnote created"
-wait_schema_reload "$VER"
-gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO obnote (subject, date) VALUES ('n0', '2026-03-01')\\\") { message } }\"}" >/dev/null
-sleep 1
-gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO obnote (subject, date) VALUES ('n1', '2026-01-01')\\\") { message } }\"}" >/dev/null
-sleep 1
-gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO obnote (subject, date) VALUES ('n2', '2026-04-01')\\\") { message } }\"}" >/dev/null
-sleep 1
-gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO obnote (subject, date) VALUES ('n3', '2026-02-01')\\\") { message } }\"}" >/dev/null
-sleep 1
-gql "{\"query\":\"mutation { executeSql(sql: \\\"UPDATE obnote SET subject = 'n0e' WHERE subject = 'n0'\\\") { message } }\"}" >/dev/null
-
-# created_at ASC: date order Jan < Feb < Mar < Apr = [n1, n3, n0e, n2].
-# Differs from id ASC [n0e,n1,n2,n3] -- proves date sort, not insertion order.
-OB=$(gql '{"query":"{ obnotes(orderBy: { created_at: ASC }) { items { subject } totalCount } }"}')
-echo "$OB" | jq -e '[.data.obnotes.items[].subject] == ["n1","n3","n0e","n2"]' >/dev/null
-echo "$OB" | jq -e '.data.obnotes.totalCount == 4' >/dev/null
-pass "serve: orderBy created_at ASC"
-
-# created_at DESC: date order Apr > Mar > Feb > Jan = [n2, n0e, n3, n1].
-# Differs from ASC -- proves direction matters.
-OB=$(gql '{"query":"{ obnotes(orderBy: { created_at: DESC }) { items { subject } } }"}')
-echo "$OB" | jq -e '[.data.obnotes.items[].subject] == ["n2","n0e","n3","n1"]' >/dev/null
-pass "serve: orderBy created_at DESC"
-
-# updated_at DESC: n0e was re-indexed last (UPDATE), so it is newest.
-OB=$(gql '{"query":"{ obnotes(orderBy: { updated_at: DESC }) { items { subject } } }"}')
-echo "$OB" | jq -e '[.data.obnotes.items[].subject] == ["n0e","n3","n2","n1"]' >/dev/null
-pass "serve: orderBy updated_at DESC"
-
-# updated_at ASC: n1 has the oldest updated_at, n0e the newest.
-OB=$(gql '{"query":"{ obnotes(orderBy: { updated_at: ASC }) { items { subject } } }"}')
-echo "$OB" | jq -e '[.data.obnotes.items[].subject] == ["n1","n2","n3","n0e"]' >/dev/null
-pass "serve: orderBy updated_at ASC"
-
-# id ASC: insertion order.
-OB=$(gql '{"query":"{ obnotes(orderBy: { id: ASC }) { items { subject } } }"}')
-echo "$OB" | jq -e '[.data.obnotes.items[].subject] == ["n0e","n1","n2","n3"]' >/dev/null
-pass "serve: orderBy id ASC"
-
-# id DESC: reverse insertion order.
-OB=$(gql '{"query":"{ obnotes(orderBy: { id: DESC }) { items { subject } } }"}')
-echo "$OB" | jq -e '[.data.obnotes.items[].subject] == ["n3","n2","n1","n0e"]' >/dev/null
-pass "serve: orderBy id DESC"
-
-# Deterministic pagination over created_at ASC: page1 + page2 reconstruct the
-# full order with no gaps or dupes (the id tiebreaker guarantees a total order).
-P1=$(gql '{"query":"{ obnotes(orderBy: { created_at: ASC }, limit: 2, offset: 0) { items { subject } } }"}')
-P2=$(gql '{"query":"{ obnotes(orderBy: { created_at: ASC }, limit: 2, offset: 2) { items { subject } } }"}')
-echo "$P1" | jq -e '[.data.obnotes.items[].subject] == ["n1","n3"]' >/dev/null
-echo "$P2" | jq -e '[.data.obnotes.items[].subject] == ["n0e","n2"]' >/dev/null
-pass "serve: orderBy created_at ASC deterministic pagination (no gaps/dupes)"
-
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE obnote CASCADE\") { message } }"}' >/dev/null
-
-# 43. SQL INSERT via executeSql defaults date, created_at non-null
-gql '{"query":"mutation{executeSql(sql:\"CREATE TABLE datecheck (name TEXT)\"){message}}"}' >/dev/null
-DC_RESULT=$(gql '{"query":"mutation{executeSql(sql:\"INSERT INTO datecheck (name) VALUES (\\\"DateTest\\\")\"){message}}"}')
-DC_ID=$(echo "$DC_RESULT" | sed -n 's/.*"message":"\([0-9]*\)".*/\1/p')
-DC_EXPECTED="$(echo "$DC_ID" | cut -c1-4)-$(echo "$DC_ID" | cut -c5-6)-$(echo "$DC_ID" | cut -c7-8)"
-DC_QUERY=$(gql "{\"query\":\"{ datechecks { items { id created_at } } }\"}")
-DC_CREATED=$(echo "$DC_QUERY" | sed -n 's/.*"created_at":"\([^"]*\)".*/\1/p')
-[ "$DC_CREATED" = "$DC_EXPECTED" ]
-pass "serve: SQL INSERT defaults date, created_at matches ID"
-
-# executeBatch also defaults date
-EB_RESULT=$(gql '{"query":"mutation{executeBatch(statements:[\"INSERT INTO datecheck (name) VALUES (\\\"BatchTest\\\")\"]){message}}"}')
-EB_ID=$(echo "$EB_RESULT" | sed -n 's/.*"message":"\([0-9]*\)".*/\1/p')
-EB_EXPECTED="$(echo "$EB_ID" | cut -c1-4)-$(echo "$EB_ID" | cut -c5-6)-$(echo "$EB_ID" | cut -c7-8)"
-EB_QUERY=$(gql "{\"query\":\"{ doogat(id: \\\"$EB_ID\\\") { created_at } }\"}")
-EB_CREATED=$(echo "$EB_QUERY" | sed -n 's/.*"created_at":"\([^"]*\)".*/\1/p')
-[ "$EB_CREATED" = "$EB_EXPECTED" ]
-pass "serve: executeBatch INSERT defaults date, created_at matches ID"
-
-# 43.D SQL constraint enforcement on executeSql write path (PRD 00122 / issue #7)
-# Six checks (D1-D6) extending the existing INSERT-validation neighborhood.
-
-# Setup: a NOT NULL link table for D1-D5 and a numeric table for D3.
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation{executeSql(sql:\"CREATE TABLE link_d1 (title VARCHAR(255) NOT NULL, url VARCHAR(255) NOT NULL)\"){message}}"}' >/dev/null
-gql '{"query":"mutation{executeSql(sql:\"CREATE TABLE numeric_d3 (title VARCHAR(255) NOT NULL, count INTEGER)\"){message}}"}' >/dev/null
-wait_schema_reload "$VER"
-
-# D1. NOT NULL: INSERT with NULL title is rejected and no row is created.
-D1_RESULT=$(gql '{"query":"mutation{executeSql(sql:\"INSERT INTO link_d1 (title, url) VALUES (NULL, \\\"https://n.com\\\")\"){message}}"}')
-echo "$D1_RESULT" | grep -q "NOT NULL constraint violated: link_d1.title"
-D1_COUNT=$(gql '{"query":"mutation{executeSql(sql:\"SELECT COUNT(*) FROM link_d1\"){rows}}"}')
-echo "$D1_COUNT" | grep -qF '[\"0\"]'
-pass "serve: D1 INSERT NULL on NOT NULL is rejected, no row created"
-
-# D2. VARCHAR(N) overflow: 300-char title against VARCHAR(255) is rejected.
-LONG=$(printf 'x%.0s' {1..300})
-D2_RESULT=$(gql "{\"query\":\"mutation{executeSql(sql:\\\"INSERT INTO link_d1 (title, url) VALUES (\\\\\\\"$LONG\\\\\\\", \\\\\\\"https://v.com\\\\\\\")\\\"){message}}\"}")
-echo "$D2_RESULT" | grep -q "value too long for link_d1.title"
-D2_COUNT=$(gql '{"query":"mutation{executeSql(sql:\"SELECT COUNT(*) FROM link_d1\"){rows}}"}')
-echo "$D2_COUNT" | grep -qF '[\"0\"]'
-pass "serve: D2 VARCHAR(N) overflow is rejected, no row created"
-
-# D3. INTEGER type mismatch: non-numeric value into INTEGER column is rejected.
-D3_RESULT=$(gql '{"query":"mutation{executeSql(sql:\"INSERT INTO numeric_d3 (title, count) VALUES (\\\"a\\\", \\\"not_a_number\\\")\"){message}}"}')

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


