
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition contains all task changes in these files: ddb-core/src/indexer/tests/mod.rs, ddb-core/src/search_query.rs, tests/e2e/cli_create_unregistered_type.rs, tests/e2e/integration_alter_rename.rs, tests/e2e/integration_binary_lww.rs, tests/e2e/integration_bundle.rs, tests/e2e/integration_compact_stats.rs, tests/e2e/integration_crdt_conflicts.rs, tests/e2e/integration_error_codes.rs, tests/e2e/integration_hyphenated_type.rs, tests/e2e/integration_id_poison.rs, tests/e2e/integration_nosql_cli.rs, tests/e2e/integration_orderby_base_fields.rs, tests/e2e/integration_singleton_flow.rs, tests/e2e/integration_singleton_parity.rs, tests/e2e/integration_singleton_races.rs, tests/e2e/integration_sql_no_match.rs, tests/e2e/integration_sync.rs, tests/e2e/integration_typed_write_cli.rs, tests/e2e/integration_update_bin.rs, tests/e2e/integration_warnings_update.rs, tests/e2e/integration_write_lock_races.rs, tests/e2e/poison_file_reindex.rs. Other task files are reviewed in separate partitions.

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/ddb-core/src/indexer/tests/mod.rs b/ddb-core/src/indexer/tests/mod.rs
index dfc25e2..1bdd3f1 100644
--- a/ddb-core/src/indexer/tests/mod.rs
+++ b/ddb-core/src/indexer/tests/mod.rs
@@ -4259,12 +4259,12 @@ fn rebuild_if_stale_inside_transaction_skips_full_rebuild_on_diff_failure() {
 
 #[test]
 fn rematerialize_never_exposes_missing_table_to_concurrent_reader() {
-    // §55.A residual race: `materialize_all_types` dropped and recreated each
+    // Rematerialization race: `materialize_all_types` dropped and recreated each
     // user table in SEPARATE autocommit statements, so a second connection (WAL)
     // could read between the committed DROP and the committed CREATE and see
     // "no such table". Two concurrent `ddb create` into a SINGLETON typedef hit
     // exactly this: the loser surfaced "no such table" instead of the structured
-    // SINGLETON message, failing integration.sh §55.A intermittently on linux CI.
+    // SINGLETON message, failing singleton_cross_process_create intermittently on Linux CI.
     // The fix wraps the rematerialize in one transaction, so a concurrent reader
     // sees the OLD table or the NEW table, never an absent one.
     use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
@@ -4272,7 +4272,7 @@ fn rematerialize_never_exposes_missing_table_to_concurrent_reader() {
 
     let dir = tempfile::TempDir::new().unwrap();
     let repo = GitRepo::init(dir.path()).unwrap();
-    // A _typedef-backed table (like §55.A's `CREATE TABLE ... SINGLETON`): it is
+    // A _typedef-backed table (as in `CREATE TABLE ... SINGLETON`): it is
     // in the orphan-cleanup keep-set, so it persists across rematerialize passes.
     // (An inferred-only table would be dropped by drop_orphan_materialized_tables
     // every pass, which is a legitimate absence, not the race under test.)
diff --git a/ddb-core/src/search_query.rs b/ddb-core/src/search_query.rs
index 67de545..9a3bb2b 100644
--- a/ddb-core/src/search_query.rs
+++ b/ddb-core/src/search_query.rs
@@ -1410,8 +1410,8 @@ mod tests {
     // accepts produces a normalized form compile_search_plan also accepts. PRD
     // 00121 fixed the original inconsistency where normalizeSearchQuery
     // accepted `tag=rust` while search() rejected it. This test pins the
-    // contract at the unit level in addition to the GraphQL-surface check
-    // already in integration.sh section 18h.
+    // contract at the unit level alongside the Rust e2e GraphQL-surface check
+    // integration_graphql_server::integration_18h_in_query_field_filter_and_error_class.
     #[test]
     fn normalize_and_search_accept_same_inputs_issue_6_c1() {
         // Curated inputs covering the patterns jink uses + the bugs from #6.
diff --git a/tests/e2e/cli_create_unregistered_type.rs b/tests/e2e/cli_create_unregistered_type.rs
index b9bdf90..ca2ec63 100644
--- a/tests/e2e/cli_create_unregistered_type.rs
+++ b/tests/e2e/cli_create_unregistered_type.rs
@@ -1,5 +1,4 @@
-//! CLI `ddb create --type <unregistered>` regression (PRD 00155; nightly
-//! `full-validation` red since 2026-05-29 at `tests/smoke.sh:33`).
+//! CLI `ddb create --type <unregistered>` regression (PRD 00155).
 //!
 //! PRD 00147 rerouted CLI create through the app facade, whose
 //! `batch_create_with_message` contract rejects an unregistered `doogat_type`
@@ -10,7 +9,7 @@
 //! create command; the lenient path now surfaces an `UNREGISTERED_TYPE_BASE_ONLY`
 //! warning on stderr (the released path was silent).
 //!
-//! This is the exact `tests/smoke.sh:33` shape: `ddb create --type project`
+//! Regression shape: `ddb create --type project`
 //! on a fresh repo with no `ddb type install project`.
 
 use crate::common::DdbTestRepo;
@@ -19,7 +18,7 @@ use crate::common::DdbTestRepo;
 fn cli_create_unregistered_type_creates_base_doogat_with_warning() {
     let repo = DdbTestRepo::init();
 
-    // smoke.sh:33 shape: unregistered `project` type on a fresh repo.
+    // Unregistered `project` type on a fresh repo.
     let out = repo
         .ddb()
         .args([
diff --git a/tests/e2e/integration_alter_rename.rs b/tests/e2e/integration_alter_rename.rs
index 2b920e3..dc5faba 100644
--- a/tests/e2e/integration_alter_rename.rs
+++ b/tests/e2e/integration_alter_rename.rs
@@ -1,5 +1,5 @@
-//! Port of tests/integration.sh:2159-2186 (PRD 00132 ALTER TABLE RENAME
-//! across protocols). CLI-transport coverage already exists in
+//! ALTER TABLE RENAME across protocols (PRD 00132).
+//! CLI-transport coverage already exists in
 //! `tests/e2e/alter_table_rename.rs`; these tests cover the GraphQL and
 //! PgWire transports.
 
diff --git a/tests/e2e/integration_binary_lww.rs b/tests/e2e/integration_binary_lww.rs
index 798aa94..45bd290 100644
--- a/tests/e2e/integration_binary_lww.rs
+++ b/tests/e2e/integration_binary_lww.rs
@@ -1,5 +1,4 @@
-//! Ported from tests/integration.sh §40 (lines 3407-3460): a binary asset
-//! conflict resolves via last-writer-wins on the commit's `HLC:` trailer
+//! A binary asset conflict resolves via last-writer-wins on the commit's `HLC:` trailer
 //! (PRD 00166), preserving the loser's content in history via a merge
 //! commit rather than silently dropping it.
 
diff --git a/tests/e2e/integration_bundle.rs b/tests/e2e/integration_bundle.rs
index b52ac72..2540d45 100644
--- a/tests/e2e/integration_bundle.rs
+++ b/tests/e2e/integration_bundle.rs
@@ -1,5 +1,4 @@
-//! Ported from tests/integration.sh §28 (lines 3181-3191): a targeted
-//! `bundle export --target <uuid>` delta export (PRD 00168 bundle import),
+//! A targeted `bundle export --target <uuid>` delta export (PRD 00168 bundle import),
 //! distinct from `--full`, delivers content scoped to the named node.
 
 use crate::common::{DdbTestRepo, TwoNodeSetup};
diff --git a/tests/e2e/integration_compact_stats.rs b/tests/e2e/integration_compact_stats.rs
index 99ee06e..ef1fe2f 100644
--- a/tests/e2e/integration_compact_stats.rs
+++ b/tests/e2e/integration_compact_stats.rs
@@ -1,5 +1,4 @@
-//! Ported from tests/integration.sh §33 (lines 3298-3345), byte-stats
-//! portion only: `ddb compact --force`'s report includes byte-stats lines.
+//! The `ddb compact --force` report includes byte-stats lines.
 //! The stale-node-resync flow itself is already covered by
 //! `multi_device::stale_node_resync_after_compaction`.
 
diff --git a/tests/e2e/integration_crdt_conflicts.rs b/tests/e2e/integration_crdt_conflicts.rs
index b92e167..c72f7f9 100644
--- a/tests/e2e/integration_crdt_conflicts.rs
+++ b/tests/e2e/integration_crdt_conflicts.rs
@@ -1,5 +1,4 @@
-//! Ported from tests/integration.sh §26 (lines 2976-3000) and §27c (lines
-//! 3056-3093): CRDT union of two reference-section additions, and PRD
+//! CRDT union of two reference-section additions, and PRD
 //! 00200's three-way conflicted merge (a deletion and a non-conflicting
 //! edit both survive a real conflicted sync).
 
diff --git a/tests/e2e/integration_error_codes.rs b/tests/e2e/integration_error_codes.rs
index dbaa23f..c22fa1d 100644
--- a/tests/e2e/integration_error_codes.rs
+++ b/tests/e2e/integration_error_codes.rs
@@ -1,5 +1,5 @@
-//! Port of tests/integration.sh:2109-2157 (PRD 00131 structured-error code
-//! propagation): GraphQL errors for constraint violations carry a
+//! Structured-error code propagation (PRD 00131):
+//! GraphQL errors for constraint violations carry a
 //! machine-readable `extensions.code` (and related fields), not just a
 //! human-readable message.
 
diff --git a/tests/e2e/integration_hyphenated_type.rs b/tests/e2e/integration_hyphenated_type.rs
index 7aadb38..696110e 100644
--- a/tests/e2e/integration_hyphenated_type.rs
+++ b/tests/e2e/integration_hyphenated_type.rs
@@ -1,5 +1,4 @@
-//! Ports tests/integration.sh §36 (lines 3366-3372): hyphenated type name
-//! via double-quoted SQL identifiers.
+//! Hyphenated type names via double-quoted SQL identifiers.
 
 use crate::common::DdbTestRepo;
 use predicates::prelude::*;
diff --git a/tests/e2e/integration_id_poison.rs b/tests/e2e/integration_id_poison.rs
index 91d5b96..8481d05 100644
--- a/tests/e2e/integration_id_poison.rs
+++ b/tests/e2e/integration_id_poison.rs
@@ -1,4 +1,4 @@
-//! Port of tests/integration.sh:3720-3796.
+//! Repo-aware ID minting and poison-file reindex warnings.
 //!
 //! §62 (PRD 00164, unified repo-aware ID minting): the batch (multi-row
 //! INSERT) and single (`ddb create`) mint paths agree on "id taken", so
diff --git a/tests/e2e/integration_nosql_cli.rs b/tests/e2e/integration_nosql_cli.rs
index 7e14a7e..e4e5a1f 100644
--- a/tests/e2e/integration_nosql_cli.rs
+++ b/tests/e2e/integration_nosql_cli.rs
@@ -1,7 +1,5 @@
-//! Ports tests/integration.sh §32 (lines 3284-3296): NoSQL CLI commands
-//! (get, scan --tag, scan --type, backlinks). The shell script reuses
-//! fixture state created much earlier in the script, so this test builds an
-//! equivalent self-contained fixture instead.
+//! NoSQL CLI commands (get, scan --tag, scan --type, backlinks)
+//! exercised against a self-contained fixture.
 
 use crate::common::DdbTestRepo;
 use predicates::prelude::*;
diff --git a/tests/e2e/integration_orderby_base_fields.rs b/tests/e2e/integration_orderby_base_fields.rs
index d0e0603..18d4a3e 100644
--- a/tests/e2e/integration_orderby_base_fields.rs
+++ b/tests/e2e/integration_orderby_base_fields.rs
@@ -2,7 +2,7 @@ use crate::common::{DdbTestRepo, ServerGuard};
 
 /// §42b base-field orderBy (created_at/updated_at/id) + deterministic
 /// pagination (PRD 00158), exercised through a live `ddb serve` process via
-/// `ServerGuard`. Mirrors tests/integration.sh:1529-1601. Rows are inserted
+/// `ServerGuard`. Rows are inserted
 /// with distinct dates scrambled relative to insertion order so that
 /// created_at ASC, created_at DESC, and id ASC each produce a different
 /// ordering, binding the sort direction.
diff --git a/tests/e2e/integration_singleton_flow.rs b/tests/e2e/integration_singleton_flow.rs
index abea276..6fc9706 100644
--- a/tests/e2e/integration_singleton_flow.rs
+++ b/tests/e2e/integration_singleton_flow.rs
@@ -1,5 +1,5 @@
-//! Port of tests/integration.sh:2188-2281 (PRD 00139 T20/T22 SINGLETON
-//! GraphQL flow, ALTER SET/DROP SINGLETON, DEFAULT VALUES auto-seed).
+//! SINGLETON GraphQL flow, ALTER SET/DROP SINGLETON, and DEFAULT VALUES
+//! auto-seed (PRD 00139 T20/T22).
 
 use crate::common::{select_scalar, DdbTestRepo, ServerGuard};
 use predicates::prelude::*;
diff --git a/tests/e2e/integration_singleton_parity.rs b/tests/e2e/integration_singleton_parity.rs
index 80caac4..2844e4e 100644
--- a/tests/e2e/integration_singleton_parity.rs
+++ b/tests/e2e/integration_singleton_parity.rs
@@ -1,4 +1,4 @@
-//! Cross-protocol SINGLETON duplicate-insert parity (integration.sh §54.D / integration.ps1 §54.D).
+//! Cross-protocol SINGLETON duplicate-insert parity.
 //!
 //! One seeded row in a SINGLETON table, then a duplicate insert attempted on
 //! every remaining public transport. The CLI leg lives in
diff --git a/tests/e2e/integration_singleton_races.rs b/tests/e2e/integration_singleton_races.rs
index c61efad..dd85a08 100644
--- a/tests/e2e/integration_singleton_races.rs
+++ b/tests/e2e/integration_singleton_races.rs
@@ -1,5 +1,5 @@
-//! SINGLETON insert races from integration.sh / integration.ps1 §55.B–E.
-//! Each race includes §55.E's exact row count. The CLI-only §55.A/E leg is
+//! SINGLETON insert races, each asserting the exact final row count.
+//! The CLI-only leg is
 //! `singleton_cross_process_create::two_concurrent_ddb_create_on_singleton_converge_on_one_row`.
 
 use crate::common::{DdbTestRepo, ServerGuard};
diff --git a/tests/e2e/integration_sql_no_match.rs b/tests/e2e/integration_sql_no_match.rs
index 83eeeca..69adcac 100644
--- a/tests/e2e/integration_sql_no_match.rs
+++ b/tests/e2e/integration_sql_no_match.rs
@@ -1,5 +1,4 @@
-//! Ports tests/integration.sh §30 no-match half (lines 3240-3256) and §30.F1
-//! (lines 3258-3270): WHERE-id no-match semantics for UPDATE/DELETE, and CLI
+//! WHERE-id no-match semantics for UPDATE/DELETE, and CLI
 //! propagation of the composite-UNIQUE duplicate rejection error.
 
 use crate::common::DdbTestRepo;
diff --git a/tests/e2e/integration_sync.rs b/tests/e2e/integration_sync.rs
index 39e0204..eb052a6 100644
--- a/tests/e2e/integration_sync.rs
+++ b/tests/e2e/integration_sync.rs
@@ -1,4 +1,4 @@
-//! Ported from tests/integration.sh §21 (lines 2886-2898): a raw `git clone`
+//! A raw `git clone`
 //! followed by `ddb reindex`, with no `ddb sync` involved at all, already
 //! sees content another node pushed.
 
diff --git a/tests/e2e/integration_typed_write_cli.rs b/tests/e2e/integration_typed_write_cli.rs
index d6d3eb7..d18edbf 100644
--- a/tests/e2e/integration_typed_write_cli.rs
+++ b/tests/e2e/integration_typed_write_cli.rs
@@ -1,10 +1,8 @@
-//! Ports tests/integration.sh §48 (lines 3563-3621, PRD 00129, CREATE INDEX +
-//! CASCADE + cycle-detection halves only — the RESTRICT-blocks-delete half is
-//! already covered by cascade_delete.rs), §49 (lines 3626-3669, PRD 00133) and
-//! §44.L (lines 3674-3693, PRD 00134): typed write blockers (CREATE INDEX
-//! no-op/rejection, ON DELETE CASCADE, cascade cycle detection), CLI typed
+//! Typed write blockers (PRD 00129: CREATE INDEX no-op/rejection,
+//! ON DELETE CASCADE, cascade cycle detection), CLI typed
 //! `create` populating REFERENCES columns and rejecting wrong-type FKs, and CLI
-//! `create` populating an auto-generated junction table atomically.
+//! `create` populating an auto-generated junction table atomically (PRDs 00133/00134).
+//! RESTRICT blocking deletion is covered by `cascade_delete.rs`.
 
 use crate::common::DdbTestRepo;
 use predicates::prelude::*;
diff --git a/tests/e2e/integration_update_bin.rs b/tests/e2e/integration_update_bin.rs
index 970895f..e78cdef 100644
--- a/tests/e2e/integration_update_bin.rs
+++ b/tests/e2e/integration_update_bin.rs
@@ -1,4 +1,4 @@
-//! Ports tests/integration.sh §29 (lines 3215-3223): `update-bin --help`
+//! `update-bin --help`
 //! output and `update-bin --rollback` with no backup present.
 
 use crate::common::DdbTestRepo;
diff --git a/tests/e2e/integration_warnings_update.rs b/tests/e2e/integration_warnings_update.rs
index 366b954..68cba16 100644
--- a/tests/e2e/integration_warnings_update.rs
+++ b/tests/e2e/integration_warnings_update.rs
@@ -1,5 +1,5 @@
-//! Port of tests/integration.sh:2538-2657 (PRD 00147 REST warnings envelope,
-//! PRD 00154 GraphQL warnings envelope, PRD 00149 update warning/error shape).
+//! REST warnings envelope (PRD 00147), GraphQL warnings envelope (PRD 00154),
+//! and update warning/error shape (PRD 00149).
 
 use crate::common::{DdbTestRepo, ServerGuard};
 
diff --git a/tests/e2e/integration_write_lock_races.rs b/tests/e2e/integration_write_lock_races.rs
index c0575da..05a91f1 100644
--- a/tests/e2e/integration_write_lock_races.rs
+++ b/tests/e2e/integration_write_lock_races.rs
@@ -1,5 +1,4 @@
-//! Cross-process write-lock races between `ddb serve` and the `ddb` CLI
-//! (integration.sh §61.B / integration.ps1 §61.B).
+//! Cross-process write-lock races between `ddb serve` and the `ddb` CLI.
 //!
 //! The headline deployment shape: a long-running server process and an operator
 //! at the CLI write to the same repo at the same time. Both sides' writes must
diff --git a/tests/e2e/poison_file_reindex.rs b/tests/e2e/poison_file_reindex.rs
index b723d19..ffba91d 100644
--- a/tests/e2e/poison_file_reindex.rs
+++ b/tests/e2e/poison_file_reindex.rs
@@ -100,8 +100,7 @@ fn lenient_reindex_skips_poison_file_and_indexes_the_rest() {
     // which rebuilds a stale index before answering — so that check passes even
     // if this `reindex` indexed nothing at all, and proves only that the CLI
     // still works. The `indexed N doogats` assertion above is what actually
-    // binds this reindex to having indexed the valid files. Same self-heal
-    // hazard the NOTE at `tests/smoke.sh:733-739` records.
+    // binds this reindex to having indexed the valid files.
 }
 
 /// `--strict` is the opt-in hard failure: over the same corpus the command must
@@ -111,7 +110,6 @@ fn lenient_reindex_skips_poison_file_and_indexes_the_rest() {
 /// in stderr: the lenient skip logs that same path as a warning, so a
 /// `--strict` that regressed to lenient would still print it and a bare
 /// `contains` would pass. Only the error line separates an abort from a skip.
-/// (Same false-pass shape that was fixed in `tests/smoke.sh` section 32.)
 #[test]
 fn strict_reindex_fails_and_names_the_poison_file() {
     let (repo, _ids) = repo_with_poison_file();

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


