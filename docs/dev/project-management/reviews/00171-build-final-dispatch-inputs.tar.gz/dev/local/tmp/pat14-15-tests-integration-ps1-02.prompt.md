
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.ps1, original lines 566-1071, segment 2/8. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.ps1:506: DONE; targets=integration_graphql_server::integration_18h_in_query_field_filter_and_error_class
tests/integration.ps1:573: DONE; targets=integration_graphql_server::integration_18i_in_query_substring_and_references_title
tests/integration.ps1:603: DONE; targets=integration_graphql_server::integration_18z_update_delete_no_match_parity
tests/integration.ps1:636: DONE; targets=integration_graphql_server::integration_18z2_execute_batch_atomicity
tests/integration.ps1:660: DONE; targets=integration_graphql_server::integration_18z3_update_doogat_tag_semantics
tests/integration.ps1:690: DONE; targets=integration_graphql_server::integration_18z4_sql_feature_coverage_pins
tests/integration.ps1:720: DONE; targets=integration_graphql_server::integration_18z5_search_limit_boundary_pins
tests/integration.ps1:743: DONE; targets=integration_graphql_server::integration_18z6_alter_table_add_column_in_typedefs_introspection
tests/integration.ps1:756: DONE; targets=integration_graphql_server::integration_18z7_graphql_schema_introspection_contract
tests/integration.ps1:784: DONE; targets=integration_graphql_jink::integration_18z8_jink_category_membership_port
tests/integration.ps1:821: DONE; targets=integration_graphql_jink::integration_18z9_jink_quotes_saved_searches_pinned_results_config_port
tests/integration.ps1:880: DONE; targets=integration_graphql_jink::integration_18z10_jink_composite_unique_and_batch_delete_port
tests/integration.ps1:912: DONE; targets=integration_rest_pgwire::integration_19_rest_sort_parameter
tests/integration.ps1:1006: DONE; targets=integration_rest_pgwire::integration_20_compact_custom_backup_path, integration_rest_pgwire::integration_20_maintenance_mutation, integration_rest_pgwire::integration_20_nosql_endpoints, integration_rest_pgwire::integration_20_pgwire_boolean_type, integration_rest_pgwire::integration_20_sql_engine_error_descriptive, rest::rest_get_unknown_id_returns_404, serve::graphql_introspection_hides_internal_tables, server_mutations::compact_force_mutation, server_mutations::compact_mutation_returns_result, server_mutations::compact_no_backup_mutation, server_mutations::sync_mutation_no_remote_returns_error

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.ps1 b/tests/integration.ps1
deleted file mode 100644
index 2f21127..0000000
--- a/tests/integration.ps1
+++ /dev/null
@@ -566,506 +0,0 @@
-if ($result -match 'internal error') { throw "round-trip: leaked internal error, got $result" }
-pass "serve: search accepts normalized query round-trip"
-
-gqlq "mutation { deleteDoogat(id: `"$PRD121A_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$PRD121B_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$PRD121G_ID`") }" | Out-Null
-
-# 18i. In-query field-filter substring + REFERENCES title resolution (PRD 00133)
-ddl 'mutation { executeSql(sql: "CREATE TABLE int133cat (label VARCHAR(100))") { message } }'
-ddl 'mutation { executeSql(sql: "CREATE TABLE int133link (url TEXT, int133cat VARCHAR(14) REFERENCES int133cat(id))") { message } }'
-$p133Dev = gqlq 'mutation { executeSql(sql: "INSERT INTO int133cat (title, label) VALUES (''Development'', ''dev'')") { message } }'
-$P133_DEV_ID = extractId $p133Dev
-if (-not $P133_DEV_ID) { throw "18i: failed to seed category row" }
-gqlq "mutation { executeSql(sql: `"INSERT INTO int133link (title, url, int133cat) VALUES ('Rust Async', 'https://example.com/rust-async', '$P133_DEV_ID')`") { message } }" | Out-Null
-gqlq 'mutation { executeSql(sql: "INSERT INTO int133link (title, url) VALUES (''Meeting Notes Archive'', ''https://example.com/archive'')") { message } }' | Out-Null
-
-$result = gqlq '{ search(query: "title=Archive") { totalCount hits { title } } }'
-if ($result -notmatch 'Meeting Notes Archive') { throw "18i: title=Archive did not substring-match: $result" }
-pass "serve: in-query title=X does substring match"
-
-$result = gqlq '{ search(query: "int133cat=Development") { totalCount hits { title } } }'
-if ($result -notmatch 'Rust Async') { throw "18i: int133cat=Development did not resolve via referenced title: $result" }
-pass "serve: in-query <ref_col>=X resolves via referenced typedef title"
-
-$result = gqlq '{ search(query: "", where: [{field: "int133cat", eq: "Development"}]) { totalCount } }'
-$count = if ($result -match '"totalCount":(\d+)') { $Matches[1] }
-if ($count -ne '0') { throw "18i: explicit where eq should not LIKE-match for REFERENCES, got count=$count" }
-pass "serve: explicit where eq stays exact (not LIKE) for REFERENCES"
-
-$result = gqlq "{ search(query: `"`", where: [{field: `"int133cat`", eq: `"$P133_DEV_ID`"}]) { totalCount } }"
-$count = if ($result -match '"totalCount":(\d+)') { $Matches[1] }
-if ($count -ne '1') { throw "18i: explicit where eq <id> should match exactly, got count=$count" }
-pass "serve: explicit where eq matches REFERENCES doogat ID exactly"
-
-ddl 'mutation { executeSql(sql: "DROP TABLE int133link CASCADE") { message } }'
-ddl 'mutation { executeSql(sql: "DROP TABLE int133cat CASCADE") { message } }'
-
-# 18z - UPDATE/DELETE WHERE id no-match GraphQL parity (#5 group B).
-ddl 'mutation { executeSql(sql: "CREATE TABLE link_b1 (url VARCHAR(255))") { message } }'
-$b1Seed = gqlq 'mutation { executeSql(sql: "INSERT INTO link_b1 (title, url) VALUES (''A'', ''https://a.com'')") { message } }'
-$B1_SEED_ID = extractId $b1Seed
-if (-not $B1_SEED_ID) { throw "18z: failed to seed B1 row" }
-
-$b1 = gqlq 'mutation { executeSql(sql: "UPDATE link_b1 SET title = ''x'' WHERE id = ''does_not_exist_b1''") { affected message } }'
-assertGqlOk $b1 "B1"
-if ($b1 -notmatch '"affected":0') { throw "18z B1: expected affected=0, got: $b1" }
-
-$b2 = gqlq 'mutation { executeSql(sql: "DELETE FROM link_b1 WHERE id = ''does_not_exist_b2''") { affected message } }'
-assertGqlOk $b2 "B2"
-if ($b2 -notmatch '"affected":0') { throw "18z B2: expected affected=0, got: $b2" }
-
-$b3 = gqlq 'mutation { executeSql(sql: "UPDATE link_b1 SET title = ''x'' WHERE url = ''https://nope.com''") { affected message } }'
-assertGqlOk $b3 "B3"
-if ($b3 -notmatch '"affected":0') { throw "18z B3: expected affected=0, got: $b3" }
-
-$b4 = gqlq "mutation { executeSql(sql: `"UPDATE link_b1 SET title = 'x' WHERE id = '$B1_SEED_ID' AND url = 'https://wrong.com'`") { affected message } }"
-assertGqlOk $b4 "B4"
-if ($b4 -notmatch '"affected":0') { throw "18z B4: expected affected=0, got: $b4" }
-
-$b5 = gqlq "mutation { executeSql(sql: `"UPDATE link_b1 SET title = 'from_in_clause' WHERE id IN ('nope', '$B1_SEED_ID')`") { affected message } }"
-assertGqlOk $b5 "B5"
-if ($b5 -notmatch '"affected":1') { throw "18z B5: expected affected=1, got: $b5" }
-
-$b5Fast = gqlq "mutation { executeSql(sql: `"UPDATE link_b1 SET title = 'final' WHERE id = '$B1_SEED_ID'`") { affected message } }"
-assertGqlOk $b5Fast "B5 fast"
-if ($b5Fast -notmatch '"affected":1') { throw "18z B5 fast: expected affected=1, got: $b5Fast" }
-
-gqlq 'mutation { executeSql(sql: "DROP TABLE link_b1 CASCADE") { message } }' | Out-Null
-pass "issue-5-B1..B5: UPDATE/DELETE no-match GraphQL parity"
-
-# 18z2 - executeBatch atomicity (#9 F4).
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation { executeSql(sql: "CREATE TABLE link_f4 (url VARCHAR(255))") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "CREATE TABLE membership_f4 (link_id VARCHAR(255), category VARCHAR(255), UNIQUE(link_id, category))") { message } }' | Out-Null
-waitSchemaReload $ver
-$f4Link = gqlq 'mutation { executeSql(sql: "INSERT INTO link_f4 (title, url) VALUES (''initial'', ''https://f4.com'')") { message } }'
-$F4_LINK_ID = extractId $f4Link
-if (-not $F4_LINK_ID) { throw "18z2: could not extract F4_LINK_ID" }
-
-gqlq "mutation { executeSql(sql: `"INSERT INTO membership_f4 (title, link_id, category) VALUES ('m', '$F4_LINK_ID', 'work')`") { message } }" | Out-Null
-
-$f4Batch = gqlq "mutation { executeBatch(statements: [`"UPDATE link_f4 SET title = 'batched' WHERE id = '$F4_LINK_ID' AND url = 'https://f4.com'`", `"INSERT INTO membership_f4 (title, link_id, category) VALUES ('dup', '$F4_LINK_ID', 'work')`"]) { message } }"
-assertGqlErrors $f4Batch "F4 batch"
-if ($f4Batch -notmatch 'UNIQUE') { throw "18z2: batch error missing UNIQUE marker, got: $f4Batch" }
-
-$f4After = gqlq "{ sql(query: `"SELECT title FROM link_f4 WHERE id = '$F4_LINK_ID'`") { rows } }"
-assertGqlOk $f4After "F4 after"
-if ($f4After -notmatch 'initial') { throw "18z2: batch was not rolled back, title changed, got: $f4After" }
-if ($f4After -match 'batched') { throw "18z2: batch rollback failed, found 'batched' in: $f4After" }
-
-gqlq 'mutation { executeSql(sql: "DROP TABLE link_f4 CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE membership_f4 CASCADE") { message } }' | Out-Null
-pass "issue-9-F4: executeBatch rolls back all statements when one fails"
-
-# 18z3 - updateDoogat tag semantics (#9 F5/F6/F7).
-$f5 = gqlq 'mutation { createDoogat(input: { title: "F5 tag clear", tags: ["a", "b", "c"] }) { id tags } }'
-$F5_ID = if ($f5 -match '"id":"([^"]+)"') { $Matches[1] } else { throw "18z3 F5: no id" }
-if ($f5 -notmatch '"a"') { throw "18z3 F5: initial tags missing 'a'" }
-gqlq "mutation { updateDoogat(input: { id: `"$F5_ID`", tags: [] }) { id } }" | Out-Null
-$f5Check = gqlq "{ doogat(id: `"$F5_ID`") { id tags } }"
-if ($f5Check -notmatch '"tags":\[\]') { throw "18z3 F5: tags not cleared, got: $f5Check" }
-gqlq "mutation { deleteDoogat(id: `"$F5_ID`") }" | Out-Null
-pass "issue-9-F5: updateDoogat tags: [] clears all tags"
-
-$f6 = gqlq 'mutation { createDoogat(input: { title: "F6 dedupe" }) { id } }'
-$F6_ID = if ($f6 -match '"id":"([^"]+)"') { $Matches[1] } else { throw "18z3 F6: no id" }
-gqlq "mutation { updateDoogat(input: { id: `"$F6_ID`", tags: [`"x`", `"y`", `"x`", `"y`", `"x`"] }) { id tags } }" | Out-Null
-$f6Check = gqlq "{ doogat(id: `"$F6_ID`") { id tags } }"
-$f6XCount = ([regex]::Matches($f6Check, '"x"')).Count
-$f6YCount = ([regex]::Matches($f6Check, '"y"')).Count
-if ($f6XCount -ne 1) { throw "18z3 F6: expected 1 'x', got $f6XCount in $f6Check" }
-if ($f6YCount -ne 1) { throw "18z3 F6: expected 1 'y', got $f6YCount in $f6Check" }
-gqlq "mutation { deleteDoogat(id: `"$F6_ID`") }" | Out-Null
-pass "issue-9-F6: updateDoogat dedupes input tags"
-
-$f7 = gqlq 'mutation { createDoogat(input: { title: "F7 unicode", tags: ["日本語", "café", "ñoño"] }) { id tags } }'
-$F7_ID = if ($f7 -match '"id":"([^"]+)"') { $Matches[1] } else { throw "18z3 F7: no id" }
-$f7Check = gqlq "{ doogat(id: `"$F7_ID`") { id tags } }"
-if ($f7Check -notmatch '日本語|\\u65e5\\u672c\\u8a9e') { throw "18z3 F7: missing 日本語 in $f7Check" }
-if ($f7Check -notmatch 'café|caf\\u00e9') { throw "18z3 F7: missing café in $f7Check" }
-if ($f7Check -notmatch 'ñoño|\\u00f1o\\u00f1o') { throw "18z3 F7: missing ñoño in $f7Check" }
-gqlq "mutation { deleteDoogat(id: `"$F7_ID`") }" | Out-Null
-pass "issue-9-F7: updateDoogat preserves unicode tags"
-
-# 18z4 - SQL feature coverage pins (#9 F9).
-ddl 'mutation { executeSql(sql: "CREATE TABLE feat (val INTEGER, label VARCHAR(255), maybe_null VARCHAR(255))") { message } }'
-gqlq 'mutation { executeSql(sql: "INSERT INTO feat (title, val, label, maybe_null) VALUES (''r1'', 1, ''a'', ''x'')") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "INSERT INTO feat (title, val, label) VALUES (''r2'', 2, ''a'')") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "INSERT INTO feat (title, val, label, maybe_null) VALUES (''r3'', 3, ''b'', ''y'')") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "INSERT INTO feat (title, val, label) VALUES (''r4'', 4, ''b'')") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "INSERT INTO feat (title, val, label, maybe_null) VALUES (''r5'', 5, ''c'', ''z'')") { message } }' | Out-Null
-
-$f9Cnt = gqlq '{ sql(query: "SELECT COUNT(*) FROM feat") { rows } }'
-if ($f9Cnt -notmatch '\[\\"5\\"\]') { throw "18z4 F9: COUNT(*) did not return 5: $f9Cnt" }
-$f9Grp = gqlq '{ sql(query: "SELECT label, COUNT(*) FROM feat GROUP BY label ORDER BY label") { rows } }'
-assertGqlOk $f9Grp "F9 GROUP BY"
-foreach ($g in @('\\"a\\"', '\\"b\\"', '\\"c\\"')) {
-    if ($f9Grp -notmatch $g) { throw "18z4 F9: GROUP BY missing $g in $f9Grp" }
-}
-$f9Ord = gqlq '{ sql(query: "SELECT label FROM feat ORDER BY val DESC LIMIT 2") { rows } }'
-if ($f9Ord -notmatch '\[\\"c\\"\]') { throw "18z4 F9 ORDER BY: missing [c]: $f9Ord" }
-if ($f9Ord -notmatch '\[\\"b\\"\]') { throw "18z4 F9 ORDER BY: missing [b]: $f9Ord" }
-if ($f9Ord -match '\[\\"a\\"\]') { throw "18z4 F9 ORDER BY: unexpected [a]: $f9Ord" }
-$f9Off = gqlq '{ sql(query: "SELECT val FROM feat ORDER BY val ASC LIMIT 10 OFFSET 3") { rows } }'
-if ($f9Off -notmatch '\[\\"4\\"\]') { throw "18z4 F9 OFFSET: missing [4]: $f9Off" }
-if ($f9Off -notmatch '\[\\"5\\"\]') { throw "18z4 F9 OFFSET: missing [5]: $f9Off" }
-if ($f9Off -match '\[\\"1\\"\]') { throw "18z4 F9 OFFSET: unexpected [1]: $f9Off" }
-$f9Nul = gqlq '{ sql(query: "SELECT COUNT(*) FROM feat WHERE maybe_null IS NULL") { rows } }'
-if ($f9Nul -notmatch '\[\\"2\\"\]') { throw "18z4 F9 IS NULL: expected 2: $f9Nul" }
-$f9Lik = gqlq '{ sql(query: "SELECT COUNT(*) FROM feat WHERE label LIKE \"a%\"") { rows } }'
-if ($f9Lik -notmatch '\[\\"2\\"\]') { throw "18z4 F9 LIKE: expected 2: $f9Lik" }
-gqlq 'mutation { executeSql(sql: "DROP TABLE feat CASCADE") { message } }' | Out-Null
-pass "issue-9-F9: SQL feature coverage (COUNT, GROUP BY, ORDER BY, LIMIT, OFFSET, IS NULL, LIKE)"
-
-# 18z5 - search() limit boundary pins (#9 F10).
-$f10a = gqlq 'mutation { createDoogat(input: { title: "F10boundary alpha" }) { id } }'
-$F10A_ID = if ($f10a -match '"id":"([^"]+)"') { $Matches[1] } else { throw "F10A no id" }
-$f10b = gqlq 'mutation { createDoogat(input: { title: "F10boundary beta" }) { id } }'
-$F10B_ID = if ($f10b -match '"id":"([^"]+)"') { $Matches[1] } else { throw "F10B no id" }
-$f10c = gqlq 'mutation { createDoogat(input: { title: "F10boundary gamma" }) { id } }'
-$F10C_ID = if ($f10c -match '"id":"([^"]+)"') { $Matches[1] } else { throw "F10C no id" }
-Start-Sleep -Seconds 1
-$f10Zero = gqlq '{ search(query: "F10boundary", limit: 0) { totalCount hits { id } } }'
-if ($f10Zero -match 'internal error') { throw "18z5 F10: limit 0 should not surface internal error: $f10Zero" }
-$f10Max = gqlq '{ search(query: "F10boundary", limit: 10000) { totalCount hits { id } } }'
-assertGqlOk $f10Max "F10 max"
-if ($f10Max -notmatch '"totalCount":3') { throw "18z5 F10: limit 10000 should return 3 rows: $f10Max" }
-$f10Over = gqlq '{ search(query: "F10boundary", limit: 10001) { totalCount } }'
-if ($f10Over -notmatch 'limit must not exceed') { throw "18z5 F10: limit 10001 should error with 'limit must not exceed': $f10Over" }
-if ($f10Over -match 'internal error') { throw "18z5 F10: limit 10001 should not surface internal error: $f10Over" }
-$f10Neg = gqlq '{ search(query: "F10boundary", limit: -1) { totalCount } }'
-if ($f10Neg -match 'internal error') { throw "18z5 F10: limit -1 should not surface internal error: $f10Neg" }
-gqlq "mutation { deleteDoogat(id: `"$F10A_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$F10B_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$F10C_ID`") }" | Out-Null
-pass "issue-9-F10: search limit boundaries (0, 10000, 10001, -1)"
-
-# 18z6 - ALTER TABLE ADD COLUMN appears in typeDefs introspection (#9 F11).
-ddl 'mutation { executeSql(sql: "CREATE TABLE altschema_f11 (a VARCHAR(255))") { message } }'
-$f11Before = gqlq '{ typeDefs { name columns { name dataType } } }'
-assertGqlOk $f11Before "F11 before"
-if ($f11Before -notmatch '"altschema_f11"') { throw "18z6 F11: altschema_f11 missing from typeDefs" }
-if ($f11Before -notmatch '"a"') { throw "18z6 F11: column a missing before ALTER" }
-ddl 'mutation { executeSql(sql: "ALTER TABLE altschema_f11 ADD COLUMN b INTEGER") { message } }'
-$f11After = gqlq '{ typeDefs { name columns { name dataType } } }'
-assertGqlOk $f11After "F11 after"
-if ($f11After -notmatch '"b"') { throw "18z6 F11: column b missing after ALTER, got: $f11After" }
-gqlq 'mutation { executeSql(sql: "DROP TABLE altschema_f11 CASCADE") { message } }' | Out-Null
-pass "issue-9-F11: ALTER TABLE ADD COLUMN appears in typeDefs introspection"
-
-# 18z7 - GraphQL schema introspection contract (#9 group G).
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation { executeSql(sql: "CREATE TABLE gqtesta (label VARCHAR(255))") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "CREATE TABLE gqtestb (label VARCHAR(255))") { message } }' | Out-Null
-waitSchemaReload $ver
-$gIntro = gqlq '{ __schema { queryType { fields { name } } types { name fields { name } } } }'
-assertGqlOk $gIntro "G introspection"
-foreach ($fld in @('"name":"gqtestas"', '"name":"gqtestasAggregate"', '"name":"gqtestbs"', '"name":"gqtestbsAggregate"')) {
-    if ($gIntro -notmatch [regex]::Escape($fld)) { throw "18z7 G1: missing field $fld" }
-}
-foreach ($conn in @('GqtestaConnection', 'GqtestbConnection')) {
-    if ($gIntro -notmatch $conn) { throw "18z7 G2: missing $conn connection type" }
-}
-# G2: verify items and totalCount fields on Connection types structurally.
-$gIntroObj = $gIntro | ConvertFrom-Json
-$gTypes = @{}
-foreach ($t in $gIntroObj.data.__schema.types) { $gTypes[$t.name] = $t }
-foreach ($conn in @('GqtestaConnection', 'GqtestbConnection')) {
-    if (-not $gTypes.ContainsKey($conn)) { throw "18z7 G2: $conn missing from schema types" }
-    $fields = @($gTypes[$conn].fields | ForEach-Object { $_.name })
-    if ('items' -notin $fields) { throw "18z7 G2: $conn missing items field, got: $($fields -join ',')" }
-    if ('totalCount' -notin $fields) { throw "18z7 G2: $conn missing totalCount field, got: $($fields -join ',')" }
-}
-gqlq 'mutation { executeSql(sql: "DROP TABLE gqtesta CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE gqtestb CASCADE") { message } }' | Out-Null
-pass "issue-9-G1: every typed table has plural and Aggregate query fields"
-pass "issue-9-G2: every Connection type has items and totalCount fields"
-
-# 18z8 - Category + membership jink port (#9 jink full-sweep section 5).
-$j3Cat = gqlq 'mutation { executeSql(sql: "INSERT INTO category (title, fqn, space, sort_order) VALUES (''Dev'', ''work.dev'', ''work'', 0)") { message } }'
-assertGqlOk $j3Cat "j3 category insert"
-$JINK_CAT_ID = extractId $j3Cat
-if (-not $JINK_CAT_ID) { throw "18z8: could not extract JINK_CAT_ID" }
-pass "j3: INSERT category"
-
-$j3CatSpace = gqlq '{ categories(where: {space: {eq: "work"}}) { items { id fqn title space sort_order } } }'
-assertGqlOk $j3CatSpace "j3 category by space"
-if ($j3CatSpace -notmatch '"work.dev"') { throw "18z8 j3: missing work.dev in space query" }
-pass "j3: categories GraphQL query by space"
-
-$j3CatIn = gqlq '{ categories(where: {fqn: {in: ["work.dev"]}}) { items { fqn title space } } }'
-assertGqlOk $j3CatIn "j3 category by fqn IN"
-if ($j3CatIn -notmatch '"work.dev"') { throw "18z8 j3: missing work.dev in IN query" }
-pass "j3: categories GraphQL query by fqn IN list"
-
-$j3Cm = gqlq "mutation { executeSql(sql: `"INSERT INTO \`"category-membership\`" (title, link_id, category_fqn, sort_order) VALUES ('Test in work.dev', '$JINK_LINK_ID', 'work.dev', COALESCE((SELECT MAX(sort_order) + 1 FROM \`"category-membership\`" WHERE category_fqn = 'work.dev'), 0))`") { message } }"
-assertGqlOk $j3Cm "j3 category-membership insert"
-if ($j3Cm -notmatch '"message":"\d+"') { throw "18z8 j3: category-membership insert did not return id: $j3Cm" }
-pass "j3: INSERT category-membership with COALESCE+subquery sort_order"
-
-$j3CmBoth = gqlq "{ categoryMemberships(where: {link_id: {eq: `"$JINK_LINK_ID`"}, category_fqn: {eq: `"work.dev`"}}) { items { id link_id category_fqn pinned sort_order } } }"
-assertGqlOk $j3CmBoth "j3 categoryMemberships both"
-if ($j3CmBoth -notmatch '"work.dev"') { throw "18z8 j3: categoryMemberships by both missing work.dev" }
-pass "j3: categoryMemberships by link_id + category_fqn"
-
-$j3CmLink = gqlq "{ categoryMemberships(where: {link_id: {eq: `"$JINK_LINK_ID`"}}) { items { category_fqn } } }"
-assertGqlOk $j3CmLink "j3 categoryMemberships by link_id"
-if ($j3CmLink -notmatch '"work.dev"') { throw "18z8 j3: categoryMemberships by link_id missing work.dev" }
-pass "j3: categoryMemberships by link_id only"
-
-$j3CmCat = gqlq '{ categoryMemberships(where: {category_fqn: {eq: "work.dev"}}) { items { link_id pinned sort_order } } }'
-assertGqlOk $j3CmCat "j3 categoryMemberships by category"
-if ($j3CmCat -notmatch $JINK_LINK_ID) { throw "18z8 j3: categoryMemberships by category missing JINK_LINK_ID" }
-pass "j3: categoryMemberships by category_fqn only"
-
-# 18z9 - Jink quotes + saved-searches + pinned-results + jinkConfigs port
-# (#9 jink full-sweep sections 10-12).
-$j4Q = gqlq 'mutation { executeSql(sql: "INSERT INTO quote (title, author, text) VALUES (''First'', ''Anon'', ''Hello world'')") { message } }'
-assertGqlOk $j4Q "j4 quote insert"
-$JINK_QUOTE_ID = extractId $j4Q
-if (-not $JINK_QUOTE_ID) { throw "18z9: could not extract JINK_QUOTE_ID" }
-pass "j4: INSERT quote"
-
-$j4QId = gqlq "{ quotes(where: {id: {eq: `"$JINK_QUOTE_ID`"}}) { items { id title text author } } }"
-assertGqlOk $j4QId "j4 quotes by id"
-if ($j4QId -notmatch 'Hello world') { throw "18z9 j4: quote query missing 'Hello world'" }
-pass "j4: quotes query by id"
-
-$j4QAll = gqlq '{ quotes { items { id } } }'
-assertGqlOk $j4QAll "j4 quotes all"
-if ($j4QAll -notmatch '"quotes"') { throw "18z9 j4: quotes query missing quotes key" }
-pass "j4: quotes query all"
-
-$j4QUpd = gqlq "mutation { executeSql(sql: `"UPDATE quote SET favorited = 'true' WHERE id = '$JINK_QUOTE_ID' AND title = 'First'`") { affected } }"
-assertGqlOk $j4QUpd "j4 quote update"
-if ($j4QUpd -notmatch '"affected":1') { throw "18z9 j4: quote update did not affect 1 row: $j4QUpd" }
-pass "j4: UPDATE quote SET favorited (compound predicate)"
-
-$j4Ss = gqlq 'mutation { executeSql(sql: "INSERT INTO \"saved-search\" (title, query_raw, query_normalized) VALUES (''rust stuff'', ''Rust'', ''rust'')") { message } }'
-assertGqlOk $j4Ss "j4 saved-search insert"
-$JINK_SS_ID = extractId $j4Ss
-if (-not $JINK_SS_ID) { throw "18z9: could not extract JINK_SS_ID" }
-pass "j4: INSERT saved-search"
-
-$j4SsQ = gqlq "{ savedSearches(where: {id: {eq: `"$JINK_SS_ID`"}}) { items { id title query_raw query_normalized } } }"
-assertGqlOk $j4SsQ "j4 savedSearches query"
-if ($j4SsQ -notmatch '"rust"') { throw "18z9 j4: savedSearches query missing rust" }
-pass "j4: savedSearches query by id"
-
-$j4Pr = gqlq "mutation { executeSql(sql: `"INSERT INTO \`"pinned-result\`" (title, query_normalized, link_id, sort_order) VALUES ('pinned test', 'rust', '$JINK_LINK_ID', 0)`") { message } }"
-assertGqlOk $j4Pr "j4 pinned-result insert"
-if ($j4Pr -notmatch '"message":"\d+"') { throw "18z9 j4: pinned-result insert did not return id: $j4Pr" }
-pass "j4: INSERT pinned-result"
-
-$j4PrQ = gqlq '{ pinnedResults(where: {query_normalized: {eq: "rust"}}) { items { id query_normalized link_id sort_order } } }'
-assertGqlOk $j4PrQ "j4 pinnedResults query"
-if ($j4PrQ -notmatch $JINK_LINK_ID) { throw "18z9 j4: pinnedResults query missing JINK_LINK_ID" }
-pass "j4: pinnedResults query by query_normalized"
-
-$j4Jc = gqlq '{ jinkConfigs { items { id dashboard_title quote_rotation_minutes links_per_category frontend_version } } }'
-assertGqlOk $j4Jc "j4 jinkConfigs query"
-if ($j4Jc -notmatch 'dashboard_title') { throw "18z9 j4: jinkConfigs missing dashboard_title" }
-pass "j4: jinkConfigs query"
-
-$j4JcUpd = gqlq 'mutation { executeSql(sql: "UPDATE \"jink-config\" SET frontend_version = ''1.0.0'' WHERE title = ''jink-config''") { affected } }'
-assertGqlOk $j4JcUpd "j4 jink-config update"
-if ($j4JcUpd -notmatch '"affected":1') { throw "18z9 j4: jink-config update did not affect 1: $j4JcUpd" }
-pass "j4: UPDATE jink-config frontend_version (compound predicate)"
-
-$j4JcSel = gqlq '{ sql(query: "SELECT frontend_version FROM \"jink-config\" LIMIT 1") { rows } }'
-assertGqlOk $j4JcSel "j4 jink-config select"
-if ($j4JcSel -notmatch '\\"1.0.0\\"') { throw "18z9 j4: jink-config SELECT did not return 1.0.0: $j4JcSel" }
-pass "j4: SELECT frontend_version returns 1.0.0"
-
-# 18z10 - composite UNIQUE duplicate + compound-predicate DELETE jink port
-# (#9 jink full-sweep sections 6 + 13). Also drops all jink tables.
-$j5Dup = gqlq "mutation { executeSql(sql: `"INSERT INTO \`"category-membership\`" (title, link_id, category_fqn) VALUES ('dup', '$JINK_LINK_ID', 'work.dev')`") { message } }"
-assertGqlErrors $j5Dup "j5 duplicate"
-if ($j5Dup -notmatch 'UNIQUE') { throw "18z10 j5: duplicate should mention UNIQUE: $j5Dup" }
-pass "j5: duplicate category-membership rejected with UNIQUE error"
-
-$j5Batch = gqlq "mutation { executeBatch(statements: [`"DELETE FROM \`"category-membership\`" WHERE link_id = '$JINK_LINK_ID' AND category_fqn = 'work.dev'`", `"DELETE FROM link WHERE id = '$JINK_LINK_ID' AND url = 'https://example.com'`"]) { message } }"
-assertGqlOk $j5Batch "j5 batch delete"
-if ($j5Batch -notmatch '"executeBatch"') { throw "18z10 j5: batch delete missing executeBatch key: $j5Batch" }
-pass "j5: executeBatch DELETE category-membership + link (compound predicates)"
-
-$j5LinkGone = gqlq "{ links(where: {id: {eq: `"$JINK_LINK_ID`"}}) { items { id } } }"
-assertGqlOk $j5LinkGone "j5 link gone"
-if ($j5LinkGone -notmatch '"items":\[\]') { throw "18z10 j5: link not gone after batch delete: $j5LinkGone" }
-pass "j5: link is gone after batch delete"
-
-$j5QDel = gqlq "mutation { executeSql(sql: `"DELETE FROM quote WHERE id = '$JINK_QUOTE_ID' AND title = 'First'`") { affected } }"
-assertGqlOk $j5QDel "j5 quote delete"
-if ($j5QDel -notmatch '"affected":1') { throw "18z10 j5: quote delete did not affect 1: $j5QDel" }
-pass "j5: DELETE quote (compound predicate)"
-
-# Final cleanup: drop all jink tables from sub-block J1.
-gqlq 'mutation { executeSql(sql: "DROP TABLE link CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE category CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE \"category-membership\" CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE quote CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE \"saved-search\" CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE \"pinned-result\" CASCADE") { message } }' | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE \"jink-config\" CASCADE") { message } }' | Out-Null
-pass "j5: jink port cleanup (all tables dropped)"
-
-# 19. REST API CRUD
-try {
-    Invoke-WebRequest -Uri "$REST_URL/doogats" -Method POST -ContentType "application/json" `
-        -Body '{"title":"REST No Auth"}' -ErrorAction Stop
-    throw "should have been 401"
-} catch {
-    if ($_.Exception.Response.StatusCode.value__ -ne 401) { throw "expected 401" }
-}
-pass "rest: auth rejects missing token"
-
-$resp = rest "/doogats" "POST" '{"title":"REST Smoke","body":"rest body","tags":["rest"]}'
-if ($resp.StatusCode -ne 201) { throw "rest create expected 201" }
-$REST_ID = if ((content $resp) -match '"id":"([^"]+)"') { $Matches[1] } else { throw "no id" }
-pass "rest: create"
-
-$resp = rest "/doogats/$REST_ID"
-if ((content $resp) -notmatch "REST Smoke") { throw "rest get failed" }
-pass "rest: get"
-
-$resp = rest "/doogats/$REST_ID" "PUT" '{"title":"REST Updated"}'
-if ((content $resp) -notmatch "REST Updated") { throw "rest update failed" }
-pass "rest: update"
-
-$resp = rest "/doogats?tag=rest"
-if ((content $resp) -notmatch $REST_ID) { throw "rest list failed" }
-pass "rest: list with filter"
-
-# Field filtering
-gqlq 'mutation{executeSql(sql:"CREATE TABLE smokeitem (label TEXT NOT NULL, priority INTEGER)"){message}}'
-gqlq 'mutation{executeSql(sql:"INSERT INTO smokeitem (label, priority) VALUES (''Smoke1'', 7)"){message}}'
-$resp = rest "/doogats?field.priority=7"
-if ((content $resp) -notmatch "Smoke1") { throw "field filter failed" }
-pass "rest: field filter"
-
-$resp = rest "/doogats?field.priority=999"
-if ((content $resp) -notmatch '"data":\[\]') { throw "field filter no-match failed" }
-pass "rest: field filter no match"
-
-# REST sort: create doogats with distinct titles
-$resp = rest "/doogats" "POST" '{"title":"Charlie Sort","tags":["sorttest"]}'
-$SORT_A = if ((content $resp) -match '"id":"([^"]+)"') { $Matches[1] } else { throw "no id" }
-Start-Sleep -Milliseconds 100
-$resp = rest "/doogats" "POST" '{"title":"Alpha Sort","tags":["sorttest"]}'
-$SORT_B = if ((content $resp) -match '"id":"([^"]+)"') { $Matches[1] } else { throw "no id" }
-Start-Sleep -Milliseconds 100
-$resp = rest "/doogats" "POST" '{"title":"Bravo Sort","tags":["sorttest"]}'
-$SORT_C = if ((content $resp) -match '"id":"([^"]+)"') { $Matches[1] } else { throw "no id" }
-
-$resp = rest "/doogats?tag=sorttest&sort=title"
-$c = content $resp
-if ($c -notmatch '"data":\[\{[^}]*"title":"([^"]*)"') { throw "sort title parse" }
-if ($Matches[1] -ne "Alpha Sort") { throw "sort title asc: got $($Matches[1])" }
-pass "rest: sort by title ascending"
-
-$resp = rest "/doogats?tag=sorttest&sort=-title"
-$c = content $resp
-if ($c -notmatch '"data":\[\{[^}]*"title":"([^"]*)"') { throw "sort -title parse" }
-if ($Matches[1] -ne "Charlie Sort") { throw "sort title desc: got $($Matches[1])" }
-pass "rest: sort by title descending"
-
-$resp = rest "/doogats?tag=sorttest&sort=date"
-$c = content $resp
-if ($c -notmatch '"data":\[\{[^}]*"id":"([^"]*)"') { throw "sort date parse" }
-if ($Matches[1] -ne $SORT_C) { throw "sort date desc: expected $SORT_C, got $($Matches[1])" }
-pass "rest: sort by date descending (default)"
-
-try {
-    Invoke-WebRequest -Uri "$REST_URL/doogats?sort=invalid" -Method GET `
-        -Headers @{ Authorization = "Bearer $TOKEN" } -ErrorAction Stop
-    throw "should have been 400"
-} catch {
-    if ($_.Exception.Response.StatusCode.value__ -ne 400) { throw "expected 400, got $($_.Exception.Response.StatusCode.value__)" }
-}
-pass "rest: sort invalid field returns 400"
-
-# Clean up sort test doogats
-Invoke-WebRequest -Uri "$REST_URL/doogats/$SORT_A" -Method DELETE -Headers @{ Authorization = "Bearer $TOKEN" } -ErrorAction SilentlyContinue | Out-Null
-Invoke-WebRequest -Uri "$REST_URL/doogats/$SORT_B" -Method DELETE -Headers @{ Authorization = "Bearer $TOKEN" } -ErrorAction SilentlyContinue | Out-Null
-Invoke-WebRequest -Uri "$REST_URL/doogats/$SORT_C" -Method DELETE -Headers @{ Authorization = "Bearer $TOKEN" } -ErrorAction SilentlyContinue | Out-Null
-
-$resp = Invoke-WebRequest -Uri "$REST_URL/doogats/$REST_ID" -Method DELETE `
-    -Headers @{ Authorization = "Bearer $TOKEN" } -ErrorAction Stop
-if ($resp.StatusCode -ne 204) { throw "rest delete expected 204" }
-pass "rest: delete"
-
-try {
-    Invoke-WebRequest -Uri "$REST_URL/doogats/$REST_ID" -Method GET `
-        -Headers @{ Authorization = "Bearer $TOKEN" } -ErrorAction Stop
-    throw "should have been 404"
-} catch {
-    if ($_.Exception.Response.StatusCode.value__ -ne 404) { throw "expected 404" }
-}
-pass "rest: get after delete returns 404"
-
-# 20. PgWire — skip on Windows (psql rarely available)
-pass "pgwire: skipped (windows)"
-
-# NoSQL server endpoints
-$NOSQL_URL = "http://127.0.0.1:$SERVER_PORT/nosql"
-function nosql($path) {
-    $resp = Invoke-WebRequest -Uri "$NOSQL_URL$path" `
-        -Headers @{ Authorization = "Bearer $TOKEN" } -ErrorAction Stop
-    if ($resp.Content -is [byte[]]) { return [System.Text.Encoding]::UTF8.GetString($resp.Content) }
-    return $resp.Content
-}
-
-$result = nosql "/$ID1"
-if ($result -notmatch "First note") { throw "nosql get failed" }
-pass "nosql-api: get by id"
-
-$result = nosql "?tag=smoke"
-if ($result -notmatch $ID1) { throw "nosql scan failed" }
-pass "nosql-api: scan by tag"
-
-try {
-    Invoke-WebRequest -Uri "$NOSQL_URL`?type=project&tag=test" `
-        -Headers @{ Authorization = "Bearer $TOKEN" } -ErrorAction Stop
-    throw "should have been 400"
-} catch {
-    if ($_.Exception.Response.StatusCode.value__ -ne 400) { throw "expected 400" }
-}
-pass "nosql-api: rejects both type and tag"
-
-try {
-    Invoke-WebRequest -Uri "$NOSQL_URL/$ID1" -Method GET -ContentType "application/json" -ErrorAction Stop
-    throw "should have been 401"
-} catch {
-    if ($_.Exception.Response.StatusCode.value__ -ne 401) { throw "expected 401" }
-}
-pass "nosql-api: auth rejects missing token"
-
-# error response — SQL engine errors are descriptive (user-actionable)
-$result = gqlq 'mutation { executeSql(sql: "SELCT * FORM oops") { message } }'
-if ($result -notmatch "errors") { throw "expected errors in response" }
-if ($result -notmatch "(?i)parse:") { throw "expected descriptive parse error" }
-pass "serve: sql engine error is descriptive"
-
-# error sanitization — not-found returns 404
-try {
-    Invoke-WebRequest -Uri "$REST_URL/doogats/99990101000000" `
-        -Headers @{ Authorization = "Bearer $TOKEN" } -ErrorAction Stop
-    throw "should have been 404"
-} catch {
-    if ($_.Exception.Response.StatusCode.value__ -ne 404) { throw "expected 404" }
-}
-pass "serve: not-found returns 404"
-
-# GraphQL introspection hides internal tables
-$intro = gqlq '{ __schema { queryType { fields { name } } } }'
-if ($intro -match "_ddb_") { throw "introspection leaked internal table: $intro" }
-pass "serve: introspection hides internal tables"
-
-# compact mutation
-$result = gqlq 'mutation { compact { filesRemoved crdtDocsCompacted gcSuccess crdtTempBytesBefore crdtTempBytesAfter crdtTempFilesBefore crdtTempFilesAfter repoBytesBefore repoBytesAfter backupPath } }'
-if ($result -notmatch "gcSuccess") { throw "compact mutation failed" }
-pass "serve: compact mutation"
-
-# compact(force: true)
-$result = gqlq 'mutation { compact(force: true) { filesRemoved crdtDocsCompacted gcSuccess crdtTempBytesBefore crdtTempBytesAfter repoBytesBefore repoBytesAfter backupPath } }'
-if ($result -notmatch "gcSuccess") { throw "compact(force:true) mutation failed" }

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


