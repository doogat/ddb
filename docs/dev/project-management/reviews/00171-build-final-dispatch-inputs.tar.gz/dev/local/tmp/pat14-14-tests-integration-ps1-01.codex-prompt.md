
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.ps1, original lines 1-565, segment 1/8. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
tests/integration.ps1:85: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:52']
tests/integration.ps1:212: DONE; targets=integration_graphql_jink::integration_17j1_jink_schema_create_tables
tests/integration.ps1:252: DONE; targets=integration_graphql_jink::integration_17j2_jink_config_singleton_and_link_crud
tests/integration.ps1:283: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:243']
tests/integration.ps1:302: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:262']
tests/integration.ps1:307: DONE; targets=integration_graphql_server::integration_18c_graphql_tag_queries
tests/integration.ps1:324: DONE; targets=integration_graphql_server::integration_18c2_updated_at_created_at_fields
tests/integration.ps1:343: DONE; targets=integration_graphql_server::integration_18d_search_filter_by_type_and_tag
tests/integration.ps1:370: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:335']
tests/integration.ps1:408: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:377']
tests/integration.ps1:456: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:429']
tests/integration.ps1:488: DONE; targets=integration_graphql_server::integration_18g_normalize_query_implicit_and_lowercase
tests/integration.ps1:506: DONE; targets=integration_graphql_server::integration_18h_in_query_field_filter_and_error_class

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.ps1 b/tests/integration.ps1
deleted file mode 100644
index 2f21127..0000000
--- a/tests/integration.ps1
+++ /dev/null
@@ -1,565 +0,0 @@
-#!/usr/bin/env pwsh
-
-# Integration tests: server, sync, CRDT conflicts, bundles, advanced SQL.
-# Runs smoke tests first, then continues with full integration suite.
-
-$ErrorActionPreference = "Stop"
-
-# --- Build + lint when DDB_BIN is not injected ---
-$prepLabel = "prebuilt binary"
-if (-not $env:DDB_BIN) {
-    cargo build --quiet
-    cargo clippy --workspace --quiet
-    cargo bench --no-run --quiet 2>$null
-    $prepLabel = "clippy + bench compile"
-}
-
-if ($env:DDB_BIN) {
-    $DDB = $env:DDB_BIN
-} else {
-    $meta = cargo metadata --format-version=1 --no-deps | ConvertFrom-Json
-    $DDB = Join-Path $meta.target_directory "debug" "ddb.exe"
-}
-$env:DDB_BIN = $DDB
-
-# --- Integration tests ---
-function New-TempDir {
-    $p = Join-Path ([System.IO.Path]::GetTempPath()) ([System.IO.Path]::GetRandomFileName())
-    New-Item -ItemType Directory -Path $p | Out-Null
-    return $p
-}
-
-$TMPDIR = New-TempDir
-$REMOTE_DIR = New-TempDir
-$NODE1_DIR = New-TempDir
-$NODE2_DIR = New-TempDir
-$NODE3_DIR = New-TempDir
-
-function Cleanup {
-    if ($env:CI) { return }
-    foreach ($d in @($TMPDIR, $REMOTE_DIR, $NODE1_DIR, $NODE2_DIR, $NODE3_DIR)) {
-        if (Test-Path $d) { Remove-Item -Recurse -Force $d -ErrorAction SilentlyContinue }
-    }
-    if ($script:STALE_REMOTE -and (Test-Path $script:STALE_REMOTE)) { Remove-Item -Recurse -Force $script:STALE_REMOTE -ErrorAction SilentlyContinue }
-    if ($script:STALE_N1 -and (Test-Path $script:STALE_N1)) { Remove-Item -Recurse -Force $script:STALE_N1 -ErrorAction SilentlyContinue }
-    if ($script:STALE_N2 -and (Test-Path $script:STALE_N2)) { Remove-Item -Recurse -Force $script:STALE_N2 -ErrorAction SilentlyContinue }
-}
-
-trap { Cleanup }
-
-# --- Run smoke tests first (after Cleanup is defined so trap can call it) ---
-$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
-& "$scriptDir/smoke.ps1"
-
-Push-Location $TMPDIR
-
-function pass($msg) { Write-Host "  ✓ $msg" }
-
-function ddb {
-    $raw = & $DDB @args 2>&1
-    $lines = @($raw) | ForEach-Object { "$_" -replace '\x1b\[[0-9;]*m', '' } |
-        Where-Object { $_ -notmatch '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}' -and $_ -ne '' }
-    $text = [string]::Join("`n", @($lines))
-    if ($LASTEXITCODE -ne 0) { throw "ddb $($args -join ' ') failed: $text" }
-    return $text
-}
-
-function ddb-fails {
-    & $DDB @args 2>&1 | Out-Null
-    return ($LASTEXITCODE -ne 0)
-}
-
-Write-Host "=== integration tests ==="
-
-# Init a repo for server and CLI integration tests
-ddb init . | Out-Null
-$ID1 = ddb create --title "First note" --tags "test,smoke" --body "Hello world"
-$ID2 = ddb create --title "Links to first" --body "See [[$ID1]]"
-ddb update $ID1 --title "First note (edited)" --tags "test,smoke,updated"
-ddb update $ID1 --body "- [ ] open task`n- [x] done task`n- [i] 2026-01-01 10:00 - info note"
-ddb reindex | Out-Null
-ddb query "CREATE TABLE foo (bar TEXT, baz INTEGER)" | Out-Null
-ddb query "INSERT INTO foo (title, bar, baz) VALUES ('for suggest', 'val', 1)" | Out-Null
-ddb register-node "integ-node" | Out-Null
-
-# 17. GraphQL server
-$SERVER_PORT = 19200 + (Get-Random -Maximum 800)
-$PG_PORT = $SERVER_PORT + 1
-$serverProc = Start-Process -FilePath $DDB -ArgumentList "serve","--port","$SERVER_PORT","--pg-port","$PG_PORT" -PassThru -NoNewWindow
-
-# Wait for server to start (re-read token each iteration since the server writes it on startup)
-$tokenPath = Join-Path $env:USERPROFILE ".config" "ddb" "token"
-
-for ($i = 0; $i -lt 20; $i++) {
-    try {
-        $TOKEN = if (Test-Path $tokenPath) { (Get-Content $tokenPath -Raw).Trim() } else { "" }
-        $null = Invoke-WebRequest -Uri "http://127.0.0.1:$SERVER_PORT/graphql" `
-            -Method POST -ContentType "application/json" `
-            -Headers @{ Authorization = "Bearer $TOKEN" } `
-            -Body '{"query":"{ typeDefs { name } }"}' -ErrorAction Stop
-        break
-    } catch {
-        Start-Sleep -Milliseconds 200
-    }
-}
-$TOKEN = if (Test-Path $tokenPath) { (Get-Content $tokenPath -Raw).Trim() } else { "" }
-
-$GQL_URL = "http://127.0.0.1:$SERVER_PORT/graphql"
-$REST_URL = "http://127.0.0.1:$SERVER_PORT/rest"
-
-function gql($body) {
-    $resp = Invoke-WebRequest -Uri $GQL_URL -Method POST -ContentType "application/json" `
-        -Headers @{ Authorization = "Bearer $TOKEN" } -Body $body -ErrorAction Stop
-    if ($resp.Content -is [byte[]]) { return [System.Text.Encoding]::UTF8.GetString($resp.Content) }
-    return $resp.Content
-}
-
-# Accepts a plain GraphQL query string; wraps it in a JSON envelope via
-# ConvertTo-Json so callers never hand-escape JSON inside PowerShell strings.
-function gqlq([string]$query) {
-    return gql (@{ query = $query } | ConvertTo-Json -Compress)
-}
-# Wait for the GraphQL schema to reload after a DDL statement. Polls
-# schemaVersion until it exceeds $before. Times out after 4 seconds (40 x 100ms).
-function waitSchemaReload([int]$before) {
-    for ($i = 0; $i -lt 40; $i++) {
-        $r = gqlq '{ schemaVersion }'
-        if ($r -match '"schemaVersion":(\d+)' -and [int]$Matches[1] -gt $before) { return }
-        Start-Sleep -Milliseconds 100
-    }
-    throw "waitSchemaReload: version did not advance past $before within 4s"
-}
-function ddl([string]$query) {
-    $r = gqlq '{ schemaVersion }'
-    $ver = if ($r -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-    gqlq $query | Out-Null
-    waitSchemaReload $ver
-}
-
-# Extract the "message" field of a successful executeSql response (which is the
-# new doogat id). Mirrors the bash extract_id helper for jink-port checks.
-function extractId([string]$response) {
-    $m = [regex]::Match($response, '"message":"([^"]+)"')
-    if ($m.Success) { return $m.Groups[1].Value }
-    return ""
-}
-
-# Assert that the given response contains "errors" (i.e. GraphQL rejected the
-# call). Throws on missing "errors" so set-style error handling kicks in.
-function assertGqlErrors([string]$response, [string]$context = "") {
-    if ($response -notmatch '"errors"') {
-        throw "assertGqlErrors$(if ($context) { " ($context)" }): response had no errors key`n  response: $response"
-    }
-}
-
-# Assert that the given response is a successful GraphQL response (has "data"
-# and no "errors"). Throws on either failure.
-function assertGqlOk([string]$response, [string]$context = "") {
-    if ($response -match '"errors"') {
-        throw "assertGqlOk$(if ($context) { " ($context)" }): response had errors`n  response: $response"
-    }
-    if ($response -notmatch '"data"') {
-        throw "assertGqlOk$(if ($context) { " ($context)" }): response had no data key`n  response: $response"
-    }
-}
-
-function rest {
-    param([string]$path, [string]$method = "GET", [string]$body = $null)
-    $params = @{
-        Uri = "$REST_URL$path"
-        Method = $method
-        ContentType = "application/json"
-        Headers = @{ Authorization = "Bearer $TOKEN" }
-        ErrorAction = "Stop"
-    }
-    if ($body) { $params.Body = $body }
-    $resp = Invoke-WebRequest @params
-    return $resp
-}
-
-function content($resp) {
-    if ($resp.Content -is [byte[]]) { return [System.Text.Encoding]::UTF8.GetString($resp.Content) }
-    return $resp.Content
-}
-
-
-# Test auth
-try {
-    Invoke-WebRequest -Uri $GQL_URL -Method POST -ContentType "application/json" `
-        -Body '{"query":"{ typeDefs { name } }"}' -ErrorAction Stop
-    throw "should have been 401"
-} catch {
-    if ($_.Exception.Response.StatusCode.value__ -ne 401) { throw "expected 401, got $($_.Exception.Response.StatusCode.value__)" }
-}
-pass "serve: auth rejects missing token"
-
-# Health endpoint (no auth required)
-$health = Invoke-RestMethod -Uri "http://127.0.0.1:$SERVER_PORT/health" -Method Get
-if ($health.status -ne "ok") { throw "health endpoint returned unexpected status: $($health.status)" }
-pass "serve: health endpoint"
-
-# Test query
-$result = gqlq '{ typeDefs { name } }'
-if ($result -notmatch '"typeDefs"') { throw "graphql query failed" }
-pass "serve: graphql query"
-
-# Test mutation -- create
-$result = gqlq 'mutation { createDoogat(input: { title: "Smoke Server" }) { id title } }'
-if ($result -notmatch '"Smoke Server"') { throw "graphql create failed" }
-$GQL_ID = if ($result -match '"id":"([^"]+)"') { $Matches[1] } else { throw "no id in response" }
-pass "serve: graphql create"
-
-# 17.J1 - Jink schema CREATE TABLE definitions (#9 jink full-sweep section 1).
-# Tables persist across sub-blocks 17.J2, 18z8, 18z9, 18z10 below. Do NOT
-# drop these in any sub-block other than the final cleanup in 18z10.
-$j1Link = gqlq 'mutation { executeSql(sql: "CREATE TABLE link (title VARCHAR(255) NOT NULL, url VARCHAR(255) NOT NULL, subtitle VARCHAR(255), favicon_path VARCHAR(255), favicon_origin VARCHAR(255), bookmark_source VARCHAR(255), last_opened_at VARCHAR(255), description TEXT)") { message } }'
-assertGqlOk $j1Link "j1 link create"
-if ($j1Link -notmatch '"message":"table link') { throw "j1: link create did not return 'table link'" }
-pass "j1: created link table"
-
-$j1Cat = gqlq 'mutation { executeSql(sql: "CREATE TABLE category (title VARCHAR(255) NOT NULL, fqn VARCHAR(255) NOT NULL, space VARCHAR(255) NOT NULL, sort_order INTEGER DEFAULT 0)") { message } }'
-assertGqlOk $j1Cat "j1 category create"
-if ($j1Cat -notmatch '"message":"table category') { throw "j1: category create did not return 'table category'" }
-pass "j1: created category table"
-
-$j1Cm = gqlq 'mutation { executeSql(sql: "CREATE TABLE \"category-membership\" (title VARCHAR(255) NOT NULL, link_id VARCHAR(255) NOT NULL, category_fqn VARCHAR(255) NOT NULL, pinned BOOLEAN DEFAULT FALSE, sort_order INTEGER DEFAULT 0, UNIQUE(link_id, category_fqn))") { message } }'
-assertGqlOk $j1Cm "j1 category-membership create"
-if ($j1Cm -notmatch '"message":"table category-membership') { throw "j1: category-membership create did not return expected message" }
-pass "j1: created category-membership table with composite UNIQUE"
-
-$j1Q = gqlq 'mutation { executeSql(sql: "CREATE TABLE quote (title VARCHAR(255) NOT NULL, author VARCHAR(255), source VARCHAR(255), favorited BOOLEAN DEFAULT FALSE, text TEXT)") { message } }'
-assertGqlOk $j1Q "j1 quote create"
-if ($j1Q -notmatch '"message":"table quote') { throw "j1: quote create did not return expected message" }
-pass "j1: created quote table"
-
-$j1Ss = gqlq 'mutation { executeSql(sql: "CREATE TABLE \"saved-search\" (title VARCHAR(255) NOT NULL, query_raw VARCHAR(255) NOT NULL, query_normalized VARCHAR(255) NOT NULL)") { message } }'
-assertGqlOk $j1Ss "j1 saved-search create"
-if ($j1Ss -notmatch '"message":"table saved-search') { throw "j1: saved-search create did not return expected message" }
-pass "j1: created saved-search table"
-
-$j1Pr = gqlq 'mutation { executeSql(sql: "CREATE TABLE \"pinned-result\" (title VARCHAR(255) NOT NULL, query_normalized VARCHAR(255) NOT NULL, link_id VARCHAR(255) NOT NULL, sort_order INTEGER DEFAULT 0)") { message } }'
-assertGqlOk $j1Pr "j1 pinned-result create"
-if ($j1Pr -notmatch '"message":"table pinned-result') { throw "j1: pinned-result create did not return expected message" }
-pass "j1: created pinned-result table"
-
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-$j1Jc = gqlq 'mutation { executeSql(sql: "CREATE TABLE \"jink-config\" (dashboard_title VARCHAR(255) DEFAULT ''Bobs Battlestation'', quote_rotation_minutes INTEGER DEFAULT 30, links_per_category INTEGER DEFAULT 8, frontend_version VARCHAR(255))") { message } }'
-assertGqlOk $j1Jc "j1 jink-config create"
-if ($j1Jc -notmatch '"message":"table jink-config') { throw "j1: jink-config create did not return expected message" }
-pass "j1: created jink-config table"
-waitSchemaReload $ver
-
-# 17.J2 - jink-config singleton + Link CRUD (#9 jink full-sweep sections 3-4).
-$j2JcEmpty = gqlq '{ sql(query: "SELECT id FROM \"jink-config\" LIMIT 1") { rows } }'
-assertGqlOk $j2JcEmpty "j2 jink-config empty select"
-if ($j2JcEmpty -notmatch '"rows"') { throw "j2: empty select missing rows" }
-pass "j2: SELECT from empty jink-config"
-
-$j2JcIns = gqlq 'mutation { executeSql(sql: "INSERT INTO \"jink-config\" (title, dashboard_title, quote_rotation_minutes, links_per_category) VALUES (''jink-config'', ''Bobs Battlestation'', 30, 8)") { message } }'
-assertGqlOk $j2JcIns "j2 jink-config insert"
-if ($j2JcIns -notmatch '"message":"\d+"') { throw "j2: jink-config insert did not return id" }
-pass "j2: INSERT jink-config singleton"
-
-$j2JcSel = gqlq '{ sql(query: "SELECT quote_rotation_minutes FROM \"jink-config\" LIMIT 1") { rows } }'
-assertGqlOk $j2JcSel "j2 jink-config select"
-if ($j2JcSel -notmatch '\\"30\\"') { throw "j2: SELECT did not return 30, got: $j2JcSel" }
-pass "j2: SELECT quote_rotation_minutes returns 30"
-
-$j2LinkIns = gqlq 'mutation { executeSql(sql: "INSERT INTO link (title, url, description) VALUES (''Test Link'', ''https://example.com'', ''a test link'')") { message } }'
-assertGqlOk $j2LinkIns "j2 link insert"
-$JINK_LINK_ID = extractId $j2LinkIns
-if (-not $JINK_LINK_ID) { throw "j2: could not extract JINK_LINK_ID from: $j2LinkIns" }
-pass "j2: INSERT link returns id"
-
-$j2LinkGql = gqlq "{ links(where: {id: {eq: `"$JINK_LINK_ID`"}}) { items { id title url description tags } } }"
-assertGqlOk $j2LinkGql "j2 link graphql query"
-if ($j2LinkGql -notmatch '"Test Link"') { throw "j2: GraphQL links query missing 'Test Link'" }
-pass "j2: query links via GraphQL"
-
-$j2LinkUpd = gqlq "mutation { executeSql(sql: `"UPDATE link SET favicon_path = 'favicon/x.png', favicon_origin = 'fetched' WHERE id = '$JINK_LINK_ID' AND url = 'https://example.com'`") { message affected } }"
-assertGqlOk $j2LinkUpd "j2 link update"
-pass "j2: UPDATE link favicon via compound-predicate SQL"
-
-# 18. expanded GraphQL operations
-$result = gqlq "mutation { updateDoogat(input: { id: `"$GQL_ID`", title: `"Smoke Updated`" }) { id title } }"
-if ($result -notmatch '"Smoke Updated"') { throw "graphql update failed" }
-pass "serve: graphql update"
-
-$result = gqlq '{ search(query: "Smoke") { totalCount hits { id title tags type fields created_at } } }'
-if ($result -notmatch '"search"') { throw "graphql search failed" }
-if ($result -notmatch '"tags"') { throw "graphql search missing tags" }
-if ($result -notmatch '"created_at"') { throw "graphql search missing created_at" }
-pass "serve: graphql search with enriched fields"
-
-$result = gqlq '{ doogats { id title } }'
-if ($result -notmatch '"doogats"') { throw "graphql doogats failed" }
-pass "serve: graphql doogats"
-
-$result = gqlq "mutation { deleteDoogat(id: `"$GQL_ID`") }"
-if ($result -notmatch "true") { throw "graphql delete failed" }
-pass "serve: graphql delete"
-
-# 18b. GraphQL checkbox queries
-$result = gqlq '{ openActions { state content } }'
-if ($result -notmatch '"openActions"') { throw "graphql openActions failed" }
-pass "serve: graphql openActions"
-
-# 18c. GraphQL tag queries
-$result = gqlq 'mutation { createDoogat(input: { title: "Tag Test", tags: ["alpha", "beta"] }) { id title tags } }'
-if ($result -notmatch '"alpha"') { throw "graphql create with tags failed" }
-$TAG_ID = if ($result -match '"id":"([^"]+)"') { $Matches[1] } else { throw "no tag id in response" }
-pass "serve: graphql create with tags"
-
-$result = gqlq '{ tags { name count } }'
-if ($result -notmatch '"alpha"') { throw "tags query missing alpha" }
-if ($result -notmatch '"beta"') { throw "tags query missing beta" }
-pass "serve: graphql tags query"
-
-$result = gqlq '{ doogats(tag: "alpha") { id title tags } }'
-if ($result -notmatch $TAG_ID) { throw "tag filter missing expected doogat" }
-pass "serve: graphql doogats tag filter"
-
-gqlq "mutation { deleteDoogat(id: `"$TAG_ID`") }" | Out-Null
-
-# 18c2. GraphQL updated_at and created_at fields
-$ts_result = gqlq 'mutation { createDoogat(input: { title: "Timestamp Test" }) { id } }'
-$TS_ID = if ($ts_result -match '"id":"([^"]+)"') { $Matches[1] }
-$ts_query = gqlq "{ doogat(id: `"$TS_ID`") { updated_at created_at date } }"
-if ($ts_query -notmatch '"updated_at"') { throw "missing updated_at" }
-if ($ts_query -notmatch '"created_at"') { throw "missing created_at" }
-pass "serve: graphql updated_at and created_at fields"
-
-$ts_date = if ($ts_query -match '"date":"([^"]+)"') { $Matches[1] }
-$ts_created = if ($ts_query -match '"created_at":"([^"]+)"') { $Matches[1] }
-if ($ts_date -ne $ts_created) { throw "created_at does not equal date" }
-pass "serve: created_at equals date"
-
-$ts_search = gqlq '{ search(query: "Timestamp Test") { hits { id updated_at } } }'
-if ($ts_search -notmatch '"updated_at"') { throw "search hit missing updated_at" }
-pass "serve: search hits include updated_at"
-
-gqlq "mutation { deleteDoogat(id: `"$TS_ID`") }" | Out-Null
-
-# 18d. GraphQL search filters
-# Section j1 above registered the `link` typedef with url NOT NULL, so typed
-# creates must supply url. SF2 stays untyped since `note` is not a registered
-# typedef and PRD 00129 rejects unregistered types from GraphQL createDoogat.
-$sf1 = gqlq 'mutation { createDoogat(input: { title: "SearchFilter Alpha", type: "link", tags: ["sf-tag"], fields: "{\"url\":\"https://example.com/sf1\"}" }) { id } }'
-$SF1_ID = if ($sf1 -match '"id":"([^"]+)"') { $Matches[1] }
-$sf2 = gqlq 'mutation { createDoogat(input: { title: "SearchFilter Beta", tags: ["sf-tag"] }) { id } }'
-$SF2_ID = if ($sf2 -match '"id":"([^"]+)"') { $Matches[1] }
-$sf3 = gqlq 'mutation { createDoogat(input: { title: "SearchFilter Gamma", type: "link", fields: "{\"url\":\"https://example.com/sf3\"}" }) { id } }'
-$SF3_ID = if ($sf3 -match '"id":"([^"]+)"') { $Matches[1] }
-
-$result = gqlq '{ search(query: "SearchFilter", types: ["link"]) { totalCount hits { id } } }'
-if ($result -notmatch '"totalCount":2') { throw "search type filter: expected 2, got $result" }
-pass "serve: search filter by type"
-
-$result = gqlq '{ search(query: "SearchFilter", tag: "sf-tag") { totalCount hits { id } } }'
-if ($result -notmatch '"totalCount":2') { throw "search tag filter: expected 2, got $result" }
-pass "serve: search filter by tag"
-
-$result = gqlq '{ search(query: "SearchFilter", types: ["link"], tag: "sf-tag") { totalCount hits { id } } }'
-if ($result -notmatch '"totalCount":1') { throw "search combined filter: expected 1, got $result" }
-pass "serve: search filter combined type+tag"
-
-gqlq "mutation { deleteDoogat(id: `"$SF1_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$SF2_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$SF3_ID`") }" | Out-Null
-
-# 18d2. Search where field filters (materialized columns + tag)
-gqlq 'mutation { executeSql(sql: "CREATE TABLE wflink (url TEXT NOT NULL)") { message } }' | Out-Null
-$wf1 = gqlq 'mutation { executeSql(sql: "INSERT INTO wflink (title, url) VALUES (''WFLink Alpha'', ''https://example.com'')") { message } }'
-$WF1_ID = if ($wf1 -match '"message":"([^"]+)"') { $Matches[1].Trim() }
-$wf2 = gqlq 'mutation { executeSql(sql: "INSERT INTO wflink (title, url) VALUES (''WFLink Beta'', ''https://other.org'')") { message } }'
-$WF2_ID = if ($wf2 -match '"message":"([^"]+)"') { $Matches[1].Trim() }
-$wf3 = gqlq 'mutation { executeSql(sql: "INSERT INTO wflink (title, url) VALUES (''WFLink Gamma'', ''https://example.com/page'')") { message } }'
-$WF3_ID = if ($wf3 -match '"message":"([^"]+)"') { $Matches[1].Trim() }
-
-$result = gqlq '{ search(query: "WFLink", where: [{field: "url", eq: "https://example.com"}]) { totalCount } }'
-if ($result -notmatch '"totalCount":1') { throw "search where eq: expected 1, got $result" }
-pass "serve: search where filter materialized column eq"
-
-$result = gqlq '{ search(query: "WFLink", where: [{field: "url", contains: "example"}]) { totalCount } }'
-if ($result -notmatch '"totalCount":2') { throw "search where contains: expected 2, got $result" }
-pass "serve: search where filter materialized column contains"
-
-# Tag via where filter
-$wft1 = gqlq 'mutation { createDoogat(input: { title: "WFTag Alpha", tags: ["wf-rust"] }) { id } }'
-$WFT1_ID = if ($wft1 -match '"id":"([^"]+)"') { $Matches[1] }
-$wft2 = gqlq 'mutation { createDoogat(input: { title: "WFTag Beta", tags: ["wf-python"] }) { id } }'
-$WFT2_ID = if ($wft2 -match '"id":"([^"]+)"') { $Matches[1] }
-
-$result = gqlq '{ search(query: "WFTag", where: [{field: "tag", eq: "wf-rust"}]) { totalCount } }'
-if ($result -notmatch '"totalCount":1') { throw "search where tag: expected 1, got $result" }
-pass "serve: search where filter tag eq"
-
-# Combined type + where field filter
-$result = gqlq '{ search(query: "WFLink", types: ["wflink"], where: [{field: "url", eq: "https://example.com"}]) { totalCount } }'
-if ($result -notmatch '"totalCount":1') { throw "search where type+field: expected 1, got $result" }
-pass "serve: search where filter combined type+field"
-
-gqlq "mutation { deleteDoogat(id: `"$WF1_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$WF2_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$WF3_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$WFT1_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$WFT2_ID`") }" | Out-Null
-
-# 18d3. Search where filter: in operator
-$in1 = gqlq 'mutation { createDoogat(input: { title: "InOp Alpha", tags: ["in-rust", "in-systems"] }) { id } }'
-$IN1_ID = if ($in1 -match '"id":"([^"]+)"') { $Matches[1] }
-$in2 = gqlq 'mutation { createDoogat(input: { title: "InOp Beta", tags: ["in-python"] }) { id } }'
-$IN2_ID = if ($in2 -match '"id":"([^"]+)"') { $Matches[1] }
-$in3 = gqlq 'mutation { createDoogat(input: { title: "InOp Gamma", tags: ["in-go"] }) { id } }'
-$IN3_ID = if ($in3 -match '"id":"([^"]+)"') { $Matches[1] }
-
-# in with multiple values — should match Alpha (in-rust) and Beta (in-python)
-$result = gqlq '{ search(query: "InOp", where: [{field: "tag", in: ["in-rust", "in-python"]}]) { totalCount hits { id } } }'
-if ($result -notmatch '"totalCount":2') { throw "search where in multi: expected 2, got $result" }
-if ($result -notmatch $IN1_ID) { throw "search where in multi: missing Alpha" }
-if ($result -notmatch $IN2_ID) { throw "search where in multi: missing Beta" }
-pass "serve: search where filter in operator (multiple values)"
-
-# in with single value — should match Gamma only
-$result = gqlq '{ search(query: "InOp", where: [{field: "tag", in: ["in-go"]}]) { totalCount } }'
-if ($result -notmatch '"totalCount":1') { throw "search where in single: expected 1, got $result" }
-pass "serve: search where filter in operator (single value)"
-
-# in with empty array — should match nothing
-$result = gqlq '{ search(query: "InOp", where: [{field: "tag", in: []}]) { totalCount } }'
-if ($result -notmatch '"totalCount":0') { throw "search where in empty: expected 0, got $result" }
-pass "serve: search where filter in operator (empty array)"
-
-# in on materialized column
-gqlq 'mutation { executeSql(sql: "CREATE TABLE inlink (url TEXT NOT NULL)") { message } }' | Out-Null
-$inl1 = gqlq 'mutation { executeSql(sql: "INSERT INTO inlink (title, url) VALUES (''InLink A'', ''https://a.example.com'')") { message } }'
-$INL1_ID = if ($inl1 -match '"message":"([^"]+)"') { $Matches[1].Trim() }
-$inl2 = gqlq 'mutation { executeSql(sql: "INSERT INTO inlink (title, url) VALUES (''InLink B'', ''https://b.example.com'')") { message } }'
-$INL2_ID = if ($inl2 -match '"message":"([^"]+)"') { $Matches[1].Trim() }
-$inl3 = gqlq 'mutation { executeSql(sql: "INSERT INTO inlink (title, url) VALUES (''InLink C'', ''https://c.example.com'')") { message } }'
-$INL3_ID = if ($inl3 -match '"message":"([^"]+)"') { $Matches[1].Trim() }
-
-$result = gqlq '{ search(query: "InLink", where: [{field: "url", in: ["https://a.example.com", "https://c.example.com"]}]) { totalCount hits { id } } }'
-if ($result -notmatch '"totalCount":2') { throw "search where in materialized: expected 2, got $result" }
-if ($result -notmatch $INL1_ID) { throw "search where in materialized: missing A" }
-if ($result -notmatch $INL3_ID) { throw "search where in materialized: missing C" }
-pass "serve: search where filter in operator (materialized column)"
-
-gqlq "mutation { deleteDoogat(id: `"$IN1_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$IN2_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$IN3_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$INL1_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$INL2_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$INL3_ID`") }" | Out-Null
-gqlq 'mutation { executeSql(sql: "DROP TABLE inlink CASCADE") { message } }' | Out-Null
-
-# 18e. Boolean and phrase search queries
-$bq1 = gqlq 'mutation { createDoogat(input: { title: "BoolSearch Rust CRDT", content: "rust crdt patterns" }) { id } }'
-$BQ1_ID = if ($bq1 -match '"id":"([^"]+)"') { $Matches[1] }
-$bq2 = gqlq 'mutation { createDoogat(input: { title: "BoolSearch Rust Only", content: "rust programming" }) { id } }'
-$BQ2_ID = if ($bq2 -match '"id":"([^"]+)"') { $Matches[1] }
-$bq3 = gqlq 'mutation { createDoogat(input: { title: "BoolSearch Golang", content: "golang programming" }) { id } }'
-$BQ3_ID = if ($bq3 -match '"id":"([^"]+)"') { $Matches[1] }
-
-$result = gqlq '{ search(query: "rust AND crdt") { totalCount } }'
-if ($result -notmatch '"totalCount":1') { throw "search AND: expected 1, got $result" }
-pass "serve: search boolean AND"
-
-$result = gqlq '{ search(query: "rust OR golang") { totalCount } }'
-if ($result -notmatch '"totalCount":3') { throw "search OR: expected 3, got $result" }
-pass "serve: search boolean OR"
-
-$result = gqlq '{ search(query: "rust NOT crdt") { totalCount } }'
-if ($result -notmatch '"totalCount":1') { throw "search NOT: expected 1, got $result" }
-pass "serve: search boolean NOT"
-
-$result = gqlq '{ search(query: "\"rust crdt\"") { totalCount } }'
-if ($result -notmatch '"totalCount":1') { throw "search phrase: expected 1, got $result" }
-pass "serve: search quoted phrase"
-
-$result = try { gqlq '{ search(query: "AND AND") { totalCount } }' } catch { $_.Exception.Message }
-if ($result -notmatch 'invalid search query') { throw "search malformed: expected error message, got $result" }
-pass "serve: search malformed query returns error"
-
-gqlq "mutation { deleteDoogat(id: `"$BQ1_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$BQ2_ID`") }" | Out-Null
-gqlq "mutation { deleteDoogat(id: `"$BQ3_ID`") }" | Out-Null
-
-# 18g. Search query normalization
-$result = gqlq '{ normalizeSearchQuery(query: "B AND A") }'
-if ($result -notmatch '"a and b"') { throw "normalizeSearchQuery sort: expected 'a and b', got $result" }
-pass "serve: normalizeSearchQuery sorts AND operands"
-
-$result = gqlq '{ normalizeSearchQuery(query: "Tag=svelte AND category=work.portals") }'
-if ($result -notmatch '"category=work.portals and tag=svelte"') { throw "normalizeSearchQuery fields: unexpected $result" }
-pass "serve: normalizeSearchQuery sorts field filters"
-
-$result = gqlq '{ normalizeSearchQuery(query: "  MEETING   Minutes  ") }'
-if ($result -notmatch '"meeting and minutes"') { throw "normalizeSearchQuery implicit AND: unexpected $result" }
-pass "serve: normalizeSearchQuery implicit AND and lowercase"
-
-$result = gqlq '{ search(query: "rust AND crdt") { queryNormalized } }'
-if ($result -notmatch '"queryNormalized"') { throw "search queryNormalized missing: $result" }
-if ($result -notmatch '"crdt and rust"') { throw "search queryNormalized value: unexpected $result" }
-pass "serve: search returns queryNormalized"
-
-# 18h. In-query field-filter alignment + error-class consistency (PRD 00121)
-$prd121a = gqlq 'mutation { createDoogat(input: { title: "PRD121 Alpha", tags: ["prd121-rust"] }) { id } }'
-$PRD121A_ID = if ($prd121a -match '"id":"([^"]+)"') { $Matches[1] }
-$prd121b = gqlq 'mutation { createDoogat(input: { title: "PRD121 Beta", tags: ["prd121-python"] }) { id } }'
-$PRD121B_ID = if ($prd121b -match '"id":"([^"]+)"') { $Matches[1] }
-$prd121g = gqlq 'mutation { createDoogat(input: { title: "PRD121 Gamma", tags: ["prd121-rust", "prd121-cli"] }) { id } }'
-$PRD121G_ID = if ($prd121g -match '"id":"([^"]+)"') { $Matches[1] }
-
-$result = gqlq '{ search(query: "tag=prd121-rust") { totalCount hits { id } } }'
-if ($result -notmatch '"totalCount":2') { throw "search in-query tag: expected 2, got $result" }
-pass "serve: search in-query tag filter returns matching set"
-
-$resultInq = gqlq '{ search(query: "tag=prd121-rust") { hits { id } } }'
-$resultWhere = gqlq '{ search(query: "", where: [{field: "tag", eq: "prd121-rust"}]) { hits { id } } }'
-$idsInq = [regex]::Matches($resultInq, '"id":"([^"]+)"') | ForEach-Object { $_.Groups[1].Value } | Sort-Object
-$idsWhere = [regex]::Matches($resultWhere, '"id":"([^"]+)"') | ForEach-Object { $_.Groups[1].Value } | Sort-Object
-if (($idsInq -join ',') -ne ($idsWhere -join ',')) {
-    throw "in-query vs where mismatch: inq=$($idsInq -join ',') where=$($idsWhere -join ',')"
-}
-pass "serve: in-query tag filter matches where-arg tag filter"
-
-$result = gqlq '{ search(query: "PRD121 tag=prd121-rust") { totalCount } }'
-if ($result -notmatch '"totalCount":2') { throw "search text AND tag: expected 2, got $result" }
-pass "serve: search text AND in-query tag filter"
-
-$result = gqlq '{ search(query: "tag=prd121-rust", where: [{field: "tag", eq: "prd121-python"}]) { totalCount } }'
-if ($result -notmatch '"totalCount":0') { throw "search intersect filters: expected 0, got $result" }
-pass "serve: search in-query + where tag filters intersect (AND)"
-
-$result = try { gqlq '{ search(query: "*") { totalCount } }' } catch { $_.Exception.Message }
-if ($result -notmatch 'invalid search query') { throw "bare asterisk: expected invalid search query, got $result" }
-if ($result -match 'internal error') { throw "bare asterisk: leaked internal error, got $result" }
-pass "serve: search bare asterisk returns bad request (not internal)"
-
-$result = try { gqlq '{ search(query: "**") { totalCount } }' } catch { $_.Exception.Message }
-if ($result -notmatch 'invalid search query') { throw "double asterisk: expected invalid search query, got $result" }
-if ($result -match 'internal error') { throw "double asterisk: leaked internal error, got $result" }
-pass "serve: search double asterisk returns bad request (not internal)"
-
-$result = try { gqlq '{ search(query: "(unbalanced") { totalCount } }' } catch { $_.Exception.Message }
-if ($result -notmatch 'invalid search query') { throw "unbalanced paren: expected invalid search query, got $result" }
-if ($result -match 'internal error') { throw "unbalanced paren: leaked internal error, got $result" }
-pass "serve: search unbalanced paren returns bad request (not internal)"
-
-$result = try { gqlq '{ search(query: "AND") { totalCount } }' } catch { $_.Exception.Message }
-if ($result -notmatch 'invalid search query') { throw "bare AND: expected invalid search query, got $result" }
-if ($result -match 'internal error') { throw "bare AND: leaked internal error, got $result" }
-pass "serve: search bare AND returns bad request (not internal)"
-
-$result = gqlq '{ normalizeSearchQuery(query: "tag=prd121-rust") }'
-if ($result -notmatch '"tag=prd121-rust"') { throw "normalizeSearchQuery in-query tag: unexpected $result" }
-pass "serve: normalizeSearchQuery preserves in-query tag filter"
-
-$normResult = gqlq '{ normalizeSearchQuery(query: "tag=prd121-rust AND category=work.dev") }'
-$normalized = if ($normResult -match '"normalizeSearchQuery":"([^"]+)"') { $Matches[1] }
-if ($normalized -ne 'category=work.dev and tag=prd121-rust') {
-    throw "normalizeSearchQuery round-trip: unexpected '$normalized'"
-}
-$result = gqlq "{ search(query: `"$normalized`") { totalCount } }"
-if ($result -match 'invalid search query') { throw "round-trip: invalid search query, got $result" }

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is GREEN on exact deletion SHA; both test and coverage jobs succeeded. Final Clippy passed (2m04s); cargo test-ci passed42CLI +1555core +222server, no failed/ignored tests. Three actual generic adversarial mutants were caught (two by focused tests, one by the full suite); final real-binary five-test control passed. All facades are neutralized. Task completion awaits this per-task review. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


