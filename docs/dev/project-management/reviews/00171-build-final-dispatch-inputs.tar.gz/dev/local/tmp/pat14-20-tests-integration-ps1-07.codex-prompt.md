
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.ps1, original lines 3096-3691, segment 7/8. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.ps1:3081: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3155']
tests/integration.ps1:3096: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3168']
tests/integration.ps1:3110: DONE; targets=integration_bundle::integration_28_delta_bundle_target_export
tests/integration.ps1:3125: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3193']
tests/integration.ps1:3144: DONE; targets=integration_update_bin::integration_29_update_bin_help_and_rollback
tests/integration.ps1:3155: DONE (no-match-semantics half only); targets=integration_sql_no_match::integration_30_where_id_no_match_semantics, sql_lifecycle::bulk_delete, sql_lifecycle::bulk_update
tests/integration.ps1:3205: DONE; targets=integration_sql_no_match::integration_30_f1_composite_unique_cli_rejection
tests/integration.ps1:3218: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3272']
tests/integration.ps1:3235: DONE; targets=integration_nosql_cli::integration_32_nosql_cli_commands
tests/integration.ps1:3252: DONE (byte-stats-report half only); targets=integration_compact_stats::integration_33_compact_byte_stats_report
tests/integration.ps1:3301: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3347']
tests/integration.ps1:3310: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3355']
tests/integration.ps1:3323: DONE; targets=integration_hyphenated_type::integration_36_hyphenated_type_create_table
tests/integration.ps1:3333: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3374']
tests/integration.ps1:3354: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3390']
tests/integration.ps1:3363: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3398']
tests/integration.ps1:3372: DONE (pre-existing, no port needed); targets=help::help_create_app_prints_guide, help::help_no_topic_lists_guides, help::help_unknown_topic_fails
tests/integration.ps1:3387: DONE; targets=integration_binary_lww::integration_40_binary_asset_lww
tests/integration.ps1:3438: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3464']
tests/integration.ps1:3466: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3488']
tests/integration.ps1:3498: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:3516']
tests/integration.ps1:3538: DONE (CREATE INDEX + CASCADE + cycle-detection halves only); targets=integration_typed_write_cli::integration_48_typed_write_blockers_and_cascade
tests/integration.ps1:3595: DONE; targets=integration_typed_write_cli::integration_49_unify_typed_write_paths
tests/integration.ps1:3633: DONE; targets=integration_typed_write_cli::integration_44_l_cli_create_auto_junction
tests/integration.ps1:3654: DONE (pre-existing, no port needed); targets=cli_create_fk_freshness::create_link_after_category_in_separate_process_succeeds_without_reindex
tests/integration.ps1:3678: DONE; targets=integration_id_poison::integration_62_id_minting_no_same_second_collision

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.ps1 b/tests/integration.ps1
deleted file mode 100644
index 2f21127..0000000
--- a/tests/integration.ps1
+++ /dev/null
@@ -3096,596 +0,0 @@
-# 27. bundle export --full + import
-Pop-Location  # NODE1_DIR
-ddb sync origin master | Out-Null
-ddb bundle export --full --output (Join-Path $TMPDIR "full-bundle.tar") | Out-Null
-
-Push-Location $NODE3_DIR
-ddb init . | Out-Null
-ddb register-node "Tablet" | Out-Null
-$output = ddb bundle import (Join-Path $TMPDIR "full-bundle.tar")
-if ($output -notmatch "imported") { throw "bundle import failed" }
-$output = ddb read $SYNC_ID
-if ($output -notmatch "laptop note") { throw "bundle content missing" }
-pass "bundle export --full + import"
-
-# 28. delta bundle export + import
-Pop-Location  # NODE1_DIR
-$DELTA_ID = ddb create --title "Delta note" --body "only in delta"
-
-$NODE2_UUID = Get-Content (Join-Path $NODE2_DIR ".git" "ddb-node") -Raw
-$NODE2_UUID = $NODE2_UUID.Trim()
-ddb bundle export --target $NODE2_UUID --output (Join-Path $TMPDIR "delta-bundle.tar") | Out-Null
-
-Push-Location $NODE2_DIR
-$output = ddb bundle import (Join-Path $TMPDIR "delta-bundle.tar")
-if ($output -notmatch "imported") { throw "delta import failed" }
-$output = ddb read $DELTA_ID
-if ($output -notmatch "Delta note") { throw "delta content missing" }
-pass "delta bundle export + import"
-
-# 28a. bundle-import conflict recovery — nodes diverge WITHOUT git-remote sync,
-# a real conflict is resolved through bundle import, and re-importing the same
-# bundle afterward is a no-op (PRD 00168)
-Push-Location $NODE1_DIR
-ddb update $SYNC_ID --title "Bundle Laptop Title" | Out-Null
-ddb bundle export --full --output (Join-Path $TMPDIR "conflict-bundle.tar") | Out-Null
-Pop-Location  # back to NODE2_DIR
-ddb update $SYNC_ID --title "Bundle Desktop Title" | Out-Null
-$importOut = ddb bundle import (Join-Path $TMPDIR "conflict-bundle.tar")
-if ($importOut -notmatch "imported: conflicts resolved: 1") { throw "bundle import conflict not resolved" }
-$titleOut = ddb read $SYNC_ID
-if ($titleOut -notmatch "Bundle Laptop Title|Bundle Desktop Title") { throw "bundle import title mismatch" }
-# re-importing the SAME bundle must not error: its commits are already
-# ancestors of local HEAD, so the merge classifies as already-up-to-date
-# and resolves zero (new) conflicts.
-$importOut2 = ddb bundle import (Join-Path $TMPDIR "conflict-bundle.tar")
-if ($importOut2 -notmatch "imported: conflicts resolved: 0") { throw "second bundle import should be no-op" }
-pass "bundle-import conflict recovery (real conflict resolved, second import no-op)"
-
-# 29. update-bin help + rollback
-$output = ddb update-bin --help
-if ($output -notmatch "Update ddb") { throw "update-bin help failed" }
-if ($output -notmatch "--rollback") { throw "update-bin help missing --rollback" }
-pass "update-bin --help (includes --rollback)"
-
-# rollback with no backup should fail gracefully (expected failure — bypass ddb wrapper)
-$rollbackOutput = & $DDB update-bin --rollback 2>&1 | ForEach-Object { "$_" }
-if (($rollbackOutput -join "`n") -notmatch "no backup") { throw "update-bin --rollback should report no backup" }
-pass "update-bin --rollback (no backup error)"
-
-# 30. ALTER TABLE + DROP TABLE + bulk UPDATE/DELETE
-Pop-Location  # back to TMPDIR
-Push-Location $TMPDIR
-
-$output = ddb query "CREATE TABLE smokealt (name TEXT, score INTEGER)"
-if ($output -notmatch "table smokealt created") { throw "create smokealt failed" }
-ddb query "INSERT INTO smokealt (name, score) VALUES ('a', 1)" | Out-Null
-Start-Sleep -Seconds 1
-ddb query "INSERT INTO smokealt (name, score) VALUES ('b', 2)" | Out-Null
-$output = ddb query "ALTER TABLE smokealt ADD COLUMN tag TEXT"
-if ($output -notmatch "altered") { throw "alter add failed" }
-$output = ddb query "SELECT name, tag FROM smokealt"
-if ($output -notmatch "NULL") { throw "null check failed" }
-$output = ddb query "ALTER TABLE smokealt RENAME COLUMN tag TO label"
-if ($output -notmatch "renamed") { throw "alter rename failed" }
-$output = ddb query "SELECT name, label FROM smokealt"
-if ($output -notmatch "a") { throw "select after rename failed" }
-$output = ddb query "UPDATE smokealt SET score = 99 WHERE name = 'a'"
-if ($output -notmatch "1 row\(s\) affected") { throw "bulk update failed" }
-$output = ddb query "DELETE FROM smokealt WHERE name = 'b'"
-if ($output -notmatch "1 row\(s\) affected") { throw "bulk delete failed" }
-$output = ddb query "DROP TABLE smokealt CASCADE"
-if ($output -notmatch "dropped") { throw "drop table failed" }
-pass "alter/drop table + bulk ops"
-
-# UPDATE/DELETE WHERE id no-match semantics (continuation of section 30, #5)
-$output = ddb query "CREATE TABLE smokenomatch (name TEXT, score INTEGER)"
-if ($output -notmatch "table smokenomatch created") { throw "create smokenomatch failed" }
-$nomatchId = ddb query "INSERT INTO smokenomatch (name, score) VALUES ('alpha', 1)"
-# B1: UPDATE with nonexistent id returns 0 rows affected (not an error)
-$output = ddb query "UPDATE smokenomatch SET score = 1 WHERE id = 'nonexistent_id_00000000000000'"
-if ($output -notmatch "0 row\(s\) affected") { throw "B1 update missing id failed: $output" }
-# B2: DELETE with nonexistent id returns 0 rows affected (not an error)
-$output = ddb query "DELETE FROM smokenomatch WHERE id = 'nonexistent_id_00000000000000'"
-if ($output -notmatch "0 row\(s\) affected") { throw "B2 delete missing id failed: $output" }
-# B3: IN clause mixing missing and valid ids still affects 1 row
-$output = ddb query "UPDATE smokenomatch SET score = 7 WHERE id IN ('nope', '$nomatchId')"
-if ($output -notmatch "1 row\(s\) affected") { throw "B3 IN-clause mixed failed: $output" }
-# B4: compound predicate with valid id + non-matching column returns 0 rows affected
-$output = ddb query "UPDATE smokenomatch SET score = 99 WHERE id = '$nomatchId' AND name = 'wrongname'"
-if ($output -notmatch "0 row\(s\) affected") { throw "B4 compound non-match failed: $output" }
-# B5: valid id on the fast path still affects 1 row
-$output = ddb query "UPDATE smokenomatch SET score = 42 WHERE id = '$nomatchId'"
-if ($output -notmatch "1 row\(s\) affected") { throw "B5 valid fast-path failed: $output" }
-$output = ddb query "SELECT score FROM smokenomatch WHERE id = '$nomatchId'"
-if ($output -notmatch "42") { throw "B5 materialized score mismatch: $output" }
-$output = ddb query "DROP TABLE smokenomatch CASCADE"
-if ($output -notmatch "dropped") { throw "drop smokenomatch failed" }
-pass "update/delete WHERE id no-match semantics (#5)"
-
-# 30.F1 - composite UNIQUE duplicate rejection surfaces a clear error on the
-# CLI (#9 group F1).
-$output = ddb query 'CREATE TABLE f1mship (title VARCHAR(255), link_id VARCHAR(255), category VARCHAR(255), UNIQUE(link_id, category))'
-if ($output -notmatch "table f1mship created") { throw "f1mship create failed" }
-ddb query "INSERT INTO f1mship (title, link_id, category) VALUES ('a', 'link1', 'cat1')" | Out-Null
-$f1Dup = & $DDB query "INSERT INTO f1mship (title, link_id, category) VALUES ('b', 'link1', 'cat1')" 2>&1 | Out-String
-if ($LASTEXITCODE -eq 0) { throw "30.F1: duplicate INSERT should have failed, got: $f1Dup" }
-if ($f1Dup -notmatch "UNIQUE") { throw "30.F1: duplicate INSERT should mention UNIQUE: $f1Dup" }
-if ($f1Dup -notmatch "f1mship|link_id|category") { throw "30.F1: error should mention table/col: $f1Dup" }
-$output = ddb query "DROP TABLE f1mship CASCADE"
-if ($output -notmatch "dropped") { throw "f1mship drop failed" }
-pass "issue-9-F1: composite UNIQUE duplicate rejected with clear error"
-
-# 31. file attachments
-$attachFile = Join-Path $TMPDIR "ddb-smoke-attach.txt"
-Set-Content $attachFile -Value "hello attachment"
-$output = ddb attach $ID1 $attachFile
-if ($output -notmatch "attached") { throw "attach failed" }
-$output = ddb attachments $ID1
-if ($output -notmatch "ddb-smoke-attach.txt") { throw "attachments list failed" }
-if ($output -notmatch "text/plain") { throw "mime type wrong" }
-$output = ddb query "SELECT name, mime FROM _ddb_attachments WHERE doogat_id = '$ID1'"
-if ($output -notmatch "ddb-smoke-attach.txt") { throw "attach query failed" }
-$output = ddb detach $ID1 "ddb-smoke-attach.txt"
-if ($output -notmatch "detached") { throw "detach failed" }
-$output = ddb attachments $ID1
-if ($output -notmatch "no attachments") { throw "post-detach failed" }
-Remove-Item $attachFile -ErrorAction SilentlyContinue
-pass "file attachments (attach/list/query/detach)"
-
-# 32. NoSQL CLI commands
-$output = ddb get $ID1
-if ($output -notmatch "First note \(edited\)") { throw "nosql get failed" }
-pass "nosql: get"
-
-$output = ddb scan --tag test
-if ($output -notmatch $ID1) { throw "nosql scan --tag failed" }
-pass "nosql: scan --tag"
-
-$output = ddb scan --type foo
-if ($output -notmatch "(?m)^\d{14}$") { throw "nosql scan --type failed" }
-pass "nosql: scan --type"
-
-$output = ddb backlinks $ID1
-if ($output -notmatch $ID2) { throw "nosql backlinks failed" }
-pass "nosql: backlinks"
-
-# 33. stale node resync after compaction
-Write-Host "=== stale node resync ==="
-$script:STALE_REMOTE = New-TempDir
-$script:STALE_N1 = New-TempDir
-$script:STALE_N2 = New-TempDir
-
-git init --bare $script:STALE_REMOTE 2>&1 | Out-Null
-
-Push-Location $script:STALE_N1
-ddb init . | Out-Null
-git remote add origin $script:STALE_REMOTE
-ddb register-node "StaleNode1" | Out-Null
-$STALE_ID = ddb create --title "Stale shared" --body "original content"
-git push -u origin master 2>&1 | Out-Null
-
-git clone $script:STALE_REMOTE $script:STALE_N2 2>&1 | Out-Null
-Push-Location $script:STALE_N2
-ddb reindex | Out-Null
-ddb register-node "StaleNode2" | Out-Null
-
-# Both nodes edit the same doogat
-Pop-Location  # STALE_N1
-ddb update $STALE_ID --body "body from node1"
-git push origin master 2>&1 | Out-Null
-
-Push-Location $script:STALE_N2
-ddb update $STALE_ID --body "body from node2"
-ddb sync origin master | Out-Null
-
-# Compact to remove CRDT temp files — verify report includes byte stats
-$compactOut = ddb compact --force
-if ($compactOut -notmatch "crdt temp:") { throw "compact missing crdt temp stats in stale test" }
-if ($compactOut -notmatch "repo \(\.git\):") { throw "compact missing repo stats in stale test" }
-
-# Create another conflict without CRDT state
-Pop-Location  # STALE_N1
-ddb sync origin master | Out-Null
-ddb update $STALE_ID --body "second edit node1"
-git push origin master 2>&1 | Out-Null
-
-Push-Location $script:STALE_N2
-ddb update $STALE_ID --body "second edit node2"
-ddb sync origin master | Out-Null
-
-# Verify doogat is readable and valid
-$output = ddb read $STALE_ID
-if ($output -notmatch "title:") { throw "stale resync failed" }
-pass "stale node resync after compaction"
-
-# 34. multi-row INSERT
-Push-Location $TMPDIR
-ddb query "CREATE TABLE multirow (name TEXT, val INTEGER)" | Out-Null
-$MULTI_IDS = ddb query "INSERT INTO multirow (name, val) VALUES ('a', 1), ('b', 2), ('c', 3)"
-if ($MULTI_IDS -notmatch "(?m)^\d{14},\d{14},\d{14}$") { throw "multi-row insert did not return 3 IDs: $MULTI_IDS" }
-$count = ddb query "SELECT COUNT(*) FROM multirow"
-if ($count -notmatch "3") { throw "expected 3 rows, got: $count" }
-pass "multi-row insert"
-
-# 35. transaction commit + rollback
-Push-Location $TMPDIR
-ddb query "CREATE TABLE txntest (val TEXT)" | Out-Null
-$txnOut = ddb query "BEGIN; INSERT INTO txntest (val) VALUES ('committed'); COMMIT"
-if ($txnOut -notmatch "COMMIT") { throw "transaction commit failed: $txnOut" }
-$txnSel = ddb query "SELECT val FROM txntest"
-if ($txnSel -notmatch "committed") { throw "committed row missing" }
-$rbOut = ddb query "BEGIN; INSERT INTO txntest (val) VALUES ('rolled-back'); ROLLBACK"
-if ($rbOut -notmatch "ROLLBACK") { throw "rollback failed: $rbOut" }
-$txnCount = ddb query "SELECT COUNT(*) FROM txntest"
-if ($txnCount -notmatch "1") { throw "expected 1 row after rollback, got: $txnCount" }
-pass "transaction commit + rollback"
-
-# 36. hyphenated type SQL via quoted identifiers
-Push-Location $TMPDIR
-ddb query 'CREATE TABLE "my-type" (label TEXT)' | Out-Null
-$MY_ID = ddb query "INSERT INTO `"my-type`" (label) VALUES ('test')"
-$hSel = ddb query "SELECT label FROM `"my-type`""
-if ($hSel -notmatch "test") { throw "hyphenated select failed" }
-$hDel = ddb query "DELETE FROM `"my-type`" WHERE id = '$MY_ID'"
-if ($hDel -notmatch "1 row") { throw "hyphenated delete failed: $hDel" }
-pass "hyphenated type SQL"
-
-# 37. junction table CRUD (multi-value references)
-Push-Location $TMPDIR
-ddb query "CREATE TABLE jtag (name VARCHAR(100))" | Out-Null
-ddb query "CREATE TABLE jpost (url TEXT, jtag TEXT REFERENCES jtag)" | Out-Null
-$JT_TAG_ID = ddb query "INSERT INTO jtag (name) VALUES ('rust')"
-Start-Sleep -Seconds 1
-$JT_POST_ID = ddb query "INSERT INTO jpost (url) VALUES ('https://example.com')"
-$jtIns = ddb query "INSERT INTO jpost_jtag (jpost_id, jtag_id) VALUES ('$JT_POST_ID', '$JT_TAG_ID')"
-if ($jtIns -notmatch "1 row") { throw "junction insert failed: $jtIns" }
-$jtSel = ddb query "SELECT jtag_id FROM jpost_jtag WHERE jpost_id = '$JT_POST_ID'"
-if ($jtSel -notmatch $JT_TAG_ID) { throw "junction select failed: $jtSel" }
-$jtDel = ddb query "DELETE FROM jpost_jtag WHERE jpost_id = '$JT_POST_ID' AND jtag_id = '$JT_TAG_ID'"
-if ($jtDel -notmatch "1 row") { throw "junction delete failed: $jtDel" }
-$jtCount = ddb query "SELECT COUNT(*) FROM jpost_jtag"
-if ($jtCount -notmatch "0") { throw "junction not empty after delete: $jtCount" }
-ddb query "INSERT INTO jpost_jtag (jpost_id, jtag_id) VALUES ('$JT_POST_ID', '$JT_TAG_ID')" | Out-Null
-$jtDrop = ddb query "DROP TABLE jpost CASCADE"
-if ($jtDrop -notmatch "dropped") { throw "cascade drop failed: $jtDrop" }
-if (-not (ddb-fails query "SELECT * FROM jpost_jtag")) { throw "junction table should not exist after cascade" }
-pass "junction table CRUD"
-
-# 38. title template compliance check
-Push-Location $TMPDIR
-ddb query "CREATE TABLE smwidget (name VARCHAR(100), description TEXT)" | Out-Null
-ddb query "ALTER TABLE smwidget SET TITLE TEMPLATE '{name} Widget'" | Out-Null
-ddb query "INSERT INTO smwidget (name, description) VALUES ('Foo', 'A foo widget')" | Out-Null
-$fixVerbose = ddb fix --verbose --dry-run
-if ($fixVerbose -notmatch "title does not match template") { throw "title compliance not reported" }
-pass "title template compliance check"
-
-# 39. zone migration
-Push-Location $TMPDIR
-ddb query "CREATE TABLE gadget (notes TEXT)" | Out-Null
-ddb query "INSERT INTO gadget (notes) VALUES ('Some notes')" | Out-Null
-ddb query "ALTER TABLE gadget SET ZONE frontmatter FOR notes" | Out-Null
-$fixMigrate = ddb fix --migrate --verbose
-if ($fixMigrate -notmatch "zone-migrated") { throw "zone migration not reported: $fixMigrate" }
-pass "zone migration"
-
-# 40. help guides
-$helpOut = ddb help create-app
-if ($helpOut -notmatch "CREATE TABLE") { throw "help create-app missing CREATE TABLE" }
-pass "help create-app"
-$helpList = ddb help
-if ($helpList -notmatch "create-app") { throw "help list missing create-app" }
-pass "help list"
-$helpFail = $null
-try { ddb help nonexistent 2>$null } catch { $helpFail = $true }
-if (-not $helpFail) {
-    # Also check exit code via $LASTEXITCODE for native commands
-    if ($LASTEXITCODE -eq 0) { throw "help unknown should fail" }
-}
-pass "help unknown fails"
-
-# 40. binary asset LWW conflict resolution
-Write-Host "=== binary asset LWW ==="
-$BIN_REMOTE = New-TempDir
-$BIN_NODE1 = New-TempDir
-$BIN_NODE2 = New-TempDir
-git init --bare $BIN_REMOTE 2>$null | Out-Null
-
-Push-Location $BIN_NODE1
-ddb init . | Out-Null
-git remote add origin $BIN_REMOTE
-ddb register-node "BinNode1" | Out-Null
-$binId = ddb create --title "Binary test"
-New-Item -ItemType Directory -Force -Path "reference/test" | Out-Null
-[System.IO.File]::WriteAllBytes("$BIN_NODE1/reference/test/photo.bin", [byte[]](0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A))
-git add reference/test/photo.bin
-git commit -m "add binary asset" 2>$null | Out-Null
-git push -u origin master 2>$null | Out-Null
-
-git clone $BIN_REMOTE $BIN_NODE2 2>$null | Out-Null
-Push-Location $BIN_NODE2
-ddb reindex | Out-Null
-ddb register-node "BinNode2" | Out-Null
-Pop-Location
-
-# Node1: modify binary with higher HLC
-# Trailer uses the real load-bearing `HLC: {wall_ms}-{counter:04}-{node}` format read by extract_hlc (PRD 00166).
-[System.IO.File]::WriteAllText("$BIN_NODE1/reference/test/photo.bin", "NODE1_WINS_CONTENT")
-git add reference/test/photo.bin
-git commit -m "node1 update binary`n`nHLC: 9999999999999-0000-BinNode1" 2>$null | Out-Null
-git push origin master 2>$null | Out-Null
-
-# Node2: modify same binary with lower HLC
-Push-Location $BIN_NODE2
-[System.IO.File]::WriteAllText("$BIN_NODE2/reference/test/photo.bin", "NODE2_LOSES_CONTENT")
-git add reference/test/photo.bin
-git commit -m "node2 update binary`n`nHLC: 1000000000000-0000-BinNode2" 2>$null | Out-Null
-
-$syncOut = ddb sync origin master
-if ($syncOut -notmatch "conflicts resolved: 1") { throw "expected 1 conflict resolved: $syncOut" }
-$resolved = [System.IO.File]::ReadAllText("$BIN_NODE2/reference/test/photo.bin")
-if ($resolved -ne "NODE1_WINS_CONTENT") { throw "LWW winner wrong: $resolved" }
-pass "binary asset LWW (higher HLC wins)"
-
-$mergeLog = git log --merges --oneline -1
-if ($mergeLog -notmatch "resolve merge") { throw "no merge commit found: $mergeLog" }
-pass "binary asset LWW (loser preserved in history)"
-Pop-Location
-Pop-Location
-
-Remove-Item -Recurse -Force $BIN_REMOTE, $BIN_NODE1, $BIN_NODE2
-
-# 41. auto-register node on first sync
-$AR_REMOTE = New-TempDir
-$AR_NODE = New-TempDir
-git init --bare $AR_REMOTE 2>$null | Out-Null
-ddb init $AR_NODE | Out-Null
-Push-Location $AR_NODE
-git remote add origin $AR_REMOTE
-git push -u origin master 2>$null | Out-Null
-
-# No register-node — sync should auto-register
-if (Test-Path ".git/ddb-node") { throw "node file should not exist before sync" }
-ddb sync origin master | Out-Null
-if (-not (Test-Path ".git/ddb-node")) { throw "auto-register should create .git/ddb-node" }
-pass "auto-register node on first sync"
-
-# Subsequent sync reuses registration
-$uuidBefore = Get-Content ".git/ddb-node"
-ddb sync origin master | Out-Null
-$uuidAfter = Get-Content ".git/ddb-node"
-if ($uuidBefore -ne $uuidAfter) { throw "existing registration should be reused" }
-pass "auto-register reuses existing registration"
-
-Pop-Location
-Remove-Item -Recurse -Force $AR_REMOTE, $AR_NODE
-
-# Return to original directory
-Set-Location $TMPDIR
-
-# 46. title_template REFERENCES resolution (PRD 00127).
-# Server has been down since section 28, so use the CLI directly.
-Write-Host "=== title_template REFERENCES resolution ==="
-$TT_DIR = New-Item -ItemType Directory -Path (Join-Path $env:TEMP ([guid]::NewGuid().ToString())) | ForEach-Object { $_.FullName }
-Push-Location $TT_DIR
-ddb init | Out-Null
-ddb query "CREATE TABLE tt_link (url TEXT)" | Out-Null
-ddb query "CREATE TABLE tt_category (fqn TEXT)" | Out-Null
-ddb query "CREATE TABLE tt_membership (link TEXT REFERENCES tt_link, category TEXT REFERENCES tt_category)" | Out-Null
-ddb query "ALTER TABLE tt_membership SET TITLE TEMPLATE '{link.title} in {category.fqn}'" | Out-Null
-pass "46: declared dotted title_template"
-
-$ttLinkId = (ddb query "INSERT INTO tt_link (title, url) VALUES ('My Link', 'https://x')").Trim()
-Start-Sleep -Seconds 1
-$ttCatId = (ddb query "INSERT INTO tt_category (title, fqn) VALUES ('Cat', 'A/B')").Trim()
-Start-Sleep -Seconds 1
-$ttMemId = (ddb query "INSERT INTO tt_membership (link, category) VALUES ('$ttLinkId', '$ttCatId')").Trim()
-$titleRow = ddb query "SELECT title FROM tt_membership WHERE id = '$ttMemId'"
-if ($titleRow -notmatch "My Link in A/B") { throw "46: composed title missing: $titleRow" }
-pass "46: composed title 'My Link in A/B' from REFERENCES"
-
-# Call $DDB directly (the `ddb` wrapper throws on non-zero exit) and flatten
-# stderr+stdout with Out-String so -match operates on a single string instead
-# of a per-line array (where -notmatch returns non-matching elements, not a
-# bool).
-$badOut = & $DDB query "ALTER TABLE tt_membership SET TITLE TEMPLATE '{link.does_not_exist}'" 2>&1 | Out-String
-if ($badOut -notmatch "does not exist on tt_link") { throw "46: bad path was not rejected: $badOut" }
-pass "46: ALTER TABLE rejects bad dotted path"
-
-Pop-Location
-Remove-Item -Recurse -Force $TT_DIR
-
-# 47. ALTER TABLE ALTER COLUMN TYPE (PRD 00128).
-Write-Host "=== ALTER TABLE ALTER COLUMN TYPE ==="
-$AC_DIR = New-Item -ItemType Directory -Path (Join-Path $env:TEMP ([guid]::NewGuid().ToString())) | ForEach-Object { $_.FullName }
-Push-Location $AC_DIR
-ddb init | Out-Null
-ddb query "CREATE TABLE ac_link (url VARCHAR(32))" | Out-Null
-
-$acShort = 'a' * 32
-$acId1 = (ddb query "INSERT INTO ac_link (title, url) VALUES ('boundary', '$acShort')").Trim()
-if (-not $acId1) { throw "47: expected boundary insert to return an id" }
-pass "47: baseline VARCHAR(32) insert at boundary"
-
-$acLong = 'b' * 80
-$acFailOut = & $DDB query "INSERT INTO ac_link (title, url) VALUES ('toolong', '$acLong')" 2>&1 | Out-String
-if ($acFailOut -notmatch "exceeds limit") { throw "47: pre-ALTER 80-char insert should have been rejected: $acFailOut" }
-pass "47: pre-ALTER INSERT rejects 80-char value for VARCHAR(32)"
-
-ddb query "ALTER TABLE ac_link ALTER COLUMN url TYPE VARCHAR(100)" | Out-Null
-pass "47: widen VARCHAR(32) -> VARCHAR(100) succeeds"
-
-Start-Sleep -Seconds 1
-$acId2 = (ddb query "INSERT INTO ac_link (title, url) VALUES ('now-ok', '$acLong')").Trim()
-if (-not $acId2) { throw "47: post-ALTER 80-char insert should succeed" }
-pass "47: post-ALTER INSERT accepts 80-char value"
-
-$acNarrowOut = & $DDB query "ALTER TABLE ac_link ALTER COLUMN url TYPE VARCHAR(5)" 2>&1 | Out-String
-if ($acNarrowOut -notmatch "cannot narrow") { throw "47: narrowing should emit 'cannot narrow': $acNarrowOut" }
-if ($acNarrowOut -notmatch "existing rows exceed limit") { throw "47: narrowing should include row-count message: $acNarrowOut" }
-pass "47: narrowing rejects with cannot-narrow row-count message"
-
-ddb query "ALTER TABLE ac_link ALTER COLUMN url TYPE TEXT" | Out-Null
-Start-Sleep -Seconds 1
-$acHuge = 'c' * 2000
-$acId3 = (ddb query "INSERT INTO ac_link (title, url) VALUES ('text-row', '$acHuge')").Trim()
-if (-not $acId3) { throw "47: 2000-char insert should succeed after widening to TEXT" }
-pass "47: VARCHAR -> TEXT widening persists and accepts long values"
-
-Pop-Location
-Remove-Item -Recurse -Force $AC_DIR
-
-# 48. PRD 00129: typed write blockers + ON DELETE CASCADE + INDEX no-op.
-Write-Host "=== PRD 00129: typed write blockers + ON DELETE CASCADE + INDEX no-op ==="
-$P9_DIR = New-TempDir
-Push-Location $P9_DIR
-ddb init | Out-Null
-
-# §3b: CREATE INDEX IF NOT EXISTS is accepted as a no-op.
-ddb query "CREATE TABLE p9_link (title TEXT, url VARCHAR(255))" | Out-Null
-$p9IndexOut = ddb query "CREATE INDEX IF NOT EXISTS idx_p9_url ON p9_link(url)" 2>&1
-if ($p9IndexOut -notmatch "ignored") { throw "48: CREATE INDEX IF NOT EXISTS should emit 'ignored': $p9IndexOut" }
-pass "48: CREATE INDEX IF NOT EXISTS accepted as no-op"
-
-$p9PlainOut = & $DDB query "CREATE INDEX idx_plain ON p9_link(url)" 2>&1 | Out-String
-if ($p9PlainOut -notmatch "CREATE INDEX not supported") { throw "48: plain CREATE INDEX should reject: $p9PlainOut" }
-pass "48: plain CREATE INDEX still rejects"
-
-# §2: ON DELETE CASCADE walks one level.
-ddb query "CREATE TABLE p9_membership (title TEXT, link VARCHAR(255) REFERENCES p9_link(id) ON DELETE CASCADE)" | Out-Null
-$p9LinkId = (ddb query "INSERT INTO p9_link (title, url) VALUES ('Parent', 'https://x')").Trim()
-Start-Sleep -Seconds 1
-$p9MemId = (ddb query "INSERT INTO p9_membership (title, link) VALUES ('Child', '$p9LinkId')").Trim()
-if (-not $p9MemId) { throw "48: typed insert into cascade-bound child failed" }
-pass "48: typed insert into cascade-bound child succeeds"
-
-ddb delete $p9LinkId | Out-Null
-$p9AfterLink = ddb query "SELECT id FROM p9_link WHERE id = '$p9LinkId'" 2>&1
-$p9AfterMem = ddb query "SELECT id FROM p9_membership WHERE id = '$p9MemId'" 2>&1
-if ($p9AfterLink -match $p9LinkId) { throw "48: parent should be gone after CASCADE delete" }
-if ($p9AfterMem -match $p9MemId) { throw "48: child should be gone after CASCADE delete" }
-pass "48: ON DELETE CASCADE removes parent and child in one delete"
-
-# §2: ON DELETE RESTRICT (default) blocks parent delete.
-ddb query "CREATE TABLE p9_blocker (title TEXT, link VARCHAR(255) NOT NULL REFERENCES p9_link(id))" | Out-Null
-$p9LinkId2 = (ddb query "INSERT INTO p9_link (title, url) VALUES ('R Parent', 'https://r')").Trim()
-Start-Sleep -Seconds 1
-ddb query "INSERT INTO p9_blocker (title, link) VALUES ('Block', '$p9LinkId2')" | Out-Null
-$p9RestrictOut = & $DDB delete $p9LinkId2 2>&1 | Out-String
-if ($p9RestrictOut -notmatch "NOT NULL REFERENCES from p9_blocker.link") { throw "48: RESTRICT should block parent delete: $p9RestrictOut" }
-pass "48: ON DELETE RESTRICT (default) rejects parent delete"
-
-# §2: cascade cycle detection.
-ddb query "CREATE TABLE p9_a (title TEXT)" | Out-Null
-ddb query "CREATE TABLE p9_b (title TEXT)" | Out-Null
-ddb query "ALTER TABLE p9_a ADD COLUMN b VARCHAR(255) REFERENCES p9_b(id) ON DELETE CASCADE" | Out-Null
-ddb query "ALTER TABLE p9_b ADD COLUMN a VARCHAR(255) REFERENCES p9_a(id) ON DELETE CASCADE" | Out-Null
-$p9AId = (ddb query "INSERT INTO p9_a (title) VALUES ('A')").Trim()
-Start-Sleep -Seconds 1
-$p9BId = (ddb query "INSERT INTO p9_b (title) VALUES ('B')").Trim()
-ddb query "UPDATE p9_a SET b = '$p9BId' WHERE id = '$p9AId'" | Out-Null
-ddb query "UPDATE p9_b SET a = '$p9AId' WHERE id = '$p9BId'" | Out-Null
-$p9CycleOut = & $DDB delete $p9AId 2>&1 | Out-String
-if ($p9CycleOut -notmatch "cascade delete would form a cycle") { throw "48: cycle should be detected: $p9CycleOut" }
-pass "48: ON DELETE CASCADE cycle detection rejects"
-
-Pop-Location
-Remove-Item -Recurse -Force $P9_DIR
-
-# 49. PRD 00133 unify-typed-write-paths: CLI typed `create` on a registered
-# typedef must populate the reference zone for REFERENCES columns and reject
-# FK to wrong-type ids. Unit-test suite covers GraphQL parity end-to-end
-# (`service::tests::batch_create_*`, `create_doogat_with_extra_*`); this
-# section drives the CLI/FFI surface so cross-shell regressions surface in CI.
-Write-Host "=== PRD 00133: unified typed-write paths (CLI parity) ==="
-$TW_DIR = New-TempDir
-Push-Location $TW_DIR
-ddb init | Out-Null
-ddb query "CREATE TABLE tw_category (label VARCHAR(64))" | Out-Null
-$twCat1 = (ddb query "INSERT INTO tw_category (title, label) VALUES ('c1', 'alpha')").Trim()
-Start-Sleep -Seconds 1
-$twCat2 = (ddb query "INSERT INTO tw_category (title, label) VALUES ('c2', 'beta')").Trim()
-if (-not $twCat1 -or -not $twCat2) { throw "49: failed to seed tw_category rows" }
-pass "49: junction typedef setup with two category rows"
-
-ddb query "CREATE TABLE tw_membership (link VARCHAR(64) REFERENCES tw_category, parent VARCHAR(64) REFERENCES tw_category)" | Out-Null
-Start-Sleep -Seconds 1
-$twMemId = (ddb create --type tw_membership --title "M1" --set "link=$twCat1" --set "parent=$twCat2").Trim()
-if (-not $twMemId) { throw "49: CLI create on junction typedef returned empty id" }
-pass "49: CLI create on junction-style typedef succeeds"
-
-$twRaw = (ddb get $twMemId | Out-String)
-if ($twRaw -notmatch [regex]::Escape("link:: [[$twCat1]]")) { throw "49: link reference zone missing: $twRaw" }
-if ($twRaw -notmatch [regex]::Escape("parent:: [[$twCat2]]")) { throw "49: parent reference zone missing: $twRaw" }
-pass "49: CLI create populates reference zone for REFERENCES columns"
-
-ddb query "CREATE TABLE tw_link (label VARCHAR(64))" | Out-Null
-Start-Sleep -Seconds 1
-$twLinkId = (ddb query "INSERT INTO tw_link (title, label) VALUES ('not a category', 'plain')").Trim()
-if (-not $twLinkId) { throw "49: tw_link seed failed" }
-$twBadOut = (& $DDB create --type tw_membership --title "Bogus" --set "link=$twLinkId" --set "parent=$twCat1" 2>&1 | Out-String)
-if ($twBadOut -notmatch "references non-existent tw_category") { throw "49: expected wrong-type FK rejection, got: $twBadOut" }
-pass "49: CLI create rejects FK to wrong-type id"
-
-Pop-Location
-Remove-Item -Recurse -Force $TW_DIR
-
-# 44.L - CLI ddb create populates auto-junction atomically (PRD 00134
-# cycle-1 review C1 task #4). Mirrors bash section 44.L through the CLI/FFI
-# entry point so the typed materialization path is exercised end-to-end
-# across surfaces. Unit tests cover the service-layer typed-create.
-$J134L_DIR = New-TempDir
-Push-Location $J134L_DIR
-ddb init | Out-Null
-ddb query "CREATE TABLE j134l_cat (label VARCHAR(64))" | Out-Null
-Start-Sleep -Seconds 1
-$j134lCat = (ddb query "INSERT INTO j134l_cat (title, label) VALUES ('lcat', 'alpha')").Trim()
-if (-not $j134lCat) { throw "44.L: failed to seed j134l_cat" }
-ddb query "CREATE TABLE j134l_bm (url VARCHAR(200), category VARCHAR(64) REFERENCES j134l_cat)" | Out-Null
-Start-Sleep -Seconds 1
-$j134lBm = (ddb create --type j134l_bm --title "L1" --set "url=https://l.example" --set "category=$j134lCat").Trim()
-if (-not $j134lBm) { throw "44.L: ddb create did not return id" }
-$j134lJoin = ddb query "SELECT bm.id FROM j134l_bm bm JOIN j134l_bm_category j ON j.j134l_bm_id = bm.id WHERE j.category_id = '$j134lCat'"
-if ($j134lJoin -notmatch [regex]::Escape($j134lBm)) { throw "44.L: JOIN did not return the bookmark via auto-junction: $j134lJoin" }
-pass "PRD 00134: CLI ddb create populates auto-junction for REFERENCES column (44.L)"
-Pop-Location
-Remove-Item -Recurse -Force $J134L_DIR
-
-# 50. PRD 00136 / #16 - cross-process FK freshness on `ddb create`.
-# The bug shape: process 1 creates a typed parent via `ddb create`, then
-# process 2 (a fresh DoogatService) creates a typed child whose FK
-# references the parent. Pre-fix, process 2's stale SqlEngine rejected
-# with REFERENCES_VIOLATION even though the parent existed in git and in
-# the global doogats index. Distinct from 49 / 44.L (which seed parents
-# via ddb query "INSERT INTO ..."); only the back-to-back CLI ddb create
-# shape reproduces the pre-PRD-00136 stale-index FK rejection.
-# The `ddb` wrapper at the top of this file checks $LASTEXITCODE and
-# throws on non-zero exit, so a regression where the second `ddb create`
-# rejects with REFERENCES_VIOLATION aborts this script via the wrapper.
-$INT136_DIR = New-TempDir
-Push-Location $INT136_DIR
-ddb init | Out-Null
-ddb query "CREATE TABLE int136cat (fqn VARCHAR(255))" | Out-Null
-ddb query "CREATE TABLE int136link (url TEXT, category TEXT REFERENCES int136cat)" | Out-Null
-$int136Cat = (ddb create --type int136cat --title "Cat 136" --set "fqn=test.fqn").Trim()
-if ($int136Cat -notmatch '^\d{14}$') { throw "50: int136cat id malformed: $int136Cat" }
-$int136Link = (ddb create --type int136link --title "Link 136" --set "url=https://a" --set "category=$int136Cat").Trim()
-if ($int136Link -notmatch '^\d{14}$') { throw "50: int136link id malformed: $int136Link" }
-pass "PRD 00136 / #16: cross-process FK freshness on ddb create"
-Pop-Location
-Remove-Item -Recurse -Force $INT136_DIR
-
-# 62. PRD 00164 - unified repo-aware ID minting (end-to-end CLI conformance):
-# the batch (multi-row INSERT) and single (ddb create) mint paths agree on "id
-# taken", so back-to-back mints in the same wall-clock second yield distinct,
-# non-colliding ids. No sleep between mints on purpose. NOTE: ddb create is the
-# normal create path, already repo-aware before 00164. The blind |_| false
-# paths are repo-aware now too: create_doogat_raw mint collisions are pinned by
-# the core Rust regressions (ddb-core/tests/id_mint_collision.rs,
-# raw_create_mint_collision.rs); install_bundled_type routes through the same
-# shared oracle (ddb-core/src/id_minting.rs unit tests). Neither is exercised by
-# this CLI scenario.
-$INT164_DIR = New-TempDir
-Push-Location $INT164_DIR
-ddb init | Out-Null
-ddb query "CREATE TABLE int164 (label TEXT)" | Out-Null

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is GREEN on exact deletion SHA; both test and coverage jobs succeeded. Final Clippy passed (2m04s); cargo test-ci passed42CLI +1555core +222server, no failed/ignored tests. Three actual generic adversarial mutants were caught (two by focused tests, one by the full suite); final real-binary five-test control passed. All facades are neutralized. Task completion awaits this per-task review. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


