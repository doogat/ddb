
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.sh, original lines 2614-3330, segment 6/7. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.sh:2606: DONE (pre-existing, no port needed); targets=; fixture/scaffolding
tests/integration.sh:2617: DONE; targets=integration_warnings_update::integration_58_a_graphql_update_warnings_empty
tests/integration.sh:2628: DONE; targets=cli_update_app_error::cli_update_missing_id_reports_app_error, cross_transport_error::delete_unknown_id_reports_not_found_on_both_transports, cross_transport_error::read_unknown_id_reports_not_found_on_both_transports, integration_warnings_update::integration_58_b_graphql_update_missing_id_not_found
tests/integration.sh:2635: DONE; targets=integration_warnings_update::integration_58_c_rest_update_warnings_empty, rest::rest_crud_lifecycle
tests/integration.sh:2648: DONE; targets=cross_transport_error::delete_unknown_id_reports_not_found_on_both_transports, integration_warnings_update::integration_58_d_rest_update_missing_id_not_found, rest::rest_get_unknown_id_returns_404
tests/integration.sh:2659: DONE (pre-existing, no port needed); targets=; fixture/scaffolding
tests/integration.sh:2667: DONE (pre-existing, no port needed); targets=rest::rest_typed_create_populates_typed_columns
tests/integration.sh:2680: DONE (pre-existing, no port needed); targets=rest::rest_create_malformed_fields_returns_400
tests/integration.sh:2698: DONE (pre-existing, no port needed); targets=typed_where_filter::typed_where_filter_completeness
tests/integration.sh:2739: DONE (pre-existing, no port needed); targets=typed_where_filter::typed_where_filter_completeness
tests/integration.sh:2750: DONE (pre-existing, no port needed); targets=typed_where_filter::typed_where_filter_completeness
tests/integration.sh:2761: DONE (pre-existing, no port needed); targets=typed_where_filter::typed_where_filter_completeness
tests/integration.sh:2772: DONE (pre-existing, no port needed); targets=typed_where_filter::typed_where_filter_completeness
tests/integration.sh:2778: DONE (pre-existing, no port needed); targets=typed_where_filter::typed_where_filter_completeness
tests/integration.sh:2789: DONE (pre-existing, no port needed); targets=typed_where_filter::typed_where_filter_completeness
tests/integration.sh:2800: DONE (pre-existing, no port needed); targets=typed_where_filter::typed_where_filter_completeness
tests/integration.sh:2817: DONE (pre-existing, no port needed); targets=; fixture/scaffolding
tests/integration.sh:2826: DONE (pre-existing, no port needed); targets=concurrent_writes::concurrent_cli_update_processes_lose_no_commit
tests/integration.sh:2847: DONE; targets=integration_write_lock_races::integration_61_b_concurrent_cli_and_graphql_write_lock, server_mutations::sync_during_writes_serialized_through_actor
tests/integration.sh:2886: DONE; targets=integration_sync::integration_21_clone_reindex_reads_pushed_note, sync_crdt::two_node_fast_forward_sync
tests/integration.sh:2900: DONE (pre-existing, no port needed); targets=sync_crdt::non_overlapping_edits_merge_cleanly
tests/integration.sh:2918: DONE (pre-existing, no port needed); targets=sync_crdt::frontmatter_conflict_creates_fm_crdt_file
tests/integration.sh:2937: DONE (pre-existing, no port needed); targets=sync_crdt::concurrent_tag_additions_both_survive
tests/integration.sh:2956: DONE (pre-existing, no port needed); targets=sync_crdt::overlapping_body_edits_resolved_by_crdt
tests/integration.sh:2976: DONE; targets=integration_crdt_conflicts::integration_26_reference_section_conflict
tests/integration.sh:3002: DONE (pre-existing, no port needed); targets=multi_device::concurrent_edits_same_doogat
tests/integration.sh:3028: DONE (pre-existing, no port needed); targets=sync_crdt::sync_output_reports_resurrected_count
tests/integration.sh:3056: DONE; targets=integration_crdt_conflicts::integration_27c_three_way_conflicted_merge
tests/integration.sh:3097: DONE (pre-existing, no port needed); targets=collision::add_add_collision_both_doogats_survive, collision::add_add_collision_resolves_in_single_commit
tests/integration.sh:3155: DONE (pre-existing, no port needed); targets=collision::add_add_collision_both_doogats_survive
tests/integration.sh:3168: DONE (pre-existing, no port needed); targets=multi_device::bundle_full_bootstrap
tests/integration.sh:3181: DONE; targets=integration_bundle::integration_28_delta_bundle_target_export, multi_device::airgapped_delta_transfer
tests/integration.sh:3193: DONE (pre-existing, no port needed); targets=bundle_import_conflict_recovery::bundle_import_recovers_real_conflict_and_reimport_is_noop
tests/integration.sh:3215: DONE; targets=integration_update_bin::integration_29_update_bin_help_and_rollback, sql_lifecycle::transaction_rollback_via_cli
tests/integration.sh:3225: DONE (no-match-semantics half only); targets=integration_sql_no_match::integration_30_where_id_no_match_semantics, sql_lifecycle::alter_table_add_column, sql_lifecycle::alter_table_rename_column, sql_lifecycle::bulk_delete, sql_lifecycle::bulk_update, sql_lifecycle::drop_table_cascade
tests/integration.sh:3258: DONE; targets=integration_sql_no_match::integration_30_f1_composite_unique_cli_rejection
tests/integration.sh:3272: DONE (pre-existing, no port needed); targets=attachments::attach_and_list, attachments::detach_removes_file
tests/integration.sh:3284: DONE; targets=integration_nosql_cli::integration_32_nosql_cli_commands
tests/integration.sh:3298: DONE (byte-stats-report half only); targets=integration_compact_stats::integration_33_compact_byte_stats_report, multi_device::compact_creates_recoverable_backup, multi_device::compacted_node_resolves_second_conflict, multi_device::stale_node_resync_after_compaction

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.sh b/tests/integration.sh
deleted file mode 100755
index 6942304..0000000
--- a/tests/integration.sh
+++ /dev/null
@@ -2614,717 +0,0 @@
-# schema reload) so the server sees it despite set_skip_stale_check(true).
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE ig_upd_demo (note TEXT)\") { message } }"}'
-
-# 58.A — GraphQL updateDoogat carries extensions.warnings: [] (always present)
-# and applies the change. No update-specific warnings exist today.
-IG_UPD_CREATE=$(gql '{"query":"mutation { createDoogat(input: { title: \"upd-orig\", type: \"ig_upd_demo\" }) { id } }"}')
-assert_gql_ok "$IG_UPD_CREATE"
-IG_UPD_ID=$(printf '%s' "$IG_UPD_CREATE" | jq -r '.data.createDoogat.id')
-IG_UPD_GQL=$(gql "{\"query\":\"mutation { updateDoogat(input: { id: \\\"$IG_UPD_ID\\\", title: \\\"upd-changed\\\" }) { id title } }\"}")
-assert_gql_ok "$IG_UPD_GQL"
-printf '%s' "$IG_UPD_GQL" | jq -e '.extensions.warnings == []' >/dev/null
-printf '%s' "$IG_UPD_GQL" | jq -e '.data.updateDoogat.title == "upd-changed"' >/dev/null
-pass "58.A: GraphQL updateDoogat returns extensions.warnings: [] and applies the change"
-
-# 58.B — GraphQL updateDoogat on a missing id surfaces extensions.code = NOT_FOUND
-# (app-error shape via to_graphql_error_from_app), not an untyped string.
-IG_UPD_MISS=$(gql '{"query":"mutation { updateDoogat(input: { id: \"99990101000000\", title: \"nope\" }) { id } }"}')
-assert_gql_errors "$IG_UPD_MISS"
-printf '%s' "$IG_UPD_MISS" | jq -e '.errors[0].extensions.code == "NOT_FOUND"' >/dev/null
-pass "58.B: GraphQL updateDoogat on missing id carries extensions.code = NOT_FOUND"
-
-# 58.C — REST PUT /doogats/{id} update response always carries a warnings array
-# (empty today) and applies the change, parallel to the create envelope (§56.A).
-IG_UPD_REST_BODY="$TMPDIR/ig-upd-rest.json"
-IG_UPD_REST_CODE=$(curl -sS -o "$IG_UPD_REST_BODY" -w "%{http_code}" "$REST_URL/doogats/$IG_UPD_ID" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -X PUT \
-  -d '{"title":"upd-rest"}')
-[ "$IG_UPD_REST_CODE" = "200" ]
-jq -e '.warnings == []' "$IG_UPD_REST_BODY" >/dev/null
-jq -e '.data.title == "upd-rest"' "$IG_UPD_REST_BODY" >/dev/null
-pass "58.C: REST PUT /doogats update response carries warnings: [] and applies the change"
-
-# 58.D — REST PUT on a missing id surfaces the structured NOT_FOUND envelope (404).
-IG_UPD_MISS_BODY="$TMPDIR/ig-upd-miss.json"
-IG_UPD_MISS_CODE=$(curl -sS -o "$IG_UPD_MISS_BODY" -w "%{http_code}" "$REST_URL/doogats/99990101000000" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -X PUT \
-  -d '{"title":"nope"}')
-[ "$IG_UPD_MISS_CODE" = "404" ]
-jq -e '.error == "NOT_FOUND"' "$IG_UPD_MISS_BODY" >/dev/null
-pass "58.D: REST PUT /doogats on missing id returns 404 + NOT_FOUND envelope"
-
-# 59. REST typed create via the `fields` body member (PRD 00149). Before this
-# PRD, REST CreateBody had no `fields` member, so typed create was not
-# expressible over REST despite the D-04/D-09 migration notes claiming it
-# shipped. Task 6 added CreateBody.fields; this pins that typed columns are
-# populated and that a malformed fields payload is rejected with the structured
-# VALIDATION_ERROR (400), matching the GraphQL/SQL typed-create contract.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE ig_rest_typed (slug VARCHAR(64))\") { message } }"}'
-
-# 59.A — POST /doogats with type + fields populates the typed column. Verified
-# by reading the materialized column back through the CLI (its own index
-# rebuilds from the server-committed row).
-IG_RT_BODY="$TMPDIR/ig-rest-typed.json"
-IG_RT_CODE=$(curl -sS -o "$IG_RT_BODY" -w "%{http_code}" "$REST_URL/doogats" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -d '{"title":"typed-rest","type":"ig_rest_typed","fields":"{\"slug\":\"hello-rest\"}"}')
-[ "$IG_RT_CODE" = "201" ]
-IG_RT_ID=$(jq -r '.data.id' "$IG_RT_BODY")
-$DDB query "SELECT slug FROM ig_rest_typed WHERE id = '$IG_RT_ID'" | grep -q "hello-rest"
-pass "59.A: REST POST /doogats with fields populates the typed column"
-
-# 59.B — malformed fields JSON is rejected with 400 + VALIDATION_ERROR before
-# any row is written.
-IG_RT_BAD_BODY="$TMPDIR/ig-rest-typed-bad.json"
-IG_RT_BAD_CODE=$(curl -sS -o "$IG_RT_BAD_BODY" -w "%{http_code}" "$REST_URL/doogats" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -d '{"title":"typed-bad","type":"ig_rest_typed","fields":"{not valid json"}')
-[ "$IG_RT_BAD_CODE" = "400" ]
-jq -e '.error == "VALIDATION_ERROR"' "$IG_RT_BAD_BODY" >/dev/null
-pass "59.B: REST POST /doogats with malformed fields returns 400 + VALIDATION_ERROR"
-
-# Cleanup §58/§59
-curl -sf "$REST_URL/doogats/$IG_UPD_ID" -H "Authorization: Bearer $TOKEN" -X DELETE >/dev/null
-curl -sf "$REST_URL/doogats/$IG_RT_ID" -H "Authorization: Bearer $TOKEN" -X DELETE >/dev/null
-$DDB query "DROP TABLE ig_upd_demo CASCADE" | grep -q "dropped"
-$DDB query "DROP TABLE ig_rest_typed CASCADE" | grep -q "dropped"
-rm -f "$IG_UPD_REST_BODY" "$IG_UPD_MISS_BODY" "$IG_RT_BODY" "$IG_RT_BAD_BODY"
-
-# 60. Typed where-filter completeness (PRD 00159)
-# Tests negation/null ops, forward relation sub-filters, reverse membership,
-# and totalCount correlation with pagination.
-
-# --- Fixture ---
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE relcat (title TEXT, slug TEXT)\") { message } }"}' | grep -q "table relcat created"
-wait_schema_reload "$VER"
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE rellink (url TEXT, category TEXT REFERENCES relcat)\") { message } }"}' | grep -q "table rellink created"
-wait_schema_reload "$VER"
-
-# Seed relcat rows (capture ids)
-CAT_RUST=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO relcat (title, slug) VALUES ('Rust', 'rust')\\\") { message } }\"}")
-CAT_RUST_ID=$(printf '%s' "$CAT_RUST" | extract_id)
-[ -n "$CAT_RUST_ID" ]
-
-CAT_PY=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO relcat (title, slug) VALUES ('Python', 'py')\\\") { message } }\"}")
-CAT_PY_ID=$(printf '%s' "$CAT_PY" | extract_id)
-[ -n "$CAT_PY_ID" ]
-
-CAT_EMPTY=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO relcat (title, slug) VALUES ('Empty', 'empty')\\\") { message } }\"}")
-CAT_EMPTY_ID=$(printf '%s' "$CAT_EMPTY" | extract_id)
-[ -n "$CAT_EMPTY_ID" ]
-
-# Seed rellink rows
-LINK1=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO rellink (url, category) VALUES ('https://rust.example', '$CAT_RUST_ID')\\\") { message } }\"}")
-LINK1_ID=$(printf '%s' "$LINK1" | extract_id)
-[ -n "$LINK1_ID" ]
-
-LINK2=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO rellink (url, category) VALUES ('https://py.example', '$CAT_PY_ID')\\\") { message } }\"}")
-LINK2_ID=$(printf '%s' "$LINK2" | extract_id)
-[ -n "$LINK2_ID" ]
-
-LINK3=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO rellink (title) VALUES ('orphan-link')\\\") { message } }\"}")
-LINK3_ID=$(printf '%s' "$LINK3" | extract_id)
-[ -n "$LINK3_ID" ]
-
-sleep 1
-
-# 60.A — Negation: notIn / nin
-RL=$(gql "{\"query\":\"{ rellinks(where: { id: { notIn: [\\\"$LINK1_ID\\\"] } }) { totalCount } }\"}")
-RL_CNT=$(echo "$RL" | jq -e '.data.rellinks.totalCount')
-[ "$RL_CNT" = "2" ]
-pass "serve: rellinks where id notIn returns 2"
-
-RL=$(gql "{\"query\":\"{ rellinks(where: { id: { nin: [\\\"$LINK1_ID\\\"] } }) { totalCount } }\"}")
-RL_CNT=$(echo "$RL" | jq -e '.data.rellinks.totalCount')
-[ "$RL_CNT" = "2" ]
-pass "serve: rellinks where id nin (alias) returns 2"
-
-# 60.B — Null operators
-RL=$(gql '{"query":"{ rellinks(where: { url: { isNull: true } }) { totalCount } }"}')
-RL_CNT=$(echo "$RL" | jq -e '.data.rellinks.totalCount')
-[ "$RL_CNT" = "1" ]
-pass "serve: rellinks where url isNull true returns 1"
-
-RL=$(gql '{"query":"{ rellinks(where: { url: { isNull: false } }) { totalCount } }"}')
-RL_CNT=$(echo "$RL" | jq -e '.data.rellinks.totalCount')
-[ "$RL_CNT" = "2" ]
-pass "serve: rellinks where url isNull false returns 2"
-
-# 60.C — Forward relation sub-filter (inlined target columns)
-RL=$(gql "{\"query\":\"{ rellinks(where: { category: { title: { eq: \\\"Rust\\\" } } }) { items { url } totalCount } }\"}")
-echo "$RL" | jq -e '.data.rellinks.totalCount == 1' >/dev/null
-echo "$RL" | jq -e '.data.rellinks.items[0].url == "https://rust.example"' >/dev/null
-pass "serve: rellinks where category.title eq Rust returns 1"
-
-RL=$(gql "{\"query\":\"{ rellinks(where: { category: { slug: { eq: \\\"py\\\" } } }) { totalCount } }\"}")
-RL_CNT=$(echo "$RL" | jq -e '.data.rellinks.totalCount')
-[ "$RL_CNT" = "1" ]
-pass "serve: rellinks where category.slug eq py returns 1"
-
-# 60.D — Forward id-ops (back-compatible)
-RL=$(gql "{\"query\":\"{ rellinks(where: { category: { eq: \\\"$CAT_RUST_ID\\\" } }) { totalCount } }\"}")
-RL_CNT=$(echo "$RL" | jq -e '.data.rellinks.totalCount')
-[ "$RL_CNT" = "1" ]
-pass "serve: rellinks where category eq returns 1"
-
-# 60.E — none / some
-RL=$(gql '{"query":"{ rellinks(where: { category: { none: {} } }) { totalCount } }"}')
-RL_CNT=$(echo "$RL" | jq -e '.data.rellinks.totalCount')
-[ "$RL_CNT" = "1" ]
-pass "serve: rellinks where category none returns 1 (orphan)"
-
-RL=$(gql '{"query":"{ rellinks(where: { category: { some: {} } }) { totalCount } }"}')
-RL_CNT=$(echo "$RL" | jq -e '.data.rellinks.totalCount')
-[ "$RL_CNT" = "2" ]
-pass "serve: rellinks where category some returns 2"
-
-# 60.F — Reverse membership
-RC=$(gql "{\"query\":\"{ relcats(where: { rellinks: { some: { url: { contains: \\\"rust\\\" } } } }) { items { title } totalCount } }\"}")
-echo "$RC" | jq -e '.data.relcats.totalCount == 1' >/dev/null
-echo "$RC" | jq -e '.data.relcats.items[0].title == "Rust"' >/dev/null
-pass "serve: relcats where rellinks some url contains rust returns 1"
-
-RC=$(gql '{"query":"{ relcats(where: { rellinks: { none: {} } }) { items { title } totalCount } }"}')
-echo "$RC" | jq -e '.data.relcats.totalCount == 1' >/dev/null
-echo "$RC" | jq -e '.data.relcats.items[0].title == "Empty"' >/dev/null
-pass "serve: relcats where rellinks none returns 1 (Empty category)"
-
-# 60.G — Relation filter + orderBy + pagination + totalCount correlation
-RL=$(gql "{\"query\":\"{ rellinks(where: { category: { some: {} } }, orderBy: { id: ASC }, limit: 1, offset: 0) { items { url } totalCount } }\"}")
-echo "$RL" | jq -e '.data.rellinks.items | length == 1' >/dev/null
-echo "$RL" | jq -e '.data.rellinks.totalCount == 2' >/dev/null
-RL0_URL=$(echo "$RL" | jq -r '.data.rellinks.items[0].url')
-
-RL=$(gql "{\"query\":\"{ rellinks(where: { category: { some: {} } }, orderBy: { id: ASC }, limit: 1, offset: 1) { items { url } totalCount } }\"}")
-echo "$RL" | jq -e '.data.rellinks.items | length == 1' >/dev/null
-echo "$RL" | jq -e '.data.rellinks.totalCount == 2' >/dev/null
-RL1_URL=$(echo "$RL" | jq -r '.data.rellinks.items[0].url')
-[ "$RL0_URL" != "$RL1_URL" ]
-pass "serve: rellinks pagination with relation filter (totalCount=2, no dupes)"
-
-# Cleanup
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE rellink CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE relcat CASCADE\") { message } }"}' >/dev/null
-
-# 61. Cross-process write lock: no lost commit under concurrent writers (PRD 00162).
-# The advisory lock on .git/ddb-write.lock serializes every git commit critical
-# section across processes, so concurrent writers can't drop each other's
-# commits via a stale-parent HEAD force-update. Both sub-scenarios target
-# DISTINCT doogat ids (so the still-open id-mint race, PRD 00164, can't confound
-# the result) and assert durability against HEAD with `git show`, not the work
-# tree — a lost commit leaves its file on disk but absent from HEAD.
-cd "$TMPDIR"
-
-# 61.A — N concurrent CLI `ddb update` writers on distinct doogats must all land.
-WL_IDS=()
-for i in $(seq 1 6); do
-  WL_IDS+=("$($DDB create --title "WL seed $i" --body "wl-original-$i")")
-done
-set +e
-WL_PIDS=()
-for i in $(seq 1 6); do
-  $DDB update "${WL_IDS[$((i - 1))]}" --body "wl-landed-$i" >/dev/null 2>&1 &
-  WL_PIDS+=("$!")
-done
-WL_FAIL=0
-for pid in "${WL_PIDS[@]}"; do wait "$pid" || WL_FAIL=$((WL_FAIL + 1)); done
-set -e
-[ "$WL_FAIL" -eq 0 ] || fail "61.A: $WL_FAIL concurrent CLI update(s) exited non-zero"
-for i in $(seq 1 6); do
-  git show "HEAD:ddb/${WL_IDS[$((i - 1))]}.md" | grep -q "wl-landed-$i" \
-    || fail "61.A: concurrent update $i is not durable in HEAD (lost commit)"
-done
-pass "61.A: 6 concurrent CLI updates all landed in HEAD (no lost commit)"
-
-# 61.B — a `ddb serve` (GraphQL) write concurrent with a CLI write; both must land.
-# The PRD's headline deployment: a downstream app runs `ddb serve` while the
-# user runs the CLI against the same repo. Seed both rows via GraphQL so the
-# running server already indexes them, then race one GraphQL update (server
-# process) against one CLI update (separate process).
-WL_GID=$(gql '{"query":"mutation { createDoogat(input: { title: \"WL serve seed\" }) { id } }"}' | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-WL_CID=$(gql '{"query":"mutation { createDoogat(input: { title: \"WL cli seed\" }) { id } }"}' | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-[ -n "$WL_GID" ] || fail "61.B: GraphQL seed returned no id"
-[ -n "$WL_CID" ] || fail "61.B: CLI seed returned no id"
-set +e
-gql "{\"query\":\"mutation { updateDoogat(input: { id: \\\"$WL_GID\\\", title: \\\"wl-serve-landed\\\" }) { id } }\"}" >"$TMPDIR/wl_serve.json" 2>&1 &
-WL_SPID=$!
-$DDB update "$WL_CID" --body "wl-cli-landed" >/dev/null 2>&1 &
-WL_CPID=$!
-wait "$WL_SPID"
-wait "$WL_CPID"; WL_CEXIT=$?
-set -e
-[ "$WL_CEXIT" -eq 0 ] || fail "61.B: concurrent CLI write exited non-zero"
-grep -q '"id"' "$TMPDIR/wl_serve.json" || fail "61.B: concurrent GraphQL write failed: $(cat "$TMPDIR/wl_serve.json")"
-git show "HEAD:ddb/$WL_GID.md" | grep -q "wl-serve-landed" || fail "61.B: serve write not durable in HEAD"
-git show "HEAD:ddb/$WL_CID.md" | grep -q "wl-cli-landed" || fail "61.B: CLI write not durable in HEAD"
-pass "61.B: concurrent ddb serve + CLI writes both landed in HEAD (cross-process lock)"
-
-kill "$SERVER_PID" 2>/dev/null || true
-wait "$SERVER_PID" 2>/dev/null || true
-pass "serve: clean shutdown"
-
-echo "=== sync conflict scenarios ==="
-
-# --- Two-node setup ---
-# bare remote
-git init --bare "$REMOTE_DIR" >/dev/null 2>&1
-
-# node1: init + push
-cd "$NODE1_DIR"
-$DDB init . >/dev/null
-git remote add origin "$REMOTE_DIR"
-$DDB register-node "Laptop" >/dev/null
-
-# 21. fast-forward sync
-SYNC_ID=$($DDB create --title "Shared note" --tags "shared" --body "Original body")
-git push -u origin master >/dev/null 2>&1
-
-# clone to node2
-git clone "$REMOTE_DIR" "$NODE2_DIR" >/dev/null 2>&1
-cd "$NODE2_DIR"
-# init ddb index without reinitializing git
-$DDB reindex >/dev/null
-$DDB register-node "Desktop" >/dev/null
-
-$DDB read "$SYNC_ID" | grep -q "Shared note"
-pass "fast-forward sync"
-
-# 22. non-overlapping edits (clean git merge, no CRDT)
-cd "$NODE1_DIR"
-$DDB update "$SYNC_ID" --title "Updated Title" --tags "shared,laptop"
-
-cd "$NODE2_DIR"
-$DDB update "$SYNC_ID" --body "Modified body"
-
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-
-cd "$NODE2_DIR"
-SYNC_OUT=$($DDB sync origin master)
-echo "$SYNC_OUT" | grep -q "conflicts resolved: 0"
-
-$DDB read "$SYNC_ID" | grep -q "Updated Title"
-$DDB read "$SYNC_ID" | grep -q "Modified body"
-pass "non-overlapping edits (clean merge)"
-
-# 23. frontmatter scalar conflict (title) — CRDT resolves
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-$DDB update "$SYNC_ID" --title "Laptop Title"
-
-cd "$NODE2_DIR"
-$DDB update "$SYNC_ID" --title "Desktop Title"
-
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-
-cd "$NODE2_DIR"
-SYNC_OUT=$($DDB sync origin master)
-echo "$SYNC_OUT" | grep -q "conflicts resolved: 1"
-
-TITLE=$($DDB read "$SYNC_ID" | grep "^title:")
-echo "$TITLE" | grep -qE "(Laptop Title|Desktop Title)"
-pass "frontmatter scalar conflict (CRDT)"
-
-# 24. frontmatter list conflict (tags) — CRDT set-union
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-$DDB update "$SYNC_ID" --tags "base,alpha"
-
-cd "$NODE2_DIR"
-$DDB update "$SYNC_ID" --tags "base,beta"
-
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-
-cd "$NODE2_DIR"
-$DDB sync origin master >/dev/null
-
-READ_OUT=$($DDB read "$SYNC_ID")
-echo "$READ_OUT" | grep -q "alpha"
-echo "$READ_OUT" | grep -q "beta"
-pass "frontmatter list conflict (tag union)"
-
-# 25. body conflict — Automerge Text CRDT
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-$DDB update "$SYNC_ID" --body $'Line one LAPTOP.\nLine two.\nLine three.'
-
-cd "$NODE2_DIR"
-$DDB update "$SYNC_ID" --body $'Line one.\nLine two DESKTOP.\nLine three.'
-
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-
-cd "$NODE2_DIR"
-SYNC_OUT=$($DDB sync origin master)
-echo "$SYNC_OUT" | grep -q "conflicts resolved: 1"
-
-READ_OUT=$($DDB read "$SYNC_ID")
-echo "$READ_OUT" | grep -q "LAPTOP"
-echo "$READ_OUT" | grep -q "DESKTOP"
-pass "body conflict (CRDT text merge)"
-
-# 26. reference section conflict — write files directly, CRDT union
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-
-DOOGAT_FILE="ddb/${SYNC_ID}.md"
-
-# node1: append reference section with laptop-specific field
-CONTENT=$(cat "$DOOGAT_FILE")
-printf '%s\n---\n- laptop note:: Added from laptop\n' "$CONTENT" > "$DOOGAT_FILE"
-git add "$DOOGAT_FILE" && git commit -m "node1 add reference" >/dev/null 2>&1
-git push origin master >/dev/null 2>&1
-
-# node2: append different reference field (from its pre-push version)
-cd "$NODE2_DIR"
-CONTENT=$(cat "$DOOGAT_FILE")
-printf '%s\n---\n- desktop note:: Added from desktop\n' "$CONTENT" > "$DOOGAT_FILE"
-git add "$DOOGAT_FILE" && git commit -m "node2 add reference" >/dev/null 2>&1
-
-SYNC_OUT=$($DDB sync origin master)
-echo "$SYNC_OUT" | grep -q "conflicts resolved: 1"
-
-READ_OUT=$($DDB read "$SYNC_ID")
-echo "$READ_OUT" | grep -q "laptop note"
-echo "$READ_OUT" | grep -q "desktop note"
-pass "reference section conflict (CRDT union)"
-
-# 26b. deterministic CRDT convergence smoke — both nodes reach the SAME title after a real conflict resolution (independent-resolution determinism is unit-tested in crdt_determinism.rs) (PRD 00165)
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-$DDB update "$SYNC_ID" --title "Converge Laptop"
-
-cd "$NODE2_DIR"
-$DDB update "$SYNC_ID" --title "Converge Desktop"
-
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-
-cd "$NODE2_DIR"
-RESOLVE_OUT=$($DDB sync origin master)
-echo "$RESOLVE_OUT" | grep -qE "^sync:.*conflicts resolved: [1-9]"
-
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-
-cd "$NODE1_DIR"
-T1=$($DDB read "$SYNC_ID" | grep "^title:")
-cd "$NODE2_DIR"
-T2=$($DDB read "$SYNC_ID" | grep "^title:")
-[ -n "$T1" ] && [ "$T1" = "$T2" ]
-echo "$T1" | grep -qE "(Converge Laptop|Converge Desktop)"
-pass "deterministic CRDT convergence smoke (both nodes same title after real conflict resolution, PRD 00165)"
-
-# 27b. delete-vs-edit conflict — edit wins, doogat resurrected
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-DEL_ID=$($DDB create --title "To be deleted" --body "Original content")
-$DDB sync origin master >/dev/null
-
-cd "$NODE2_DIR"
-$DDB sync origin master >/dev/null
-$DDB read "$DEL_ID" | grep -q "To be deleted"
-
-# node1 deletes, node2 edits
-cd "$NODE1_DIR"
-$DDB delete "$DEL_ID"
-
-cd "$NODE2_DIR"
-$DDB update "$DEL_ID" --body "Edited on desktop"
-
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-
-cd "$NODE2_DIR"
-$DDB sync origin master >/dev/null
-
-# Edit wins: doogat exists and is marked resurrected
-$DDB read "$DEL_ID" | grep -q "Edited on desktop"
-$DDB status | grep -q "resurrected"
-pass "delete-vs-edit conflict (edit wins, resurrected)"
-
-# 27c. three-way conflicted merge preserves deletion + local edit (PRD 00200)
-THREE_REMOTE="$(mktemp -d)"
-THREE_OURS="$(mktemp -d)"
-THREE_THEIRS_PARENT="$(mktemp -d)"
-git init --bare "$THREE_REMOTE" >/dev/null 2>&1
-
-# Node "ours": init, add remote, register, create three doogats, push
-cd "$THREE_OURS"
-$DDB init . >/dev/null
-git remote add origin "$THREE_REMOTE"
-$DDB register-node "Ours" >/dev/null
-THREE_A=$($DDB create --title "Conflict doogat" --body "base A")
-THREE_X=$($DDB create --title "Doomed doogat" --body "base X")
-THREE_Y=$($DDB create --title "Survivor doogat" --body "base Y")
-git push -u origin master >/dev/null 2>&1
-
-# Node "theirs": clone, register, edit A + delete X, sync (pushes theirs)
-git clone "$THREE_REMOTE" "$THREE_THEIRS_PARENT/repo" >/dev/null 2>&1
-THREE_THEIRS="$THREE_THEIRS_PARENT/repo"
-cd "$THREE_THEIRS"
-$DDB reindex >/dev/null
-$DDB register-node "Theirs" >/dev/null
-$DDB update "$THREE_A" --title "Theirs A" >/dev/null
-$DDB delete "$THREE_X" >/dev/null
-$DDB sync origin master >/dev/null
-
-# Back on "ours": collide on A, non-conflicting edit on Y, then sync (conflicted merge)
-cd "$THREE_OURS"
-$DDB update "$THREE_A" --title "Ours A" >/dev/null
-$DDB update "$THREE_Y" --body "ours Y edit" >/dev/null
-SYNC_OUT=$($DDB sync origin master)
-
-# Assertions
-echo "$SYNC_OUT" | grep -q "conflicts resolved: 1"
-[ ! -f "ddb/${THREE_X}.md" ]
-$DDB read "$THREE_Y" | grep -q "ours Y edit"
-$DDB read "$THREE_A" | grep -qE "(Theirs A|Ours A)"
-pass "three-way conflicted merge preserves deletion + local edit (PRD 00200)"
-
-echo "=== id collision detection ==="
-
-# 27a. add-add collision: both doogats survive
-# Use a fresh pair of repos to avoid interference with earlier sync state.
-COLL_REMOTE="$(mktemp -d)"
-COLL_A="$(mktemp -d)"
-COLL_B_PARENT="$(mktemp -d)"
-git init --bare "$COLL_REMOTE" >/dev/null 2>&1
-
-# Node A: init, push, register
-cd "$COLL_A"
-$DDB init . >/dev/null
-git remote add origin "$COLL_REMOTE"
-$DDB register-node "CollA" >/dev/null
-git push -u origin master >/dev/null 2>&1
-
-# Node B: clone, register
-git clone "$COLL_REMOTE" "$COLL_B_PARENT/repo" >/dev/null 2>&1
-COLL_B="$COLL_B_PARENT/repo"
-cd "$COLL_B"
-$DDB reindex >/dev/null
-$DDB register-node "CollB" >/dev/null
-git push origin master >/dev/null 2>&1
-
-# Sync A to pick up B's node
-cd "$COLL_A"
-$DDB sync origin master >/dev/null
-
-# Both create the same-ID doogat independently
-COLL_ID="20260101120000"
-cd "$COLL_A"
-mkdir -p ddb
-printf -- '---\nid: %s\ntitle: From A\ndate: 2026-01-01\n---\nBody A\n' "$COLL_ID" > "ddb/${COLL_ID}.md"
-git add "ddb/${COLL_ID}.md"
-git commit -m "A creates $COLL_ID" >/dev/null 2>&1
-git push origin master >/dev/null 2>&1
-
-cd "$COLL_B"
-mkdir -p ddb
-printf -- '---\nid: %s\ntitle: From B\ndate: 2026-01-01\n---\nBody B\n' "$COLL_ID" > "ddb/${COLL_ID}.md"
-git add "ddb/${COLL_ID}.md"
-git commit -m "B creates $COLL_ID" >/dev/null 2>&1
-
-# B syncs — collision detected and resolved (single commit, atomic)
-COLL_B_HEAD_BEFORE=$(git rev-parse HEAD)
-COLL_OUT=$($DDB sync origin master)
-echo "$COLL_OUT" | grep -q "collisions reassigned: 1"
-COLL_COUNT=$(find ddb -name '*.md' ! -name '_*' | wc -l | tr -d ' ')
-[ "$COLL_COUNT" -eq 2 ]
-COLL_B_HEAD_AFTER=$(git rev-parse HEAD)
-# sync() always appends one more single-parent "update sync state" commit
-# (finalize_sync -> update_sync_state) after resolution, so the resolution
-# itself landing atomically means exactly 2 new commits here, not 1 — the
-# two-parent winner+loser merge commit, then the trailing state commit.
-# --first-parent is required: a plain range also walks the merge's other
-# parent (the peer's fetched commits), which isn't part of this node's own chain.
-COLL_COMMIT_COUNT=$(git rev-list --first-parent --count "$COLL_B_HEAD_BEFORE".."$COLL_B_HEAD_AFTER" | tr -d ' ')
-[ "$COLL_COMMIT_COUNT" -eq 2 ]
-pass "add-add collision: both doogats survive"
-
-# 27a2. add-add collision: single commit + both nodes converge
-cd "$COLL_B"
-git push origin master >/dev/null 2>&1
-cd "$COLL_A"
-$DDB sync origin master >/dev/null
-COLL_A_FILES=$(find ddb -name '*.md' ! -name '_*' | sort)
-cd "$COLL_B"
-COLL_B_FILES=$(find ddb -name '*.md' ! -name '_*' | sort)
-[ "$COLL_A_FILES" = "$COLL_B_FILES" ]
-pass "add-add collision: single commit + both nodes converge"
-
-echo "=== bundle sync ==="
-
-# 27. bundle export --full + import
-cd "$NODE1_DIR"
-$DDB sync origin master >/dev/null
-$DDB bundle export --full --output "$TMPDIR/full-bundle.tar"
-echo "$TMPDIR/full-bundle.tar" | grep -q "full-bundle.tar"
-
-cd "$NODE3_DIR"
-$DDB init . >/dev/null
-$DDB register-node "Tablet" >/dev/null
-$DDB bundle import "$TMPDIR/full-bundle.tar" | grep -q "imported"
-$DDB read "$SYNC_ID" | grep -q "laptop note"
-pass "bundle export --full + import"
-
-# 28. delta bundle export + import
-cd "$NODE1_DIR"
-DELTA_ID=$($DDB create --title "Delta note" --body "only in delta")
-
-NODE2_UUID=$(cd "$NODE2_DIR" && cat .git/ddb-node)
-$DDB bundle export --target "$NODE2_UUID" --output "$TMPDIR/delta-bundle.tar"
-
-cd "$NODE2_DIR"
-$DDB bundle import "$TMPDIR/delta-bundle.tar" | grep -q "imported"
-$DDB read "$DELTA_ID" | grep -q "Delta note"
-pass "delta bundle export + import"
-
-# 28a. bundle-import conflict recovery — nodes diverge WITHOUT git-remote sync,
-# a real conflict is resolved through bundle import, and re-importing the same
-# bundle afterward is a no-op (PRD 00168)
-cd "$NODE1_DIR"
-$DDB update "$SYNC_ID" --title "Bundle Laptop Title"
-$DDB bundle export --full --output "$TMPDIR/conflict-bundle.tar"
-
-cd "$NODE2_DIR"
-$DDB update "$SYNC_ID" --title "Bundle Desktop Title"
-IMPORT_OUT=$($DDB bundle import "$TMPDIR/conflict-bundle.tar")
-echo "$IMPORT_OUT" | grep -q "imported: conflicts resolved: 1"
-
-TITLE=$($DDB read "$SYNC_ID" | grep "^title:")
-echo "$TITLE" | grep -qE "(Bundle Laptop Title|Bundle Desktop Title)"
-
-# re-importing the SAME bundle must not error: its commits are already
-# ancestors of local HEAD, so the merge classifies as already-up-to-date
-# and resolves zero (new) conflicts.
-IMPORT_OUT2=$($DDB bundle import "$TMPDIR/conflict-bundle.tar")
-echo "$IMPORT_OUT2" | grep -q "imported: conflicts resolved: 0"
-pass "bundle-import conflict recovery (real conflict resolved, second import no-op)"
-
-# 29. update-bin help + rollback
-$DDB update-bin --help | grep -q "Update ddb"
-$DDB update-bin --help | grep -q "\-\-rollback"
-pass "update-bin --help (includes --rollback)"
-
-# rollback with no backup should fail gracefully
-ROLLBACK_OUT=$($DDB update-bin --rollback 2>&1 || true)
-echo "$ROLLBACK_OUT" | grep -q "no backup"
-pass "update-bin --rollback (no backup error)"
-
-# 30. ALTER TABLE + DROP TABLE + bulk UPDATE/DELETE
-cd "$TMPDIR"
-$DDB query "CREATE TABLE smokealt (name TEXT, score INTEGER)" | grep -q "table smokealt created"
-$DDB query "INSERT INTO smokealt (name, score) VALUES ('a', 1)" >/dev/null
-sleep 1
-$DDB query "INSERT INTO smokealt (name, score) VALUES ('b', 2)" >/dev/null
-$DDB query "ALTER TABLE smokealt ADD COLUMN tag TEXT" | grep -q "altered"
-$DDB query "SELECT name, tag FROM smokealt" | grep -q "NULL"
-$DDB query "ALTER TABLE smokealt RENAME COLUMN tag TO label" | grep -q "renamed"
-$DDB query "SELECT name, label FROM smokealt" | grep -q "a"
-$DDB query "UPDATE smokealt SET score = 99 WHERE name = 'a'" | grep -q "1 row(s) affected"
-$DDB query "DELETE FROM smokealt WHERE name = 'b'" | grep -q "1 row(s) affected"
-$DDB query "DROP TABLE smokealt CASCADE" | grep -q "dropped"
-pass "alter/drop table + bulk ops"
-
-# UPDATE/DELETE WHERE id no-match semantics (continuation of section 30, #5)
-cd "$TMPDIR"
-$DDB query "CREATE TABLE smokenomatch (name TEXT, score INTEGER)" | grep -q "table smokenomatch created"
-NOMATCH_ID=$($DDB query "INSERT INTO smokenomatch (name, score) VALUES ('alpha', 1)")
-# B1: UPDATE with nonexistent id returns 0 rows affected (not an error)
-$DDB query "UPDATE smokenomatch SET score = 1 WHERE id = 'nonexistent_id_00000000000000'" | grep -q "0 row(s) affected"
-# B2: DELETE with nonexistent id returns 0 rows affected (not an error)
-$DDB query "DELETE FROM smokenomatch WHERE id = 'nonexistent_id_00000000000000'" | grep -q "0 row(s) affected"
-# B3: IN clause mixing missing and valid ids still affects 1 row
-$DDB query "UPDATE smokenomatch SET score = 7 WHERE id IN ('nope', '$NOMATCH_ID')" | grep -q "1 row(s) affected"
-# B4: compound predicate with valid id + non-matching column returns 0 rows affected
-$DDB query "UPDATE smokenomatch SET score = 99 WHERE id = '$NOMATCH_ID' AND name = 'wrongname'" | grep -q "0 row(s) affected"
-# B5: valid id on the fast path still affects 1 row
-$DDB query "UPDATE smokenomatch SET score = 42 WHERE id = '$NOMATCH_ID'" | grep -q "1 row(s) affected"
-$DDB query "SELECT score FROM smokenomatch WHERE id = '$NOMATCH_ID'" | grep -q "42"
-$DDB query "DROP TABLE smokenomatch CASCADE" | grep -q "dropped"
-pass "update/delete WHERE id no-match semantics (#5)"
-
-# 30.F1 — composite UNIQUE duplicate rejection surfaces a clear error on the
-# CLI (#9 group F1). The Rust unit test
-# composite_unique_duplicate_rejected_with_clear_error_issue_9_f1 covers the
-# error message at the engine level; this check confirms the CLI path
-# propagates the same error with the table context intact.
-cd "$TMPDIR"
-$DDB query 'CREATE TABLE f1mship (title VARCHAR(255), link_id VARCHAR(255), category VARCHAR(255), UNIQUE(link_id, category))' | grep -q "table f1mship created"
-$DDB query "INSERT INTO f1mship (title, link_id, category) VALUES ('a', 'link1', 'cat1')" >/dev/null
-F1_DUP=$($DDB query "INSERT INTO f1mship (title, link_id, category) VALUES ('b', 'link1', 'cat1')" 2>&1 || true)
-echo "$F1_DUP" | grep -q "UNIQUE"
-echo "$F1_DUP" | grep -qE "f1mship|link_id|category"
-$DDB query "DROP TABLE f1mship CASCADE" | grep -q "dropped"
-pass "issue-9-F1: composite UNIQUE duplicate rejected with clear error"
-
-# 31. file attachments
-cd "$TMPDIR"
-echo "hello attachment" > $TMPDIR/ddb-smoke-attach.txt
-$DDB attach "$ID1" $TMPDIR/ddb-smoke-attach.txt | grep -q "attached"
-$DDB attachments "$ID1" | grep -q "ddb-smoke-attach.txt"
-$DDB attachments "$ID1" | grep -q "text/plain"
-$DDB query "SELECT name, mime FROM _ddb_attachments WHERE doogat_id = '$ID1'" | grep -q "ddb-smoke-attach.txt"
-$DDB detach "$ID1" "ddb-smoke-attach.txt" | grep -q "detached"
-$DDB attachments "$ID1" | grep -q "no attachments"
-rm -f $TMPDIR/ddb-smoke-attach.txt
-pass "file attachments (attach/list/query/detach)"
-
-# 32. NoSQL CLI commands
-cd "$TMPDIR"
-$DDB get "$ID1" | grep -q "First note (edited)"
-pass "nosql: get"
-
-$DDB scan --tag test | grep -q "$ID1"
-pass "nosql: scan --tag"
-
-$DDB scan --type foo | grep -qE "^[0-9]{14}$"
-pass "nosql: scan --type"
-
-$DDB backlinks "$ID1" | grep -q "$ID2"
-pass "nosql: backlinks"
-
-# 33. stale node resync after compaction
-echo "=== stale node resync ==="
-STALE_REMOTE="$(mktemp -d)"
-STALE_N1="$(mktemp -d)"
-STALE_N2="$(mktemp -d)"
-trap 'rm -rf "$TMPDIR" "$REMOTE_DIR" "$NODE1_DIR" "$NODE2_DIR" "$NODE3_DIR" "$STALE_REMOTE" "$STALE_N1" "$STALE_N2" "$COLL_REMOTE" "$COLL_A" "$COLL_B_PARENT"' EXIT
-
-git init --bare "$STALE_REMOTE" >/dev/null 2>&1
-
-cd "$STALE_N1"
-$DDB init . >/dev/null
-git remote add origin "$STALE_REMOTE"
-$DDB register-node "StaleNode1" >/dev/null
-STALE_ID=$($DDB create --title "Stale shared" --body "original content")
-git push -u origin master >/dev/null 2>&1
-
-git clone "$STALE_REMOTE" "$STALE_N2" >/dev/null 2>&1
-cd "$STALE_N2"
-$DDB reindex >/dev/null
-$DDB register-node "StaleNode2" >/dev/null
-
-# Both nodes edit the same doogat → conflict
-cd "$STALE_N1"
-$DDB update "$STALE_ID" --body "body from node1"
-git push origin master >/dev/null 2>&1
-
-cd "$STALE_N2"
-$DDB update "$STALE_ID" --body "body from node2"
-$DDB sync origin master >/dev/null
-
-# Compact to remove CRDT temp files — verify report includes byte stats
-COMPACT_OUT=$($DDB compact --force)
-echo "$COMPACT_OUT" | grep -q "crdt temp:"

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is GREEN on exact deletion SHA; both test and coverage jobs succeeded. Final Clippy passed (2m04s); cargo test-ci passed42CLI +1555core +222server, no failed/ignored tests. Three actual generic adversarial mutants were caught (two by focused tests, one by the full suite); final real-binary five-test control passed. All facades are neutralized. Task completion awaits this per-task review. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


