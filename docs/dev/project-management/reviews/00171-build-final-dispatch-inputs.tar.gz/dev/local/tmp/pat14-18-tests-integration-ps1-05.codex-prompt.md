
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.ps1, original lines 1974-2456, segment 5/8. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.ps1:1971: DONE; targets=integration_error_codes::integration_49_1_unique_violation_extensions_code
tests/integration.ps1:1993: DONE; targets=integration_error_codes::integration_49_2_not_null_violation_extensions_code
tests/integration.ps1:2005: DONE; targets=integration_error_codes::integration_49_3_createmany_error_extensions_code
tests/integration.ps1:2014: DONE; targets=integration_error_codes::integration_49_4_createmany_intra_batch_error_extensions_code
tests/integration.ps1:2026: DONE (pre-existing, no port needed) <!-- banner-only line, nothing to port; see 50a/50b -->; targets=; fixture/scaffolding
tests/integration.ps1:2027: DONE; targets=integration_alter_rename::integration_50a_alter_rename_graphql
tests/integration.ps1:2036: DONE; targets=integration_alter_rename::integration_50b_mysql_rename_alias_rejected_graphql
tests/integration.ps1:2046: DONE (pre-existing, no port needed); targets=; fixture/scaffolding
tests/integration.ps1:2050: DONE; targets=integration_singleton_flow::integration_51_a_singleton_graphql_flow
tests/integration.ps1:2117: DONE; targets=integration_singleton_flow::integration_52_b_graphql_alter_set_drop_singleton_reload
tests/integration.ps1:2155: DONE; targets=integration_singleton_flow::integration_53_c_singleton_default_values_auto_seed
tests/integration.ps1:2166: DONE; targets=integration_singleton_parity::integration_54_d_cross_protocol_singleton_duplicate_parity
tests/integration.ps1:2268: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2366']
tests/integration.ps1:2270: DONE (pre-existing, no port needed); targets=; aliases=['tests/integration.sh:2376']
tests/integration.ps1:2303: DONE; targets=integration_singleton_races::integration_55_b_graphql_execute_sql_singleton_insert_race
tests/integration.ps1:2335: DONE; targets=integration_singleton_races::integration_55_c_graphql_create_doogat_singleton_insert_race
tests/integration.ps1:2364: DONE; targets=integration_singleton_races::integration_55_d_cli_vs_pgwire_singleton_insert_race
tests/integration.ps1:2432: DONE; targets=integration_singleton_races::integration_55_b_graphql_execute_sql_singleton_insert_race, integration_singleton_races::integration_55_c_graphql_create_doogat_singleton_insert_race, integration_singleton_races::integration_55_d_cli_vs_pgwire_singleton_insert_race, singleton_cross_process_create::two_concurrent_ddb_create_on_singleton_converge_on_one_row
tests/integration.ps1:2449: DONE (pre-existing, no port needed); targets=; fixture/scaffolding

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.ps1 b/tests/integration.ps1
deleted file mode 100644
index 2f21127..0000000
--- a/tests/integration.ps1
+++ /dev/null
@@ -1974,483 +0,0 @@
-$seFirst = gqlq 'mutation { createDoogat(input: {type: "puv_link", title: "first", fields: "{\"slug\":\"hn\",\"space\":\"news\"}"}) { id } }'
-assertGqlOk $seFirst "49.1 first insert"
-
-$seDup = gqlq 'mutation { createDoogat(input: {type: "puv_link", title: "dup", fields: "{\"slug\":\"hn\",\"space\":\"news\"}"}) { id } }'
-assertGqlErrors $seDup "49.1 duplicate"
-$seDupParsed = $seDup | ConvertFrom-Json
-if ($seDupParsed.errors[0].extensions.code -ne "UNIQUE_VIOLATION") {
-    throw "49.1: expected UNIQUE_VIOLATION, got: $($seDupParsed.errors[0].extensions.code)"
-}
-$seDupCols = $seDupParsed.errors[0].extensions.columns
-if (-not ($seDupCols -is [array]) -or $seDupCols.Count -ne 2 -or $seDupCols[0] -ne "slug" -or $seDupCols[1] -ne "space") {
-    throw "49.1: expected columns [slug, space], got: $($seDupCols -join ',')"
-}
-$seDupVals = $seDupParsed.errors[0].extensions.values
-if (-not ($seDupVals -is [array]) -or $seDupVals.Count -ne 2) {
-    throw "49.1: expected values list of length 2, got: $($seDupVals -join ',')"
-}
-pass "49.1: createDoogat UNIQUE violation carries extensions.code = UNIQUE_VIOLATION"
-
-# 49.2 - createDoogat NOT NULL violation carries extensions.code.
-$seNn = gqlq 'mutation { createDoogat(input: {type: "puv_link", title: "missing-slug", fields: "{\"space\":\"news\"}"}) { id } }'
-assertGqlErrors $seNn "49.2 missing required column"
-$seNnParsed = $seNn | ConvertFrom-Json
-if ($seNnParsed.errors[0].extensions.code -ne "NOT_NULL_VIOLATION") {
-    throw "49.2: expected NOT_NULL_VIOLATION, got: $($seNnParsed.errors[0].extensions.code)"
-}
-if ($seNnParsed.errors[0].extensions.column -ne "slug") {
-    throw "49.2: expected column=slug, got: $($seNnParsed.errors[0].extensions.column)"
-}
-pass "49.2: createDoogat NOT NULL violation carries extensions.code = NOT_NULL_VIOLATION"
-
-# 49.3 - createMany single-input ERROR carries extensions.code.
-$seCm = gqlq 'mutation { createMany(inputs: [{type: "puv_link", title: "cm-dup", fields: "{\"slug\":\"hn\",\"space\":\"news\"}"}], onConflict: ERROR) { id } }'
-assertGqlErrors $seCm "49.3 createMany ERROR"
-$seCmParsed = $seCm | ConvertFrom-Json
-if ($seCmParsed.errors[0].extensions.code -ne "UNIQUE_VIOLATION") {
-    throw "49.3: expected UNIQUE_VIOLATION, got: $($seCmParsed.errors[0].extensions.code)"
-}
-pass "49.3: createMany ERROR UNIQUE violation carries extensions.code = UNIQUE_VIOLATION"
-
-# 49.4 - createMany multi-input intra-batch duplicate under ERROR.
-$seCmIntra = gqlq 'mutation { createMany(inputs: [{type: "puv_link", title: "cm-a", fields: "{\"slug\":\"twin\",\"space\":\"news\"}"}, {type: "puv_link", title: "cm-b", fields: "{\"slug\":\"twin\",\"space\":\"news\"}"}], onConflict: ERROR) { id } }'
-assertGqlErrors $seCmIntra "49.4 intra-batch ERROR"
-$seCmIntraParsed = $seCmIntra | ConvertFrom-Json
-if ($seCmIntraParsed.errors[0].extensions.code -ne "UNIQUE_VIOLATION") {
-    throw "49.4: expected UNIQUE_VIOLATION, got: $($seCmIntraParsed.errors[0].extensions.code)"
-}
-pass "49.4: createMany intra-batch ERROR carries extensions.code = UNIQUE_VIOLATION"
-
-# Cleanup: drop the typedef so subsequent runs start clean.
-ddl 'mutation { executeSql(sql: "DROP TABLE puv_link") { message } }'
-
-# 50. PRD 00132: ALTER TABLE foo RENAME TO bar across protocols.
-# 50a. via GraphQL executeSql.
-ddl 'mutation { executeSql(sql: "CREATE TABLE rngql_src (title VARCHAR(64))") { message } }'
-ddl 'mutation { executeSql(sql: "ALTER TABLE rngql_src RENAME TO rngql_dst") { message } }'
-$rnGqlOk = gqlq 'mutation { executeSql(sql: "SELECT count(*) FROM rngql_dst") { message } }'
-if ($rnGqlOk -notmatch '"data"') { throw "50a: expected data after rename, got $rnGqlOk" }
-$rnGqlOld = gqlq 'mutation { executeSql(sql: "SELECT count(*) FROM rngql_src") { message } }'
-assertGqlErrors $rnGqlOld "50a: old name should no longer resolve"
-pass "50a: ALTER TABLE RENAME TO via GraphQL executeSql succeeds; old name no longer resolves"
-
-# 50b. MySQL alias rejected with explicit message.
-$rnAlias = gqlq 'mutation { executeSql(sql: "RENAME TABLE rngql_dst TO rngql_dst2") { message } }'
-if ($rnAlias -notmatch 'RENAME TABLE not supported') {
-    throw "50b: expected RENAME TABLE rejection hint, got $rnAlias"
-}
-pass "50b: MySQL RENAME TABLE alias rejected with explicit ALTER TABLE hint"
-
-# Cleanup so subsequent runs start clean.
-ddl 'mutation { executeSql(sql: "DROP TABLE rngql_dst") { message } }'
-
-# 51. SINGLETON GraphQL flow + ALTER + parity (PRD 00139 T20/T22).
-# Reuse the GraphQL server started near the top of the script; it stays up until
-# the existing clean shutdown immediately below.
-
-# 51.A - GraphQL singleton flow (T20 §A)
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-# Route DDL through GraphQL executeSql so the running server's schema reload
-# fires; a raw `ddb query` mutates the repo but never wakes the server.
-$output = gqlq 'mutation { executeSql(sql: "CREATE TABLE ig_app_config (theme TEXT) SINGLETON") { message } }'
-if ($output -notmatch "table ig_app_config created") { throw "51.A: ig_app_config create failed: $output" }
-waitSchemaReload $ver
-
-$igAppEmpty = gqlq '{ ig_app_config { id theme } }'
-assertGqlOk $igAppEmpty "51.A empty singleton query"
-$igAppEmptyObj = $igAppEmpty | ConvertFrom-Json
-if ($null -ne $igAppEmptyObj.data.ig_app_config) { throw "51.A: expected ig_app_config == null before first row, got: $igAppEmpty" }
-pass "51.A: ig_app_config singular query returns null before first row"
-
-$igAppUpdateEmpty = gqlq 'mutation { update_ig_app_config(input: "{\"theme\":\"dark\"}") { id theme } }'
-assertGqlErrors $igAppUpdateEmpty "51.A update on empty singleton"
-$igAppUpdateEmptyObj = $igAppUpdateEmpty | ConvertFrom-Json
-if ($igAppUpdateEmptyObj.errors[0].extensions.code -ne "SINGLETON_NOT_FOUND") {
-    throw "51.A: expected SINGLETON_NOT_FOUND, got: $($igAppUpdateEmptyObj.errors[0].extensions.code)"
-}
-pass "51.A: update_ig_app_config rejects empty table with SINGLETON_NOT_FOUND"
-
-$igAppUpsertCreate = gqlq 'mutation { upsert_ig_app_config(input: "{\"theme\":\"dark\"}") { id created } }'
-assertGqlOk $igAppUpsertCreate "51.A first upsert"
-$igAppUpsertCreateObj = $igAppUpsertCreate | ConvertFrom-Json
-$IG_APP_ID = $igAppUpsertCreateObj.data.upsert_ig_app_config.id
-if (-not $IG_APP_ID) { throw "51.A: first upsert returned empty id" }
-if (-not $igAppUpsertCreateObj.data.upsert_ig_app_config.created) { throw "51.A: first upsert should return created=true" }
-pass "51.A: upsert_ig_app_config creates the first singleton row"
-
-$igAppAfterCreate = gqlq '{ ig_app_config { theme } }'
-assertGqlOk $igAppAfterCreate "51.A singular query after create"
-if ((($igAppAfterCreate | ConvertFrom-Json).data.ig_app_config.theme) -ne "dark") {
-    throw "51.A: expected theme=dark after first upsert, got: $igAppAfterCreate"
-}
-pass "51.A: ig_app_config singular query returns theme dark after upsert"
-
-$igAppUpsertUpdate = gqlq 'mutation { upsert_ig_app_config(input: "{\"theme\":\"light\"}") { id created } }'
-assertGqlOk $igAppUpsertUpdate "51.A second upsert"
-$igAppUpsertUpdateObj = $igAppUpsertUpdate | ConvertFrom-Json
-if ($igAppUpsertUpdateObj.data.upsert_ig_app_config.created) { throw "51.A: second upsert should return created=false" }
-if ($igAppUpsertUpdateObj.data.upsert_ig_app_config.id -ne $IG_APP_ID) {
-    throw "51.A: second upsert should preserve id $IG_APP_ID, got $($igAppUpsertUpdateObj.data.upsert_ig_app_config.id)"
-}
-pass "51.A: upsert_ig_app_config returns created=false once the row exists"
-
-$igAppUpdateOk = gqlq 'mutation { update_ig_app_config(input: "{\"theme\":\"auto\"}") { id theme } }'
-assertGqlOk $igAppUpdateOk "51.A update after create"
-$igAppUpdateOkObj = $igAppUpdateOk | ConvertFrom-Json
-if ($igAppUpdateOkObj.data.update_ig_app_config.id -ne $IG_APP_ID) { throw "51.A: update should preserve id $IG_APP_ID" }
-if ($igAppUpdateOkObj.data.update_ig_app_config.theme -ne "auto") { throw "51.A: update should return theme=auto, got: $igAppUpdateOk" }
-pass "51.A: update_ig_app_config updates the singleton row in place"
-
-$igAppCreateFail = gqlq 'mutation { createDoogat(input: { type: "ig_app_config", title: "x", fields: "{\"theme\":\"system\"}" }) { id } }'
-assertGqlErrors $igAppCreateFail "51.A createDoogat duplicate singleton"
-$igAppCreateFailObj = $igAppCreateFail | ConvertFrom-Json
-if ($igAppCreateFailObj.errors[0].extensions.code -ne "SINGLETON_VIOLATION") {
-    throw "51.A: expected SINGLETON_VIOLATION, got: $($igAppCreateFailObj.errors[0].extensions.code)"
-}
-pass "51.A: createDoogat rejects a second ig_app_config row with SINGLETON_VIOLATION"
-
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-# DROP via GraphQL executeSql so the server reloads its schema (see 51.A note).
-$output = gqlq 'mutation { executeSql(sql: "DROP TABLE ig_app_config CASCADE") { message } }'
-if ($output -notmatch "dropped") { throw "51.A: ig_app_config drop failed: $output" }
-waitSchemaReload $ver
-
-# 52.B - ALTER TABLE SET/DROP SINGLETON (T20 §B)
-$output = ddb query "CREATE TABLE ig_alter_cfg (theme TEXT)"
-if ($output -notmatch "table ig_alter_cfg created") { throw "52.B: ig_alter_cfg create failed: $output" }
-$alterIds = ddb query "INSERT INTO ig_alter_cfg (title, theme) VALUES ('cfg-a', 'dark'), ('cfg-b', 'light')"
-if ($alterIds -notmatch "^\d{14},\d{14}$") { throw "52.B: expected 2 ids from ig_alter_cfg seed, got: $alterIds" }
-
-$igAlterSetFail = & $DDB query "ALTER TABLE ig_alter_cfg SET SINGLETON" 2>&1 | Out-String
-if ($LASTEXITCODE -eq 0) { throw "52.B: SET SINGLETON should fail while 2 rows exist" }
-if ($igAlterSetFail -notmatch "typedef holds 2 rows") { throw "52.B: wrong multi-row rejection: $igAlterSetFail" }
-pass "52.B: ALTER TABLE ... SET SINGLETON rejects a typedef holding 2 rows"
-
-$output = ddb query "DELETE FROM ig_alter_cfg WHERE title = 'cfg-b'"
-if ($output -notmatch "1 row") { throw "52.B: delete down to one row failed: $output" }
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-# Route ALTER through GraphQL executeSql so the running server's schema
-# reload triggers (mutations.rs::executeSql fires trigger_reload_and_wait
-# on every "ALTER TABLE"). Going through the CLI mutates the repo but
-# never wakes the server.
-gqlq 'mutation { executeSql(sql: "ALTER TABLE ig_alter_cfg SET SINGLETON") { message } }' | Out-Null
-waitSchemaReload $ver
-$igAlterIntro = gqlq '{ __schema { queryType { fields { name } } } }'
-assertGqlOk $igAlterIntro "52.B introspection after SET SINGLETON"
-$igAlterFields = @((($igAlterIntro | ConvertFrom-Json).data.__schema.queryType.fields) | ForEach-Object { $_.name })
-if ("ig_alter_cfg" -notin $igAlterFields) { throw "52.B: missing ig_alter_cfg singular field after SET SINGLETON" }
-pass "52.B: ALTER TABLE ... SET SINGLETON adds the ig_alter_cfg singular query field"
-
-$ver = if ((gqlq '{ schemaVersion }') -match '"schemaVersion":(\d+)') { [int]$Matches[1] } else { 0 }
-gqlq 'mutation { executeSql(sql: "ALTER TABLE ig_alter_cfg DROP SINGLETON") { message } }' | Out-Null
-waitSchemaReload $ver
-$igAlterDropIntro = gqlq '{ __schema { queryType { fields { name } } } }'
-assertGqlOk $igAlterDropIntro "52.B introspection after DROP SINGLETON"
-$igAlterDropFields = @((($igAlterDropIntro | ConvertFrom-Json).data.__schema.queryType.fields) | ForEach-Object { $_.name })
-if ("ig_alter_cfg" -in $igAlterDropFields) { throw "52.B: ig_alter_cfg singular field should disappear after DROP SINGLETON" }
-pass "52.B: ALTER TABLE ... DROP SINGLETON removes the ig_alter_cfg singular query field"
-
-$output = ddb query "DROP TABLE ig_alter_cfg CASCADE"
-if ($output -notmatch "dropped") { throw "52.B: ig_alter_cfg drop failed: $output" }
-
-# 53.C - SINGLETON DEFAULT VALUES auto-seed (T20 §C)
-$output = ddb query "CREATE TABLE ig_seed_cfg (theme TEXT DEFAULT 'system', schema_version INTEGER DEFAULT 1) SINGLETON DEFAULT VALUES"
-if ($output -notmatch "table ig_seed_cfg created") { throw "53.C: ig_seed_cfg create failed: $output" }
-$seedCount = ddb query "SELECT COUNT(*) FROM ig_seed_cfg"
-if ($seedCount -notmatch "^1$") { throw "53.C: expected exactly one ig_seed_cfg row, got: $seedCount" }
-$seedValues = ddb query "SELECT theme, schema_version FROM ig_seed_cfg"
-if ($seedValues -notmatch "system") { throw "53.C: missing theme=system in auto-seeded row: $seedValues" }
-if ($seedValues -notmatch "1") { throw "53.C: missing schema_version=1 in auto-seeded row: $seedValues" }
-pass "53.C: SINGLETON DEFAULT VALUES auto-seeds one ig_seed_cfg row with defaults"
-ddb query "DROP TABLE ig_seed_cfg CASCADE" | Out-Null
-
-# 54.D - Cross-protocol parity (T22)
-$output = ddb query "CREATE TABLE ig_parity_cfg (theme TEXT) SINGLETON"
-if ($output -notmatch "table ig_parity_cfg created") { throw "54.D: ig_parity_cfg create failed: $output" }
-$igParityId = (ddb query "INSERT INTO ig_parity_cfg (title, theme) VALUES ('seed', 'p1')").Trim()
-if ($igParityId -notmatch '^\d{14}$') { throw "54.D: seed insert returned malformed id: $igParityId" }
-
-$igParityCliOut = & $DDB query "INSERT INTO ig_parity_cfg (title, theme) VALUES ('x', 'p2')" 2>&1 | Out-String
-$igParityCliExit = $LASTEXITCODE
-if ($igParityCliExit -eq 0) { throw "54.D: raw ddb query duplicate INSERT should fail" }
-if ($igParityCliOut -notmatch "SINGLETON constraint") { throw "54.D: raw ddb query duplicate should surface SINGLETON constraint, got: $igParityCliOut" }
-pass "54.D: raw ddb query duplicate INSERT surfaces the SINGLETON constraint message"
-
-$igParityGqlSql = gqlq 'mutation { executeSql(sql: "INSERT INTO ig_parity_cfg (title, theme) VALUES (''x'', ''p2'')") { message affected rows } }'
-assertGqlErrors $igParityGqlSql "54.D GraphQL executeSql duplicate"
-$igParityGqlSqlObj = $igParityGqlSql | ConvertFrom-Json
-if ($igParityGqlSqlObj.errors[0].extensions.code -ne "SINGLETON_VIOLATION") {
-    throw "54.D: executeSql expected SINGLETON_VIOLATION, got: $($igParityGqlSqlObj.errors[0].extensions.code)"
-}
-if ($igParityGqlSqlObj.errors[0].extensions.table -ne "ig_parity_cfg") {
-    throw "54.D: executeSql expected table=ig_parity_cfg, got: $($igParityGqlSqlObj.errors[0].extensions.table)"
-}
-pass "54.D: GraphQL executeSql duplicate INSERT carries SINGLETON_VIOLATION + table"
-
-$igParityGqlTyped = gqlq 'mutation { createDoogat(input: { type: "ig_parity_cfg", title: "x", fields: "{\"theme\":\"p3\"}" }) { id } }'
-assertGqlErrors $igParityGqlTyped "54.D GraphQL createDoogat duplicate"
-$igParityGqlTypedObj = $igParityGqlTyped | ConvertFrom-Json
-if ($igParityGqlTypedObj.errors[0].extensions.code -ne "SINGLETON_VIOLATION") {
-    throw "54.D: createDoogat expected SINGLETON_VIOLATION, got: $($igParityGqlTypedObj.errors[0].extensions.code)"
-}
-if ($igParityGqlTypedObj.errors[0].extensions.table -ne "ig_parity_cfg") {
-    throw "54.D: createDoogat expected table=ig_parity_cfg, got: $($igParityGqlTypedObj.errors[0].extensions.table)"
-}
-pass "54.D: GraphQL createDoogat duplicate INSERT carries SINGLETON_VIOLATION + table"
-
-if (
-    $igParityGqlSqlObj.errors[0].extensions.code -ne $igParityGqlTypedObj.errors[0].extensions.code -or
-    $igParityGqlSqlObj.errors[0].extensions.table -ne $igParityGqlTypedObj.errors[0].extensions.table
-) {
-    throw "54.D: GraphQL singleton error extensions diverged between executeSql and createDoogat"
-}
-pass "54.D: GraphQL executeSql and createDoogat return identical singleton error extensions"
-
-$igParityRestResp = Invoke-WebRequest -Uri "$REST_URL/doogats" -Method POST -ContentType "application/json" `
-    -Headers @{ Authorization = "Bearer $TOKEN" } `
-    -Body '{"title":"x","type":"ig_parity_cfg"}' -SkipHttpErrorCheck
-$igParityRestStatus = [int]$igParityRestResp.StatusCode
-# PRD 00139 cycle-3 #2: client errors must land in 4xx, not 5xx. Tighten the
-# assertion from "lt 400" (which passed for 500) to the specific 409 mapping
-# the new rest_error code-to-status mapping produces for SINGLETON_VIOLATION.
-if ($igParityRestStatus -ne 409) { throw "54.D: REST duplicate create should return 409 Conflict, got HTTP $igParityRestStatus" }
-$igParityRestObj = (content $igParityRestResp) | ConvertFrom-Json
-if ($igParityRestObj.error -ne "SINGLETON_VIOLATION") {
-    throw "54.D: REST duplicate create expected SINGLETON_VIOLATION, got: $($igParityRestObj.error)"
-}
-if ($igParityRestObj.message -notmatch "ig_parity_cfg") {
-    throw "54.D: REST duplicate create message should mention table=ig_parity_cfg, got: $($igParityRestObj.message)"
-}
-if ($igParityRestObj.message -notmatch [regex]::Escape($igParityId)) {
-    throw "54.D: REST duplicate create message should mention existing_id=$igParityId, got: $($igParityRestObj.message)"
-}
-pass "54.D: REST POST /doogats duplicate create carries SINGLETON_VIOLATION + table/id in the error envelope"
-
-# NoSQL HTTP is read-only today: ddb-server/src/nosql_api.rs exposes only GET
-# scan/get/backlinks routes, so SINGLETON write parity is N/A until the surface
-# grows a typed write route. The follow-up is tracked in
-# dev/local/autopilot/deferred/00139-cycle-1-deferred.json instead of silently
-# skipping coverage.
-$igParityNosqlResp = Invoke-WebRequest -Uri $NOSQL_URL -Method POST -ContentType "application/json" `
-    -Headers @{ Authorization = "Bearer $TOKEN" } `
-    -Body '{"title":"x","type":"ig_parity_cfg"}' -SkipHttpErrorCheck
-$igParityNosqlStatus = [int]$igParityNosqlResp.StatusCode
-if (($igParityNosqlStatus -ne 404) -and ($igParityNosqlStatus -ne 405)) {
-    throw "54.D: NoSQL HTTP should expose no POST write route, got HTTP $igParityNosqlStatus"
-}
-pass "54.D: NoSQL HTTP exposes no typed write route for singleton parity; deferred gap recorded"
-
-# CLI and PgWire expose human-readable SQL-style messages rather than the
-# GraphQL `extensions` envelope, so parity here is asserted on the stable
-# message fragment instead of byte-identical structured JSON. PowerShell often
-# runs on Windows CI hosts without `psql`, so skip only the shell-driven PgWire
-# leg here; `cargo test -p ddb-e2e --test e2e -- pgwire_singleton` provides
-# the cross-platform PgWire singleton coverage path for Windows CI.
-$psql = Get-Command psql -ErrorAction SilentlyContinue
-if ($psql) {
-    $env:PGPASSWORD = $TOKEN
-    $igParityPgOut = & psql -h 127.0.0.1 -p $PG_PORT -U ddb -d ddb -c "INSERT INTO ig_parity_cfg (title, theme) VALUES ('x', 'p4')" 2>&1 | Out-String
-    $igParityPgExit = $LASTEXITCODE
-    Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
-    if ($igParityPgExit -eq 0) { throw "54.D: PgWire duplicate INSERT should fail" }
-    if ($igParityPgOut -notmatch "SINGLETON constraint") { throw "54.D: PgWire duplicate should surface SINGLETON constraint, got: $igParityPgOut" }
-    pass "54.D: PgWire duplicate INSERT surfaces the SINGLETON constraint message"
-} else {
-    pass "54.D: PgWire parity covered by cargo test -p ddb-e2e --test e2e -- pgwire_singleton (no psql on host)"
-}
-
-$parityCount = ddb query "SELECT COUNT(*) FROM ig_parity_cfg"
-if ($parityCount -notmatch "^1$") { throw "54.D: singleton parity count should stay at 1, got: $parityCount" }
-$parityTheme = ddb query "SELECT theme FROM ig_parity_cfg"
-if ($parityTheme -notmatch "p1") { throw "54.D: singleton parity theme should remain p1, got: $parityTheme" }
-pass "54.D: duplicate INSERT parity leaves the singleton end state unchanged"
-ddb query "DROP TABLE ig_parity_cfg CASCADE" | Out-Null
-
-# 55. Cross-process SINGLETON write race + structured-error parity (PRD 00140).
-
-# 55.A - CLI `ddb create` race
-# Each job returns a hashtable with output (string) and exit (int) so both are
-# recoverable from Receive-Job without inspecting internal job streams.
-ddl 'mutation { executeSql(sql: "CREATE TABLE ig_race_cli (theme TEXT) SINGLETON") { message } }'
-$job55A1 = Start-Job -ScriptBlock {
-    param($ddb)
-    $out = & $ddb create --type ig_race_cli --title x --set theme=dark 2>&1 | Out-String
-    @{ out = $out; exit = $LASTEXITCODE }
-} -ArgumentList $DDB
-$job55A2 = Start-Job -ScriptBlock {
-    param($ddb)
-    $out = & $ddb create --type ig_race_cli --title x --set theme=dark 2>&1 | Out-String
-    @{ out = $out; exit = $LASTEXITCODE }
-} -ArgumentList $DDB
-$res55A1 = Receive-Job -Job $job55A1 -Wait
-$res55A2 = Receive-Job -Job $job55A2 -Wait
-Remove-Job $job55A1
-Remove-Job $job55A2
-$exit55A1 = [int]$res55A1.exit; $out55A1 = [string]$res55A1.out
-$exit55A2 = [int]$res55A2.exit; $out55A2 = [string]$res55A2.out
-$cliOk = (($exit55A1 -eq 0) ? 1 : 0) + (($exit55A2 -eq 0) ? 1 : 0)
-$cliFail = (($exit55A1 -ne 0) ? 1 : 0) + (($exit55A2 -ne 0) ? 1 : 0)
-if ($cliOk -ne 1) { throw "55.A: expected exactly 1 CLI winner, got $cliOk" }
-if ($cliFail -ne 1) { throw "55.A: expected exactly 1 CLI loser, got $cliFail" }
-$cliLoserOut = if ($exit55A1 -ne 0) { $out55A1 } else { $out55A2 }
-if ($cliLoserOut -notmatch "SINGLETON constraint violated: ig_race_cli already holds row") {
-    throw "55.A: loser output missing SINGLETON constraint message: $cliLoserOut"
-}
-if ($cliLoserOut -match "UNIQUE constraint failed") { throw "55.A: loser output leaked raw UNIQUE constraint failed" }
-$count55A = ddb query "SELECT COUNT(*) FROM ig_race_cli"
-if ($count55A -notmatch "^1$") { throw "55.A: ig_race_cli did not converge on exactly one row, got: $count55A" }
-pass "55.A: concurrent ddb create on a SINGLETON typedef converges on one row; loser carries the structured SINGLETON message"
-
-# 55.B - GraphQL `executeSql` INSERT race
-# Jobs use Invoke-WebRequest directly (gql helper is not visible in job runspace).
-# The server returns 200 even for GraphQL errors, so we detect winner/loser by
-# response content rather than HTTP status.
-ddl 'mutation { executeSql(sql: "CREATE TABLE ig_race_sql (theme TEXT) SINGLETON") { message } }'
-$gqlBody55B = '{"query":"mutation { executeSql(sql: \"INSERT INTO ig_race_sql (title, theme) VALUES (\\\"x\\\", \\\"dark\\\")\") { message } }"}'
-$job55B1 = Start-Job -ScriptBlock {
-    param($url, $token, $body)
-    $r = Invoke-WebRequest -Uri $url -Method POST -ContentType "application/json" `
-        -Headers @{ Authorization = "Bearer $token" } -Body $body -SkipHttpErrorCheck
-    if ($r.Content -is [byte[]]) { [System.Text.Encoding]::UTF8.GetString($r.Content) } else { $r.Content }
-} -ArgumentList $GQL_URL, $TOKEN, $gqlBody55B
-$job55B2 = Start-Job -ScriptBlock {
-    param($url, $token, $body)
-    $r = Invoke-WebRequest -Uri $url -Method POST -ContentType "application/json" `
-        -Headers @{ Authorization = "Bearer $token" } -Body $body -SkipHttpErrorCheck
-    if ($r.Content -is [byte[]]) { [System.Text.Encoding]::UTF8.GetString($r.Content) } else { $r.Content }
-} -ArgumentList $GQL_URL, $TOKEN, $gqlBody55B
-$resp55B1 = [string](Receive-Job -Job $job55B1 -Wait)
-$resp55B2 = [string](Receive-Job -Job $job55B2 -Wait)
-Remove-Job $job55B1
-Remove-Job $job55B2
-$sqlViolations = @($resp55B1, $resp55B2 | Where-Object { $_ -match "SINGLETON_VIOLATION" }).Count
-$sqlErrors = @($resp55B1, $resp55B2 | Where-Object { $_ -match '"errors"' }).Count
-if ($sqlViolations -ne 1) { throw "55.B: expected exactly 1 SINGLETON_VIOLATION, got $sqlViolations" }
-if ($sqlErrors -ne 1) { throw "55.B: expected exactly 1 errors response, got $sqlErrors" }
-if ($resp55B1 -match "UNIQUE constraint failed") { throw "55.B: race_sql_1 leaked raw UNIQUE constraint failed" }
-if ($resp55B2 -match "UNIQUE constraint failed") { throw "55.B: race_sql_2 leaked raw UNIQUE constraint failed" }
-$count55B = ddb query "SELECT COUNT(*) FROM ig_race_sql"
-if ($count55B -notmatch "^1$") { throw "55.B: ig_race_sql did not converge on exactly one row, got: $count55B" }
-pass "55.B: concurrent executeSql INSERT race - loser carries SINGLETON_VIOLATION"
-
-# 55.C - GraphQL typed `createDoogat` race
-ddl 'mutation { executeSql(sql: "CREATE TABLE ig_race_typed (theme TEXT) SINGLETON") { message } }'
-$gqlBody55C = '{"query":"mutation { createDoogat(input: { type: \"ig_race_typed\", title: \"x\", fields: \"{\\\"theme\\\":\\\"dark\\\"}\" }) { id } }"}'
-$job55C1 = Start-Job -ScriptBlock {
-    param($url, $token, $body)
-    $r = Invoke-WebRequest -Uri $url -Method POST -ContentType "application/json" `
-        -Headers @{ Authorization = "Bearer $token" } -Body $body -SkipHttpErrorCheck
-    if ($r.Content -is [byte[]]) { [System.Text.Encoding]::UTF8.GetString($r.Content) } else { $r.Content }
-} -ArgumentList $GQL_URL, $TOKEN, $gqlBody55C
-$job55C2 = Start-Job -ScriptBlock {
-    param($url, $token, $body)
-    $r = Invoke-WebRequest -Uri $url -Method POST -ContentType "application/json" `
-        -Headers @{ Authorization = "Bearer $token" } -Body $body -SkipHttpErrorCheck
-    if ($r.Content -is [byte[]]) { [System.Text.Encoding]::UTF8.GetString($r.Content) } else { $r.Content }
-} -ArgumentList $GQL_URL, $TOKEN, $gqlBody55C
-$resp55C1 = [string](Receive-Job -Job $job55C1 -Wait)
-$resp55C2 = [string](Receive-Job -Job $job55C2 -Wait)
-Remove-Job $job55C1
-Remove-Job $job55C2
-$typedViolations = @($resp55C1, $resp55C2 | Where-Object { $_ -match "SINGLETON_VIOLATION" }).Count
-$typedErrors = @($resp55C1, $resp55C2 | Where-Object { $_ -match '"errors"' }).Count
-if ($typedViolations -ne 1) { throw "55.C: expected exactly 1 SINGLETON_VIOLATION, got $typedViolations" }
-if ($typedErrors -ne 1) { throw "55.C: expected exactly 1 errors response, got $typedErrors" }
-if ($resp55C1 -match "UNIQUE constraint failed") { throw "55.C: race_typed_1 leaked raw UNIQUE constraint failed" }
-if ($resp55C2 -match "UNIQUE constraint failed") { throw "55.C: race_typed_2 leaked raw UNIQUE constraint failed" }
-$count55C = ddb query "SELECT COUNT(*) FROM ig_race_typed"
-if ($count55C -notmatch "^1$") { throw "55.C: ig_race_typed did not converge on exactly one row, got: $count55C" }
-pass "55.C: concurrent createDoogat race - loser carries SINGLETON_VIOLATION"
-
-# 55.D - CLI-vs-PgWire concurrent INSERT race.
-#
-# Determinism contract (PRD 00157, root-caused 2026-06-16; see
-# docs/src/technical/sql-engine.md "Cross-process SINGLETON write safety").
-# This is the ONLY truly cross-process race in section 55: a separate `ddb` CLI
-# process (service path, holds BEGIN IMMEDIATE) racing the server's PgWire
-# INSERT (dml.rs path - no IMMEDIATE window: Layer-2 pre-check + Layer-3
-# `<table>_singleton_lock` UNIQUE backstop). 55.A/B/C are serialized within a
-# single process, so their loser deterministically carries the structured
-# SINGLETON message. 55.D cannot promise that wording: the two processes do not
-# share one lock discipline and additionally contend on git (`.git/index.lock`,
-# ref updates) outside SQLite's lock, so a loser that collides on git (or waits
-# out the winner's held write lock) before reaching a singleton enforcement
-# layer surfaces a transient contention error instead. Closing that window
-# would need a cross-process git lock - out of PRD 00157 scope. The
-# DETERMINISTIC promise is therefore: (1) exactly one winner and one loser;
-# (2) exactly one materialized row survives (Layer-3 UNIQUE - hard); (3) no raw
-# `UNIQUE constraint failed` ever leaks; (4) the loser surfaces a RECOGNIZED
-# failure - the structured SINGLETON message OR a transient cross-process
-# contention error - never an unrecognized error, never a second row. No retry
-# loop: the assertion encodes the real promise (PRD Risk #2).
-#
-# Follow .ps1 section 54.D convention: skip (pass) when psql is absent; only
-# create/assert ig_race_pg when psql is present.
-$pgRan = $false
-$psql55 = Get-Command psql -ErrorAction SilentlyContinue
-if ($psql55) {
-    ddl 'mutation { executeSql(sql: "CREATE TABLE ig_race_pg (theme TEXT) SINGLETON") { message } }'
-    $job55D1 = Start-Job -ScriptBlock {
-        param($ddb)
-        $out = & $ddb create --type ig_race_pg --title x --set theme=dark 2>&1 | Out-String
-        @{ out = $out; exit = $LASTEXITCODE }
-    } -ArgumentList $DDB
-    $job55D2 = Start-Job -ScriptBlock {
-        param($pgPort, $token)
-        $env:PGPASSWORD = $token
-        $out = & psql -h 127.0.0.1 -p $pgPort -U ddb -d ddb `
-            -c "INSERT INTO ig_race_pg (title, theme) VALUES ('x', 'dark')" 2>&1 | Out-String
-        @{ out = $out; exit = $LASTEXITCODE }
-    } -ArgumentList $PG_PORT, $TOKEN
-    $res55D1 = Receive-Job -Job $job55D1 -Wait
-    $res55D2 = Receive-Job -Job $job55D2 -Wait
-    Remove-Job $job55D1
-    Remove-Job $job55D2
-    $exit55D1 = [int]$res55D1.exit; $out55D1 = [string]$res55D1.out
-    $exit55D2 = [int]$res55D2.exit; $out55D2 = [string]$res55D2.out
-    $pgOk = (($exit55D1 -eq 0) ? 1 : 0) + (($exit55D2 -eq 0) ? 1 : 0)
-    $pgFail = (($exit55D1 -ne 0) ? 1 : 0) + (($exit55D2 -ne 0) ? 1 : 0)
-    if ($pgOk -ne 1) { throw "55.D: expected exactly 1 winner, got $pgOk" }
-    if ($pgFail -ne 1) { throw "55.D: expected exactly 1 loser, got $pgFail" }
-    $pgLoserOut = if ($exit55D1 -ne 0) { $out55D1 } else { $out55D2 }
-    # Promise (3): a raw UNIQUE leak is always a bug, whichever layer caught it.
-    if ($pgLoserOut -match "UNIQUE constraint failed") { throw "55.D: loser leaked raw UNIQUE constraint failed" }
-    # Promise (4): the loser must surface a RECOGNIZED failure - the structured
-    # SINGLETON message, or a transient cross-process contention error (git lock
-    # / SQLite busy). An unrecognized error means a new failure mode to triage.
-    if ($pgLoserOut -notmatch "SINGLETON constraint|locked|busy|index\.lock|cannot lock|unable to create|File exists|another git process") {
-        throw "55.D: loser surfaced an unrecognized error (expected structured SINGLETON message or a transient cross-process contention error): $pgLoserOut"
-    }
-    # Promise (2): convergence - exactly one materialized row survives.
-    $count55D = ddb query "SELECT COUNT(*) FROM ig_race_pg"
-    if ($count55D -notmatch "^1$") { throw "55.D: ig_race_pg did not converge on exactly one row, got: $count55D" }
-    pass "55.D: concurrent CLI-vs-PgWire INSERT race on a SINGLETON typedef - converges on one row; loser carries the structured SINGLETON message or a transient cross-process contention error, never a raw UNIQUE leak"
-    $pgRan = $true
-} else {
-    pass "55.D: PgWire race covered by cargo test -p ddb-e2e --test e2e -- pgwire_singleton (no psql on host)"
-}
-
-# 55.E - convergence parity: every race left exactly one row.
-foreach ($t in @("ig_race_cli", "ig_race_sql", "ig_race_typed")) {
-    $c = ddb query "SELECT COUNT(*) FROM $t"
-    if ($c -notmatch "^1$") { throw "55.E: $t did not converge on exactly one row, got: $c" }
-}
-if ($pgRan) {
-    $c = ddb query "SELECT COUNT(*) FROM ig_race_pg"
-    if ($c -notmatch "^1$") { throw "55.E: ig_race_pg did not converge on exactly one row, got: $c" }
-}
-pass "55.E: CLI, executeSql, createDoogat, and PgWire races each converged on exactly one row (A/B/C losers carry the structured SINGLETON violation; the cross-process PgWire loser carries a recognized SINGLETON-or-contention failure, never a raw UNIQUE leak)"
-
-# Cleanup
-ddb query "DROP TABLE ig_race_cli CASCADE" | Out-Null
-ddb query "DROP TABLE ig_race_sql CASCADE" | Out-Null
-ddb query "DROP TABLE ig_race_typed CASCADE" | Out-Null
-if ($pgRan) { ddb query "DROP TABLE ig_race_pg CASCADE" | Out-Null }
-
-# 56. REST warnings envelope (PRD 00147 doubt-review follow-up). Pins the
-# AppOutput.warnings surface that ddb-server/src/rest.rs:create_doogat exposes:
-# the response body always carries a `warnings` array (empty when none) and a
-# template-rendered title fires a TITLE_FROM_TEMPLATE entry. Mirrors the bash
-# scenario added at the same time so cross-platform CI exercises the same
-# contract.
-$warnCreate = ddb query "CREATE TABLE ig_warn_demo (note TEXT)"
-if ($warnCreate -notmatch "table ig_warn_demo created") { throw "56: ig_warn_demo create failed: $warnCreate" }

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is GREEN on exact deletion SHA; both test and coverage jobs succeeded. Final Clippy passed (2m04s); cargo test-ci passed42CLI +1555core +222server, no failed/ignored tests. Three actual generic adversarial mutants were caught (two by focused tests, one by the full suite); final real-binary five-test control passed. All facades are neutralized. Task completion awaits this per-task review. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


