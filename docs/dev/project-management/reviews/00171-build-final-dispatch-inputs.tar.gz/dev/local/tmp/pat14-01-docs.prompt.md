
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition contains all task changes in these files: AGENTS.md, CONTRIBUTING.md, README.md, docs/src/technical/sql-engine.md, docs/src/technical/walkthrough.md. Other task files are reviewed in separate partitions.

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/AGENTS.md b/AGENTS.md
index 49e5ed8..5c7ff32 100644
--- a/AGENTS.md
+++ b/AGENTS.md
@@ -24,7 +24,7 @@ ddb-uniffi-bindgen/  UniFFI bindgen binary (isolated from ddb-core)
 ddb-cli/src/         Binary crate: main.rs dispatch + commands/ subcommand handlers
 ddb-server/src/      GraphQL server: lib.rs entrypoint, actor/ core bridge, schema/ dynamic
                      GraphQL (queries, mutations/, subscriptions), auth.rs, config.rs, error.rs
-tests/               e2e/ (assert_cmd), smoke.sh + integration.sh (+ .ps1 ports), fixtures/
+tests/               e2e/ (Rust smoke_, integration_, and other assert_cmd scenarios), fixtures/
 dev/bin/             Developer scripts (release, build-xcframework, build-android,
                      safe-showboat-verify + its regression test)
 docs/src/            mdbook documentation (architecture, technical, guide)
@@ -105,7 +105,7 @@ A task is NOT complete unless ALL of these pass locally:
 3. **Fast tests** — `cargo test-ci` passes.
 4. **TDD unit tests** — unit tests for the change live alongside the module being touched and pass under `cargo test-ci`.
 
-Do NOT run `cargo test --workspace`, the e2e suite, `tests/integration.sh`, the `.ps1` ports, property tests, cross-platform jobs, coverage, or `showboat verify` per task. Those belong to Tier 2.
+Do NOT run `cargo test --workspace`, the e2e suite, property tests, cross-platform jobs, coverage, or `showboat verify` per task. Those belong to Tier 2.
 
 One narrow exception: `CLAUDE.md` instructs Claude-routed sessions to run `cargo test -p ddb-e2e` after any task that deletes or replaces existing code paths (skipped for purely additive tasks). That conditional, scope-limited e2e run is intentional — it is a deletion safety net, not a relaxation of Tier 1. See `CLAUDE.md` for the exact wording.
 
@@ -113,8 +113,8 @@ One narrow exception: `CLAUDE.md` instructs Claude-routed sessions to run `cargo
 
 The heavy battery is owned by the GitHub Actions workflows:
 
-- `test.yml` runs on every push: full workspace tests, cross-platform jobs, and the matrix that catches regressions the fast tier can miss.
-- `full-validation.yml` runs nightly: full `cargo test --workspace`, the e2e suite, `tests/integration.sh`, property tests, cross-platform validation, and coverage.
+- `test.yml` runs on every push: Linux Clippy, CLI build, `cargo test-ci`, Rust `smoke_` e2e scenarios, core sync integration tests, five targeted e2e cases, and a separate coverage job.
+- `full-validation.yml` runs nightly: full `cargo test --workspace`, the Rust e2e smoke and integration scenarios, property tests, cross-platform validation, and coverage.
 
 Do not duplicate these locally. If a CI failure is reproducible only locally, run the specific failing command in isolation rather than the full battery.
 
@@ -122,7 +122,7 @@ Do not duplicate these locally. If a CI failure is reproducible only locally, ru
 
 These are authoring obligations, not local execution gates:
 
-- **Smoke/integration scenario authoring** — if the PRD adds a CLI command or user-facing behavior, add a scenario to `tests/smoke.sh` and `tests/smoke.ps1`. If it adds a server endpoint, sync behavior, or CRDT logic, add it to `tests/integration.sh` and `tests/integration.ps1`. All four files follow the numbered-section + `pass` helper pattern. Execution of these scripts is delegated to CI (Tier 2). Upstream jink-feedback repros for the SQL regression suite live at `dev/local/specs/jink-feedback/ddb-repros/` (gitignored and machine-local — absent on fresh checkouts; skip this channel when the directory is missing); if present, run `bash dev/local/specs/jink-feedback/ddb-repros/run-all.sh` for an independent verification channel when investigating.
+- **Smoke/integration scenario authoring** — if the PRD adds a CLI command or user-facing behavior, add a `smoke_` scenario under `tests/e2e/`. If it adds a server endpoint, sync behavior, CRDT logic, or a multi-step workflow, add an `integration_` scenario there. Register new modules in `tests/e2e/main.rs`. Execution of these Rust e2e scenarios is delegated to CI (Tier 2). Upstream jink-feedback repros for the SQL regression suite live at `dev/local/specs/jink-feedback/ddb-repros/` (gitignored and machine-local — absent on fresh checkouts; skip this channel when the directory is missing); if present, run `bash dev/local/specs/jink-feedback/ddb-repros/run-all.sh` for an independent verification channel when investigating.
 - **E2E test authoring** — new user-facing behavior still requires its e2e test written under `tests/e2e/`. The test is authored as part of the PRD; execution happens in CI.
 - **Docs** — update relevant files in `docs/src/` to reflect any behavioral or API changes.
 - **Walkthrough** — if the PRD adds a CLI command, server endpoint, or user-facing behavior, create an executable showboat walkthrough in `dev/local/walkthroughs/` (see Showboat Walkthroughs below).
@@ -156,8 +156,8 @@ cargo test -p ddb-e2e                 Run e2e tests only
 cargo bench                           Run criterion benchmarks (CRUD + search)
 cargo bench --no-run                  Compile benchmarks without running
 cargo build -p ddb-core --features profiling   Build with tracing instrumentation
-./tests/smoke.sh                      CLI smoke test
-./tests/integration.sh                Full integration tests (runs smoke first)
+cargo test -p ddb-e2e smoke_          CLI smoke scenarios (Tier 2)
+cargo test -p ddb-e2e integration_    Integration scenarios (Tier 2)
 cargo test -p ddb-core --test property_tests   Property-based integration tests
 cargo test -p ddb-core --test sync_test        Core sync integration tests
 cargo clippy --workspace --all-targets   Lint (incl. test targets; matches CI)
diff --git a/CONTRIBUTING.md b/CONTRIBUTING.md
index 217990f..4f3098d 100644
--- a/CONTRIBUTING.md
+++ b/CONTRIBUTING.md
@@ -19,7 +19,7 @@ git config core.hooksPath dev/hooks
 
 ```bash
 cargo build
-cargo test
+cargo test-ci
 ```
 
 See [AGENTS.md](AGENTS.md) for the full command reference.
@@ -38,22 +38,24 @@ Follow the conventions in [AGENTS.md](AGENTS.md). Key points:
 Every change needs tests:
 
 - **Unit tests** in the module
-- **Integration/e2e tests** in `tests/` for behavior changes
-- **Smoke test** scenarios in `tests/smoke.sh` and `tests/smoke.ps1` for CLI changes
-- **Integration test** scenarios in `tests/integration.sh` and `tests/integration.ps1` for server or sync changes
+- **Integration/e2e tests** in `tests/e2e/` for behavior changes
+- **Smoke/integration scenario authoring** — if the PRD adds a CLI command or user-facing behavior, add a `smoke_` scenario under `tests/e2e/`. If it adds a server endpoint, sync behavior, CRDT logic, or a multi-step workflow, add an `integration_` scenario there. Register new modules in `tests/e2e/main.rs`. Execution of these Rust e2e scenarios is delegated to CI (Tier 2).
 
-Run the full suite before submitting:
+Run the Tier 1 local gate after every task:
 
 ```bash
-cargo clippy --workspace
-cargo test --workspace
+cargo build
+cargo clippy --workspace --all-targets
+cargo test-ci
 ```
 
+Tier 2 runs in CI: full workspace tests, Rust e2e scenarios, property tests, cross-platform validation, and coverage. Do not duplicate the heavy battery locally. The narrow deletion safety exception in `CLAUDE.md` requires Claude-routed sessions to run `cargo test -p ddb-e2e` after tasks that delete or replace existing code paths; purely additive tasks skip that run. See [AGENTS.md](AGENTS.md) for the full two-tier policy.
+
 ## Pull Request Process
 
 1. Fork the repo and create a branch from `master`
 2. Make your changes with tests
-3. Ensure `cargo clippy --workspace` and `cargo test --workspace` pass
+3. Ensure the Tier 1 local gate and required CI checks pass
 4. Submit a PR against `master`
 
 Keep PRs focused — one concern per PR.
diff --git a/README.md b/README.md
index c4bd85e..01cef69 100644
--- a/README.md
+++ b/README.md
@@ -94,14 +94,16 @@ cargo build --release      # release build (default dev crates)
 ### Test
 
 ```bash
-cargo test                 # fast local tier
-cargo test-ci              # bounded CI matrix tier (unit/bin targets only)
-cargo test-full            # full cargo suite (includes ddb-e2e)
-cargo clippy --workspace   # lint
-./tests/smoke.sh             # CLI smoke test
-./tests/integration.sh       # full integration (runs smoke first)
+cargo test                            # default workspace test selection
+cargo test-ci                         # fast local tier (unit/bin targets only)
+cargo test-full                       # full cargo suite (Tier 2, CI)
+cargo clippy --workspace --all-targets # lint
+cargo test -p ddb-e2e                  # Rust smoke and integration scenarios (Tier 2)
+cargo test -p ddb-e2e smoke_           # CLI smoke scenarios (Tier 2)
 ```
 
+Run `cargo build`, all-target Clippy, and `cargo test-ci` locally after each task; CI runs the heavy Tier 2 battery. See [AGENTS.md](AGENTS.md) for the deletion safety exception.
+
 ### Benchmarks
 
 ```bash
diff --git a/docs/src/technical/sql-engine.md b/docs/src/technical/sql-engine.md
index 09ae575..38b0dfd 100644
--- a/docs/src/technical/sql-engine.md
+++ b/docs/src/technical/sql-engine.md
@@ -611,7 +611,7 @@ A `title_template` placeholder of the form `{col.field}` dereferences a `REFEREN
 
 65+ unit tests covering CREATE TABLE, INSERT (single and multi-row), SELECT, UPDATE, DELETE, FK validation, zone mapping (type-aware inference, VARCHAR boundary, ENUM/SET extraction, blob types), duplicate rejection, reserved name rejection, ALTER TABLE (ADD/DROP/RENAME COLUMN), DROP TABLE (CASCADE, IF EXISTS), bulk UPDATE, bulk DELETE, 8 transaction tests, 8 rejection tests for unsupported SQL features, and 7 type-aware inference tests.
 
-PRD 00122 added (all in `ddb-core/src/sql_engine/tests.rs`):
+PRD 00122 added (core tests in `ddb-core/src/sql_engine/tests.rs`):
 
 - 14 unit tests for `validate_row_against_schema` covering all 5 error message formats with explicit null/absent distinction.
 - 4 INSERT-rejection unit tests + 4 UPDATE-rejection unit tests via `executeSql`, each asserting the row is absent from BOTH the materialized table AND the `doogats` index after rejection.
@@ -619,38 +619,38 @@ PRD 00122 added (all in `ddb-core/src/sql_engine/tests.rs`):
 - 5 expression-synthesized NULL tests (`COALESCE(NULL, NULL)`, `IFNULL(NULL, NULL)`, etc.) for both INSERT and UPDATE paths (blind review C1 fix).
 - 3 multi-row INSERT atomicity tests proving that a validation failure on row N writes none of rows 1..N (blind review C2 fix).
 - 2 explicit empty-string tests pinning that `''` is rejected on INTEGER columns and accepted on TEXT.
-- 6 integration-script checks (D1-D6 in section 43 of `tests/integration.sh` and `tests/integration.ps1`).
+- 6 constraint-enforcement checks (D1-D6), now covered by the Rust e2e test `integration_sql_writes::integration_43_d_sql_constraint_enforcement`.
 
 9 E2E tests in `tests/e2e/sql_lifecycle.rs`. 3 E2E tests for junction tables in `tests/e2e/junction_tables.rs` (round-trip CRUD, reindex survival, multiple REFERENCES columns). 4 E2E tests for upsert/conflict handling in `tests/e2e/upsert.rs` (onConflict argument, IGNORE returns existing, ERROR on duplicate, mixed new/existing batch).
 
 ### PRD 00124 regression test suite (groups A-G)
 
-PRD 00124 closed the regression-coverage gap exposed by the jink-feedback integration sweep (issues #4-#8). Groups A-G map to specific files and line ranges; any new SQL correctness bug should extend the same cluster so future regressions trace back to both the originating issue and the jink repro.
+PRD 00124 closed the regression-coverage gap exposed by the jink-feedback integration sweep (issues #4-#8). Groups A-G map to core regression clusters and Rust e2e targets; any new SQL correctness bug should extend the same cluster so future regressions trace back to both the originating issue and the jink repro.
 
 **Upstream source.** The ported tests originate from shell scripts at `dev/local/specs/jink-feedback/ddb-repros/` (gitignored). The scripts use an inverted-assertion convention where exit 0 = bug reproduces. Running `bash dev/local/specs/jink-feedback/ddb-repros/run-all.sh` against a healthy build reports all four as FIXED and is a valid independent verification channel — the in-repo tests assert the opposite polarity.
 
 **Coverage map.**
 
-| Group | Bug | Rust cluster (`ddb-core/src/sql_engine/tests.rs`) | Integration (`tests/integration.sh`) | Smoke (`tests/smoke.sh`) |
-|-------|-----|---------------------------------------------------|--------------------------------------|--------------------------|
-| A1 | #4 cross-mutation parity | `update_after_unique_failure_succeeds_issue_4_a1`, `insert_after_unique_failure_succeeds_issue_4_a1`, `delete_after_unique_failure_succeeds_issue_4_a1` | Section 45 sub-block `45.A1` | Section 11 ghost-row pin |
-| A2 | #4 restart persistence | — (integration only) | Section 45 sub-block `45.A2` (kill + restart) | — |
-| A3 | #4 cross-table isolation | `failed_insert_on_table_a_does_not_corrupt_table_b_issue_4_a3` | Section 45 sub-block `45.A3` | — |
-| B1-B5 | #5 UPDATE/DELETE no-match | `update_with_missing_id_returns_affected_zero` and neighbours | Section 18 sub-block `18z` (GraphQL) + Section 30 (CLI) | — |
-| C1 | #6 search/normalize parity | `normalize_and_search_accept_same_inputs_issue_6_c1` in `search_query.rs` | Section 18h (PRD 00121) | — |
-| D1-D6 | #7 constraint enforcement | `executesql_*_rejects_*` cluster + `validate_*` | Section 43.D (PRD 00122) | — |
-| E1 | #8 JOIN pinning | `select_join_returns_joined_rows_issue_8_e1` plus CTE/subquery/UNION/window audit | Section 44 sub-block `44.E1` | — |
-| F1 | #9 composite UNIQUE error | `composite_unique_duplicate_rejected_with_clear_error_issue_9_f1` | Section 30 `30.F1` | — |
-| F2 | #9 single-col UNIQUE error | `single_column_unique_duplicate_rejected_with_clear_error_issue_9_f2` | — (pre-existing `create_table_with_unique_constraint_enforced` covers rejection) | — |
-| F3 | #9 CREATE INDEX rejected | Pre-existing `create_index_rejected_with_reason` | Section 44 (pre-existing DDL consistency check) | — |
-| F4 | #9 executeBatch atomicity | — | Section 18 sub-block `18z2` | — |
-| F5-F7 | #9 updateDoogat tag semantics | — | Section 18 sub-block `18z3` | — |
-| F9 | #9 SQL feature smoke | — | Section 18 sub-block `18z4` | — |
-| F10 | #9 search limit boundaries | — | Section 18 sub-block `18z5` | — |
-| F11 | #9 ALTER + typeDefs | — | Section 18 sub-block `18z6` | — |
-| G1, G2 | #9 GraphQL schema contract | — | Section 18 sub-block `18z7` | — |
-
-**Jink full-sweep port.** The 40+ checks from `validate-full-sweep.sh` are distributed across the existing section 17 and section 18 numbered neighbourhoods via sub-blocks `17.J1`, `17.J2`, `18z8`, `18z9`, `18z10`. The jink tables (`link`, `category`, `category-membership`, `quote`, `saved-search`, `pinned-result`, `jink-config`) are created once in `17.J1` and dropped at the end of `18z10`; they persist across the F-group and G-group sub-blocks between them.
+| Group | Bug | Rust cluster (`ddb-core/src/sql_engine/tests.rs`) | Rust E2E target (`tests/e2e/`) |
+|-------|-----|---------------------------------------------------|------------------------------|
+| A1 | #4 cross-mutation parity | `update_after_unique_failure_succeeds_issue_4_a1`, `insert_after_unique_failure_succeeds_issue_4_a1`, `delete_after_unique_failure_succeeds_issue_4_a1` | `integration_write_recovery::integration_45_a1_cross_mutation_parity_after_unique_failure`, `smoke_sql::smoke_11c_ghost_row_recovery` |
+| A2 | #4 restart persistence | — (integration only) | `integration_write_recovery::integration_45_a2_ghost_row_survives_server_restart` |
+| A3 | #4 cross-table isolation | `failed_insert_on_table_a_does_not_corrupt_table_b_issue_4_a3` | `integration_write_recovery::integration_45_a3_cross_table_isolation_after_unique_failure` |
+| B1-B5 | #5 UPDATE/DELETE no-match | `update_with_missing_id_returns_affected_zero` and neighbours | `integration_graphql_server::integration_18z_update_delete_no_match_parity`, `integration_sql_no_match::integration_30_where_id_no_match_semantics` |
+| C1 | #6 search/normalize parity | `normalize_and_search_accept_same_inputs_issue_6_c1` in `search_query.rs` | `integration_graphql_server::integration_18h_in_query_field_filter_and_error_class` |
+| D1-D6 | #7 constraint enforcement | `executesql_*_rejects_*` cluster + `validate_*` | `integration_sql_writes::integration_43_d_sql_constraint_enforcement` |
+| E1 | #8 JOIN pinning | `select_join_returns_joined_rows_issue_8_e1` plus CTE/subquery/UNION/window audit | `integration_junction_sync::integration_44_e1_join_pin_graphql` |
+| F1 | #9 composite UNIQUE error | `composite_unique_duplicate_rejected_with_clear_error_issue_9_f1` | `integration_sql_no_match::integration_30_f1_composite_unique_cli_rejection` |
+| F2 | #9 single-col UNIQUE error | `single_column_unique_duplicate_rejected_with_clear_error_issue_9_f2`, `create_table_with_unique_constraint_enforced` | — |
+| F3 | #9 CREATE INDEX rejected | Pre-existing `create_index_rejected_with_reason` | `integration_typed_write_polish::integration_44_ddl_response_consistency` |
+| F4 | #9 executeBatch atomicity | — | `integration_graphql_server::integration_18z2_execute_batch_atomicity` |
+| F5-F7 | #9 updateDoogat tag semantics | — | `integration_graphql_server::integration_18z3_update_doogat_tag_semantics` |
+| F9 | #9 SQL feature smoke | — | `integration_graphql_server::integration_18z4_sql_feature_coverage_pins` |
+| F10 | #9 search limit boundaries | — | `integration_graphql_server::integration_18z5_search_limit_boundary_pins` |
+| F11 | #9 ALTER + typeDefs | — | `integration_graphql_server::integration_18z6_alter_table_add_column_in_typedefs_introspection` |
+| G1, G2 | #9 GraphQL schema contract | — | `integration_graphql_server::integration_18z7_graphql_schema_introspection_contract` |
+
+**Jink full-sweep port.** The 40+ checks from `validate-full-sweep.sh` are covered by five Rust e2e tests in `integration_graphql_jink`: `integration_17j1_jink_schema_create_tables`, `integration_17j2_jink_config_singleton_and_link_crud`, `integration_18z8_jink_category_membership_port`, `integration_18z9_jink_quotes_saved_searches_pinned_results_config_port`, and `integration_18z10_jink_composite_unique_and_batch_delete_port`. Each test starts its own repository and server and calls `setup_jink_schema` to create the jink tables (`link`, `category`, `category-membership`, `quote`, `saved-search`, `pinned-result`, `jink-config`); tests do not share fixture state.
 
 **Property tests.** `ddb-core/tests/property_tests.rs` carries four SQL engine invariant properties under the `// SQL engine invariants` section header:
 
diff --git a/docs/src/technical/walkthrough.md b/docs/src/technical/walkthrough.md
index d3a92c1..1074407 100644
--- a/docs/src/technical/walkthrough.md
+++ b/docs/src/technical/walkthrough.md
@@ -25,17 +25,17 @@ An isolated binary crate whose sole purpose is to host the UniFFI bindgen tool.
 
 ### tests (ddb-e2e)
 
-An end-to-end test harness using `assert_cmd` for CLI tests and `reqwest` for server tests. E2E tests require the `ddb` binary on the PATH, so `cargo build -p ddb-cli` must run first. The crate lives in `tests/` and is declared as the fifth workspace member.
+An end-to-end test harness using `assert_cmd` for CLI tests and `reqwest` for server tests. E2E tests require the built `ddb` binary, so `cargo build -p ddb-cli` must run first. The crate lives in `tests/`, with scenario modules under `tests/e2e/` registered in `tests/e2e/main.rs`, and is declared as the fifth workspace member.
 
 ### Build aliases and test tiers
 
 The workspace defines custom Cargo aliases:
 
-- `cargo test` runs the fast local tier (unit tests in default members).
-- `cargo test-ci` runs the bounded CI matrix (unit and binary targets only).
-- `cargo test-full` runs the complete suite including workspace-wide and e2e tests.
+- `cargo test` runs the default workspace test selection.
+- `cargo test-ci` runs the fast local tier (unit and binary targets only).
+- `cargo test-full` runs the complete suite including workspace-wide and e2e tests (Tier 2, CI).
 
-Additional test surfaces include `tests/smoke.sh` and `tests/smoke.ps1` for CLI smoke tests, `tests/integration.sh` and `tests/integration.ps1` for full integration tests (server, sync, CRDT), and Criterion benchmarks in `ddb-core/benches/` for CRUD and search performance.
+The Rust e2e crate includes `smoke_` scenarios for CLI behavior and `integration_` scenarios for server, sync, CRDT, and multi-step workflows. Run all scenarios with `cargo test -p ddb-e2e`, or filter with `smoke_` or `integration_`. Execution belongs to Tier 2; the deletion safety exception in `AGENTS.md` still applies. Criterion benchmarks in `ddb-core/benches/` cover CRUD and search performance.
 
 
 ## 2. Core Data Model
@@ -407,11 +407,11 @@ The compaction module (see `compaction/mod.rs`) cleans up CRDT temporary files i
 
 ## 7. Testing Strategy
 
-Doogat DB uses a layered testing approach with six distinct tiers, each covering different aspects of the system.
+Doogat DB uses the following test surfaces across two execution tiers: a fast local gate and the heavy CI battery. See `AGENTS.md` for the full policy and deletion safety exception.
 
 ### Unit tests
 
-In-module `#[cfg(test)] mod tests` blocks test individual functions in isolation. These run with `cargo test` (the fast local tier) and cover parsing edge cases, CRDT merge logic, SQL translation, type inference, HLC arithmetic, and error mapping. The `MockSource` in `traits::mock` provides an in-memory doogat store for tests that need a `DoogatSource` without touching Git.
+In-module `#[cfg(test)] mod tests` blocks test individual functions in isolation. These run with `cargo test-ci` (the fast local tier) and cover parsing edge cases, CRDT merge logic, SQL translation, type inference, HLC arithmetic, and error mapping. The `MockSource` in `traits::mock` provides an in-memory doogat store for tests that need a `DoogatSource` without touching Git.
 
 ### Integration tests
 
@@ -427,7 +427,7 @@ The `tests/e2e/` directory contains assert_cmd-based tests that exercise the `dd
 
 ### Smoke tests
 
-`tests/smoke.sh` (bash) and `tests/smoke.ps1` (PowerShell) provide quick CLI validation (init, CRUD, search, SQL, types, compact). `tests/integration.sh` and `tests/integration.ps1` run the smoke tests first, then continue with server, sync, CRDT conflict resolution, bundles, and advanced SQL tests. All files follow a numbered-section pattern with a `pass` helper for status reporting.
+The Rust `smoke_` scenarios in `tests/e2e/` validate CLI behavior (init, CRUD, search, SQL, types, compact); `cargo test -p ddb-e2e smoke_` selects them. The `integration_` scenarios cover server, sync, CRDT conflict resolution, bundles, advanced SQL, and other multi-step workflows. New scenarios follow these prefixes, and new modules must be registered in `tests/e2e/main.rs`. Both groups run in CI on Linux, macOS, and Windows as part of Tier 2.
 
 ### Benchmarks
 
@@ -435,7 +435,7 @@ Criterion benchmarks in `ddb-core/benches/` measure CRUD operations and search p
 
 ### Full suite
 
-`cargo test --workspace` (aliased as `cargo test-full`) runs all of the above: unit tests, integration tests, and e2e tests across all crates. This is the definitive validation before merging any change.
+`cargo test --workspace` (aliased as `cargo test-full`) runs unit tests, integration tests, and e2e tests across all crates. CI owns this Tier 2 execution; the per-task local gate is `cargo build`, `cargo clippy --workspace --all-targets`, and `cargo test-ci`.
 
 ## 8. Consistency Auto-Fix
 
@@ -774,7 +774,7 @@ The three layers keep the database correct under contention, but Layer 1's check
 
 `upsert<TypeName>` runs its existence check and the create-or-update branch under one `BEGIN IMMEDIATE` window via `DoogatService::upsert_singleton`, so two concurrent upserts on an empty SINGLETON typedef converge on one row: one call returns `created: true`, the loser takes the UPDATE branch and returns `created: false` against the same id.
 
-Trade-off: every SINGLETON write serializes through the SQLite write lock. This is acceptable by definition -- a SINGLETON typedef holds one row, so write throughput is irrelevant. Cross-process behavior is exercised by the e2e tests `singleton_cross_process_create` / `singleton_cross_process_upsert` and `tests/integration.{sh,ps1}` section 55.
+Trade-off: every SINGLETON write serializes through the SQLite write lock. This is acceptable by definition -- a SINGLETON typedef holds one row, so write throughput is irrelevant. Cross-process behavior is exercised by the e2e tests `singleton_cross_process_create` / `singleton_cross_process_upsert` and the `integration_singleton_races` and `integration_write_lock_races` modules in `tests/e2e/`.
 
 ### Auto-seed on origin-only
 

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


