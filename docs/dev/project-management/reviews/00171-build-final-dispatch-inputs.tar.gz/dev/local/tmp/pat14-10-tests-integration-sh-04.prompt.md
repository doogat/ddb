
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.sh, original lines 1649-2113, segment 4/7. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.sh:1622: DONE; targets=integration_sql_writes::integration_43_d_sql_constraint_enforcement
tests/integration.sh:1685: DONE; targets=integration_junction_sync::integration_44_e1_join_pin_graphql, sql_lifecycle::multi_table_schema_prd_scenario, tags::tag_join_filters_doogats
tests/integration.sh:1705: DONE; targets=cascade_delete::cascade_delete_cleans_owned_junction_when_parent_deleted, integration_junction_sync::integration_44_j_auto_junction_atomic_graphql
tests/integration.sh:1746: DONE; targets=integration_junction_sync::integration_44_k_create_doogat_auto_junction
tests/integration.sh:1769: DONE; targets=cascade_delete::cascade_delete_cleans_owned_junction_when_parent_deleted, integration_junction_sync::integration_44_m_parent_junction_cleanup_graphql
tests/integration.sh:1804: DONE; targets=integration_typed_write_polish::integration_44_ddl_response_consistency
tests/integration.sh:1848: DONE (pre-existing, no port needed); targets=upsert::create_many_on_conflict_ignore_returns_existing
tests/integration.sh:1870: DONE; targets=integration_typed_write_polish::integration_45_g13_title_template_omit
tests/integration.sh:1891: DONE; targets=integration_typed_write_polish::integration_45_g12_intra_batch_ignore_surviving_id, upsert::create_many_on_conflict_ignore_mixed_new_and_existing
tests/integration.sh:1917: DONE; targets=integration_tags_filter::integration_45_g11_tags_filter_nullable_operators
tests/integration.sh:1969: DONE; targets=integration_write_recovery::integration_45_a1_cross_mutation_parity_after_unique_failure
tests/integration.sh:1998: DONE; targets=integration_write_recovery::integration_45_a3_cross_table_isolation_after_unique_failure
tests/integration.sh:2021: DONE; targets=cascade_delete::delete_rejected_by_not_null_references_sql_issue_10, integration_write_recovery::integration_45_r10_restrict_blocks_sql_and_graphql_delete
tests/integration.sh:2073: DONE; targets=integration_write_recovery::integration_45_a2_ghost_row_survives_server_restart
tests/integration.sh:2109: DONE (pre-existing, no port needed) <!-- banner-only line, nothing to port; see 49.1-49.4 -->; targets=; fixture/scaffolding

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.sh b/tests/integration.sh
deleted file mode 100755
index 6942304..0000000
--- a/tests/integration.sh
+++ /dev/null
@@ -1649,465 +0,0 @@
-echo "$D3_RESULT" | grep -q "type mismatch for numeric_d3.count: expected INTEGER"
-D3_COUNT=$(gql '{"query":"mutation{executeSql(sql:\"SELECT COUNT(*) FROM numeric_d3\"){rows}}"}')
-echo "$D3_COUNT" | grep -qF '[\"0\"]'
-pass "serve: D3 INTEGER type mismatch is rejected, no row created"
-
-# D4. Unknown column on INSERT: column not in schema is rejected.
-D4_RESULT=$(gql '{"query":"mutation{executeSql(sql:\"INSERT INTO link_d1 (title, url, unknown_col) VALUES (\\\"t\\\", \\\"https://u.com\\\", \\\"dropped\\\")\"){message}}"}')
-echo "$D4_RESULT" | grep -q "unknown column: link_d1.unknown_col"
-D4_COUNT=$(gql '{"query":"mutation{executeSql(sql:\"SELECT COUNT(*) FROM link_d1\"){rows}}"}')
-echo "$D4_COUNT" | grep -qF '[\"0\"]'
-pass "serve: D4 unknown column on INSERT is rejected, no row created"
-
-# D5. Unknown column on UPDATE: insert one valid row, then UPDATE with bogus
-# column. The original row's title must be unchanged after the rejection.
-D5_VALID=$(gql '{"query":"mutation{executeSql(sql:\"INSERT INTO link_d1 (title, url) VALUES (\\\"keep\\\", \\\"https://k.com\\\")\"){message}}"}')
-D5_ID=$(echo "$D5_VALID" | sed -n 's/.*"message":"\([0-9]*\)".*/\1/p')
-D5_RESULT=$(gql "{\"query\":\"mutation{executeSql(sql:\\\"UPDATE link_d1 SET unknown_col = 'x' WHERE id = '$D5_ID'\\\"){message}}\"}")
-echo "$D5_RESULT" | grep -q "unknown column: link_d1.unknown_col"
-D5_TITLE=$(gql "{\"query\":\"mutation{executeSql(sql:\\\"SELECT title FROM link_d1 WHERE id = '$D5_ID'\\\"){rows}}\"}")
-echo "$D5_TITLE" | grep -q 'keep'
-pass "serve: D5 unknown column on UPDATE is rejected, row unchanged"
-
-# D6. Silent title fallback removed: title NOT NULL with no template, INSERT
-# omitting title now fails instead of coercing url/description into title.
-ddl '{"query":"mutation{executeSql(sql:\"CREATE TABLE link_d6 (title VARCHAR(255) NOT NULL, url VARCHAR(255), description TEXT)\"){message}}"}'
-D6_RESULT=$(gql '{"query":"mutation{executeSql(sql:\"INSERT INTO link_d6 (url) VALUES (\\\"https://notitle.com\\\")\"){message}}"}')
-echo "$D6_RESULT" | grep -q "NOT NULL constraint violated: link_d6.title"
-D6_COUNT=$(gql '{"query":"mutation{executeSql(sql:\"SELECT COUNT(*) FROM link_d6\"){rows}}"}')
-echo "$D6_COUNT" | grep -qF '[\"0\"]'
-pass "serve: D6 silent title fallback removed, missing title rejected"
-
-# Cleanup D-tables
-gql '{"query":"mutation{executeSql(sql:\"DROP TABLE link_d1 CASCADE\"){message}}"}' >/dev/null
-gql '{"query":"mutation{executeSql(sql:\"DROP TABLE numeric_d3 CASCADE\"){message}}"}' >/dev/null
-gql '{"query":"mutation{executeSql(sql:\"DROP TABLE link_d6 CASCADE\"){message}}"}' >/dev/null
-
-# 44.E1 — Pin JOIN as working (issue #8 group E1). PRD 00123 was archived
-# because JOIN actually works; this check pins the behavior at the GraphQL
-# surface so a regression can't silently drop joined rows.
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE e1_link (url VARCHAR(255))\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE e1_num (count INTEGER)\") { message } }"}' >/dev/null
-wait_schema_reload "$VER"
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO e1_link (title, url) VALUES (\\\"a\\\", \\\"https://a.com\\\")\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO e1_num (title, count) VALUES (\\\"a\\\", 1)\") { message } }"}' >/dev/null
-E1_JOIN=$(gql '{"query":"{ sql(query: \"SELECT l.title, n.count FROM e1_link l JOIN e1_num n ON l.title = n.title\") { rows } }"}')
-assert_gql_ok "$E1_JOIN"
-# SQL row responses are nested JSON-escaped (["[\"a\",\"1\"]"]); grep -F for
-# the escaped form.
-printf '%s' "$E1_JOIN" | grep -qF '\"a\"'
-printf '%s' "$E1_JOIN" | grep -qF '\"1\"'
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE e1_link CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE e1_num CASCADE\") { message } }"}' >/dev/null
-pass "issue-8-E1: SELECT ... JOIN returns joined rows (PRD 00123 archived as obsolete)"
-
-# 44.J — Auto-junction tables populated atomically on SQL INSERT and UPDATE
-# (PRD 00134). Before this PRD, `INSERT INTO <typed> (..., <ref>, ...)` and
-# `UPDATE <typed> SET <ref> = ...` skipped the `<type>_<ref>` junction table,
-# so SQL JOINs against the junction returned 0 rows until a full reindex.
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE j134_cat (label VARCHAR(100))\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE j134_bm (url TEXT, category TEXT REFERENCES j134_cat)\") { message } }"}' >/dev/null
-wait_schema_reload "$VER"
-
-# Insert two distinct category rows.
-J134_CAT_A=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO j134_cat (label) VALUES (\\\"alpha\\\")\") { message } }"}' | extract_id)
-[ -n "$J134_CAT_A" ]
-J134_CAT_B=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO j134_cat (label) VALUES (\\\"beta\\\")\") { message } }"}' | extract_id)
-[ -n "$J134_CAT_B" ]
-[ "$J134_CAT_A" != "$J134_CAT_B" ]
-
-# Insert a bookmark with the category column populated. T1's INSERT-side fix
-# must populate j134_bm_category atomically.
-J134_BM=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO j134_bm (url, category) VALUES ('https://j134.example', '$J134_CAT_A')\\\") { message } }\"}" | extract_id)
-[ -n "$J134_BM" ]
-
-J134_J1=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"SELECT category_id FROM j134_bm_category WHERE j134_bm_id = '$J134_BM'\\\") { rows } }\"}")
-# `rows` is a list of JSON-stringified rows (e.g. ["[\"<id>\"]"]); `fromjson`
-# parses the inner row before indexing.
-printf '%s' "$J134_J1" | jq -e --arg id "$J134_CAT_A" '(.data.executeSql.rows[0] | fromjson)[0] == $id' >/dev/null
-pass "PRD 00134: SQL INSERT populates auto-junction atomically (no rebuild)"
-
-# UPDATE the bookmark's category. T2's UPDATE-side fix must remove the old
-# junction row and insert the new one.
-gql "{\"query\":\"mutation { executeSql(sql: \\\"UPDATE j134_bm SET category = '$J134_CAT_B' WHERE id = '$J134_BM'\\\") { message } }\"}" >/dev/null
-
-# Old junction row pointing at cat_a must be gone.
-J134_J_OLD=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"SELECT COUNT(*) FROM j134_bm_category WHERE j134_bm_id = '$J134_BM' AND category_id = '$J134_CAT_A'\\\") { rows } }\"}")
-printf '%s' "$J134_J_OLD" | jq -e '(.data.executeSql.rows[0] | fromjson)[0] == "0"' >/dev/null
-
-# New junction row pointing at cat_b must be present.
-J134_J_NEW=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"SELECT COUNT(*) FROM j134_bm_category WHERE j134_bm_id = '$J134_BM' AND category_id = '$J134_CAT_B'\\\") { rows } }\"}")
-printf '%s' "$J134_J_NEW" | jq -e '(.data.executeSql.rows[0] | fromjson)[0] == "1"' >/dev/null
-pass "PRD 00134: SQL UPDATE syncs auto-junction (old removed, new inserted)"
-
-# 44.K — GraphQL `createDoogat` typed-create populates the auto-junction
-# atomically (PRD 00134 cycle-1 review C1 task #4). The unit-test suite
-# already covers the typed-create plumbing in detail (see
-# `service::tests::batch_create_routes_references_to_reference_zone`,
-# `create_doogat_with_extra_routes_references_for_registered_type`, plus
-# the cycle-1 fix in
-# `service::tests::service_update_doogat_syncs_auto_junction_on_references_change`);
-# this section drives the full GraphQL → service → indexer pipeline so a
-# regression in any of those layers surfaces in CI.
-J134K_CAT=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO j134_cat (label) VALUES ('gamma')\\\") { message } }\"}" | extract_id)
-[ -n "$J134K_CAT" ]
-J134K_RESP=$(gql "{\"query\":\"mutation { createDoogat(input: { type: \\\"j134_bm\\\", title: \\\"K\\\", fields: \\\"{\\\\\\\"url\\\\\\\":\\\\\\\"https://k.example\\\\\\\",\\\\\\\"category\\\\\\\":\\\\\\\"$J134K_CAT\\\\\\\"}\\\" }) { id } }\"}")
-# `createDoogat` returns the id under `data.createDoogat.id`, not `message`.
-J134K_BM=$(printf '%s' "$J134K_RESP" | jq -er '.data.createDoogat.id')
-[ -n "$J134K_BM" ]
-J134K_J=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"SELECT COUNT(*) FROM j134_bm_category WHERE j134_bm_id = '$J134K_BM' AND category_id = '$J134K_CAT'\\\") { rows } }\"}")
-printf '%s' "$J134K_J" | jq -e '(.data.executeSql.rows[0] | fromjson)[0] == "1"' >/dev/null
-pass "PRD 00134: GraphQL createDoogat populates auto-junction for REFERENCES column (44.K)"
-
-# Cleanup
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE j134_bm CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE j134_cat CASCADE\") { message } }"}' >/dev/null
-
-# 44.M — Auto-junction parent-direction cleanup on DELETE (PRD 00137).
-# `cascade_junction_cleanup` previously swept only the reverse direction
-# (junctions pointing at the deleted target). The parent-direction sweep
-# (junctions OWNED by the deleted row) is added by PRD 00137 — deleting the
-# bookmark must remove its `pdc_bm_pdc_cat` row in the same transaction.
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE pdc_cat (label VARCHAR(100))\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE pdc_bm (url TEXT, pdc_cat TEXT REFERENCES pdc_cat)\") { message } }"}' >/dev/null
-wait_schema_reload "$VER"
-
-PDC_CAT=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO pdc_cat (label) VALUES (\\\"alpha\\\")\") { message } }"}' | extract_id)
-[ -n "$PDC_CAT" ]
-PDC_BM=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO pdc_bm (url, pdc_cat) VALUES ('https://pdc.example', '$PDC_CAT')\\\") { message } }\"}" | extract_id)
-[ -n "$PDC_BM" ]
-
-# Sanity: parent-direction junction row exists post-INSERT.
-PDC_PRE=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"SELECT COUNT(*) FROM pdc_bm_pdc_cat WHERE pdc_bm_id = '$PDC_BM'\\\") { rows } }\"}")
-printf '%s' "$PDC_PRE" | jq -e '(.data.executeSql.rows[0] | fromjson)[0] == "1"' >/dev/null
-
-# Delete the bookmark (parent direction). Junction row must be cleaned.
-gql "{\"query\":\"mutation { executeSql(sql: \\\"DELETE FROM pdc_bm WHERE id = '$PDC_BM'\\\") { message } }\"}" >/dev/null
-
-PDC_POST=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"SELECT COUNT(*) FROM pdc_bm_pdc_cat WHERE pdc_bm_id = '$PDC_BM'\\\") { rows } }\"}")
-printf '%s' "$PDC_POST" | jq -e '(.data.executeSql.rows[0] | fromjson)[0] == "0"' >/dev/null
-# Stronger assertion (mirrors smoke + e2e): the only row in the junction was
-# the deleted parent's, so the whole junction table must be empty.
-PDC_POST_ALL=$(gql '{"query":"mutation { executeSql(sql: \"SELECT COUNT(*) FROM pdc_bm_pdc_cat\") { rows } }"}')
-printf '%s' "$PDC_POST_ALL" | jq -e '(.data.executeSql.rows[0] | fromjson)[0] == "0"' >/dev/null
-pass "PRD 00137: parent-delete clears owned auto-junction rows (44.M)"
-
-# Cleanup
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE pdc_bm CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE pdc_cat CASCADE\") { message } }"}' >/dev/null
-
-# 44. DDL response consistency (no spurious errors)
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-RESULT=$(gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE ddltest (name VARCHAR(100))\") { columns rows message } }"}')
-echo "$RESULT" | grep -qv '"errors"'
-echo "$RESULT" | grep -q '"columns":\[\]'
-echo "$RESULT" | grep -q '"rows":\[\]'
-echo "$RESULT" | grep -q '"message"'
-pass "serve: CREATE TABLE response has no errors"
-
-wait_schema_reload "$VER"
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-RESULT=$(gql '{"query":"mutation { executeSql(sql: \"ALTER TABLE ddltest ADD COLUMN age INTEGER\") { columns rows message } }"}')
-echo "$RESULT" | grep -qv '"errors"'
-echo "$RESULT" | grep -q '"columns":\[\]'
-echo "$RESULT" | grep -q '"rows":\[\]'
-pass "serve: ALTER TABLE response has no errors"
-
-wait_schema_reload "$VER"
-RESULT=$(gql '{"query":"mutation { executeSql(sql: \"DROP TABLE ddltest\") { columns rows message } }"}')
-echo "$RESULT" | grep -qv '"errors"'
-echo "$RESULT" | grep -q '"columns":\[\]'
-echo "$RESULT" | grep -q '"rows":\[\]'
-pass "serve: DROP TABLE response has no errors"
-
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-RESULT=$(gql '{"query":"mutation { executeBatch(statements: [\"CREATE TABLE ddlbatch1 (name VARCHAR)\", \"CREATE TABLE ddlbatch2 (val INTEGER)\"]) { columns rows message } }"}')
-echo "$RESULT" | grep -qv '"errors"'
-echo "$RESULT" | grep -q '"columns":\[\]'
-echo "$RESULT" | grep -q '"rows":\[\]'
-pass "serve: executeBatch DDL responses have no errors"
-
-wait_schema_reload "$VER"
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE ddlbatch1 CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE ddlbatch2 CASCADE\") { message } }"}' >/dev/null
-
-# DML regression: INSERT still returns affected count
-DML_RESULT=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO datecheck (name) VALUES (\\\"DmlRegression\\\")\") { affected message } }"}')
-echo "$DML_RESULT" | grep -qv '"errors"'
-echo "$DML_RESULT" | grep -q '"message"'
-pass "serve: DML INSERT response unchanged"
-
-# 45. createMany onConflict: IGNORE (upsert via GraphQL)
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE upsertgql (code TEXT, label TEXT)\") { message } }"}'
-# Patch typedef to add unique_together on [code]
-cd "$TMPDIR"
-UPSERT_TYPEDEF=$(find ddb/_typedef -name '*.md' -exec grep -l 'title: upsertgql' {} \;)
-sed -i.bak 's/type: _typedef/type: _typedef\nunique_together:\n  - - code/' "$UPSERT_TYPEDEF"
-rm -f "${UPSERT_TYPEDEF}.bak"
-git add -A && git commit -m "add unique_together to upsertgql" --quiet
-$DDB reindex >/dev/null
-CM1=$(gql '{"query":"mutation { createMany(inputs: [{title: \"UpsertA\", type: \"upsertgql\", fields: \"{\\\"code\\\":\\\"X1\\\",\\\"label\\\":\\\"first\\\"}\"}]) { id title } }"}')
-CM1_ID=$(echo "$CM1" | jq -r '.data.createMany[0].id')
-[ -n "$CM1_ID" ]
-CM2=$(gql '{"query":"mutation { createMany(inputs: [{title: \"UpsertA Dup\", type: \"upsertgql\", fields: \"{\\\"code\\\":\\\"X1\\\",\\\"label\\\":\\\"second\\\"}\"}], onConflict: IGNORE) { id title } }"}')
-CM2_ID=$(echo "$CM2" | jq -r '.data.createMany[0].id')
-[ "$CM2_ID" = "$CM1_ID" ]
-CM2_TITLE=$(echo "$CM2" | jq -r '.data.createMany[0].title')
-[ "$CM2_TITLE" = "UpsertA" ]
-pass "serve: createMany onConflict IGNORE returns existing"
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE upsertgql CASCADE\") { message } }"}' >/dev/null
-
-# === PRD 00130: GraphQL typed-write polish (issues #11/#12/#13) ===
-
-# 45.G13 — issue #13: createDoogat must omit `title` when the typedef has a
-# title_template, rendering it server-side. Pre-PRD-00130 the schema marked
-# title NON_NULL so the template never fired through GraphQL.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE g13link (title TEXT, url VARCHAR(255))\") { message } }"}'
-ddl "{\"query\":\"mutation { executeSql(sql: \\\"ALTER TABLE g13link SET TITLE TEMPLATE 'link-{url}'\\\") { message } }\"}"
-G13_OMIT=$(gql '{"query":"mutation { createDoogat(input: {type: \"g13link\", fields: \"{\\\"url\\\":\\\"https://example.com\\\"}\"}) { id title } }"}')
-assert_gql_ok "$G13_OMIT"
-G13_TITLE=$(echo "$G13_OMIT" | jq -r '.data.createDoogat.title')
-[ "$G13_TITLE" = "link-https://example.com" ]
-pass "issue-13: createDoogat omits title when typedef has title_template"
-
-# Negative: typedef without a template + omitted title → NOT_NULL_VIOLATION
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE g13plain (title TEXT, url VARCHAR(255))\") { message } }"}'
-G13_NULL=$(gql '{"query":"mutation { createDoogat(input: {type: \"g13plain\", fields: \"{\\\"url\\\":\\\"https://x\\\"}\"}) { id } }"}')
-assert_gql_errors "$G13_NULL"
-printf '%s' "$G13_NULL" | grep -q "NOT NULL constraint violated: g13plain.title"
-pass "issue-13: createDoogat without title or template rejects with NOT_NULL_VIOLATION"
-
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE g13link CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE g13plain CASCADE\") { message } }"}' >/dev/null
-
-# 45.G12 — issue #12: createMany(onConflict: IGNORE) returns the surviving
-# row's ID for skipped rows when both duplicates appear in the same batch.
-# The pre-PRD-00130 path returned the rejected (rolled-back) ID, which
-# does not exist anywhere — callers using the returned ID for follow-up
-# reads silently missed.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE g12item (code TEXT, label TEXT)\") { message } }"}'
-G12_TYPEDEF=$(find ddb/_typedef -name '*.md' -exec grep -l 'title: g12item' {} \;)
-sed -i.bak 's/type: _typedef/type: _typedef\nunique_together:\n  - - code/' "$G12_TYPEDEF"
-rm -f "${G12_TYPEDEF}.bak"
-git add -A && git commit -m "add unique_together to g12item" --quiet
-$DDB reindex >/dev/null
-G12_BATCH=$(gql '{"query":"mutation { createMany(inputs: [{title: \"A\", type: \"g12item\", fields: \"{\\\"code\\\":\\\"K1\\\",\\\"label\\\":\\\"first\\\"}\"}, {title: \"A Dup\", type: \"g12item\", fields: \"{\\\"code\\\":\\\"K1\\\",\\\"label\\\":\\\"second\\\"}\"}], onConflict: IGNORE) { id title } }"}')
-assert_gql_ok "$G12_BATCH"
-G12_ID0=$(echo "$G12_BATCH" | jq -r '.data.createMany[0].id')
-G12_ID1=$(echo "$G12_BATCH" | jq -r '.data.createMany[1].id')
-[ -n "$G12_ID0" ]
-[ "$G12_ID0" = "$G12_ID1" ]
-G12_TITLE1=$(echo "$G12_BATCH" | jq -r '.data.createMany[1].title')
-[ "$G12_TITLE1" = "A" ]
-# Exactly one row in the type table; the rejected ID is nowhere.
-G12_COUNT=$(gql '{"query":"mutation { executeSql(sql: \"SELECT COUNT(*) FROM g12item\") { rows } }"}' | jq -r '.data.executeSql.rows[0]' | jq -r '.[0]')
-[ "$G12_COUNT" = "1" ]
-pass "issue-12: createMany IGNORE returns surviving ID for intra-batch duplicate"
-
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE g12item CASCADE\") { message } }"}' >/dev/null
-
-# 45.G11 — issue #11: TagsFilter operators are nullable; a contains-only
-# filter parses (was rejected pre-PRD-00130 because containsAll/containsAny
-# were schema-required); empty filter and empty arrays are rejected at
-# resolve time.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE g11link (title TEXT, url VARCHAR(255))\") { message } }"}'
-G11_CREATE=$(gql '{"query":"mutation { createDoogat(input: {title: \"Tagged\", type: \"g11link\", tags: [\"rust\", \"sql\"], fields: \"{\\\"url\\\":\\\"https://example.com\\\"}\"}) { id } }"}')
-assert_gql_ok "$G11_CREATE"
-# contains-only filter must succeed without supplying containsAll/containsAny
-G11_CONTAINS=$(gql '{"query":"{ g11links(where: {tags: {contains: \"rust\"}}) { totalCount items { id } } }"}')
-assert_gql_ok "$G11_CONTAINS"
-G11_TC=$(echo "$G11_CONTAINS" | jq -r '.data.g11links.totalCount')
-[ "$G11_TC" = "1" ]
-pass "issue-11: TagsFilter contains-only filter parses and matches"
-
-# containsAll-only must succeed
-G11_ALL=$(gql '{"query":"{ g11links(where: {tags: {containsAll: [\"rust\", \"sql\"]}}) { totalCount } }"}')
-assert_gql_ok "$G11_ALL"
-[ "$(echo "$G11_ALL" | jq -r '.data.g11links.totalCount')" = "1" ]
-pass "issue-11: TagsFilter containsAll-only filter parses"
-
-# containsAny-only must succeed
-G11_ANY=$(gql '{"query":"{ g11links(where: {tags: {containsAny: [\"rust\", \"go\"]}}) { totalCount } }"}')
-assert_gql_ok "$G11_ANY"
-[ "$(echo "$G11_ANY" | jq -r '.data.g11links.totalCount')" = "1" ]
-pass "issue-11: TagsFilter containsAny-only filter parses"
-
-# Empty filter: rejected at resolve time
-G11_EMPTY=$(gql '{"query":"{ g11links(where: {tags: {}}) { totalCount } }"}')
-assert_gql_errors "$G11_EMPTY"
-printf '%s' "$G11_EMPTY" | grep -q "tags filter requires at least one of"
-pass "issue-11: empty TagsFilter rejected with clear error"
-
-# Empty containsAll: rejected
-G11_EMPTY_ALL=$(gql '{"query":"{ g11links(where: {tags: {containsAll: []}}) { totalCount } }"}')
-assert_gql_errors "$G11_EMPTY_ALL"
-printf '%s' "$G11_EMPTY_ALL" | grep -q "containsAll cannot be empty"
-pass "issue-11: empty containsAll rejected with clear error"
-
-# Empty containsAny: rejected
-G11_EMPTY_ANY=$(gql '{"query":"{ g11links(where: {tags: {containsAny: []}}) { totalCount } }"}')
-assert_gql_errors "$G11_EMPTY_ANY"
-printf '%s' "$G11_EMPTY_ANY" | grep -q "containsAny cannot be empty"
-pass "issue-11: empty containsAny rejected with clear error"
-
-# Schema introspection: containsAll / containsAny must be nullable list
-G11_SDL=$(gql '{"query":"{ __type(name: \"TagsFilter\") { inputFields { name type { kind ofType { kind name ofType { kind name } } } } } }"}')
-echo "$G11_SDL" | jq -e '.data.__type.inputFields[] | select(.name == "containsAll") | .type.kind == "LIST"' >/dev/null
-echo "$G11_SDL" | jq -e '.data.__type.inputFields[] | select(.name == "containsAny") | .type.kind == "LIST"' >/dev/null
-pass "issue-11: TagsFilter introspection confirms containsAll/containsAny are nullable lists"
-
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE g11link CASCADE\") { message } }"}' >/dev/null
-
-# 45.A1 — Cross-mutation parity after a failed UNIQUE INSERT (issue #4 group A1).
-# duplicate_insert_does_not_leave_ghost_doogats_row pins the index invariant at
-# the unit level; this sub-block proves all THREE GraphQL write paths
-# (updateDoogat / createDoogat / deleteDoogat) still work after a UNIQUE
-# rollback. Issue #4 explicitly named all three as broken on the regression.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE a1item (title VARCHAR(255) NOT NULL, name VARCHAR(255) NOT NULL, UNIQUE(name))\") { message } }"}'
-A1_VALID=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO a1item (title, name) VALUES (\\\"a\\\", \\\"unique1\\\")\") { message } }"}')
-A1_VALID_ID=$(printf '%s' "$A1_VALID" | extract_id)
-[ -n "$A1_VALID_ID" ]
-A1_DUP=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO a1item (title, name) VALUES (\\\"b\\\", \\\"unique1\\\")\") { message } }"}')
-assert_gql_errors "$A1_DUP"
-printf '%s' "$A1_DUP" | grep -q 'UNIQUE'
-# updateDoogat after the failure
-A1_UPD=$(gql "{\"query\":\"mutation { updateDoogat(input: { id: \\\"$A1_VALID_ID\\\", tags: [\\\"a1-recovered\\\"] }) { id tags } }\"}")
-assert_gql_ok "$A1_UPD"
-printf '%s' "$A1_UPD" | grep -q 'a1-recovered'
-# createDoogat after the failure (different unique key)
-A1_CREATE=$(gql '{"query":"mutation { createDoogat(input: { type: \"a1item\", title: \"created-after-rollback\", fields: \"{\\\"name\\\":\\\"unique2\\\"}\" }) { id title } }"}')
-assert_gql_ok "$A1_CREATE"
-A1_CREATE_ID=$(printf '%s' "$A1_CREATE" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-[ -n "$A1_CREATE_ID" ]
-# deleteDoogat after the failure (delete the row created above so we don't
-# disturb the surviving baseline row)
-A1_DEL=$(gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$A1_CREATE_ID\\\") }\"}")
-assert_gql_ok "$A1_DEL"
-printf '%s' "$A1_DEL" | grep -q 'true'
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE a1item CASCADE\") { message } }"}' >/dev/null
-pass "issue-4-A1: failed UNIQUE INSERT does not break update/create/delete mutations"
-
-# 45.A3 — Cross-table isolation (issue #4 group A3). A failed UNIQUE INSERT on
-# one table must not leak into a sibling table. Proves the savepoint rollback
-# is scoped correctly.
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE a3thing (title VARCHAR(255) NOT NULL)\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE a3item (title VARCHAR(255) NOT NULL, name VARCHAR(255) NOT NULL, UNIQUE(name))\") { message } }"}' >/dev/null
-wait_schema_reload "$VER"
-A3_THING=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO a3thing (title) VALUES (\\\"t1\\\")\") { message } }"}')
-A3_THING_ID=$(printf '%s' "$A3_THING" | extract_id)
-[ -n "$A3_THING_ID" ]
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO a3item (title, name) VALUES (\\\"a\\\", \\\"u1\\\")\") { message } }"}' >/dev/null
-A3_DUP=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO a3item (title, name) VALUES (\\\"b\\\", \\\"u1\\\")\") { message } }"}')
-assert_gql_errors "$A3_DUP"
-printf '%s' "$A3_DUP" | grep -q 'UNIQUE'
-# Table a3thing must still be writable via updateDoogat after the A3 failure.
-A3_UPD=$(gql "{\"query\":\"mutation { updateDoogat(input: { id: \\\"$A3_THING_ID\\\", tags: [\\\"a3-isolated\\\"] }) { id tags } }\"}")
-assert_gql_ok "$A3_UPD"
-printf '%s' "$A3_UPD" | grep -q 'a3-isolated'
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE a3thing CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE a3item CASCADE\") { message } }"}' >/dev/null
-pass "issue-4-A3: failed INSERT on a3item does not corrupt a3thing"
-
-# 45.R10 — RESTRICT on NOT NULL REFERENCES blocks the parent delete through
-# both the SQL and deleteDoogat GraphQL surfaces (#10). The Rust unit tests
-# delete_rejected_by_not_null_references_issue_10 pin the engine invariant.
-# This scenario confirms the GraphQL layer propagates the error and leaves
-# both the parent and the child row intact.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE r10link (url VARCHAR(255) NOT NULL)\") { message } }"}'
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE r10cat (name VARCHAR(255) NOT NULL)\") { message } }"}'
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE \\\"r10-mem\\\" (link_id VARCHAR(255) NOT NULL REFERENCES r10link(id), cat_id VARCHAR(255) NOT NULL REFERENCES r10cat(id), UNIQUE(link_id, cat_id))\") { message } }"}'
-# Use raw curl (not the `-sf` gql helper) so a transient non-2xx surfaces as
-# a diagnostic instead of killing the script via set -e.
-gql_noexit() {
-  curl -s "$GQL_URL" \
-    -H "Authorization: Bearer $TOKEN" \
-    -H "Content-Type: application/json" \
-    -d "$1"
-}
-# Extract id from a JSON string; sed -n won't trip pipefail on no-match.
-extract_id_str() {
-  local s="$1"
-  printf '%s' "$s" | sed -n 's/.*"message":"\([^"]*\)".*/\1/p'
-}
-R10_L_RESP=$(gql_noexit '{"query":"mutation { executeSql(sql: \"INSERT INTO r10link (title, url) VALUES (\\\"L\\\", \\\"https://r10.example\\\")\") { message } }"}')
-R10_L_ID=$(extract_id_str "$R10_L_RESP")
-[ -n "$R10_L_ID" ] || { printf '  ✗ 45.R10: INSERT r10link returned no id: %s\n' "$R10_L_RESP" >&2; exit 1; }
-R10_C_RESP=$(gql_noexit '{"query":"mutation { executeSql(sql: \"INSERT INTO r10cat (title, name) VALUES (\\\"C\\\", \\\"c\\\")\") { message } }"}')
-R10_C_ID=$(extract_id_str "$R10_C_RESP")
-[ -n "$R10_C_ID" ] || { printf '  ✗ 45.R10: INSERT r10cat returned no id: %s\n' "$R10_C_RESP" >&2; exit 1; }
-gql_noexit "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO \\\\\\\"r10-mem\\\\\\\" (title, link_id, cat_id) VALUES (\\\\\\\"M\\\\\\\", \\\\\\\"$R10_L_ID\\\\\\\", \\\\\\\"$R10_C_ID\\\\\\\")\\\") { message } }\"}" >/dev/null
-# SQL DELETE via executeSql must surface the RESTRICT error via "errors"
-R10_SQL_ERR=$(gql_noexit "{\"query\":\"mutation { executeSql(sql: \\\"DELETE FROM r10link WHERE id = \\\\\\\"$R10_L_ID\\\\\\\"\\\") { message } }\"}")
-assert_gql_errors "$R10_SQL_ERR"
-printf '%s' "$R10_SQL_ERR" | grep -q "NOT NULL REFERENCES"
-printf '%s' "$R10_SQL_ERR" | grep -q "r10-mem"
-# deleteDoogat GraphQL mutation must also fail
-R10_GQL_ERR=$(gql_noexit "{\"query\":\"mutation { deleteDoogat(id: \\\"$R10_L_ID\\\") }\"}")
-assert_gql_errors "$R10_GQL_ERR"
-printf '%s' "$R10_GQL_ERR" | grep -q "NOT NULL REFERENCES"
-# Parent + child rows must both still exist (executeSql is a Mutation field).
-R10_PARENT=$(gql_noexit "{\"query\":\"mutation { executeSql(sql: \\\"SELECT COUNT(*) FROM r10link WHERE id = \\\\\\\"$R10_L_ID\\\\\\\"\\\") { rows } }\"}")
-printf '%s' "$R10_PARENT" | grep -q '"rows":\["\[\\"1\\"\]"\]'
-R10_CHILD=$(gql_noexit "{\"query\":\"mutation { executeSql(sql: \\\"SELECT COUNT(*) FROM \\\\\\\"r10-mem\\\\\\\" WHERE link_id = \\\\\\\"$R10_L_ID\\\\\\\"\\\") { rows } }\"}")
-printf '%s' "$R10_CHILD" | grep -q '"rows":\["\[\\"1\\"\]"\]'
-# After deleting the child, the parent delete succeeds
-gql_noexit "{\"query\":\"mutation { executeSql(sql: \\\"DELETE FROM \\\\\\\"r10-mem\\\\\\\" WHERE link_id = \\\\\\\"$R10_L_ID\\\\\\\"\\\") { message } }\"}" >/dev/null
-R10_OK=$(gql_noexit "{\"query\":\"mutation { executeSql(sql: \\\"DELETE FROM r10link WHERE id = \\\\\\\"$R10_L_ID\\\\\\\"\\\") { affected } }\"}")
-assert_gql_ok "$R10_OK"
-printf '%s' "$R10_OK" | grep -q '"affected":1'
-gql_noexit '{"query":"mutation { executeSql(sql: \"DROP TABLE \\\"r10-mem\\\" CASCADE\") { message } }"}' >/dev/null
-gql_noexit '{"query":"mutation { executeSql(sql: \"DROP TABLE r10link CASCADE\") { message } }"}' >/dev/null
-gql_noexit '{"query":"mutation { executeSql(sql: \"DROP TABLE r10cat CASCADE\") { message } }"}' >/dev/null
-pass "issue-10: RESTRICT blocks delete via SQL and deleteDoogat"
-
-# 45.A2 — Ghost-row fix persists across server restart (issue #4 group A2).
-# Seed a UNIQUE failure on the running server, kill it, restart on the same
-# $TMPDIR, then verify a fresh GraphQL write path still succeeds against the
-# restarted process. This catches a regression where the fix lives in memory
-# only and doesn't actually persist to the SQLite index file.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE a2persist (title VARCHAR(255) NOT NULL, name VARCHAR(255) NOT NULL, UNIQUE(name))\") { message } }"}'
-A2_VALID=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO a2persist (title, name) VALUES (\\\"seed\\\", \\\"uniq_a2\\\")\") { message } }"}')
-A2_VALID_ID=$(printf '%s' "$A2_VALID" | extract_id)
-[ -n "$A2_VALID_ID" ]
-A2_DUP=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO a2persist (title, name) VALUES (\\\"dup\\\", \\\"uniq_a2\\\")\") { message } }"}')
-assert_gql_errors "$A2_DUP"
-# Kill the server, confirm it's gone, then restart on the same $TMPDIR.
-kill "$SERVER_PID" 2>/dev/null || true
-wait "$SERVER_PID" 2>/dev/null || true
-$DDB serve --port "$SERVER_PORT" --pg-port "$PG_PORT" &
-SERVER_PID=$!
-for i in $(seq 1 20); do
-  if curl -sf "$GQL_URL" \
-    -H "Authorization: Bearer $TOKEN" \
-    -H "Content-Type: application/json" \
-    -d '{"query":"{ typeDefs { name } }"}' >/dev/null 2>&1; then
-    break
-  fi
-  sleep 0.2
-done
-# Restarted server must be able to updateDoogat on the pre-restart row.
-A2_UPD=$(gql "{\"query\":\"mutation { updateDoogat(input: { id: \\\"$A2_VALID_ID\\\", tags: [\\\"restart-survived\\\"] }) { id tags } }\"}")
-assert_gql_ok "$A2_UPD"
-printf '%s' "$A2_UPD" | grep -q 'restart-survived'
-# And still accept fresh INSERTs on the same table.
-A2_FRESH=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO a2persist (title, name) VALUES (\\\"fresh\\\", \\\"uniq_a2_post\\\")\") { message } }"}')
-assert_gql_ok "$A2_FRESH"
-printf '%s' "$A2_FRESH" | extract_id >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE a2persist CASCADE\") { message } }"}' >/dev/null
-pass "issue-4-A2: ghost-row fix persists across server restart"
-
-# 49. PRD 00131: structured-error code propagation through typed mutations.
-# Restores `extensions.code = "UNIQUE_VIOLATION"` (and NOT_NULL_VIOLATION)
-# on duplicate-key and missing-required-column violations through
-# `createDoogat` and `createMany`. The codes regressed in 0.2.5 when the
-# service-layer batch_create path flattened structured errors to plain

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


