
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.ps1, original lines 3692-3781, segment 8/8. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.ps1:3678: DONE; targets=integration_id_poison::integration_62_id_minting_no_same_second_collision
tests/integration.ps1:3703: DONE; targets=integration_id_poison::integration_63_poison_file_graphql_warning

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.ps1 b/tests/integration.ps1
deleted file mode 100644
index 2f21127..0000000
--- a/tests/integration.ps1
+++ /dev/null
@@ -3692,90 +0,0 @@
-$int164Batch = ddb query "INSERT INTO int164 (label) VALUES ('a'), ('b'), ('c')"
-if ($int164Batch -notmatch "(?m)^\d{14},\d{14},\d{14}$") { throw "62: batch insert did not return 3 IDs: $int164Batch" }
-$int164Single = (ddb create --type int164 --title "single 164" --set "label=d").Trim()
-if ($int164Single -notmatch '^\d{14}$') { throw "62: single create id malformed: $int164Single" }
-$int164All = @($int164Batch.Trim() -split ',') + $int164Single
-if ($int164All.Count -ne 4) { throw "62: expected 4 ids, got $($int164All.Count): $($int164All -join ',')" }
-if (($int164All | Sort-Object -Unique).Count -ne 4) { throw "62: mint collision - ids not distinct: $($int164All -join ',')" }
-pass "PRD 00164: batch + single mint paths yield distinct ids (no same-second collision)"
-Pop-Location
-Remove-Item -Recurse -Force $INT164_DIR
-
-# 63. PRD 00169 - poison-file skip warning through GraphQL extensions.
-# A doogat planted by a raw git commit (bypassing ddb CLI) with unparseable
-# frontmatter triggers a REINDEX_SKIPPED_FILES warning. The warning surfaces
-# on the FIRST mutation that calls ensure_fresh() after the poison commit,
-# because ensure_fresh() reindexes, records the skip, and leaves the index
-# fresh. A SECOND mutation sees nothing stale and returns warnings: [].
-#
-# Load-bearing ordering: the server is started BEFORE the poison file is
-# planted so its stored HEAD predates the poison commit. The assertion is
-# against the very first createDoogat after the commit. Do not add a
-# warm-up call before this assertion - it would consume the warning and
-# silently turn the check into a false pass.
-
-$INT169_DIR = New-TempDir
-Push-Location $INT169_DIR
-ddb init | Out-Null
-
-# Seed one ordinary doogat so the index is non-empty and HEAD exists.
-ddb create --title "seed" --body "seed body" | Out-Null
-
-# Start own server on its own port (distinct from the now-dead 19200-range server).
-$int169Port = 20200 + (Get-Random -Maximum 700)
-$int169PgPort = $int169Port + 1
-$int169Server = Start-Process -FilePath $DDB -ArgumentList "serve","--port","$int169Port","--pg-port","$int169PgPort" -PassThru -NoNewWindow
-
-# Wait for server to start.
-for ($i = 0; $i -lt 20; $i++) {
-    try {
-        $null = Invoke-WebRequest -Uri "http://127.0.0.1:$int169Port/graphql" `
-            -Method POST -ContentType "application/json" `
-            -Headers @{ Authorization = "Bearer $TOKEN" } `
-            -Body '{"query":"{ typeDefs { name } }"}' -ErrorAction Stop
-        break
-    } catch {
-        Start-Sleep -Milliseconds 200
-    }
-}
-
-# Now plant the poison file (same shape as smoke.ps1 section 32).
-@"
----
-: invalid yaml [
----
-body
-"@ | Set-Content -Path "ddb/29990101000000.md" -NoNewline
-git -C $INT169_DIR add -A
-git -C $INT169_DIR commit -m "add poison doogat" | Out-Null
-
-# First createDoogat after the poison commit - this is where the warning fires.
-$int169Resp = Invoke-WebRequest -Uri "http://127.0.0.1:$int169Port/graphql" `
-    -Method POST -ContentType "application/json" `
-    -Headers @{ Authorization = "Bearer $TOKEN" } `
-    -Body '{"query":"mutation { createDoogat(input: { title: \"after poison\" }) { id title } }"}' -ErrorAction Stop
-$int169Content = content $int169Resp
-
-assertGqlOk $int169Content "63: first createDoogat after poison commit"
-$int169Obj = $int169Content | ConvertFrom-Json
-if ($int169Obj.extensions.warnings.Count -ne 1) {
-    throw "63: expected one warning, got: $($int169Obj.extensions.warnings | ConvertTo-Json -Compress)"
-}
-if ($int169Obj.extensions.warnings[0].code -ne "REINDEX_SKIPPED_FILES") {
-    throw "63: expected code REINDEX_SKIPPED_FILES, got: $($int169Obj.extensions.warnings[0].code)"
-}
-if ($int169Obj.extensions.warnings[0].message -notmatch "29990101000000") {
-    throw "63: expected message to mention '29990101000000', got: $($int169Obj.extensions.warnings[0].message)"
-}
-pass "PRD 00169: poison file surfaces REINDEX_SKIPPED_FILES warning in GraphQL extensions"
-
-# Cleanup. The removal is guarded the way the Cleanup function guards its own
-# (lines 38-46): this dir hosted a live server, and $ErrorActionPreference is
-# "Stop" for the whole file, so a handle Windows has not released yet would
-# abort the entire run here - after the assertion above already passed.
-Stop-Process -Id $int169Server.Id -Force -ErrorAction SilentlyContinue
-Start-Sleep -Milliseconds 500
-Pop-Location
-Remove-Item -Recurse -Force $INT169_DIR -ErrorAction SilentlyContinue
-
-Cleanup
-Write-Host "=== all integration tests passed ==="

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is GREEN on exact deletion SHA; both test and coverage jobs succeeded. Final Clippy passed (2m04s); cargo test-ci passed42CLI +1555core +222server, no failed/ignored tests. Three actual generic adversarial mutants were caught (two by focused tests, one by the full suite); final real-binary five-test control passed. All facades are neutralized. Task completion awaits this per-task review. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


