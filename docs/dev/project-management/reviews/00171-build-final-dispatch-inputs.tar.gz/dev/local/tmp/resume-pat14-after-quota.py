from pathlib import Path
import json
import subprocess
import time
import uuid

root = Path('/Users/bob/git/src/github.com/doogat/ddb')
plugin = Path('/Users/bob/.claude/plugins/cache/buvis-plugins/autopilot/0.5.1')
tmp = root / 'dev/local/tmp'
reset = 1788681600
if time.time() < reset:
    raise SystemExit('Quota reset has not arrived; no prompt or dispatch changed')
meta_path = tmp / '00171-pat14-meta.json'
meta = json.loads(meta_path.read_text())
for index in (8, 10, 11, 12):
    group = next(g for g in meta['groups'] if g['index'] == index)
    prefix = tmp / f'pat14-{index:02d}-{group["name"]}'
    report = Path(group['report'])
    report.with_name(report.stem + '-quota.md').write_text(report.read_text())
    prompt = Path(str(prefix) + '.quota-retry-prompt.md')
    args = ['python3', str(plugin / 'skills/work/scripts/render_prompt.py'), str(plugin / 'agents/pat.md'), '--out', str(prompt)]
    for key in ('TASK_SUBJECT', 'TASK_DESCRIPTION', 'TASK_ACCEPTANCE_CRITERIA', 'DIFF'):
        args += ['--set-file', key + '=' + str(prefix) + '.' + key.lower() + '.txt']
    args += ['--set-file', 'SIMPLIFICATION_MANDATE=' + str(plugin / 'skills/work/references/simplification-mandate.md'), '--set-file', 'VERIFICATION_RESULT=' + str(tmp / 'review-task-14-verification.txt')]
    if index == 8:
        args += ['--set-file', 'CONTRACT_CORRECTION=' + str(tmp / 'pat14-correction.txt')]
    else:
        args += ['--set', 'CONTRACT_CORRECTION=']
        group['session_id'] = str(uuid.uuid4())
        group['resume'] = False
    args += ['--dispatch-kind', 'pat', '--dispatch-task', '14']
    result = subprocess.run(args, cwd=root, text=True, capture_output=True, check=True, timeout=60)
    size, dispatch_id = result.stdout.strip().splitlines()
    assert int(size) <= 50000
    group.update(prompt=str(prompt), dispatch_id=dispatch_id, bytes=int(size), quota_retry=True)
    print(index, size, dispatch_id)
meta['quota_wait']['resumed_at_epoch'] = int(time.time())
meta_path.write_text(json.dumps(meta, indent=2) + '\n')
