
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.sh, original lines 3331-3803, segment 7/7. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.sh:3298: DONE (byte-stats-report half only); targets=integration_compact_stats::integration_33_compact_byte_stats_report, multi_device::compact_creates_recoverable_backup, multi_device::compacted_node_resolves_second_conflict, multi_device::stale_node_resync_after_compaction
tests/integration.sh:3347: DONE (pre-existing, no port needed); targets=sql_lifecycle::multi_row_insert
tests/integration.sh:3355: DONE (pre-existing, no port needed); targets=sql_lifecycle::transaction_commit_via_cli, sql_lifecycle::transaction_rollback_via_cli
tests/integration.sh:3366: DONE; targets=integration_hyphenated_type::integration_36_hyphenated_type_create_table, sql_lifecycle::install_meeting_minutes_type
tests/integration.sh:3374: DONE (pre-existing, no port needed); targets=junction_tables::junction_table_round_trip
tests/integration.sh:3390: DONE (pre-existing, no port needed); targets=fix::fix_verbose_reports_title_noncompliant
tests/integration.sh:3398: DONE (pre-existing, no port needed); targets=fix::fix_migrate_rewrites_zones
tests/integration.sh:3407: DONE; targets=integration_binary_lww::integration_40_binary_asset_lww, multi_device::hlc_lww_picks_later_writer
tests/integration.sh:3464: DONE (pre-existing, no port needed); targets=sync_crdt::sync_auto_registers_node_when_none_exists
tests/integration.sh:3488: DONE (pre-existing, no port needed); targets=title_template_references::membership_title_resolves_from_referenced_doogats, title_template_references::typedef_with_bad_dotted_path_is_rejected
tests/integration.sh:3516: DONE (pre-existing, no port needed); targets=alter_column_type::narrowing_rejects_with_row_count_message, alter_column_type::widens_varchar_to_text_and_accepts_longer_values
tests/integration.sh:3563: DONE (CREATE INDEX + CASCADE + cycle-detection halves only); targets=cascade_delete::delete_rejected_by_not_null_references_cli_issue_10, integration_typed_write_cli::integration_48_typed_write_blockers_and_cascade
tests/integration.sh:3626: DONE; targets=cli_create_fk_freshness::create_link_after_category_in_separate_process_succeeds_without_reindex, integration_typed_write_cli::integration_49_unify_typed_write_paths
tests/integration.sh:3674: DONE; targets=cascade_delete::cascade_delete_cleans_owned_junction_when_parent_deleted, integration_typed_write_cli::integration_44_l_cli_create_auto_junction
tests/integration.sh:3697: DONE (pre-existing, no port needed); targets=cli_create_fk_freshness::create_link_after_category_in_separate_process_succeeds_without_reindex
tests/integration.sh:3720: DONE; targets=integration_id_poison::integration_62_id_minting_no_same_second_collision
tests/integration.sh:3746: DONE; targets=integration_id_poison::integration_63_poison_file_graphql_warning

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.sh b/tests/integration.sh
deleted file mode 100755
index 6942304..0000000
--- a/tests/integration.sh
+++ /dev/null
@@ -3331,473 +0,0 @@
-echo "$COMPACT_OUT" | grep -q "repo (.git):"
-
-# Create another conflict without CRDT state
-cd "$STALE_N1"
-$DDB sync origin master >/dev/null
-$DDB update "$STALE_ID" --body "second edit node1"
-git push origin master >/dev/null 2>&1
-
-cd "$STALE_N2"
-$DDB update "$STALE_ID" --body "second edit node2"
-$DDB sync origin master >/dev/null
-
-# Verify doogat is readable and valid
-$DDB read "$STALE_ID" | grep -q "title:"
-pass "stale node resync after compaction"
-
-# 34. multi-row INSERT
-cd "$TMPDIR"
-$DDB query "CREATE TABLE multirow (name TEXT, val INTEGER)" | grep -q "table multirow created"
-MULTI_IDS=$($DDB query "INSERT INTO multirow (name, val) VALUES ('a', 1), ('b', 2), ('c', 3)")
-echo "$MULTI_IDS" | grep -qE "^[0-9]{14},[0-9]{14},[0-9]{14}$"
-$DDB query "SELECT COUNT(*) FROM multirow" | grep -q "3"
-pass "multi-row insert"
-
-# 35. transaction commit + rollback
-cd "$TMPDIR"
-$DDB query "CREATE TABLE txntest (val TEXT)" | grep -q "table txntest created"
-$DDB query "BEGIN; INSERT INTO txntest (val) VALUES ('committed'); COMMIT" | grep -q "COMMIT"
-$DDB query "SELECT val FROM txntest" | grep -q "committed"
-$DDB query "BEGIN; INSERT INTO txntest (val) VALUES ('rolled-back'); ROLLBACK" | grep -q "ROLLBACK"
-# rolled-back row should not appear
-TXNCOUNT=$($DDB query "SELECT COUNT(*) FROM txntest")
-echo "$TXNCOUNT" | grep -q "1"
-pass "transaction commit + rollback"
-
-# 36. hyphenated type SQL via quoted identifiers
-cd "$TMPDIR"
-$DDB query 'CREATE TABLE "my-type" (label TEXT)' | grep -q "table my-type created"
-MY_ID=$($DDB query 'INSERT INTO "my-type" (label) VALUES ('\''test'\'')')
-$DDB query 'SELECT label FROM "my-type"' | grep -q "test"
-$DDB query "DELETE FROM \"my-type\" WHERE id = '$MY_ID'" | grep -q "1 row(s) affected"
-pass "hyphenated type SQL"
-
-# 37. junction table CRUD (multi-value references)
-cd "$TMPDIR"
-$DDB query "CREATE TABLE jtag (name VARCHAR(100))" | grep -q "table jtag created"
-$DDB query "CREATE TABLE jpost (url TEXT, jtag TEXT REFERENCES jtag)" | grep -q "table jpost created"
-JT_TAG_ID=$($DDB query "INSERT INTO jtag (name) VALUES ('rust')")
-sleep 1
-JT_POST_ID=$($DDB query "INSERT INTO jpost (url) VALUES ('https://example.com')")
-$DDB query "INSERT INTO jpost_jtag (jpost_id, jtag_id) VALUES ('$JT_POST_ID', '$JT_TAG_ID')" | grep -q "1 row"
-$DDB query "SELECT jtag_id FROM jpost_jtag WHERE jpost_id = '$JT_POST_ID'" | grep -q "$JT_TAG_ID"
-$DDB query "DELETE FROM jpost_jtag WHERE jpost_id = '$JT_POST_ID' AND jtag_id = '$JT_TAG_ID'" | grep -q "1 row"
-$DDB query "SELECT COUNT(*) FROM jpost_jtag" | grep -q "0"
-$DDB query "INSERT INTO jpost_jtag (jpost_id, jtag_id) VALUES ('$JT_POST_ID', '$JT_TAG_ID')" >/dev/null
-$DDB query "DROP TABLE jpost CASCADE" | grep -q "dropped"
-! $DDB query "SELECT * FROM jpost_jtag" 2>/dev/null
-pass "junction table CRUD"
-
-# 38. title template compliance check
-cd "$TMPDIR"
-$DDB query "CREATE TABLE smwidget (name VARCHAR(100), description TEXT)" >/dev/null
-$DDB query "ALTER TABLE smwidget SET TITLE TEMPLATE '{name} Widget'" >/dev/null
-$DDB query "INSERT INTO smwidget (name, description) VALUES ('Foo', 'A foo widget')" >/dev/null
-$DDB fix --verbose --dry-run | grep -q "title does not match template"
-pass "title template compliance check"
-
-# 39. zone migration
-cd "$TMPDIR"
-$DDB query "CREATE TABLE gadget (notes TEXT)" | grep -q "table gadget created"
-$DDB query "INSERT INTO gadget (notes) VALUES ('Some notes')" >/dev/null
-$DDB query "ALTER TABLE gadget SET ZONE frontmatter FOR notes" >/dev/null
-FIX_OUT=$($DDB fix --migrate --verbose)
-echo "$FIX_OUT" | grep -q "zone-migrated"
-pass "zone migration"
-
-# 40. binary asset LWW conflict resolution
-echo "=== binary asset LWW ==="
-BIN_REMOTE="$(mktemp -d)"
-BIN_NODE1="$(mktemp -d)"
-BIN_NODE2="$(mktemp -d)"
-git init --bare "$BIN_REMOTE" >/dev/null 2>&1
-
-cd "$BIN_NODE1"
-$DDB init . >/dev/null
-git remote add origin "$BIN_REMOTE"
-$DDB register-node "BinNode1" >/dev/null
-# Create a doogat so the repo has content
-BIN_DDB_ID=$($DDB create --title "Binary test")
-# Create initial binary asset
-mkdir -p reference/test
-printf '\x89PNG\r\n' > reference/test/photo.bin
-git add reference/test/photo.bin
-git commit -m "add binary asset" >/dev/null
-git push -u origin master >/dev/null 2>&1
-
-# Clone to node2
-git clone "$BIN_REMOTE" "$BIN_NODE2" >/dev/null 2>&1
-cd "$BIN_NODE2"
-$DDB reindex >/dev/null
-$DDB register-node "BinNode2" >/dev/null
-
-# Node1: modify binary with higher HLC (later wall_ms)
-# Trailer uses the real load-bearing `HLC: {wall_ms}-{counter:04}-{node}` format read by extract_hlc (PRD 00166).
-cd "$BIN_NODE1"
-printf 'NODE1_WINS_CONTENT' > reference/test/photo.bin
-git add reference/test/photo.bin
-git commit -m "node1 update binary
-
-HLC: 9999999999999-0000-BinNode1" >/dev/null
-git push origin master >/dev/null 2>&1
-
-# Node2: modify same binary with lower HLC
-cd "$BIN_NODE2"
-printf 'NODE2_LOSES_CONTENT' > reference/test/photo.bin
-git add reference/test/photo.bin
-git commit -m "node2 update binary
-
-HLC: 1000000000000-0000-BinNode2" >/dev/null
-
-# Sync node2 — should resolve conflict via LWW, node1 (higher HLC) wins
-SYNC_OUT=$($DDB sync origin master)
-echo "$SYNC_OUT" | grep -q "conflicts resolved: 1"
-RESOLVED=$(cat reference/test/photo.bin)
-[ "$RESOLVED" = "NODE1_WINS_CONTENT" ]
-pass "binary asset LWW (higher HLC wins)"
-
-# Verify a merge commit exists in recent history (loser preserved)
-git log --merges --oneline -1 | grep -q "resolve merge"
-pass "binary asset LWW (loser preserved in history)"
-
-rm -rf "$BIN_REMOTE" "$BIN_NODE1" "$BIN_NODE2"
-
-# 41. auto-register node on first sync
-AR_REMOTE="$(mktemp -d)"
-AR_NODE="$(mktemp -d)"
-git init --bare "$AR_REMOTE" >/dev/null
-$DDB init "$AR_NODE" >/dev/null
-cd "$AR_NODE"
-git remote add origin "$AR_REMOTE"
-git push -u origin master >/dev/null 2>&1
-
-# No register-node — sync should auto-register
-[ ! -f .git/ddb-node ]
-$DDB sync origin master >/dev/null
-[ -f .git/ddb-node ]
-pass "auto-register node on first sync"
-
-# Subsequent sync reuses registration
-UUID_BEFORE=$(cat .git/ddb-node)
-$DDB sync origin master >/dev/null
-UUID_AFTER=$(cat .git/ddb-node)
-[ "$UUID_BEFORE" = "$UUID_AFTER" ]
-pass "auto-register reuses existing registration"
-
-rm -rf "$AR_REMOTE" "$AR_NODE"
-
-# 46. title_template REFERENCES resolution (PRD 00127).
-# Server has been down since section 28, so use the CLI directly.
-echo "=== title_template REFERENCES resolution ==="
-TT_DIR="$(mktemp -d)"
-cd "$TT_DIR"
-$DDB init >/dev/null
-$DDB query "CREATE TABLE tt_link (url TEXT)" >/dev/null
-$DDB query "CREATE TABLE tt_category (fqn TEXT)" >/dev/null
-$DDB query "CREATE TABLE tt_membership (link TEXT REFERENCES tt_link, category TEXT REFERENCES tt_category)" >/dev/null
-$DDB query "ALTER TABLE tt_membership SET TITLE TEMPLATE '{link.title} in {category.fqn}'" >/dev/null
-pass "46: declared dotted title_template"
-
-TT_LINK_ID=$($DDB query "INSERT INTO tt_link (title, url) VALUES ('My Link', 'https://x')" | tr -d '[:space:]')
-sleep 1
-TT_CAT_ID=$($DDB query "INSERT INTO tt_category (title, fqn) VALUES ('Cat', 'A/B')" | tr -d '[:space:]')
-sleep 1
-TT_MEM_ID=$($DDB query "INSERT INTO tt_membership (link, category) VALUES ('$TT_LINK_ID', '$TT_CAT_ID')" | tr -d '[:space:]')
-$DDB query "SELECT title FROM tt_membership WHERE id = '$TT_MEM_ID'" | grep -q "My Link in A/B"
-pass "46: composed title 'My Link in A/B' from REFERENCES"
-
-# Bad dotted path is rejected at ALTER TABLE.
-TT_BAD_OUT="$($DDB query "ALTER TABLE tt_membership SET TITLE TEMPLATE '{link.does_not_exist}'" 2>&1 || true)"
-printf '%s' "$TT_BAD_OUT" | grep -q "does not exist on tt_link"
-pass "46: ALTER TABLE rejects bad dotted path"
-
-cd "$TMPDIR"
-rm -rf "$TT_DIR"
-
-# 47. ALTER TABLE ALTER COLUMN TYPE (PRD 00128).
-# Server is not running at this point; drive via CLI.
-echo "=== ALTER TABLE ALTER COLUMN TYPE ==="
-AC_DIR="$(mktemp -d)"
-cd "$AC_DIR"
-$DDB init >/dev/null
-$DDB query "CREATE TABLE ac_link (url VARCHAR(32))" >/dev/null
-
-# Insert a row at the boundary.
-AC_SHORT=$(printf 'a%.0s' $(seq 1 32))
-AC_ID1=$($DDB query "INSERT INTO ac_link (title, url) VALUES ('boundary', '$AC_SHORT')" | tr -d '[:space:]')
-[ -n "$AC_ID1" ]
-pass "47: baseline VARCHAR(32) insert at boundary"
-
-# Pre-ALTER: long insert must fail.
-AC_LONG=$(printf 'b%.0s' $(seq 1 80))
-AC_FAIL_OUT="$($DDB query "INSERT INTO ac_link (title, url) VALUES ('toolong', '$AC_LONG')" 2>&1 || true)"
-printf '%s' "$AC_FAIL_OUT" | grep -q "exceeds limit"
-pass "47: pre-ALTER INSERT rejects 80-char value for VARCHAR(32)"
-
-# Widen to VARCHAR(100).
-$DDB query "ALTER TABLE ac_link ALTER COLUMN url TYPE VARCHAR(100)" >/dev/null
-pass "47: widen VARCHAR(32) -> VARCHAR(100) succeeds"
-
-# Post-ALTER: the same long value succeeds.
-sleep 1
-AC_ID2=$($DDB query "INSERT INTO ac_link (title, url) VALUES ('now-ok', '$AC_LONG')" | tr -d '[:space:]')
-[ -n "$AC_ID2" ]
-pass "47: post-ALTER INSERT accepts 80-char value"
-
-# Narrowing with over-limit rows is rejected with a row-count message.
-AC_NARROW_OUT="$($DDB query "ALTER TABLE ac_link ALTER COLUMN url TYPE VARCHAR(5)" 2>&1 || true)"
-printf '%s' "$AC_NARROW_OUT" | grep -q "cannot narrow"
-printf '%s' "$AC_NARROW_OUT" | grep -q "existing rows exceed limit"
-pass "47: narrowing rejects with cannot-narrow row-count message"
-
-# Widen to TEXT and insert a 2000-char value.
-$DDB query "ALTER TABLE ac_link ALTER COLUMN url TYPE TEXT" >/dev/null
-sleep 1
-AC_HUGE=$(printf 'c%.0s' $(seq 1 2000))
-AC_ID3=$($DDB query "INSERT INTO ac_link (title, url) VALUES ('text-row', '$AC_HUGE')" | tr -d '[:space:]')
-[ -n "$AC_ID3" ]
-pass "47: VARCHAR -> TEXT widening persists and accepts long values"
-
-cd "$TMPDIR"
-rm -rf "$AC_DIR"
-
-# 48. PRD 00129: typed write blocker & simplification SQL surface.
-# Server is not running at this point; drive via CLI.
-echo "=== PRD 00129: typed write blockers + ON DELETE CASCADE + INDEX no-op ==="
-P9_DIR="$(mktemp -d)"
-cd "$P9_DIR"
-$DDB init >/dev/null
-
-# §3b: CREATE INDEX IF NOT EXISTS is accepted as a no-op so legacy
-# startup migrations keep working.
-$DDB query "CREATE TABLE p9_link (title TEXT, url VARCHAR(255))" >/dev/null
-P9_INDEX_OUT="$($DDB query "CREATE INDEX IF NOT EXISTS idx_p9_url ON p9_link(url)" 2>&1)"
-printf '%s' "$P9_INDEX_OUT" | grep -q "ignored"
-pass "48: CREATE INDEX IF NOT EXISTS accepted as no-op"
-
-# Plain CREATE INDEX still rejects.
-P9_PLAIN_OUT="$($DDB query "CREATE INDEX idx_plain ON p9_link(url)" 2>&1 || true)"
-printf '%s' "$P9_PLAIN_OUT" | grep -q "CREATE INDEX not supported"
-pass "48: plain CREATE INDEX still rejects"
-
-# §2: ON DELETE CASCADE walks one level.
-$DDB query "CREATE TABLE p9_membership (title TEXT, link VARCHAR(255) REFERENCES p9_link(id) ON DELETE CASCADE)" >/dev/null
-P9_LINK_ID=$($DDB query "INSERT INTO p9_link (title, url) VALUES ('Parent', 'https://x')" | tr -d '[:space:]')
-sleep 1
-P9_MEM_ID=$($DDB query "INSERT INTO p9_membership (title, link) VALUES ('Child', '$P9_LINK_ID')" | tr -d '[:space:]')
-[ -n "$P9_MEM_ID" ]
-pass "48: typed insert into cascade-bound child succeeds"
-
-$DDB delete "$P9_LINK_ID" >/dev/null
-P9_AFTER_LINK="$($DDB query "SELECT id FROM p9_link WHERE id = '$P9_LINK_ID'" 2>&1 || true)"
-P9_AFTER_MEM="$($DDB query "SELECT id FROM p9_membership WHERE id = '$P9_MEM_ID'" 2>&1 || true)"
-# `grep -qv` returned 0 on empty stdin under ugrep on developer hosts but 1
-# under GNU grep on CI, masking the assertion. Use bash's [[ != *X* ]] which
-# does abort under set -e and behaves the same regardless of grep flavor.
-[[ "$P9_AFTER_LINK" != *"$P9_LINK_ID"* ]]
-[[ "$P9_AFTER_MEM" != *"$P9_MEM_ID"* ]]
-pass "48: ON DELETE CASCADE removes parent and child in one delete"
-
-# §2: ON DELETE RESTRICT (default) blocks parent delete.
-$DDB query "CREATE TABLE p9_blocker (title TEXT, link VARCHAR(255) NOT NULL REFERENCES p9_link(id))" >/dev/null
-P9_LINK_ID2=$($DDB query "INSERT INTO p9_link (title, url) VALUES ('R Parent', 'https://r')" | tr -d '[:space:]')
-sleep 1
-$DDB query "INSERT INTO p9_blocker (title, link) VALUES ('Block', '$P9_LINK_ID2')" >/dev/null
-P9_RESTRICT_OUT="$($DDB delete "$P9_LINK_ID2" 2>&1 || true)"
-printf '%s' "$P9_RESTRICT_OUT" | grep -q "NOT NULL REFERENCES from p9_blocker.link"
-pass "48: ON DELETE RESTRICT (default) rejects parent delete"
-
-# §2: cascade cycle detection.
-$DDB query "CREATE TABLE p9_a (title TEXT)" >/dev/null
-$DDB query "CREATE TABLE p9_b (title TEXT)" >/dev/null
-$DDB query "ALTER TABLE p9_a ADD COLUMN b VARCHAR(255) REFERENCES p9_b(id) ON DELETE CASCADE" >/dev/null
-$DDB query "ALTER TABLE p9_b ADD COLUMN a VARCHAR(255) REFERENCES p9_a(id) ON DELETE CASCADE" >/dev/null
-P9_A_ID=$($DDB query "INSERT INTO p9_a (title) VALUES ('A')" | tr -d '[:space:]')
-sleep 1
-P9_B_ID=$($DDB query "INSERT INTO p9_b (title) VALUES ('B')" | tr -d '[:space:]')
-$DDB query "UPDATE p9_a SET b = '$P9_B_ID' WHERE id = '$P9_A_ID'" >/dev/null
-$DDB query "UPDATE p9_b SET a = '$P9_A_ID' WHERE id = '$P9_B_ID'" >/dev/null
-P9_CYCLE_OUT="$($DDB delete "$P9_A_ID" 2>&1 || true)"
-printf '%s' "$P9_CYCLE_OUT" | grep -q "cascade delete would form a cycle"
-pass "48: ON DELETE CASCADE cycle detection rejects"
-
-cd "$TMPDIR"
-rm -rf "$P9_DIR"
-
-# 49. PRD 00133 unify-typed-write-paths: CLI typed `create` on a registered
-# typedef must populate the reference zone for REFERENCES columns and reject
-# FK to wrong-type ids. The unit-test suite covers GraphQL `createDoogat` /
-# `createMany` parity end-to-end (see `service::tests::batch_create_*` and
-# `service::tests::create_doogat_with_extra_*`); here we drive the CLI/FFI
-# entry point through the `ddb create --field` shell surface so cross-shell
-# regressions surface in CI.
-echo "=== PRD 00133: unified typed-write paths (CLI parity) ==="
-TW_DIR="$(mktemp -d)"
-cd "$TW_DIR"
-$DDB init >/dev/null
-$DDB query "CREATE TABLE tw_category (label VARCHAR(64))" >/dev/null
-TW_CAT1=$($DDB query "INSERT INTO tw_category (title, label) VALUES ('c1', 'alpha')" | tr -d '[:space:]')
-sleep 1
-TW_CAT2=$($DDB query "INSERT INTO tw_category (title, label) VALUES ('c2', 'beta')" | tr -d '[:space:]')
-[ -n "$TW_CAT1" ] && [ -n "$TW_CAT2" ]
-pass "49: junction typedef setup with two category rows"
-
-# CLI create on tw_membership (two REFERENCES columns -> tw_category). The
-# resulting doogat must have REFERENCES values in the reference zone.
-$DDB query "CREATE TABLE tw_membership (link VARCHAR(64) REFERENCES tw_category, parent VARCHAR(64) REFERENCES tw_category)" >/dev/null
-sleep 1
-TW_MEM_ID=$($DDB create --type tw_membership --title "M1" --set "link=$TW_CAT1" --set "parent=$TW_CAT2" | tr -d '[:space:]')
-[ -n "$TW_MEM_ID" ]
-pass "49: CLI create on junction-style typedef succeeds"
-
-TW_RAW=$($DDB get "$TW_MEM_ID")
-printf '%s' "$TW_RAW" | grep -q "link:: \\[\\[$TW_CAT1\\]\\]"
-printf '%s' "$TW_RAW" | grep -q "parent:: \\[\\[$TW_CAT2\\]\\]"
-pass "49: CLI create populates reference zone for REFERENCES columns"
-
-# CLI create with FK pointing at a row of the wrong type must reject. Use a
-# row from an unrelated typedef to prove the FK queries the typedef target
-# table (tw_category), not the generic doogats index.
-$DDB query "CREATE TABLE tw_link (label VARCHAR(64))" >/dev/null
-sleep 1
-TW_LINK_ID=$($DDB query "INSERT INTO tw_link (title, label) VALUES ('not a category', 'plain')" | tr -d '[:space:]')
-[ -n "$TW_LINK_ID" ]
-TW_BAD_OUT=$($DDB create --type tw_membership --title "Bogus" --set "link=$TW_LINK_ID" --set "parent=$TW_CAT1" 2>&1 || true)
-# CLI prints the human-readable message ("references non-existent <type>");
-# the structured REFERENCES_VIOLATION code is asserted at the GraphQL layer
-# by the unit-test suite.
-printf '%s' "$TW_BAD_OUT" | grep -q "references non-existent tw_category" || { echo "CLI rejection output: $TW_BAD_OUT"; exit 1; }
-pass "49: CLI create rejects FK to wrong-type id"
-
-cd "$TMPDIR"
-rm -rf "$TW_DIR"
-
-# 44.L — CLI `ddb create` populates the auto-junction atomically (PRD 00134
-# cycle-1 review C1 task #4). Mirrors 44.K through the CLI/FFI entry point
-# so the typed materialization path is exercised end-to-end across surfaces
-# (GraphQL, CLI). Unit tests already cover the service-layer typed-create
-# (see `service::tests::create_doogat_with_extra_*`); this section adds the
-# CLI shell-process wrapper so cross-shell regressions surface in CI.
-J134L_DIR="$(mktemp -d)"
-cd "$J134L_DIR"
-$DDB init >/dev/null
-$DDB query "CREATE TABLE j134l_cat (label VARCHAR(64))" >/dev/null
-sleep 1
-J134L_CAT=$($DDB query "INSERT INTO j134l_cat (title, label) VALUES ('lcat', 'alpha')" | tr -d '[:space:]')
-[ -n "$J134L_CAT" ]
-$DDB query "CREATE TABLE j134l_bm (url VARCHAR(200), category VARCHAR(64) REFERENCES j134l_cat)" >/dev/null
-sleep 1
-J134L_BM=$($DDB create --type j134l_bm --title "L1" --set "url=https://l.example" --set "category=$J134L_CAT" | tr -d '[:space:]')
-[ -n "$J134L_BM" ]
-J134L_JOIN=$($DDB query "SELECT bm.id FROM j134l_bm bm JOIN j134l_bm_category j ON j.j134l_bm_id = bm.id WHERE j.category_id = '$J134L_CAT'")
-printf '%s' "$J134L_JOIN" | grep -qF "$J134L_BM"
-pass "PRD 00134: CLI ddb create populates auto-junction for REFERENCES column (44.L)"
-cd "$TMPDIR"
-rm -rf "$J134L_DIR"
-
-# 50. PRD 00136 / #16 — cross-process FK freshness on `ddb create`.
-# The bug shape: process 1 creates a typed parent via `ddb create`, then
-# process 2 (a fresh `DoogatService`) creates a typed child whose FK
-# references the parent. Pre-fix, process 2's stale `SqlEngine` rejected
-# with REFERENCES_VIOLATION even though the parent existed in git and in
-# the global `doogats` index. Distinct from 49 / 44.L (which seed parents
-# via `ddb query "INSERT INTO ..."`); only the back-to-back CLI `ddb
-# create` shape reproduces the pre-PRD-00136 stale-index FK rejection.
-# Each `$DDB` invocation is a fresh process, so the regression lives at
-# the cross-`ddb create` boundary that this section exercises.
-INT136_DIR="$(mktemp -d)"
-cd "$INT136_DIR"
-$DDB init >/dev/null
-$DDB query "CREATE TABLE int136cat (fqn VARCHAR(255))" >/dev/null
-$DDB query "CREATE TABLE int136link (url TEXT, category TEXT REFERENCES int136cat)" >/dev/null
-INT136_CAT=$($DDB create --type int136cat --title "Cat 136" --set "fqn=test.fqn")
-echo "$INT136_CAT" | grep -qE "^[0-9]{14}$"
-INT136_LINK=$($DDB create --type int136link --title "Link 136" --set "url=https://a" --set "category=$INT136_CAT")
-echo "$INT136_LINK" | grep -qE "^[0-9]{14}$"
-pass "PRD 00136 / #16: cross-process FK freshness on ddb create"
-cd "$TMPDIR"
-rm -rf "$INT136_DIR"
-
-# 62. PRD 00164 - unified repo-aware ID minting (end-to-end CLI conformance):
-# the batch (multi-row INSERT) and single (`ddb create`) mint paths agree on
-# "id taken", so back-to-back mints in the same wall-clock second yield
-# distinct, non-colliding ids. No `sleep 1` between mints on purpose - the
-# stale same-second workaround is exactly what this PRD removes. NOTE: `ddb
-# create` is the normal create path, already repo-aware before 00164. The blind
-# `|_| false` paths are repo-aware now too: `create_doogat_raw` mint collisions
-# are pinned by the core Rust regressions (ddb-core/tests/id_mint_collision.rs,
-# raw_create_mint_collision.rs); `install_bundled_type` routes through the same
-# shared oracle (ddb-core/src/id_minting.rs unit tests). Neither is exercised by
-# this CLI scenario.
-INT164_DIR="$(mktemp -d)"
-cd "$INT164_DIR"
-$DDB init >/dev/null
-$DDB query "CREATE TABLE int164 (label TEXT)" >/dev/null
-INT164_BATCH=$($DDB query "INSERT INTO int164 (label) VALUES ('a'), ('b'), ('c')")
-echo "$INT164_BATCH" | grep -qE "^[0-9]{14},[0-9]{14},[0-9]{14}$"
-INT164_SINGLE=$($DDB create --type int164 --title "single 164" --set "label=d")
-echo "$INT164_SINGLE" | grep -qE "^[0-9]{14}$"
-INT164_ALL=$(printf '%s\n%s\n' "$INT164_BATCH" "$INT164_SINGLE" | tr ',' '\n')
-[ "$(printf '%s\n' "$INT164_ALL" | grep -cE '^[0-9]{14}$')" = "4" ]
-[ "$(printf '%s\n' "$INT164_ALL" | sort -u | grep -cE '^[0-9]{14}$')" = "4" ]
-pass "PRD 00164: batch + single mint paths yield distinct ids (no same-second collision)"
-cd "$TMPDIR"
-rm -rf "$INT164_DIR"
-
-# 63. PRD 00169 - poison-file skip warning through GraphQL extensions.
-# A doogat planted by a raw git commit (bypassing ddb CLI) with unparseable
-# frontmatter triggers a REINDEX_SKIPPED_FILES warning. The warning surfaces
-# on the FIRST mutation that calls ensure_fresh() after the poison commit,
-# because ensure_fresh() reindexes, records the skip, and leaves the index
-# fresh. A SECOND mutation sees nothing stale and returns warnings: [].
-#
-# Load-bearing ordering: the server is started BEFORE the poison file is
-# planted so its stored HEAD predates the poison commit. The assertion is
-# against the very first createDoogat after the commit. Do not add a
-# warm-up call before this assertion - it would consume the warning and
-# silently turn the check into a false pass.
-
-INT169_DIR="$(mktemp -d)"
-cd "$INT169_DIR"
-$DDB init . >/dev/null
-
-# Seed one ordinary doogat so the index is non-empty and HEAD exists.
-$DDB create --title "seed" --body "seed body" >/dev/null
-
-# Start server on its own port (distinct from the now-dead 19200-range server).
-INT169_PORT=$((20200 + (RANDOM % 700)))
-INT169_PG_PORT=$((INT169_PORT + 1))
-$DDB serve --port "$INT169_PORT" --pg-port "$INT169_PG_PORT" &
-INT169_PID=$!
-for i in $(seq 1 20); do
-  if curl -sf "http://127.0.0.1:$INT169_PORT/graphql" \
-    -H "Authorization: Bearer $TOKEN" \
-    -H "Content-Type: application/json" \
-    -d '{"query":"{ typeDefs { name } }"}' >/dev/null 2>&1; then
-    break
-  fi
-  sleep 0.2
-done
-
-# Now plant the poison file (same shape as smoke.sh section 32).
-printf '%s\n' '---' ': invalid yaml [' '---' 'body' > "ddb/29990101000000.md"
-git -C "$INT169_DIR" add -A
-git -C "$INT169_DIR" commit -m "add poison doogat" >/dev/null
-
-# First createDoogat after the poison commit - this is where the warning fires.
-INT169_RESP=$(curl -sf "http://127.0.0.1:$INT169_PORT/graphql" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -d '{"query":"mutation { createDoogat(input: { title: \"after poison\" }) { id title } }"}')
-
-assert_gql_ok "$INT169_RESP"
-printf '%s' "$INT169_RESP" | jq -e '.extensions.warnings | length == 1
-       and (.[0].code == "REINDEX_SKIPPED_FILES")
-       and (.[0].message | test("29990101000000"))' >/dev/null
-pass "PRD 00169: poison file surfaces REINDEX_SKIPPED_FILES warning in GraphQL extensions"
-
-kill "$INT169_PID" 2>/dev/null || true
-wait "$INT169_PID" 2>/dev/null || true
-cd "$TMPDIR"
-rm -rf "$INT169_DIR"
-
-echo "=== all integration tests passed ==="

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


