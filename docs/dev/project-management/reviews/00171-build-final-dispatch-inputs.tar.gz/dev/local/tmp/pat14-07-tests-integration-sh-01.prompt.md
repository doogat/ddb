
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.sh, original lines 1-591, segment 1/7. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
tests/integration.sh:52: DONE (pre-existing, no port needed); targets=serve::auth_missing_token_returns_401, serve::crud_lifecycle, serve::health_no_auth_required, serve::health_returns_ok, serve::search_and_list
tests/integration.sh:160: DONE; targets=integration_graphql_jink::integration_17j1_jink_schema_create_tables
tests/integration.sh:164: DONE; targets=; fixture/scaffolding
tests/integration.sh:205: DONE; targets=integration_graphql_jink::integration_17j2_jink_config_singleton_and_link_crud
tests/integration.sh:243: DONE (pre-existing, no port needed); targets=serve::crud_lifecycle, serve::search_and_list, serve::search_returns_enriched_fields
tests/integration.sh:262: DONE (pre-existing, no port needed); targets=checkboxes::checkbox_graphql_queries
tests/integration.sh:267: DONE; targets=integration_graphql_server::integration_18c_graphql_tag_queries, serve::crud_lifecycle, serve::search_and_list
tests/integration.sh:284: DONE; targets=integration_graphql_server::integration_18c2_updated_at_created_at_fields
tests/integration.sh:305: DONE; targets=integration_graphql_server::integration_18d_search_filter_by_type_and_tag, serve::search_where_filter_combined_type_and_field
tests/integration.sh:335: DONE (pre-existing, no port needed); targets=serve::search_where_filter_combined_type_and_field, serve::search_where_filter_materialized_column_contains, serve::search_where_filter_materialized_column_eq, serve::search_where_filter_tag
tests/integration.sh:377: DONE (pre-existing, no port needed); targets=search_in_filter::search_where_in_empty_returns_no_results, search_in_filter::search_where_in_materialized_column, search_in_filter::search_where_in_tag
tests/integration.sh:429: DONE (pre-existing, no port needed); targets=serve::search_boolean_and_phrase_queries, serve::search_malformed_query_returns_bad_request
tests/integration.sh:465: DONE; targets=integration_graphql_server::integration_18g_normalize_query_implicit_and_lowercase, serve::normalize_search_query_standalone, serve::search_returns_query_normalized
tests/integration.sh:483: DONE; targets=integration_graphql_server::integration_18h_in_query_field_filter_and_error_class, serve::search_malformed_query_returns_bad_request
tests/integration.sh:548: DONE; targets=integration_graphql_server::integration_18i_in_query_substring_and_references_title
tests/integration.sh:584: DONE; targets=integration_graphql_server::integration_18z_update_delete_no_match_parity

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.sh b/tests/integration.sh
deleted file mode 100755
index 6942304..0000000
--- a/tests/integration.sh
+++ /dev/null
@@ -1,591 +0,0 @@
-#!/usr/bin/env bash
-set -euo pipefail
-
-# Integration tests: server, sync, CRDT conflicts, bundles, advanced SQL.
-# Runs smoke tests first, then continues with full integration suite.
-
-# --- Run smoke tests first ---
-SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
-
-# Build + lint when DDB_BIN is not injected.
-PREP_LABEL="prebuilt binary"
-if [ -z "${DDB_BIN:-}" ]; then
-  cargo build --quiet
-  cargo clippy --workspace --quiet
-  cargo bench --no-run --quiet 2>/dev/null
-  PREP_LABEL="clippy + bench compile"
-fi
-export DDB_BIN="${DDB_BIN:-$(cargo metadata --format-version=1 --no-deps | sed -n 's/.*"target_directory":"\([^"]*\)".*/\1/p')/debug/ddb}"
-
-"$SCRIPT_DIR/smoke.sh"
-
-# --- Integration tests ---
-DDB="$DDB_BIN"
-
-TMPDIR="$(mktemp -d)"
-REMOTE_DIR="$(mktemp -d)"
-NODE1_DIR="$(mktemp -d)"
-NODE2_DIR="$(mktemp -d)"
-NODE3_DIR="$(mktemp -d)"
-trap 'rm -rf "$TMPDIR" "$REMOTE_DIR" "$NODE1_DIR" "$NODE2_DIR" "$NODE3_DIR"' EXIT
-cd "$TMPDIR"
-
-pass() { printf '  ✓ %s\n' "$1"; }
-fail() {
-  printf '  ✗ %s\n' "$1" >&2
-  exit 1
-}
-
-echo "=== integration tests ==="
-
-# Init a repo for server and CLI integration tests
-$DDB init . >/dev/null
-ID1=$($DDB create --title "First note" --tags "test,smoke" --body "Hello world")
-ID2=$($DDB create --title "Links to first" --body "See [[$ID1]]")
-$DDB update "$ID1" --title "First note (edited)" --tags "test,smoke,updated"
-$DDB update "$ID1" --body "- [ ] open task\n- [x] done task\n- [i] 2026-01-01 10:00 - info note"
-$DDB reindex >/dev/null
-$DDB query "CREATE TABLE foo (bar TEXT, baz INTEGER)" >/dev/null
-$DDB query "INSERT INTO foo (title, bar, baz) VALUES ('for suggest', 'val', 1)" >/dev/null
-$DDB register-node "integ-node" >/dev/null
-
-# 17. GraphQL server
-SERVER_PORT=$((19200 + (RANDOM % 800)))
-PG_PORT=$((SERVER_PORT + 1))
-$DDB serve --port "$SERVER_PORT" --pg-port "$PG_PORT" &
-SERVER_PID=$!
-# Wait for server to start
-for i in $(seq 1 20); do
-  if curl -sf "http://127.0.0.1:$SERVER_PORT/graphql" \
-    -H "Authorization: Bearer $(cat ~/.config/ddb/token 2>/dev/null || echo '')" \
-    -H "Content-Type: application/json" \
-    -d '{"query":"{ typeDefs { name } }"}' >/dev/null 2>&1; then
-    break
-  fi
-  sleep 0.2
-done
-TOKEN=$(cat ~/.config/ddb/token 2>/dev/null || echo '')
-GQL_URL="http://127.0.0.1:$SERVER_PORT/graphql"
-REST_URL="http://127.0.0.1:$SERVER_PORT/rest"
-gql() {
-  curl -sf "$GQL_URL" \
-    -H "Authorization: Bearer $TOKEN" \
-    -H "Content-Type: application/json" \
-    -d "$1"
-}
-# Extract the "message" field of a successful executeSql response (which is the
-# new doogat id). Mirrors the helper from
-# dev/local/specs/jink-feedback/ddb-repros/_lib.sh:91 so jink-port checks can
-# use it verbatim.
-extract_id() {
-  grep -o '"message":"[^"]*"' | head -1 | sed 's/"message":"//;s/"$//'
-}
-# Assert that the given response contains "errors" (i.e. GraphQL rejected the
-# call). Returns 0 if errors are present, 1 otherwise. Prints the response on
-# failure so set -e callers get diagnostic context.
-assert_gql_errors() {
-  local resp="$1"
-  if printf '%s' "$resp" | grep -q '"errors"'; then
-    return 0
-  fi
-  printf '  ✗ assert_gql_errors: response had no "errors" key\n    response: %s\n' "$resp" >&2
-  return 1
-}
-# Assert that the given response is a successful GraphQL response (has "data"
-# and no "errors"). Returns 0 if both hold, 1 otherwise.
-assert_gql_ok() {
-  local resp="$1"
-  if printf '%s' "$resp" | grep -q '"errors"'; then
-    printf '  ✗ assert_gql_ok: response had "errors"\n    response: %s\n' "$resp" >&2
-    return 1
-  fi
-  if ! printf '%s' "$resp" | grep -q '"data"'; then
-    printf '  ✗ assert_gql_ok: response had no "data" key\n    response: %s\n' "$resp" >&2
-    return 1
-  fi
-  return 0
-}
-rest() {
-  curl -sf "$REST_URL$1" \
-    -H "Authorization: Bearer $TOKEN" \
-    -H "Content-Type: application/json" \
-    "${@:2}"
-}
-# Wait for the GraphQL schema to reload after a DDL statement. Polls
-# schemaVersion until it exceeds $1 (the version captured before the DDL).
-# Times out after 4 seconds (40 x 100ms).
-wait_schema_reload() {
-  local before="$1"
-  for i in $(seq 1 40); do
-    local ver
-    ver=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-    ver=${ver:-0}
-    [ "$ver" -gt "$before" ] && return 0
-    sleep 0.1
-  done
-  printf '  ✗ wait_schema_reload: version did not advance past %s within 4s\n' "$before" >&2
-  return 1
-}
-ddl() {
-  local ver
-  ver=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-  ver=${ver:-0}
-  gql "$1" >/dev/null
-  wait_schema_reload "$ver"
-}
-
-# Test auth
-HTTP_CODE=$(curl -so /dev/null -w "%{http_code}" "$GQL_URL" \
-  -H "Content-Type: application/json" \
-  -d '{"query":"{ typeDefs { name } }"}')
-[ "$HTTP_CODE" = "401" ]
-pass "serve: auth rejects missing token"
-
-# Health endpoint (no auth required)
-HEALTH=$(curl -sf "http://127.0.0.1:$SERVER_PORT/health")
-echo "$HEALTH" | grep -q '"status":"ok"'
-pass "serve: health endpoint"
-
-# Test query
-RESULT=$(gql '{"query":"{ typeDefs { name } }"}')
-echo "$RESULT" | grep -q '"typeDefs"'
-pass "serve: graphql query"
-
-# Test mutation — create
-RESULT=$(gql '{"query":"mutation { createDoogat(input: { title: \"Smoke Server\" }) { id title } }"}')
-echo "$RESULT" | grep -q '"Smoke Server"'
-GQL_ID=$(echo "$RESULT" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-pass "serve: graphql create"
-
-# 17.J1 — Jink schema CREATE TABLE definitions (#9 jink full-sweep section 1).
-# Seven table definitions ported from
-# dev/local/specs/jink-feedback/ddb-repros/validate-full-sweep.sh lines 34-60.
-# The tables persist through sub-blocks 17.J2, 18z8, 18z9, 18z10 below; task
-# 20 drops them all at the end. DO NOT add DROP TABLE statements between
-# these sub-blocks.
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-J1_LINK=$(gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE link (title VARCHAR(255) NOT NULL, url VARCHAR(255) NOT NULL, subtitle VARCHAR(255), favicon_path VARCHAR(255), favicon_origin VARCHAR(255), bookmark_source VARCHAR(255), last_opened_at VARCHAR(255), description TEXT)\") { message } }"}')
-assert_gql_ok "$J1_LINK"
-printf '%s' "$J1_LINK" | grep -q '"message":"table link'
-pass "j1: created link table"
-
-J1_CAT=$(gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE category (title VARCHAR(255) NOT NULL, fqn VARCHAR(255) NOT NULL, space VARCHAR(255) NOT NULL, sort_order INTEGER DEFAULT 0)\") { message } }"}')
-assert_gql_ok "$J1_CAT"
-printf '%s' "$J1_CAT" | grep -q '"message":"table category'
-pass "j1: created category table"
-
-J1_CM=$(gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE \\\"category-membership\\\" (title VARCHAR(255) NOT NULL, link_id VARCHAR(255) NOT NULL, category_fqn VARCHAR(255) NOT NULL, pinned BOOLEAN DEFAULT FALSE, sort_order INTEGER DEFAULT 0, UNIQUE(link_id, category_fqn))\") { message } }"}')
-assert_gql_ok "$J1_CM"
-printf '%s' "$J1_CM" | grep -q '"message":"table category-membership'
-pass "j1: created category-membership table with composite UNIQUE"
-
-J1_Q=$(gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE quote (title VARCHAR(255) NOT NULL, author VARCHAR(255), source VARCHAR(255), favorited BOOLEAN DEFAULT FALSE, text TEXT)\") { message } }"}')
-assert_gql_ok "$J1_Q"
-printf '%s' "$J1_Q" | grep -q '"message":"table quote'
-pass "j1: created quote table"
-
-J1_SS=$(gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE \\\"saved-search\\\" (title VARCHAR(255) NOT NULL, query_raw VARCHAR(255) NOT NULL, query_normalized VARCHAR(255) NOT NULL)\") { message } }"}')
-assert_gql_ok "$J1_SS"
-printf '%s' "$J1_SS" | grep -q '"message":"table saved-search'
-pass "j1: created saved-search table"
-
-J1_PR=$(gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE \\\"pinned-result\\\" (title VARCHAR(255) NOT NULL, query_normalized VARCHAR(255) NOT NULL, link_id VARCHAR(255) NOT NULL, sort_order INTEGER DEFAULT 0)\") { message } }"}')
-assert_gql_ok "$J1_PR"
-printf '%s' "$J1_PR" | grep -q '"message":"table pinned-result'
-pass "j1: created pinned-result table"
-
-J1_JC=$(gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE \\\"jink-config\\\" (dashboard_title VARCHAR(255) DEFAULT '\''Bobs Battlestation'\'', quote_rotation_minutes INTEGER DEFAULT 30, links_per_category INTEGER DEFAULT 8, frontend_version VARCHAR(255))\") { message } }"}')
-assert_gql_ok "$J1_JC"
-printf '%s' "$J1_JC" | grep -q '"message":"table jink-config'
-pass "j1: created jink-config table"
-
-wait_schema_reload "$VER"
-
-# 17.J2 — jink-config singleton + Link CRUD (#9 jink full-sweep sections 3-4).
-# Ported from validate-full-sweep.sh lines 70-100. Uses the jink tables from
-# J1; captures JINK_LINK_ID for use by later sub-blocks (18z8, 18z10).
-
-# jink-config singleton (3 checks from sweep section 3).
-J2_JC_EMPTY=$(gql '{"query":"{ sql(query: \"SELECT id FROM \\\"jink-config\\\" LIMIT 1\") { rows } }"}')
-assert_gql_ok "$J2_JC_EMPTY"
-printf '%s' "$J2_JC_EMPTY" | grep -q '"rows"'
-pass "j2: SELECT from empty jink-config"
-
-J2_JC_INS=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO \\\"jink-config\\\" (title, dashboard_title, quote_rotation_minutes, links_per_category) VALUES (\\\"jink-config\\\", \\\"Bobs Battlestation\\\", 30, 8)\") { message } }"}')
-assert_gql_ok "$J2_JC_INS"
-printf '%s' "$J2_JC_INS" | grep -qE '"message":"[0-9]+"'
-pass "j2: INSERT jink-config singleton"
-
-J2_JC_SEL=$(gql '{"query":"{ sql(query: \"SELECT quote_rotation_minutes FROM \\\"jink-config\\\" LIMIT 1\") { rows } }"}')
-assert_gql_ok "$J2_JC_SEL"
-printf '%s' "$J2_JC_SEL" | grep -qF '\"30\"'
-pass "j2: SELECT quote_rotation_minutes returns 30"
-
-# Link CRUD (3 checks from sweep section 4).
-J2_LINK_INS=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO link (title, url, description) VALUES (\\\"Test Link\\\", \\\"https://example.com\\\", \\\"a test link\\\")\") { message } }"}')
-assert_gql_ok "$J2_LINK_INS"
-JINK_LINK_ID=$(printf '%s' "$J2_LINK_INS" | extract_id)
-[ -n "$JINK_LINK_ID" ]
-printf '%s' "$J2_LINK_INS" | grep -qE '"message":"[0-9]+"'
-pass "j2: INSERT link returns id"
-
-J2_LINK_GQL=$(gql "{\"query\":\"{ links(where: {id: {eq: \\\"$JINK_LINK_ID\\\"}}) { items { id title url description tags } } }\"}")
-assert_gql_ok "$J2_LINK_GQL"
-printf '%s' "$J2_LINK_GQL" | grep -q '"Test Link"'
-pass "j2: query links via GraphQL"
-
-J2_LINK_UPD=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"UPDATE link SET favicon_path = 'favicon/x.png', favicon_origin = 'fetched' WHERE id = '$JINK_LINK_ID' AND url = 'https://example.com'\\\") { message affected } }\"}")
-assert_gql_ok "$J2_LINK_UPD"
-printf '%s' "$J2_LINK_UPD" | grep -q '"affected":1'
-pass "j2: UPDATE link favicon via compound-predicate SQL"
-
-# 18. expanded GraphQL operations
-RESULT=$(gql "{\"query\":\"mutation { updateDoogat(input: { id: \\\"$GQL_ID\\\", title: \\\"Smoke Updated\\\" }) { id title } }\"}")
-echo "$RESULT" | grep -q '"Smoke Updated"'
-pass "serve: graphql update"
-
-RESULT=$(gql '{"query":"{ search(query: \"Smoke\") { totalCount hits { id title tags type fields created_at } } }"}')
-echo "$RESULT" | grep -q '"search"'
-echo "$RESULT" | grep -q '"tags"'
-echo "$RESULT" | grep -q '"created_at"'
-pass "serve: graphql search with enriched fields"
-
-RESULT=$(gql '{"query":"{ doogats { id title } }"}')
-echo "$RESULT" | grep -q '"doogats"'
-pass "serve: graphql doogats"
-
-RESULT=$(gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$GQL_ID\\\") }\"}")
-echo "$RESULT" | grep -q "true"
-pass "serve: graphql delete"
-
-# 18b. GraphQL checkbox queries
-RESULT=$(gql '{"query":"{ openActions { state content } }"}')
-echo "$RESULT" | grep -q '"openActions"'
-pass "serve: graphql openActions"
-
-# 18c. GraphQL tag queries
-TAG_RESULT=$(gql '{"query":"mutation { createDoogat(input: { title: \"Tag Test\", tags: [\"alpha\", \"beta\"] }) { id title tags } }"}')
-echo "$TAG_RESULT" | grep -q '"alpha"'
-TAG_ID=$(echo "$TAG_RESULT" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-pass "serve: graphql create with tags"
-
-TAGS_RESULT=$(gql '{"query":"{ tags { name count } }"}')
-echo "$TAGS_RESULT" | grep -q '"alpha"'
-echo "$TAGS_RESULT" | grep -q '"beta"'
-pass "serve: graphql tags query"
-
-FILTERED=$(gql '{"query":"{ doogats(tag: \"alpha\") { id title tags } }"}')
-echo "$FILTERED" | grep -q "$TAG_ID"
-pass "serve: graphql doogats tag filter"
-
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$TAG_ID\\\") }\"}" >/dev/null
-
-# 18c2. GraphQL updated_at and created_at fields
-TS_RESULT=$(gql '{"query":"mutation { createDoogat(input: { title: \"Timestamp Test\" }) { id } }"}')
-TS_ID=$(echo "$TS_RESULT" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-TS_QUERY=$(gql "{\"query\":\"{ doogat(id: \\\"$TS_ID\\\") { updated_at created_at date } }\"}")
-echo "$TS_QUERY" | grep -q '"updated_at"'
-echo "$TS_QUERY" | grep -q '"created_at"'
-pass "serve: graphql updated_at and created_at fields"
-
-# Verify created_at equals date
-TS_DATE=$(echo "$TS_QUERY" | sed -n 's/.*"date":"\([^"]*\)".*/\1/p')
-TS_CREATED=$(echo "$TS_QUERY" | sed -n 's/.*"created_at":"\([^"]*\)".*/\1/p')
-[ "$TS_DATE" = "$TS_CREATED" ]
-pass "serve: created_at equals date"
-
-# Search hits include updated_at
-TS_SEARCH=$(gql '{"query":"{ search(query: \"Timestamp Test\") { hits { id updated_at } } }"}')
-echo "$TS_SEARCH" | grep -q '"updated_at"'
-pass "serve: search hits include updated_at"
-
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$TS_ID\\\") }\"}" >/dev/null
-
-# 18d. GraphQL search filters
-# Section j1 above registered the `link` typedef with url NOT NULL, so typed
-# creates must supply url. SF2 stays untyped since `note` is not a registered
-# typedef and PRD 00129 rejects unregistered types from GraphQL createDoogat.
-SF1=$(gql '{"query":"mutation { createDoogat(input: { title: \"SearchFilter Alpha\", type: \"link\", tags: [\"sf-tag\"], fields: \"{\\\"url\\\":\\\"https://example.com/sf1\\\"}\" }) { id } }"}')
-SF1_ID=$(echo "$SF1" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-SF2=$(gql '{"query":"mutation { createDoogat(input: { title: \"SearchFilter Beta\", tags: [\"sf-tag\"] }) { id } }"}')
-SF2_ID=$(echo "$SF2" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-SF3=$(gql '{"query":"mutation { createDoogat(input: { title: \"SearchFilter Gamma\", type: \"link\", fields: \"{\\\"url\\\":\\\"https://example.com/sf3\\\"}\" }) { id } }"}')
-SF3_ID=$(echo "$SF3" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-
-RESULT=$(gql '{"query":"{ search(query: \"SearchFilter\", types: [\"link\"]) { totalCount hits { id } } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "2" ]
-pass "serve: search filter by type"
-
-RESULT=$(gql '{"query":"{ search(query: \"SearchFilter\", tag: \"sf-tag\") { totalCount hits { id } } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "2" ]
-pass "serve: search filter by tag"
-
-RESULT=$(gql '{"query":"{ search(query: \"SearchFilter\", types: [\"link\"], tag: \"sf-tag\") { totalCount hits { id } } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "1" ]
-pass "serve: search filter combined type+tag"
-
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$SF1_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$SF2_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$SF3_ID\\\") }\"}" >/dev/null
-
-# 18d2. Search where field filters (materialized columns + tag)
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE wflink (url TEXT NOT NULL)\") { message } }"}' >/dev/null
-WF1=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO wflink (title, url) VALUES ('"'"'WFLink Alpha'"'"', '"'"'https://example.com'"'"')\") { message } }"}')
-WF1_ID=$(echo "$WF1" | sed -n 's/.*"message":"\([^"]*\)".*/\1/p' | tr -d ' ')
-WF2=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO wflink (title, url) VALUES ('"'"'WFLink Beta'"'"', '"'"'https://other.org'"'"')\") { message } }"}')
-WF2_ID=$(echo "$WF2" | sed -n 's/.*"message":"\([^"]*\)".*/\1/p' | tr -d ' ')
-WF3=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO wflink (title, url) VALUES ('"'"'WFLink Gamma'"'"', '"'"'https://example.com/page'"'"')\") { message } }"}')
-WF3_ID=$(echo "$WF3" | sed -n 's/.*"message":"\([^"]*\)".*/\1/p' | tr -d ' ')
-
-RESULT=$(gql '{"query":"{ search(query: \"WFLink\", where: [{field: \"url\", eq: \"https://example.com\"}]) { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "1" ]
-pass "serve: search where filter materialized column eq"
-
-RESULT=$(gql '{"query":"{ search(query: \"WFLink\", where: [{field: \"url\", contains: \"example\"}]) { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "2" ]
-pass "serve: search where filter materialized column contains"
-
-# Tag via where filter
-WFT1=$(gql '{"query":"mutation { createDoogat(input: { title: \"WFTag Alpha\", tags: [\"wf-rust\"] }) { id } }"}')
-WFT1_ID=$(echo "$WFT1" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-WFT2=$(gql '{"query":"mutation { createDoogat(input: { title: \"WFTag Beta\", tags: [\"wf-python\"] }) { id } }"}')
-WFT2_ID=$(echo "$WFT2" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-
-RESULT=$(gql '{"query":"{ search(query: \"WFTag\", where: [{field: \"tag\", eq: \"wf-rust\"}]) { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "1" ]
-pass "serve: search where filter tag eq"
-
-# Combined type + where field filter
-RESULT=$(gql '{"query":"{ search(query: \"WFLink\", types: [\"wflink\"], where: [{field: \"url\", eq: \"https://example.com\"}]) { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "1" ]
-pass "serve: search where filter combined type+field"
-
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$WF1_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$WF2_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$WF3_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$WFT1_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$WFT2_ID\\\") }\"}" >/dev/null
-
-# 18d3. Search where filter: in operator
-IN1=$(gql '{"query":"mutation { createDoogat(input: { title: \"InOp Alpha\", tags: [\"in-rust\", \"in-systems\"] }) { id } }"}')
-IN1_ID=$(echo "$IN1" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-IN2=$(gql '{"query":"mutation { createDoogat(input: { title: \"InOp Beta\", tags: [\"in-python\"] }) { id } }"}')
-IN2_ID=$(echo "$IN2" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-IN3=$(gql '{"query":"mutation { createDoogat(input: { title: \"InOp Gamma\", tags: [\"in-go\"] }) { id } }"}')
-IN3_ID=$(echo "$IN3" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-
-# in with multiple values — should match Alpha (in-rust) and Beta (in-python)
-RESULT=$(gql '{"query":"{ search(query: \"InOp\", where: [{field: \"tag\", in: [\"in-rust\", \"in-python\"]}]) { totalCount hits { id } } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "2" ]
-echo "$RESULT" | grep -q "$IN1_ID"
-echo "$RESULT" | grep -q "$IN2_ID"
-pass "serve: search where filter in operator (multiple values)"
-
-# in with single value — should match Gamma only
-RESULT=$(gql '{"query":"{ search(query: \"InOp\", where: [{field: \"tag\", in: [\"in-go\"]}]) { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "1" ]
-pass "serve: search where filter in operator (single value)"
-
-# in with empty array — should match nothing
-RESULT=$(gql '{"query":"{ search(query: \"InOp\", where: [{field: \"tag\", in: []}]) { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "0" ]
-pass "serve: search where filter in operator (empty array)"
-
-# in on materialized column
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE inlink (url TEXT NOT NULL)\") { message } }"}' >/dev/null
-INL1=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO inlink (title, url) VALUES ('"'"'InLink A'"'"', '"'"'https://a.example.com'"'"')\") { message } }"}')
-INL1_ID=$(echo "$INL1" | sed -n 's/.*"message":"\([^"]*\)".*/\1/p' | tr -d ' ')
-INL2=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO inlink (title, url) VALUES ('"'"'InLink B'"'"', '"'"'https://b.example.com'"'"')\") { message } }"}')
-INL2_ID=$(echo "$INL2" | sed -n 's/.*"message":"\([^"]*\)".*/\1/p' | tr -d ' ')
-INL3=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO inlink (title, url) VALUES ('"'"'InLink C'"'"', '"'"'https://c.example.com'"'"')\") { message } }"}')
-INL3_ID=$(echo "$INL3" | sed -n 's/.*"message":"\([^"]*\)".*/\1/p' | tr -d ' ')
-
-RESULT=$(gql '{"query":"{ search(query: \"InLink\", where: [{field: \"url\", in: [\"https://a.example.com\", \"https://c.example.com\"]}]) { totalCount hits { id } } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "2" ]
-echo "$RESULT" | grep -q "$INL1_ID"
-echo "$RESULT" | grep -q "$INL3_ID"
-pass "serve: search where filter in operator (materialized column)"
-
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$IN1_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$IN2_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$IN3_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$INL1_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$INL2_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$INL3_ID\\\") }\"}" >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE inlink CASCADE\") { message } }"}' >/dev/null
-
-# 18e. Boolean and phrase search queries
-BQ1=$(gql '{"query":"mutation { createDoogat(input: { title: \"BoolSearch Rust CRDT\", content: \"rust crdt patterns\" }) { id } }"}')
-BQ1_ID=$(echo "$BQ1" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-BQ2=$(gql '{"query":"mutation { createDoogat(input: { title: \"BoolSearch Rust Only\", content: \"rust programming\" }) { id } }"}')
-BQ2_ID=$(echo "$BQ2" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-BQ3=$(gql '{"query":"mutation { createDoogat(input: { title: \"BoolSearch Golang\", content: \"golang programming\" }) { id } }"}')
-BQ3_ID=$(echo "$BQ3" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-
-RESULT=$(gql '{"query":"{ search(query: \"rust AND crdt\") { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "1" ]
-pass "serve: search boolean AND"
-
-RESULT=$(gql '{"query":"{ search(query: \"rust OR golang\") { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "3" ]
-pass "serve: search boolean OR"
-
-RESULT=$(gql '{"query":"{ search(query: \"rust NOT crdt\") { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "1" ]
-pass "serve: search boolean NOT"
-
-RESULT=$(gql '{"query":"{ search(query: \"\\\"rust crdt\\\"\") { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "1" ]
-pass "serve: search quoted phrase"
-
-RESULT=$(gql '{"query":"{ search(query: \"AND AND\") { totalCount } }"}' 2>&1 || true)
-echo "$RESULT" | grep -q "invalid search query"
-pass "serve: search malformed query returns error"
-
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$BQ1_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$BQ2_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$BQ3_ID\\\") }\"}" >/dev/null
-
-# 18g. Search query normalization
-RESULT=$(gql '{"query":"{ normalizeSearchQuery(query: \"B AND A\") }"}')
-echo "$RESULT" | grep -q '"a and b"'
-pass "serve: normalizeSearchQuery sorts AND operands"
-
-RESULT=$(gql '{"query":"{ normalizeSearchQuery(query: \"Tag=svelte AND category=work.portals\") }"}')
-echo "$RESULT" | grep -q '"category=work.portals and tag=svelte"'
-pass "serve: normalizeSearchQuery sorts field filters"
-
-RESULT=$(gql '{"query":"{ normalizeSearchQuery(query: \"  MEETING   Minutes  \") }"}')
-echo "$RESULT" | grep -q '"meeting and minutes"'
-pass "serve: normalizeSearchQuery implicit AND and lowercase"
-
-RESULT=$(gql '{"query":"{ search(query: \"rust AND crdt\") { queryNormalized } }"}')
-echo "$RESULT" | grep -q '"queryNormalized"'
-echo "$RESULT" | grep -q '"crdt and rust"'
-pass "serve: search returns queryNormalized"
-
-# 18h. In-query field-filter alignment + error-class consistency (PRD 00121)
-PRD121A=$(gql '{"query":"mutation { createDoogat(input: { title: \"PRD121 Alpha\", tags: [\"prd121-rust\"] }) { id } }"}')
-PRD121A_ID=$(echo "$PRD121A" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-PRD121B=$(gql '{"query":"mutation { createDoogat(input: { title: \"PRD121 Beta\", tags: [\"prd121-python\"] }) { id } }"}')
-PRD121B_ID=$(echo "$PRD121B" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-PRD121G=$(gql '{"query":"mutation { createDoogat(input: { title: \"PRD121 Gamma\", tags: [\"prd121-rust\", \"prd121-cli\"] }) { id } }"}')
-PRD121G_ID=$(echo "$PRD121G" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-
-RESULT=$(gql '{"query":"{ search(query: \"tag=prd121-rust\") { totalCount hits { id } } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "2" ]
-pass "serve: search in-query tag filter returns matching set"
-
-RESULT_INQ=$(gql '{"query":"{ search(query: \"tag=prd121-rust\") { hits { id } } }"}')
-RESULT_WHERE=$(gql '{"query":"{ search(query: \"\", where: [{field: \"tag\", eq: \"prd121-rust\"}]) { hits { id } } }"}')
-IDS_INQ=$(echo "$RESULT_INQ" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p' | sort)
-IDS_WHERE=$(echo "$RESULT_WHERE" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p' | sort)
-[ "$IDS_INQ" = "$IDS_WHERE" ]
-pass "serve: in-query tag filter matches where-arg tag filter"
-
-RESULT=$(gql '{"query":"{ search(query: \"PRD121 tag=prd121-rust\") { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "2" ]
-pass "serve: search text AND in-query tag filter"
-
-RESULT=$(gql '{"query":"{ search(query: \"tag=prd121-rust\", where: [{field: \"tag\", eq: \"prd121-python\"}]) { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "0" ]
-pass "serve: search in-query + where tag filters intersect (AND)"
-
-RESULT=$(gql '{"query":"{ search(query: \"*\") { totalCount } }"}' || true)
-echo "$RESULT" | grep -q "invalid search query"
-! echo "$RESULT" | grep -q "internal error"
-pass "serve: search bare asterisk returns bad request (not internal)"
-
-RESULT=$(gql '{"query":"{ search(query: \"**\") { totalCount } }"}' || true)
-echo "$RESULT" | grep -q "invalid search query"
-! echo "$RESULT" | grep -q "internal error"
-pass "serve: search double asterisk returns bad request (not internal)"
-
-RESULT=$(gql '{"query":"{ search(query: \"(unbalanced\") { totalCount } }"}' || true)
-echo "$RESULT" | grep -q "invalid search query"
-! echo "$RESULT" | grep -q "internal error"
-pass "serve: search unbalanced paren returns bad request (not internal)"
-
-RESULT=$(gql '{"query":"{ search(query: \"AND\") { totalCount } }"}' || true)
-echo "$RESULT" | grep -q "invalid search query"
-! echo "$RESULT" | grep -q "internal error"
-pass "serve: search bare AND returns bad request (not internal)"
-
-RESULT=$(gql '{"query":"{ normalizeSearchQuery(query: \"tag=prd121-rust\") }"}')
-echo "$RESULT" | grep -q '"tag=prd121-rust"'
-pass "serve: normalizeSearchQuery preserves in-query tag filter"
-
-NORMALIZED=$(gql '{"query":"{ normalizeSearchQuery(query: \"tag=prd121-rust AND category=work.dev\") }"}' | sed -n 's/.*"normalizeSearchQuery":"\([^"]*\)".*/\1/p')
-[ "$NORMALIZED" = "category=work.dev and tag=prd121-rust" ]
-RESULT=$(gql "{\"query\":\"{ search(query: \\\"$NORMALIZED\\\") { totalCount } }\"}")
-! echo "$RESULT" | grep -q "invalid search query"
-! echo "$RESULT" | grep -q "internal error"
-pass "serve: search accepts normalized query round-trip"
-
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$PRD121A_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$PRD121B_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$PRD121G_ID\\\") }\"}" >/dev/null
-
-# 18i. In-query field-filter substring + REFERENCES title resolution (PRD 00133)
-# Pins the contract: title=X does LIKE; <ref_col>=X resolves via referenced
-# typedef title; explicit `where: { eq: X }` stays exact.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE int133cat (label VARCHAR(100))\") { message } }"}'
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE int133link (url TEXT, int133cat VARCHAR(14) REFERENCES int133cat(id))\") { message } }"}'
-P133_DEV=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO int133cat (title, label) VALUES (\\\"Development\\\", \\\"dev\\\")\") { message } }"}')
-P133_DEV_ID=$(printf '%s' "$P133_DEV" | extract_id)
-[ -n "$P133_DEV_ID" ]
-gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO int133link (title, url, int133cat) VALUES ('Rust Async', 'https://example.com/rust-async', '$P133_DEV_ID')\\\") { message } }\"}" >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO int133link (title, url) VALUES (\\\"Meeting Notes Archive\\\", \\\"https://example.com/archive\\\")\") { message } }"}' >/dev/null
-
-RESULT=$(gql '{"query":"{ search(query: \"title=Archive\") { totalCount hits { title } } }"}')
-echo "$RESULT" | grep -q "Meeting Notes Archive"
-pass "serve: in-query title=X does substring match"
-
-RESULT=$(gql '{"query":"{ search(query: \"int133cat=Development\") { totalCount hits { title } } }"}')
-echo "$RESULT" | grep -q "Rust Async"
-pass "serve: in-query <ref_col>=X resolves via referenced typedef title"
-
-# Explicit where: { eq } stays exact — Eq against the materialized column ID.
-# Title="Development" does NOT match the link.int133cat column (it stores the
-# category doogat ID), so eq with the title literal returns 0.
-RESULT=$(gql '{"query":"{ search(query: \"\", where: [{field: \"int133cat\", eq: \"Development\"}]) { totalCount } }"}')
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "0" ]
-pass "serve: explicit where eq stays exact (not LIKE) for REFERENCES"
-
-# But where: { eq: <id> } against the same column works (Eq on the stored ID).
-RESULT=$(gql "{\"query\":\"{ search(query: \\\"\\\", where: [{field: \\\"int133cat\\\", eq: \\\"$P133_DEV_ID\\\"}]) { totalCount } }\"}")
-COUNT=$(echo "$RESULT" | sed -n 's/.*"totalCount":\([0-9]*\).*/\1/p')
-[ "$COUNT" = "1" ]
-pass "serve: explicit where eq matches REFERENCES doogat ID exactly"
-
-ddl '{"query":"mutation { executeSql(sql: \"DROP TABLE int133link CASCADE\") { message } }"}'
-ddl '{"query":"mutation { executeSql(sql: \"DROP TABLE int133cat CASCADE\") { message } }"}'
-
-# 18z. UPDATE/DELETE WHERE id no-match GraphQL parity (issue #5 group B).
-# Rust unit tests and smoke CLI checks already cover B1-B5 at the lower layers;
-# this sub-block pins the same behavior at the GraphQL executeSql surface.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE link_b1 (url VARCHAR(255))\") { message } }"}'
-B1_SEED=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO link_b1 (title, url) VALUES (\\\"A\\\", \\\"https://a.com\\\")\") { message } }"}')
-B1_SEED_ID=$(printf '%s' "$B1_SEED" | extract_id)
-[ -n "$B1_SEED_ID" ]
-# B1: UPDATE WHERE id = nonexistent returns no errors and affected=0.

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


