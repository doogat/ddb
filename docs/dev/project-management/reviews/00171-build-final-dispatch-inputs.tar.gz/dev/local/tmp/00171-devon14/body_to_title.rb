#!/bin/sh
exec /Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb "$@"
