
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/integration.sh, original lines 592-1129, segment 2/7. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/integration.sh:584: DONE; targets=integration_graphql_server::integration_18z_update_delete_no_match_parity
tests/integration.sh:619: DONE; targets=integration_graphql_server::integration_18z2_execute_batch_atomicity, serve::execute_batch_format_objects, server_mutations::batch_update_atomicity_via_graphql
tests/integration.sh:648: DONE; targets=integration_graphql_server::integration_18z3_update_doogat_tag_semantics
tests/integration.sh:689: DONE; targets=integration_graphql_server::integration_18z4_sql_feature_coverage_pins
tests/integration.sh:729: DONE; targets=integration_graphql_server::integration_18z5_search_limit_boundary_pins
tests/integration.sh:760: DONE; targets=integration_graphql_server::integration_18z6_alter_table_add_column_in_typedefs_introspection, serve::alter_table_column_visible_in_graphql
tests/integration.sh:792: DONE; targets=integration_graphql_server::integration_18z7_graphql_schema_introspection_contract, serve::aggregate_query, serve::graphql_introspection_hides_internal_tables
tests/integration.sh:830: DONE; targets=integration_graphql_jink::integration_18z8_jink_category_membership_port
tests/integration.sh:870: DONE; targets=integration_graphql_jink::integration_18z9_jink_quotes_saved_searches_pinned_results_config_port
tests/integration.sh:935: DONE; targets=integration_graphql_jink::integration_18z10_jink_composite_unique_and_batch_delete_port
tests/integration.sh:974: DONE; targets=integration_rest_pgwire::integration_19_rest_sort_parameter, rest::rest_crud_lifecycle, serve::rest_auth_required, serve::rest_crud_lifecycle, serve::rest_filter_by_field, serve::rest_filter_by_tag
tests/integration.sh:1067: DONE; targets=integration_rest_pgwire::integration_20_compact_custom_backup_path, integration_rest_pgwire::integration_20_maintenance_mutation, integration_rest_pgwire::integration_20_nosql_endpoints, integration_rest_pgwire::integration_20_pgwire_boolean_type, integration_rest_pgwire::integration_20_sql_engine_error_descriptive, pgwire::pgwire_auth_rejected, pgwire::pgwire_connect_auth_ok, pgwire::pgwire_pg_catalog_hides_internal_tables, pgwire::pgwire_select_with_columns, rest::rest_get_unknown_id_returns_404, serve::graphql_introspection_hides_internal_tables, server_mutations::compact_force_mutation, server_mutations::compact_mutation_returns_result, server_mutations::compact_no_backup_mutation, server_mutations::sync_mutation_no_remote_returns_error

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/integration.sh b/tests/integration.sh
deleted file mode 100755
index 6942304..0000000
--- a/tests/integration.sh
+++ /dev/null
@@ -592,538 +0,0 @@
-B1_RESULT=$(gql '{"query":"mutation { executeSql(sql: \"UPDATE link_b1 SET title = \\\"x\\\" WHERE id = \\\"does_not_exist_b1\\\"\") { affected message } }"}')
-assert_gql_ok "$B1_RESULT"
-printf '%s' "$B1_RESULT" | grep -q '"affected":0'
-# B2: DELETE WHERE id = nonexistent returns no errors and affected=0.
-B2_RESULT=$(gql '{"query":"mutation { executeSql(sql: \"DELETE FROM link_b1 WHERE id = \\\"does_not_exist_b2\\\"\") { affected message } }"}')
-assert_gql_ok "$B2_RESULT"
-printf '%s' "$B2_RESULT" | grep -q '"affected":0'
-# B3: UPDATE WHERE non-id-column = nonexistent returns affected=0 (pin the
-# working fallthrough path so a regression can't silently remove it).
-B3_RESULT=$(gql '{"query":"mutation { executeSql(sql: \"UPDATE link_b1 SET title = \\\"x\\\" WHERE url = \\\"https://nope.com\\\"\") { affected message } }"}')
-assert_gql_ok "$B3_RESULT"
-printf '%s' "$B3_RESULT" | grep -q '"affected":0'
-# B4: UPDATE WHERE id = valid AND other = wrong returns affected=0.
-B4_RESULT=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"UPDATE link_b1 SET title = 'x' WHERE id = '$B1_SEED_ID' AND url = 'https://wrong.com'\\\") { affected message } }\"}")
-assert_gql_ok "$B4_RESULT"
-printf '%s' "$B4_RESULT" | grep -q '"affected":0'
-# B5: UPDATE WHERE id IN (nonexistent, valid) affects exactly the valid one.
-B5_RESULT=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"UPDATE link_b1 SET title = 'from_in_clause' WHERE id IN ('nope', '$B1_SEED_ID')\\\") { affected message } }\"}")
-assert_gql_ok "$B5_RESULT"
-printf '%s' "$B5_RESULT" | grep -q '"affected":1'
-# Pin the working fast path: valid id -> affected=1.
-B5_FAST=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"UPDATE link_b1 SET title = 'final' WHERE id = '$B1_SEED_ID'\\\") { affected message } }\"}")
-assert_gql_ok "$B5_FAST"
-printf '%s' "$B5_FAST" | grep -q '"affected":1'
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE link_b1 CASCADE\") { message } }"}' >/dev/null
-pass "issue-5-B1..B5: UPDATE/DELETE no-match GraphQL parity"
-
-# 18z2. executeBatch atomicity (issue #9 group F4). A batch where the second
-# statement fails on a UNIQUE constraint must roll back the first statement's
-# effect. Jink relies on this so partial writes can't leak out.
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE link_f4 (url VARCHAR(255))\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE membership_f4 (link_id VARCHAR(255), category VARCHAR(255), UNIQUE(link_id, category))\") { message } }"}' >/dev/null
-wait_schema_reload "$VER"
-F4_LINK=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO link_f4 (title, url) VALUES (\\\"initial\\\", \\\"https://f4.com\\\")\") { message } }"}')
-F4_LINK_ID=$(printf '%s' "$F4_LINK" | extract_id)
-[ -n "$F4_LINK_ID" ]
-gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO membership_f4 (title, link_id, category) VALUES ('m', '$F4_LINK_ID', 'work')\\\") { message } }\"}" >/dev/null
-# The batch: first UPDATE changes link title; second INSERT duplicates the
-# membership (UNIQUE violation). Expected: the entire batch is rolled back, so
-# link title stays "initial".
-F4_BATCH=$(gql "{\"query\":\"mutation { executeBatch(statements: [\\\"UPDATE link_f4 SET title = 'batched' WHERE id = '$F4_LINK_ID' AND url = 'https://f4.com'\\\", \\\"INSERT INTO membership_f4 (title, link_id, category) VALUES ('dup', '$F4_LINK_ID', 'work')\\\"]) { message } }\"}")
-assert_gql_errors "$F4_BATCH"
-printf '%s' "$F4_BATCH" | grep -q 'UNIQUE'
-# Verify the UPDATE was rolled back: title must still be "initial". The SQL
-# response wraps row values in nested JSON-escaped strings ("rows":["[\"initial\"]"])
-# so grep for the bare token without surrounding quotes.
-F4_AFTER=$(gql "{\"query\":\"{ sql(query: \\\"SELECT title FROM link_f4 WHERE id = '$F4_LINK_ID'\\\") { rows } }\"}")
-assert_gql_ok "$F4_AFTER"
-printf '%s' "$F4_AFTER" | grep -q 'initial'
-! printf '%s' "$F4_AFTER" | grep -q 'batched'
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE link_f4 CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE membership_f4 CASCADE\") { message } }"}' >/dev/null
-pass "issue-9-F4: executeBatch rolls back all statements when one fails"
-
-# 18z3. updateDoogat tag semantics (#9 F5/F6/F7). Pins three invariants that
-# jink relies on: tags: [] clears, duplicate inputs dedupe, unicode round-trips.
-
-# F5 — tags: [] clears all tags.
-F5=$(gql '{"query":"mutation { createDoogat(input: { title: \"F5 tag clear\", tags: [\"a\", \"b\", \"c\"] }) { id tags } }"}')
-F5_ID=$(printf '%s' "$F5" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-[ -n "$F5_ID" ]
-printf '%s' "$F5" | grep -q '"a"'
-gql "{\"query\":\"mutation { updateDoogat(input: { id: \\\"$F5_ID\\\", tags: [] }) { id } }\"}" >/dev/null
-F5_CHECK=$(gql "{\"query\":\"{ doogat(id: \\\"$F5_ID\\\") { id tags } }\"}")
-printf '%s' "$F5_CHECK" | grep -q '"tags":\[\]'
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$F5_ID\\\") }\"}" >/dev/null
-pass "issue-9-F5: updateDoogat tags: [] clears all tags"
-
-# F6 — duplicate input tags are deduplicated.
-F6=$(gql '{"query":"mutation { createDoogat(input: { title: \"F6 dedupe\" }) { id } }"}')
-F6_ID=$(printf '%s' "$F6" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-[ -n "$F6_ID" ]
-gql "{\"query\":\"mutation { updateDoogat(input: { id: \\\"$F6_ID\\\", tags: [\\\"x\\\", \\\"y\\\", \\\"x\\\", \\\"y\\\", \\\"x\\\"] }) { id tags } }\"}" >/dev/null
-F6_CHECK=$(gql "{\"query\":\"{ doogat(id: \\\"$F6_ID\\\") { id tags } }\"}")
-# Count occurrences of "x" and "y" in the tags array. Should be exactly 1 each.
-F6_X=$(printf '%s' "$F6_CHECK" | grep -o '"x"' | wc -l | tr -d ' ')
-F6_Y=$(printf '%s' "$F6_CHECK" | grep -o '"y"' | wc -l | tr -d ' ')
-[ "$F6_X" = "1" ]
-[ "$F6_Y" = "1" ]
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$F6_ID\\\") }\"}" >/dev/null
-pass "issue-9-F6: updateDoogat dedupes input tags"
-
-# F7 — unicode tags round-trip intact.
-F7=$(gql '{"query":"mutation { createDoogat(input: { title: \"F7 unicode\", tags: [\"日本語\", \"café\", \"ñoño\"] }) { id tags } }"}')
-F7_ID=$(printf '%s' "$F7" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-[ -n "$F7_ID" ]
-F7_CHECK=$(gql "{\"query\":\"{ doogat(id: \\\"$F7_ID\\\") { id tags } }\"}")
-# Some JSON encoders escape non-ASCII as \uXXXX. Check for either the raw
-# codepoint or its \u escape so the test is resilient to either representation.
-printf '%s' "$F7_CHECK" | grep -qE '日本語|\\u65e5\\u672c\\u8a9e'
-printf '%s' "$F7_CHECK" | grep -qE 'café|caf\\u00e9'
-printf '%s' "$F7_CHECK" | grep -qE 'ñoño|\\u00f1o\\u00f1o'
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$F7_ID\\\") }\"}" >/dev/null
-pass "issue-9-F7: updateDoogat preserves unicode tags"
-
-# 18z4. SQL feature coverage pins (#9 F9). Single per-feature check so a
-# regression in any one of COUNT, GROUP BY, ORDER BY, LIMIT, OFFSET, IS NULL,
-# LIKE is immediately attributable.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE feat (val INTEGER, label VARCHAR(255), maybe_null VARCHAR(255))\") { message } }"}'
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO feat (title, val, label, maybe_null) VALUES (\\\"r1\\\", 1, \\\"a\\\", \\\"x\\\")\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO feat (title, val, label) VALUES (\\\"r2\\\", 2, \\\"a\\\")\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO feat (title, val, label, maybe_null) VALUES (\\\"r3\\\", 3, \\\"b\\\", \\\"y\\\")\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO feat (title, val, label) VALUES (\\\"r4\\\", 4, \\\"b\\\")\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"INSERT INTO feat (title, val, label, maybe_null) VALUES (\\\"r5\\\", 5, \\\"c\\\", \\\"z\\\")\") { message } }"}' >/dev/null
-# COUNT(*) — SQL responses wrap row values as nested JSON-escaped arrays, so
-# grep -qF '[\"<val>\"]' is the matching pattern (see existing 43.D pattern).
-F9_CNT=$(gql '{"query":"{ sql(query: \"SELECT COUNT(*) FROM feat\") { rows } }"}')
-printf '%s' "$F9_CNT" | grep -qF '[\"5\"]'
-# GROUP BY label → three groups (a, b, c). `rows` is an array of stringified
-# arrays; format=array doesn't surface column names in the response, so only
-# check the values.
-F9_GRP=$(gql '{"query":"{ sql(query: \"SELECT label, COUNT(*) FROM feat GROUP BY label ORDER BY label\") { rows } }"}')
-assert_gql_ok "$F9_GRP"
-printf '%s' "$F9_GRP" | grep -qF '\"a\"'
-printf '%s' "$F9_GRP" | grep -qF '\"b\"'
-printf '%s' "$F9_GRP" | grep -qF '\"c\"'
-# ORDER BY DESC LIMIT 2 → rows with val 5, 4 (labels c, b)
-F9_ORD=$(gql '{"query":"{ sql(query: \"SELECT label FROM feat ORDER BY val DESC LIMIT 2\") { rows } }"}')
-printf '%s' "$F9_ORD" | grep -qF '[\"c\"]'
-printf '%s' "$F9_ORD" | grep -qF '[\"b\"]'
-! printf '%s' "$F9_ORD" | grep -qF '[\"a\"]'
-# OFFSET skipping first 3 → rows with val 4, 5
-F9_OFF=$(gql '{"query":"{ sql(query: \"SELECT val FROM feat ORDER BY val ASC LIMIT 10 OFFSET 3\") { rows } }"}')
-printf '%s' "$F9_OFF" | grep -qF '[\"4\"]'
-printf '%s' "$F9_OFF" | grep -qF '[\"5\"]'
-! printf '%s' "$F9_OFF" | grep -qF '[\"1\"]'
-# IS NULL → two rows (val 2, val 4)
-F9_NUL=$(gql '{"query":"{ sql(query: \"SELECT COUNT(*) FROM feat WHERE maybe_null IS NULL\") { rows } }"}')
-printf '%s' "$F9_NUL" | grep -qF '[\"2\"]'
-# LIKE → two rows (label a)
-F9_LIK=$(gql '{"query":"{ sql(query: \"SELECT COUNT(*) FROM feat WHERE label LIKE \\\"a%\\\"\") { rows } }"}')
-printf '%s' "$F9_LIK" | grep -qF '[\"2\"]'
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE feat CASCADE\") { message } }"}' >/dev/null
-pass "issue-9-F9: SQL feature coverage (COUNT, GROUP BY, ORDER BY, LIMIT, OFFSET, IS NULL, LIKE)"
-
-# 18z5. search() limit boundary pins (#9 F10). Seed three distinguishing
-# doogats, then probe 0 / 10000 / 10001 / -1 to capture current behavior.
-# The server enforces a hard max of 10000 so 10001 is rejected with a clear
-# message, not an internal error. This is a pin-existing-behavior check.
-F10A=$(gql '{"query":"mutation { createDoogat(input: { title: \"F10boundary alpha\" }) { id } }"}')
-F10A_ID=$(printf '%s' "$F10A" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-F10B=$(gql '{"query":"mutation { createDoogat(input: { title: \"F10boundary beta\" }) { id } }"}')
-F10B_ID=$(printf '%s' "$F10B" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-F10C=$(gql '{"query":"mutation { createDoogat(input: { title: \"F10boundary gamma\" }) { id } }"}')
-F10C_ID=$(printf '%s' "$F10C" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-sleep 1
-# limit: 0 — pin current behavior. Must not surface as an "internal error".
-F10_ZERO=$(gql '{"query":"{ search(query: \"F10boundary\", limit: 0) { totalCount hits { id } } }"}' || true)
-! printf '%s' "$F10_ZERO" | grep -q 'internal error'
-# limit: 10000 — max allowed. Must succeed and return all seeded rows.
-F10_MAX=$(gql '{"query":"{ search(query: \"F10boundary\", limit: 10000) { totalCount hits { id } } }"}')
-assert_gql_ok "$F10_MAX"
-printf '%s' "$F10_MAX" | grep -q '"totalCount":3'
-# limit: 10001 — one above the max. Pin the clear-error rejection.
-F10_OVER=$(gql '{"query":"{ search(query: \"F10boundary\", limit: 10001) { totalCount } }"}' || true)
-printf '%s' "$F10_OVER" | grep -q 'limit must not exceed'
-! printf '%s' "$F10_OVER" | grep -q 'internal error'
-# limit: -1 — GraphQL Int type may accept or reject. Either way: never an
-# internal error.
-F10_NEG=$(gql '{"query":"{ search(query: \"F10boundary\", limit: -1) { totalCount } }"}' || true)
-! printf '%s' "$F10_NEG" | grep -q 'internal error'
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$F10A_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$F10B_ID\\\") }\"}" >/dev/null
-gql "{\"query\":\"mutation { deleteDoogat(id: \\\"$F10C_ID\\\") }\"}" >/dev/null
-pass "issue-9-F10: search limit boundaries (0, 10000, 10001, -1)"
-
-# 18z6. ALTER TABLE ADD COLUMN surfaces in the typeDefs introspection query
-# (#9 F11). Jink relies on typeDefs to reflect the live schema so its client
-# code can validate columns before writing.
-ddl '{"query":"mutation { executeSql(sql: \"CREATE TABLE altschema_f11 (a VARCHAR(255))\") { message } }"}'
-F11_BEFORE=$(gql '{"query":"{ typeDefs { name columns { name dataType } } }"}')
-assert_gql_ok "$F11_BEFORE"
-printf '%s' "$F11_BEFORE" | grep -q '"altschema_f11"'
-# Column "a" should already be there; "b" should not exist yet.
-printf '%s' "$F11_BEFORE" | python3 -c "
-import json, sys
-resp = json.loads(sys.stdin.read())
-schemas = {t['name']: t['columns'] for t in resp['data']['typeDefs']}
-assert 'altschema_f11' in schemas, 'altschema_f11 missing from typeDefs'
-col_names = [c['name'] for c in schemas['altschema_f11']]
-assert 'a' in col_names, f\"column a missing from altschema_f11, got: {col_names}\"
-assert 'b' not in col_names, f\"column b unexpectedly present before ALTER, got: {col_names}\"
-"
-ddl '{"query":"mutation { executeSql(sql: \"ALTER TABLE altschema_f11 ADD COLUMN b INTEGER\") { message } }"}'
-F11_AFTER=$(gql '{"query":"{ typeDefs { name columns { name dataType } } }"}')
-assert_gql_ok "$F11_AFTER"
-printf '%s' "$F11_AFTER" | python3 -c "
-import json, sys
-resp = json.loads(sys.stdin.read())
-schemas = {t['name']: t['columns'] for t in resp['data']['typeDefs']}
-assert 'altschema_f11' in schemas, 'altschema_f11 missing from typeDefs after ALTER'
-col_names = [c['name'] for c in schemas['altschema_f11']]
-assert 'a' in col_names, f\"column a missing after ALTER, got: {col_names}\"
-assert 'b' in col_names, f\"column b missing from typeDefs after ALTER, got: {col_names}\"
-"
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE altschema_f11 CASCADE\") { message } }"}' >/dev/null
-pass "issue-9-F11: ALTER TABLE ADD COLUMN appears in typeDefs introspection"
-
-# 18z7. GraphQL schema introspection contract (#9 group G). Two invariants:
-# G1 — every typed table has a plural query field AND an Aggregate field.
-# G2 — every *Connection type exposes items and totalCount.
-# Naming rules (per ddb-server/src/schema/base_types.rs):
-#  - capitalize() upper-cases the first char → type name `Gqtesta`
-#  - pluralize() appends `s` to the lowercased name → query field `gqtestas`
-#  - Aggregate field is `<plural>Aggregate` → `gqtestasAggregate`
-#  - Connection type is `<Type>Connection` → `GqtestaConnection`
-VER=$(gql '{"query":"{ schemaVersion }"}' | sed -n 's/.*"schemaVersion":\([0-9]*\).*/\1/p')
-VER=${VER:-0}
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE gqtesta (label VARCHAR(255))\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"CREATE TABLE gqtestb (label VARCHAR(255))\") { message } }"}' >/dev/null
-wait_schema_reload "$VER"
-G_INTRO=$(gql '{"query":"{ __schema { queryType { fields { name } } types { name fields { name } } } }"}')
-assert_gql_ok "$G_INTRO"
-# G1: query fields `gqtestas` and `gqtestasAggregate` must exist (Gqtesta).
-printf '%s' "$G_INTRO" | grep -q '"name":"gqtestas"'
-printf '%s' "$G_INTRO" | grep -q '"name":"gqtestasAggregate"'
-printf '%s' "$G_INTRO" | grep -q '"name":"gqtestbs"'
-printf '%s' "$G_INTRO" | grep -q '"name":"gqtestbsAggregate"'
-# G2: Connection types must exist for both, and each must carry items +
-# totalCount. Use Python for structural parsing to avoid substring
-# ambiguity with the raw introspection JSON.
-printf '%s' "$G_INTRO" | python3 -c "
-import json, sys
-resp = json.loads(sys.stdin.read())
-types = {t['name']: t for t in resp['data']['__schema']['types']}
-for conn in ('GqtestaConnection', 'GqtestbConnection'):
-    assert conn in types, f'{conn} missing from schema types'
-    fields = {f['name'] for f in (types[conn].get('fields') or [])}
-    assert 'items' in fields, f'{conn} missing items field, got: {fields}'
-    assert 'totalCount' in fields, f'{conn} missing totalCount field, got: {fields}'
-"
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE gqtesta CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE gqtestb CASCADE\") { message } }"}' >/dev/null
-pass "issue-9-G1: every typed table has plural and Aggregate query fields"
-pass "issue-9-G2: every Connection type has items and totalCount fields"
-
-# 18z8. Category + membership jink port (#9 jink full-sweep section 5).
-# Ported from validate-full-sweep.sh lines 102-132. Uses JINK_LINK_ID from
-# sub-block 17.J2. Includes the COALESCE+subquery INSERT pattern jink relies
-# on for sort_order computation.
-J3_CAT=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO category (title, fqn, space, sort_order) VALUES (\\\"Dev\\\", \\\"work.dev\\\", \\\"work\\\", 0)\") { message } }"}')
-assert_gql_ok "$J3_CAT"
-JINK_CAT_ID=$(printf '%s' "$J3_CAT" | extract_id)
-[ -n "$JINK_CAT_ID" ]
-pass "j3: INSERT category"
-
-J3_CAT_SPACE=$(gql '{"query":"{ categories(where: {space: {eq: \"work\"}}) { items { id fqn title space sort_order } } }"}')
-assert_gql_ok "$J3_CAT_SPACE"
-printf '%s' "$J3_CAT_SPACE" | grep -q '"work.dev"'
-pass "j3: categories GraphQL query by space"
-
-J3_CAT_IN=$(gql '{"query":"{ categories(where: {fqn: {in: [\"work.dev\"]}}) { items { fqn title space } } }"}')
-assert_gql_ok "$J3_CAT_IN"
-printf '%s' "$J3_CAT_IN" | grep -q '"work.dev"'
-pass "j3: categories GraphQL query by fqn IN list"
-
-J3_CM=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO \\\\\\\"category-membership\\\\\\\" (title, link_id, category_fqn, sort_order) VALUES ('Test in work.dev', '$JINK_LINK_ID', 'work.dev', COALESCE((SELECT MAX(sort_order) + 1 FROM \\\\\\\"category-membership\\\\\\\" WHERE category_fqn = 'work.dev'), 0))\\\") { message } }\"}")
-assert_gql_ok "$J3_CM"
-printf '%s' "$J3_CM" | grep -qE '"message":"[0-9]+"'
-pass "j3: INSERT category-membership with COALESCE+subquery sort_order"
-
-J3_CM_BOTH=$(gql "{\"query\":\"{ categoryMemberships(where: {link_id: {eq: \\\"$JINK_LINK_ID\\\"}, category_fqn: {eq: \\\"work.dev\\\"}}) { items { id link_id category_fqn pinned sort_order } } }\"}")
-assert_gql_ok "$J3_CM_BOTH"
-printf '%s' "$J3_CM_BOTH" | grep -q '"work.dev"'
-pass "j3: categoryMemberships by link_id + category_fqn"
-
-J3_CM_LINK=$(gql "{\"query\":\"{ categoryMemberships(where: {link_id: {eq: \\\"$JINK_LINK_ID\\\"}}) { items { category_fqn } } }\"}")
-assert_gql_ok "$J3_CM_LINK"
-printf '%s' "$J3_CM_LINK" | grep -q '"work.dev"'
-pass "j3: categoryMemberships by link_id only"
-
-J3_CM_CAT=$(gql '{"query":"{ categoryMemberships(where: {category_fqn: {eq: \"work.dev\"}}) { items { link_id pinned sort_order } } }"}')
-assert_gql_ok "$J3_CM_CAT"
-printf '%s' "$J3_CM_CAT" | grep -q "$JINK_LINK_ID"
-pass "j3: categoryMemberships by category_fqn only"
-
-# 18z9. Jink quotes + saved-searches + pinned-results + jinkConfigs port
-# (#9 jink full-sweep sections 10-12). Ported from validate-full-sweep.sh
-# lines 188-241.
-
-# Quotes (4 checks).
-J4_Q=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO quote (title, author, text) VALUES (\\\"First\\\", \\\"Anon\\\", \\\"Hello world\\\")\") { message } }"}')
-assert_gql_ok "$J4_Q"
-JINK_QUOTE_ID=$(printf '%s' "$J4_Q" | extract_id)
-[ -n "$JINK_QUOTE_ID" ]
-pass "j4: INSERT quote"
-
-J4_Q_ID=$(gql "{\"query\":\"{ quotes(where: {id: {eq: \\\"$JINK_QUOTE_ID\\\"}}) { items { id title text author } } }\"}")
-assert_gql_ok "$J4_Q_ID"
-printf '%s' "$J4_Q_ID" | grep -q 'Hello world'
-pass "j4: quotes query by id"
-
-J4_Q_ALL=$(gql '{"query":"{ quotes { items { id } } }"}')
-assert_gql_ok "$J4_Q_ALL"
-printf '%s' "$J4_Q_ALL" | grep -q '"quotes"'
-pass "j4: quotes query all"
-
-J4_Q_UPD=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"UPDATE quote SET favorited = 'true' WHERE id = '$JINK_QUOTE_ID' AND title = 'First'\\\") { affected } }\"}")
-assert_gql_ok "$J4_Q_UPD"
-printf '%s' "$J4_Q_UPD" | grep -q '"affected":1'
-pass "j4: UPDATE quote SET favorited (compound predicate)"
-
-# Saved-search (2 checks).
-J4_SS=$(gql '{"query":"mutation { executeSql(sql: \"INSERT INTO \\\"saved-search\\\" (title, query_raw, query_normalized) VALUES (\\\"rust stuff\\\", \\\"Rust\\\", \\\"rust\\\")\") { message } }"}')
-assert_gql_ok "$J4_SS"
-JINK_SS_ID=$(printf '%s' "$J4_SS" | extract_id)
-[ -n "$JINK_SS_ID" ]
-pass "j4: INSERT saved-search"
-
-J4_SS_Q=$(gql "{\"query\":\"{ savedSearches(where: {id: {eq: \\\"$JINK_SS_ID\\\"}}) { items { id title query_raw query_normalized } } }\"}")
-assert_gql_ok "$J4_SS_Q"
-printf '%s' "$J4_SS_Q" | grep -q '"rust"'
-pass "j4: savedSearches query by id"
-
-# Pinned-result (2 checks).
-J4_PR=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO \\\\\\\"pinned-result\\\\\\\" (title, query_normalized, link_id, sort_order) VALUES ('pinned test', 'rust', '$JINK_LINK_ID', 0)\\\") { message } }\"}")
-assert_gql_ok "$J4_PR"
-printf '%s' "$J4_PR" | grep -qE '"message":"[0-9]+"'
-pass "j4: INSERT pinned-result"
-
-J4_PR_Q=$(gql '{"query":"{ pinnedResults(where: {query_normalized: {eq: \"rust\"}}) { items { id query_normalized link_id sort_order } } }"}')
-assert_gql_ok "$J4_PR_Q"
-printf '%s' "$J4_PR_Q" | grep -q "$JINK_LINK_ID"
-pass "j4: pinnedResults query by query_normalized"
-
-# jinkConfigs (3 checks).
-J4_JC=$(gql '{"query":"{ jinkConfigs { items { id dashboard_title quote_rotation_minutes links_per_category frontend_version } } }"}')
-assert_gql_ok "$J4_JC"
-printf '%s' "$J4_JC" | grep -q 'dashboard_title'
-pass "j4: jinkConfigs query"
-
-J4_JC_UPD=$(gql '{"query":"mutation { executeSql(sql: \"UPDATE \\\"jink-config\\\" SET frontend_version = '\''1.0.0'\'' WHERE title = '\''jink-config'\''\") { affected } }"}')
-assert_gql_ok "$J4_JC_UPD"
-printf '%s' "$J4_JC_UPD" | grep -q '"affected":1'
-pass "j4: UPDATE jink-config frontend_version (compound predicate)"
-
-J4_JC_SEL=$(gql '{"query":"{ sql(query: \"SELECT frontend_version FROM \\\"jink-config\\\" LIMIT 1\") { rows } }"}')
-assert_gql_ok "$J4_JC_SEL"
-printf '%s' "$J4_JC_SEL" | grep -qF '\"1.0.0\"'
-pass "j4: SELECT frontend_version returns 1.0.0"
-
-# 18z10. Composite UNIQUE duplicate + compound-predicate DELETE jink port
-# (#9 jink full-sweep sections 6 + 13). Ported from validate-full-sweep.sh
-# lines 137-139 and 246-256. Also drops all jink tables at the end so no
-# jink-port state leaks into later sections.
-
-# Sweep section 6: composite UNIQUE duplicate must be rejected with a
-# descriptive error. (Complements the F1 CLI check in section 30.)
-J5_DUP=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"INSERT INTO \\\\\\\"category-membership\\\\\\\" (title, link_id, category_fqn) VALUES ('dup', '$JINK_LINK_ID', 'work.dev')\\\") { message } }\"}")
-assert_gql_errors "$J5_DUP"
-printf '%s' "$J5_DUP" | grep -q 'UNIQUE'
-pass "j5: duplicate category-membership rejected with UNIQUE error"
-
-# Sweep section 13: executeBatch DELETE with compound predicates.
-J5_BATCH=$(gql "{\"query\":\"mutation { executeBatch(statements: [\\\"DELETE FROM \\\\\\\"category-membership\\\\\\\" WHERE link_id = '$JINK_LINK_ID' AND category_fqn = 'work.dev'\\\", \\\"DELETE FROM link WHERE id = '$JINK_LINK_ID' AND url = 'https://example.com'\\\"]) { message } }\"}")
-assert_gql_ok "$J5_BATCH"
-printf '%s' "$J5_BATCH" | grep -q '"executeBatch"'
-pass "j5: executeBatch DELETE category-membership + link (compound predicates)"
-
-J5_LINK_GONE=$(gql "{\"query\":\"{ links(where: {id: {eq: \\\"$JINK_LINK_ID\\\"}}) { items { id } } }\"}")
-assert_gql_ok "$J5_LINK_GONE"
-printf '%s' "$J5_LINK_GONE" | grep -qE '"items":\[\]'
-pass "j5: link is gone after batch delete"
-
-J5_Q_DEL=$(gql "{\"query\":\"mutation { executeSql(sql: \\\"DELETE FROM quote WHERE id = '$JINK_QUOTE_ID' AND title = 'First'\\\") { affected } }\"}")
-assert_gql_ok "$J5_Q_DEL"
-printf '%s' "$J5_Q_DEL" | grep -q '"affected":1'
-pass "j5: DELETE quote (compound predicate)"
-
-# Final cleanup: drop all jink tables from sub-block J1. Silenced so DROP
-# output doesn't pollute subsequent pass lines.
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE link CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE category CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE \\\"category-membership\\\" CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE quote CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE \\\"saved-search\\\" CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE \\\"pinned-result\\\" CASCADE\") { message } }"}' >/dev/null
-gql '{"query":"mutation { executeSql(sql: \"DROP TABLE \\\"jink-config\\\" CASCADE\") { message } }"}' >/dev/null
-pass "j5: jink port cleanup (all tables dropped)"
-
-# 19. REST API CRUD
-HTTP_CODE=$(curl -so /dev/null -w "%{http_code}" "$REST_URL/doogats" \
-  -H "Content-Type: application/json" \
-  -d '{"title":"REST No Auth"}')
-[ "$HTTP_CODE" = "401" ]
-pass "rest: auth rejects missing token"
-
-RESULT=$(curl -sf -w "\n%{http_code}" "$REST_URL/doogats" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -d '{"title":"REST Smoke","body":"rest body","tags":["rest"]}')
-HTTP_CODE=$(echo "$RESULT" | tail -1)
-BODY=$(echo "$RESULT" | sed '$d')
-[ "$HTTP_CODE" = "201" ]
-REST_ID=$(echo "$BODY" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-pass "rest: create"
-
-RESULT=$(rest "/doogats/$REST_ID")
-echo "$RESULT" | grep -q "REST Smoke"
-pass "rest: get"
-
-rest "/doogats/$REST_ID" -X PUT -d '{"title":"REST Updated"}' | grep -q "REST Updated"
-pass "rest: update"
-
-RESULT=$(rest "/doogats?tag=rest")
-echo "$RESULT" | grep -q "$REST_ID"
-pass "rest: list with filter"
-
-# Field filtering: create typed doogat via SQL, filter by field
-gql '{"query":"mutation{executeSql(sql:\"CREATE TABLE smokeitem (label TEXT NOT NULL, priority INTEGER)\"){message}}"}'
-gql '{"query":"mutation{executeSql(sql:\"INSERT INTO smokeitem (label, priority) VALUES ('\''Smoke1'\'', 7)\"){message}}"}'
-RESULT=$(rest "/doogats?field.priority=7")
-echo "$RESULT" | grep -q "Smoke1"
-pass "rest: field filter"
-
-# Field filter with nonexistent value returns empty
-RESULT=$(rest "/doogats?field.priority=999")
-echo "$RESULT" | grep -q '"data":\[\]'
-pass "rest: field filter no match"
-
-# REST sort: create doogats with distinct titles for sorting
-SORT_A=$(curl -sf "$REST_URL/doogats" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -d '{"title":"Charlie Sort","tags":["sorttest"]}' | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-sleep 0.1
-SORT_B=$(curl -sf "$REST_URL/doogats" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -d '{"title":"Alpha Sort","tags":["sorttest"]}' | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-sleep 0.1
-SORT_C=$(curl -sf "$REST_URL/doogats" \
-  -H "Authorization: Bearer $TOKEN" \
-  -H "Content-Type: application/json" \
-  -d '{"title":"Bravo Sort","tags":["sorttest"]}' | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
-
-RESULT=$(rest "/doogats?tag=sorttest&sort=title")
-FIRST_TITLE=$(echo "$RESULT" | sed -n 's/.*"data":\[{[^}]*"title":"\([^"]*\)".*/\1/p')
-[ "$FIRST_TITLE" = "Alpha Sort" ]
-pass "rest: sort by title ascending"
-
-RESULT=$(rest "/doogats?tag=sorttest&sort=-title")
-FIRST_TITLE=$(echo "$RESULT" | sed -n 's/.*"data":\[{[^}]*"title":"\([^"]*\)".*/\1/p')
-[ "$FIRST_TITLE" = "Charlie Sort" ]
-pass "rest: sort by title descending"
-
-# sort=date defaults to descending (newest first)
-RESULT=$(rest "/doogats?tag=sorttest&sort=date")
-FIRST_ID=$(echo "$RESULT" | sed -n 's/.*"data":\[{[^}]*"id":"\([^"]*\)".*/\1/p')
-[ "$FIRST_ID" = "$SORT_C" ]
-pass "rest: sort by date descending (default)"
-
-# invalid sort field returns 400
-HTTP_CODE=$(curl -so /dev/null -w "%{http_code}" "$REST_URL/doogats?sort=invalid" \
-  -H "Authorization: Bearer $TOKEN")
-[ "$HTTP_CODE" = "400" ]
-pass "rest: sort invalid field returns 400"
-
-# Clean up sort test doogats
-curl -sf "$REST_URL/doogats/$SORT_A" -H "Authorization: Bearer $TOKEN" -X DELETE >/dev/null
-curl -sf "$REST_URL/doogats/$SORT_B" -H "Authorization: Bearer $TOKEN" -X DELETE >/dev/null
-curl -sf "$REST_URL/doogats/$SORT_C" -H "Authorization: Bearer $TOKEN" -X DELETE >/dev/null
-
-HTTP_CODE=$(curl -so /dev/null -w "%{http_code}" "$REST_URL/doogats/$REST_ID" \
-  -H "Authorization: Bearer $TOKEN" -X DELETE)
-[ "$HTTP_CODE" = "204" ]
-pass "rest: delete"
-
-HTTP_CODE=$(curl -so /dev/null -w "%{http_code}" "$REST_URL/doogats/$REST_ID" \
-  -H "Authorization: Bearer $TOKEN")
-[ "$HTTP_CODE" = "404" ]
-pass "rest: get after delete returns 404"
-
-# 20. PgWire basic query
-if command -v psql >/dev/null 2>&1; then
-  PGPASSWORD="$TOKEN" psql -h 127.0.0.1 -p "$PG_PORT" -U ddb -d ddb -t -c "SELECT id, title FROM doogats" | grep -q "First note"
-  pass "pgwire: select"
-
-  ! PGPASSWORD="wrong" psql -h 127.0.0.1 -p "$PG_PORT" -U ddb -d ddb -c "SELECT 1" 2>/dev/null
-  pass "pgwire: auth rejection"
-
-  # pgwire boolean type: BOOLEAN columns should return t/f
-  ddl '{"query":"mutation{executeSql(sql:\"CREATE TABLE pgbooltest (label TEXT, active BOOLEAN)\"){message}}"}'
-  gql '{"query":"mutation{executeSql(sql:\"INSERT INTO pgbooltest (label, active) VALUES ('\''yes'\'', true)\"){message}}"}' >/dev/null
-  PG_BOOL=$(PGPASSWORD="$TOKEN" psql -h 127.0.0.1 -p "$PG_PORT" -U ddb -d ddb -t -A -c "SELECT active FROM pgbooltest WHERE label = 'yes'")
-  echo "$PG_BOOL" | grep -q "t"
-  pass "pgwire: boolean type"
-  gql '{"query":"mutation{executeSql(sql:\"DROP TABLE pgbooltest CASCADE\"){message}}"}' >/dev/null
-
-  # pgwire \dt hides internal tables
-  DT_OUT=$(PGPASSWORD="$TOKEN" psql -h 127.0.0.1 -p "$PG_PORT" -U ddb -d ddb -t -A -c "SELECT relname FROM pg_catalog.pg_class WHERE relkind = 'r'")
-  ! echo "$DT_OUT" | grep -q "_ddb_"
-  ! echo "$DT_OUT" | grep -q "^doogats$"
-  pass "pgwire: \\dt hides internal tables"
-
-  # pgwire: direct access to internal tables still works (hidden, not blocked)
-  PGPASSWORD="$TOKEN" psql -h 127.0.0.1 -p "$PG_PORT" -U ddb -d ddb -t -A -c "SELECT COUNT(*) FROM _ddb_tags" | grep -qE "^[0-9]+$"
-  pass "pgwire: direct access to internal tables works"
-else
-  # PRD 00139 cycle-3 #3: this section tests GENERAL PgWire features (boolean
-  # type, \dt internal-table filtering, _ddb_tags direct access). The
-  # cross-platform `pgwire_singleton` e2e covers SINGLETON parity only, not
-  # these general tests, so failing loud here would break CI on hosts without
-  # psql for features unrelated to SINGLETON. Keep the SINGLETON-specific
-  # PgWire parity assertion (section 54.D below) as fail() since that IS
-  # what cycle-1 6094641 intended to harden.
-  pass "pgwire: general psql smoke skipped (psql not on PATH); SINGLETON parity below is still strict"
-fi
-
-# NoSQL server endpoints
-NOSQL_URL="http://127.0.0.1:$SERVER_PORT/nosql"
-nosql() {
-  curl -sf "$NOSQL_URL$1" \
-    -H "Authorization: Bearer $TOKEN"
-}
-
-nosql "/$ID1" | grep -q "First note"
-pass "nosql-api: get by id"
-
-nosql "?tag=smoke" | grep -q "$ID1"
-pass "nosql-api: scan by tag"
-
-HTTP_CODE=$(curl -so /dev/null -w "%{http_code}" "$NOSQL_URL?type=project&tag=test" \
-  -H "Authorization: Bearer $TOKEN")
-[ "$HTTP_CODE" = "400" ]
-pass "nosql-api: rejects both type and tag"
-
-HTTP_CODE=$(curl -so /dev/null -w "%{http_code}" "$NOSQL_URL/$ID1" \
-  -H "Content-Type: application/json")
-[ "$HTTP_CODE" = "401" ]
-pass "nosql-api: auth rejects missing token"
-
-# error response — SQL engine errors are descriptive (user-actionable)
-RESULT=$(gql '{"query":"mutation { executeSql(sql: \"SELCT * FORM oops\") { message } }"}' || true)
-if [ -z "$RESULT" ]; then echo "FAIL: gql returned empty response" >&2; exit 1; fi
-echo "$RESULT" | grep -q '"errors"'

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.

Your previous reply did not follow the reporting contract. Reply again with only lines of the form `SEVERITY | file:line | issue | fix` (CRITICAL/HIGH/MEDIUM/LOW), CLOSURE lines where the description carries a findings block, or the single line `NO FINDINGS`. No other text.

