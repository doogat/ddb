from pathlib import Path
import json
import subprocess
import uuid

root = Path('/Users/bob/git/src/github.com/doogat/ddb')
plugin = Path('/Users/bob/.claude/plugins/cache/buvis-plugins/autopilot/0.5.1')
tmp = root / 'dev/local/tmp'
base = '5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
state = json.loads((root / 'dev/local/autopilot/state.json').read_text())
task = next(t for t in state['tasks'] if t['id'] == '14')
rows = json.loads((root / 'dev/local/reviews/00171-mapping-discovery.json').read_text())['rows']
deleted = ['tests/smoke.sh', 'tests/smoke.ps1', 'tests/integration.sh', 'tests/integration.ps1']
changed = subprocess.check_output(['git', 'diff', '--name-only', base, head], cwd=root, text=True).splitlines()
other = [f for f in changed if f not in deleted]
groups = []
for name, paths in [('docs', [f for f in other if not f.endswith('.rs')]), ('rust-comments', [f for f in other if f.endswith('.rs')])]:
    if paths:
        diff = subprocess.check_output(['git', 'diff', base, head, '--', *paths], cwd=root, text=True)
        groups.append((name, diff, 'This partition contains all task changes in these files: ' + ', '.join(paths) + '. Other task files are reviewed in separate partitions.'))
for file in deleted:
    patch = subprocess.check_output(['git', 'diff', base, head, '--', file], cwd=root, text=True)
    lines = patch.splitlines(keepends=True)
    hunk = next(i for i, line in enumerate(lines) if line.startswith('@@'))
    header = ''.join(lines[:hunk])
    body = lines[hunk + 1:]
    assert all(line.startswith('-') for line in body), file
    assert len(body) == len(subprocess.check_output(['git', 'show', base + ':' + file], cwd=root).splitlines()), file
    start = 1
    chunks = []
    current = []
    size = 0
    for line in body:
        if current and size + len(line.encode()) > 32000:
            chunks.append(current)
            current = []
            size = 0
        current.append(line)
        size += len(line.encode())
    if current:
        chunks.append(current)
    for n, chunk in enumerate(chunks, 1):
        end = start + len(chunk) - 1
        mapping = []
        preceding = None
        for key, value in rows.items():
            path, line = key.rsplit(':', 1)
            if path != file:
                continue
            line = int(line)
            entry = f'{key}: {value["status"]}; targets=' + ', '.join(value['tests'])
            if value.get('scaffolding'):
                entry += '; fixture/scaffolding'
            if value.get('aliases'):
                entry += '; aliases=' + str(value['aliases'])
            if line < start:
                preceding = entry
            elif line <= end:
                mapping.append(entry)
        if preceding:
            mapping.insert(0, 'Section already in progress: ' + preceding)
        note = f'This partition is the complete deletion patch for {file}, original lines {start}-{end}, segment {n}/{len(chunks)}. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.\n\nThe previously audited source-to-runner mapping rows overlapping this segment are:\n' + '\n'.join(mapping)
        groups.append((file.replace('/', '-').replace('.', '-') + f'-{n:02d}', header + f'@@ -{start},{len(chunk)} +0,0 @@\n' + ''.join(chunk), note))
        start = end + 1
    assert start == len(body) + 1
metadata = {'base': base, 'head': head, 'groups': []}
for index, (name, diff, note) in enumerate(groups, 1):
    prefix = tmp / f'pat14-{index:02d}-{name}'
    inputs = {
        'TASK_SUBJECT': task['name'],
        'TASK_DESCRIPTION': task['description'] + '\n\nPartition context:\n' + note,
        'TASK_ACCEPTANCE_CRITERIA': 'No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.',
        'DIFF': diff,
    }
    args = ['python3', str(plugin / 'skills/work/scripts/render_prompt.py'), str(plugin / 'agents/pat.md'), '--out', str(prefix) + '.prompt.md']
    for key, value in inputs.items():
        path = Path(str(prefix) + '.' + key.lower() + '.txt')
        path.write_text(value)
        args += ['--set-file', key + '=' + str(path)]
    args += ['--set-file', 'SIMPLIFICATION_MANDATE=' + str(plugin / 'skills/work/references/simplification-mandate.md'), '--set-file', 'VERIFICATION_RESULT=' + str(tmp / 'review-task-14-verification.txt'), '--set', 'CONTRACT_CORRECTION=', '--dispatch-kind', 'pat', '--dispatch-task', '14']
    result = subprocess.run(args, cwd=root, text=True, capture_output=True, check=True, timeout=60)
    size, dispatch_id = result.stdout.strip().splitlines()
    assert int(size) <= 50000, (name, size)
    metadata['groups'].append({'index': index, 'name': name, 'bytes': int(size), 'dispatch_id': dispatch_id, 'session_id': str(uuid.uuid4()), 'prompt': str(prefix) + '.prompt.md', 'report': str(root / f'dev/local/reviews/00171-task14-pat-{index:02d}-{name}.md')})
    print(index, name, size, dispatch_id)
(tmp / '00171-pat14-meta.json').write_text(json.dumps(metadata, indent=2) + '\n')
print('TOTAL', len(groups), 'partitions; each changed source line included exactly once')
