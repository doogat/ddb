
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/smoke.ps1, original lines 636-932, segment 2/2. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/smoke.ps1:627: DONE; targets=; aliases=['tests/smoke.sh:511']
tests/smoke.ps1:650: DONE; targets=; aliases=['tests/smoke.sh:534']
tests/smoke.ps1:658: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:542']
tests/smoke.ps1:680: DONE; targets=; aliases=['tests/smoke.sh:564']
tests/smoke.ps1:688: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:571']
tests/smoke.ps1:715: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:594']
tests/smoke.ps1:733: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:610']
tests/smoke.ps1:744: DONE; targets=; aliases=['tests/smoke.sh:619']
tests/smoke.ps1:758: DONE; targets=; aliases=['tests/smoke.sh:633']
tests/smoke.ps1:783: DONE; targets=; aliases=['tests/smoke.sh:652']
tests/smoke.ps1:802: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:671']
tests/smoke.ps1:815: DONE; targets=; aliases=['tests/smoke.sh:683']
tests/smoke.ps1:835: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:700']
tests/smoke.ps1:859: DONE; targets=; aliases=['tests/smoke.sh:713']
tests/smoke.ps1:891: DONE; targets=; aliases=['tests/smoke.sh:743']

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/smoke.ps1 b/tests/smoke.ps1
deleted file mode 100644
index 188f1ed..0000000
--- a/tests/smoke.ps1
+++ /dev/null
@@ -636,297 +0,0 @@
-$output = ddb query "SELECT active FROM booltest WHERE active = 0"
-if ($output -notmatch "false") { throw "boolean false not coerced: $output" }
-# NULL boolean stays NULL
-Start-Sleep -Seconds 1
-ddb query "INSERT INTO booltest (label) VALUES ('none')" | Out-Null
-$output = ddb query "SELECT active FROM booltest WHERE label = 'none'"
-if ($output -notmatch "NULL") { throw "boolean null not preserved: $output" }
-# Mixed columns: only booleans coerced
-$output = ddb query "SELECT label, active FROM booltest WHERE label = 'on'"
-if ($output -notmatch "on") { throw "non-boolean column corrupted: $output" }
-if ($output -notmatch "true") { throw "boolean column not coerced in mix: $output" }
-ddb query "DROP TABLE booltest CASCADE" | Out-Null
-pass "boolean consistency (SQL responses)"
-
-# 20. type tables are self-contained (no JOIN needed for core columns)
-$scId = ddb query "INSERT INTO foo (title, bar, baz) VALUES ('Self-Contained Test', 'val', 1)"
-$output = ddb query "SELECT id, title, date, updated_at, bar FROM foo WHERE id = '$scId'"
-if ($output -notmatch $scId) { throw "self-contained: id missing: $output" }
-if ($output -notmatch "Self-Contained Test") { throw "self-contained: title missing: $output" }
-pass "type table self-contained (core columns without JOIN)"
-ddb query "DROP TABLE foo CASCADE" | Out-Null
-
-# 21. DEFAULT NEXT auto-increment
-ddb query "CREATE TABLE nexttbl (name TEXT, pos INTEGER DEFAULT NEXT)" | Out-Null
-ddb query "INSERT INTO nexttbl (name) VALUES ('a')" | Out-Null
-Start-Sleep -Seconds 1
-ddb query "INSERT INTO nexttbl (name) VALUES ('b')" | Out-Null
-Start-Sleep -Seconds 1
-ddb query "INSERT INTO nexttbl (name) VALUES ('c')" | Out-Null
-# Verify auto-assigned values 1, 2, 3
-$output = ddb query "SELECT pos FROM nexttbl ORDER BY pos"
-if ($output -notmatch "1") { throw "NEXT default: expected 1: $output" }
-if ($output -notmatch "2") { throw "NEXT default: expected 2: $output" }
-if ($output -notmatch "3") { throw "NEXT default: expected 3: $output" }
-# Explicit override
-Start-Sleep -Seconds 1
-ddb query "INSERT INTO nexttbl (name, pos) VALUES ('d', 99)" | Out-Null
-Start-Sleep -Seconds 1
-ddb query "INSERT INTO nexttbl (name) VALUES ('e')" | Out-Null
-$output = ddb query "SELECT MAX(pos) FROM nexttbl"
-if ($output -notmatch "100") { throw "NEXT default: expected MAX 100: $output" }
-ddb query "DROP TABLE nexttbl CASCADE" | Out-Null
-pass "DEFAULT NEXT auto-increment"
-
-# 22. FTS5 search boost (search_boost on typedef columns)
-ddb type install contact 2>$null | Out-Null
-$BOOST_ID = ddb create --type contact --title "Boost Test Contact" --set email=uniquexyz@example.com
-ddb reindex | Out-Null
-$output = ddb search "uniquexyz"
-if ($output -notmatch $BOOST_ID) { throw "fts5 search boost: boosted field not found in results" }
-pass "fts5 search boost (boosted field match)"
-
-# 23. SQL expression support (COALESCE, IFNULL, arithmetic in VALUES/SET)
-$output = ddb query "CREATE TABLE exprtbl (sort_order INTEGER)"
-if ($output -notmatch "table exprtbl created") { throw "create exprtbl failed" }
-$EXPR_ID1 = ddb query "INSERT INTO exprtbl (sort_order) VALUES (COALESCE((SELECT MAX(sort_order) FROM exprtbl), 0))"
-if ($EXPR_ID1 -notmatch "^\d{14}$") { throw "insert coalesce bad id: $EXPR_ID1" }
-$output = ddb query "SELECT sort_order FROM exprtbl WHERE id = '$EXPR_ID1'"
-if ($output -notmatch "0") { throw "coalesce should yield 0: $output" }
-Start-Sleep -Seconds 1
-$EXPR_ID2 = ddb query "INSERT INTO exprtbl (sort_order) VALUES (COALESCE((SELECT MAX(sort_order) FROM exprtbl), 0) + 1)"
-if ($EXPR_ID2 -notmatch "^\d{14}$") { throw "insert coalesce+1 bad id: $EXPR_ID2" }
-$output = ddb query "SELECT sort_order FROM exprtbl WHERE id = '$EXPR_ID2'"
-if ($output -notmatch "1") { throw "coalesce+1 should yield 1: $output" }
-$output = ddb query "UPDATE exprtbl SET sort_order = IFNULL(NULL, 42) WHERE id = '$EXPR_ID1'"
-if ($output -notmatch "1 row") { throw "update ifnull failed: $output" }
-$output = ddb query "SELECT sort_order FROM exprtbl WHERE id = '$EXPR_ID1'"
-if ($output -notmatch "42") { throw "ifnull should yield 42: $output" }
-# NULLIF returns null (empty in ddb) for equal args
-ddb query "INSERT INTO exprtbl (sort_order) VALUES (NULLIF(0, 0))" | Out-Null
-# Nested expression: ABS(-1) + LENGTH('hi') = 1 + 2 = 3
-$NESTED_ID = ddb query "INSERT INTO exprtbl (sort_order) VALUES (COALESCE(ABS(-1) + LENGTH('hi'), 0))"
-$output = ddb query "SELECT sort_order FROM exprtbl WHERE id = '$NESTED_ID'"
-if ($output -notmatch "3") { throw "nested expression should yield 3: $output" }
-# Unlisted function should be rejected
-if (-not (ddb-fails query "INSERT INTO exprtbl (sort_order) VALUES (BADFUNC(1))")) { throw "unlisted function should be rejected" }
-ddb query "DROP TABLE exprtbl CASCADE" | Out-Null
-pass "sql expression support (COALESCE, IFNULL, arithmetic)"
-
-# 24. --set / --unset flags on create and update
-$SET_ID = ddb create --title "SetTest" --set color=red --set size=large
-if ($SET_ID -notmatch "^\d{14}$") { throw "--set create bad id: $SET_ID" }
-$output = ddb read $SET_ID
-if ($output -notmatch "color: red") { throw "--set color not found" }
-if ($output -notmatch "size: large") { throw "--set size not found" }
-ddb update $SET_ID --set color=blue
-$output = ddb read $SET_ID
-if ($output -notmatch "color: blue") { throw "--set update color failed" }
-ddb update $SET_ID --set "color="
-$output = ddb read $SET_ID
-if ($output -match "color: blue") { throw "--set k= should clear value" }
-ddb update $SET_ID --unset size
-$output = ddb read $SET_ID
-if ($output -match "size:") { throw "--unset should remove field" }
-if (-not (ddb-fails create --title "Bad" --set "noequals")) { throw "malformed --set should error" }
-pass "--set / --unset flags"
-
-# 25. SQL INSERT defaults date from doogat ID
-ddb query "CREATE TABLE datetest (name TEXT)"
-$DATE_ID = ddb query "INSERT INTO datetest (name) VALUES ('hello')"
-$DATE_EXPECTED = "$($DATE_ID.Substring(0,4))-$($DATE_ID.Substring(4,2))-$($DATE_ID.Substring(6,2))"
-$output = ddb read $DATE_ID
-if ($output -notmatch "date: $DATE_EXPECTED") { throw "date not derived from ID: $output" }
-$EXPLICIT_ID = ddb query "INSERT INTO datetest (name, date) VALUES ('world', '2025-01-15')"
-$output = ddb read $EXPLICIT_ID
-if ($output -notmatch "date: 2025-01-15") { throw "explicit date not preserved: $output" }
-pass "SQL INSERT defaults date from ID"
-
-# 26. FTS negation search
-$NEG_ID1 = ddb create --title "Important Design" --body "important design review"
-$NEG_ID2 = ddb create --title "Important Meeting" --body "important meeting notes"
-$NEG_ID3 = ddb create --title "Daily Standup" --body "daily standup agenda"
-ddb reindex | Out-Null
-$NEG_RESULT = ddb search "important NOT meeting"
-if ($NEG_RESULT -notmatch $NEG_ID1) { throw "fts negation: positive term not found" }
-if ($NEG_RESULT -match $NEG_ID2) { throw "fts negation: negated term should be excluded" }
-pass "fts negation (positive NOT negative)"
-$NEG_ALL = ddb search "NOT standup"
-if ($NEG_ALL -match $NEG_ID3) { throw "fts negation: all-negative should exclude matching" }
-if ($NEG_ALL -notmatch $NEG_ID1) { throw "fts negation: all-negative should include non-matching" }
-pass "fts negation (all-negative query)"
-
-# 27. ON CONFLICT DO NOTHING (upsert)
-ddb query "CREATE TABLE upsert_test (code TEXT, label TEXT)" | Out-Null
-# Patch typedef to add unique_together on [code]
-$utFile = Get-ChildItem -Path ddb/_typedef -Filter *.md | Where-Object {
-    (Get-Content $_.FullName -Raw) -match "title: upsert_test"
-} | Select-Object -First 1
-$utContent = Get-Content $utFile.FullName -Raw
-$utContent = $utContent -replace "type: _typedef", "type: _typedef`nunique_together:`n  - - code"
-Set-Content -Path $utFile.FullName -Value $utContent -NoNewline
-git add -A | Out-Null
-git commit -m "add unique_together" --quiet | Out-Null
-ddb reindex | Out-Null
-$UPSERT_ID1 = ddb query "INSERT INTO upsert_test (title, code, label) VALUES ('First', 'ABC', 'original')"
-if ($UPSERT_ID1 -notmatch "^\d{14}$") { throw "upsert: bad id: $UPSERT_ID1" }
-Start-Sleep -Seconds 1
-# Duplicate with ON CONFLICT DO NOTHING should return existing ID
-$UPSERT_ID2 = ddb query "INSERT INTO upsert_test (title, code, label) VALUES ('Second', 'ABC', 'duplicate') ON CONFLICT DO NOTHING"
-if ($UPSERT_ID2 -ne $UPSERT_ID1) { throw "upsert: duplicate should return existing ID: got $UPSERT_ID2 expected $UPSERT_ID1" }
-Start-Sleep -Seconds 1
-# Non-duplicate should create new
-$UPSERT_ID3 = ddb query "INSERT INTO upsert_test (title, code, label) VALUES ('Third', 'DEF', 'new') ON CONFLICT DO NOTHING"
-if ($UPSERT_ID3 -eq $UPSERT_ID1) { throw "upsert: non-duplicate should create new ID" }
-ddb query "DROP TABLE upsert_test CASCADE" | Out-Null
-pass "ON CONFLICT DO NOTHING (upsert)"
-
-# 28. in-query field filter substring + REFERENCES title resolution (PRD 00133)
-ddb query "CREATE TABLE smoke_cat (label VARCHAR(100))" | Out-Null
-ddb query "CREATE TABLE smoke_link (url TEXT, smoke_cat VARCHAR(14) REFERENCES smoke_cat(id))" | Out-Null
-$scDevId = ddb query "INSERT INTO smoke_cat (title, label) VALUES ('Development', 'dev')"
-ddb query "INSERT INTO smoke_link (title, url, smoke_cat) VALUES ('Rust Async', 'https://example.com/rust-async', '$scDevId')" | Out-Null
-ddb query "INSERT INTO smoke_link (title, url) VALUES ('Meeting Notes Archive', 'https://example.com/archive')" | Out-Null
-ddb reindex | Out-Null
-
-$titleLikeResult = ddb search "title=Archive" | Out-String
-if ($titleLikeResult -notmatch "Meeting Notes Archive") { throw "in-query title=X did not substring-match: $titleLikeResult" }
-pass "in-query title=X does substring match"
-
-$catResolveResult = ddb search "smoke_cat=Development" | Out-String
-if ($catResolveResult -notmatch "Rust Async") { throw "in-query <ref_col>=X did not resolve via referenced title: $catResolveResult" }
-pass "in-query <ref_col>=X resolves via referenced typedef title"
-
-ddb query "DROP TABLE smoke_link CASCADE" | Out-Null
-ddb query "DROP TABLE smoke_cat CASCADE" | Out-Null
-
-# 29. ALTER TABLE ALTER COLUMN TYPE (PRD 00128)
-ddb query "CREATE TABLE alter_type_smoke (url VARCHAR(10))" | Out-Null
-$smokeAtId = ddb query "INSERT INTO alter_type_smoke (title, url) VALUES ('start', '1234567890')"
-if ($smokeAtId -notmatch "^\d{14}$") { throw "alter-col-type: bad id: $smokeAtId" }
-ddb query "ALTER TABLE alter_type_smoke ALTER COLUMN url TYPE TEXT" | Out-Null
-Start-Sleep -Seconds 1
-$longUrl = 'x' * 500
-$smokeAtId2 = ddb query "INSERT INTO alter_type_smoke (title, url) VALUES ('post', '$longUrl')"
-if ($smokeAtId2 -notmatch "^\d{14}$") { throw "alter-col-type: post-widen insert failed: $smokeAtId2" }
-$rows = ddb query "SELECT id FROM alter_type_smoke"
-if ($rows -notmatch $smokeAtId2) { throw "alter-col-type: widened row not visible" }
-pass "ALTER TABLE ALTER COLUMN TYPE widening (VARCHAR -> TEXT)"
-
-# 30. SINGLETON typedef CRUD (PRD 00139)
-$output = ddb query "CREATE TABLE smoke_singleton (theme TEXT) SINGLETON"
-if ($output -notmatch "table smoke_singleton created") { throw "smoke_singleton create failed: $output" }
-$ssId = ddb query "INSERT INTO smoke_singleton (title, theme) VALUES ('cfg', 'dark')"
-if ($ssId -is [array]) { $ssId = $ssId[-1] }
-if ($ssId -notmatch "^\d{14}$") { throw "smoke_singleton first insert returned bad id: [$ssId]" }
-# Capture stderr of the failing second INSERT. CLI surfaces the human-readable
-# message ("SINGLETON constraint violated: ..."); the structured
-# `SINGLETON_VIOLATION` code only appears via GraphQL `extensions.code`
-# (covered by integration.ps1 §A in T20).
-$ssDup = & $DDB query "INSERT INTO smoke_singleton (title, theme) VALUES ('cfg2', 'light')" 2>&1 | Out-String
-if ($LASTEXITCODE -eq 0) { throw "smoke_singleton duplicate INSERT should have failed, got: $ssDup" }
-if ($ssDup -notmatch "SINGLETON constraint") { throw "smoke_singleton duplicate must surface SINGLETON constraint message, got: $ssDup" }
-$output = ddb query "UPDATE smoke_singleton SET theme = 'auto' WHERE id = '$ssId'"
-if ($output -notmatch "1 row\(s\) affected") { throw "smoke_singleton post-failure UPDATE failed: $output" }
-$output = ddb query "SELECT theme FROM smoke_singleton WHERE id = '$ssId'"
-if ($output -notmatch "auto") { throw "smoke_singleton SELECT returned unexpected: $output" }
-ddb query "DROP TABLE smoke_singleton CASCADE" | Out-Null
-pass "SINGLETON typedef: first INSERT, second rejects, UPDATE survives (PRD 00139)"
-
-# 31. declarative schema apply/diff (PRD 00161)
-$schemaFile = Join-Path $TMPDIR "smoke_schema.yaml"
-@"
-types:
-  - name: smoke_widget
-    columns:
-      - name: wlabel
-        data_type: VARCHAR(255)
-        zone: frontmatter
-        required: true
-"@ | Set-Content -Path $schemaFile
-# Dry-run prints a create_type plan naming the declared column; mutates nothing.
-$output = ddb schema apply $schemaFile --dry-run
-if ($output -notmatch "create_type") { throw "schema dry-run missing create_type: $output" }
-if ($output -notmatch "CREATE TABLE") { throw "schema dry-run missing CREATE TABLE: $output" }
-if (-not (ddb-fails query "SELECT wlabel FROM smoke_widget")) { throw "dry-run must not create smoke_widget" }
-# Real apply creates the type; the column is queryable afterwards.
-ddb schema apply $schemaFile | Out-Null
-ddb query "SELECT wlabel FROM smoke_widget" | Out-Null
-# Re-apply is a converged no-op (no create/add/drop op).
-$output = ddb schema apply $schemaFile
-if ($output -match "create_type") { throw "re-apply must be a no-op, got: $output" }
-pass "schema apply/diff: dry-run plan, real create, idempotent re-apply (PRD 00161)"
-
-# 32. poison-file reindex resilience (PRD 00169)
-$poisonPath = "ddb/29990101000000.md"
-@"
----
-: invalid yaml [
----
-body
-"@ | Set-Content -Path $poisonPath -NoNewline
-git -C $TMPDIR add -A
-git -C $TMPDIR commit -m "add poison doogat" | Out-Null
-
-$output = & $DDB reindex 2>&1 | Out-String
-if ($LASTEXITCODE -ne 0) { throw "lenient reindex should succeed, got: $output" }
-if ($output -notmatch [regex]::Escape($poisonPath)) { throw "lenient reindex should name poison path, got: $output" }
-pass "lenient reindex skips poison file and names its path"
-
-$output = & $DDB reindex --strict 2>&1 | Out-String
-if ($LASTEXITCODE -eq 0) { throw "strict reindex should fail" }
-if ($output -notmatch [regex]::Escape($poisonPath)) { throw "strict reindex should name poison path, got: $output" }
-pass "strict reindex fails and names the poison path"
-
-# NOTE: this asserts the CLI stays usable after a strict abort, NOT that the
-# abort was non-destructive. `ddb query` calls `ensure_fresh` (service/sql.rs),
-# which would silently rebuild a dropped index before answering, so this check
-# cannot fail on the wipe-then-error scenario. The non-destructive property is
-# bound properly at unit level by
-# `indexer::tests::rebuild_strict_aborting_leaves_previously_indexed_rows_intact`.
-# Do not relabel this as an index-preservation check.
-$output = ddb query "SELECT id FROM doogats WHERE id = '$ID1'"
-if ($output -notmatch $ID1) { throw "cli should still answer queries after a strict reindex abort, got: $output" }
-pass "cli still answers queries after a strict reindex abort"
-
-# 33. reindex report + ddb create AppWarning surface skipped files (PRD 00169 gap closure)
-
-# Gap 1: `ddb reindex`'s OWN report (not the tracing subscriber on stderr) must
-# name skipped paths. With RUST_LOG=error the tracing channel is silenced, so
-# this binds the command's own report output, not the channel section 32
-# binds. Written fail-first: against the pre-fix binary reindex() printed only
-# "indexed N doogats" / "N warning(s)" and this assertion failed; the
-# per-warning lines it now binds ship in the same change.
-$env:RUST_LOG = "error"
-$output = & $DDB reindex 2>&1 | Out-String
-$reindexQuietExit = $LASTEXITCODE
-Remove-Item Env:\RUST_LOG -ErrorAction SilentlyContinue
-if ($reindexQuietExit -ne 0) { throw "reindex should succeed with RUST_LOG=error, got exit ${reindexQuietExit}: $output" }
-if ($output -notmatch [regex]::Escape($poisonPath)) { throw "reindex should name skipped path in its own report even with RUST_LOG=error, got: $output" }
-pass "reindex names skipped path in its own report even with RUST_LOG=error"
-
-# Gap 2: the AppWarning envelope (write_warnings, printed to stderr for verbs
-# like `ddb create`) is a DIFFERENT channel from the tracing output bound
-# above and in section 32. Commit a NEW poison file and make `ddb create` the
-# FIRST ddb invocation after that commit: the freshness reindex that surfaces
-# REINDEX_SKIPPED_FILES fires once per staleness, and section 32 already
-# consumed it for $poisonPath.
-$poisonPath2 = "ddb/29990101000001.md"
-@"
----
-: invalid yaml [
----
-body
-"@ | Set-Content -Path $poisonPath2 -NoNewline
-git -C $TMPDIR add -A
-git -C $TMPDIR commit -m "add second poison doogat" | Out-Null
-
-$createAfterPoisonErr = Join-Path $TMPDIR "create_after_poison.err"
-& $DDB create --title "After poison" --body "triggers freshness reindex" 2>$createAfterPoisonErr | Out-Null
-if ($LASTEXITCODE -ne 0) { throw "create after poison commit should succeed: $(Get-Content $createAfterPoisonErr -Raw)" }
-if ((Get-Content $createAfterPoisonErr -Raw) -notmatch "REINDEX_SKIPPED_FILES") {
-    throw "ddb create should surface REINDEX_SKIPPED_FILES AppWarning after a poison commit, got: $(Get-Content $createAfterPoisonErr -Raw)"
-}
-pass "ddb create surfaces REINDEX_SKIPPED_FILES AppWarning after a poison commit"
-
-Cleanup
-Write-Host "=== all smoke tests passed ==="

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


