
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/smoke.sh, original lines 673-769, segment 2/2. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
Section already in progress: tests/smoke.sh:671: DONE (pre-existing, no port needed); targets=alter_column_type::narrowing_rejects_with_row_count_message, alter_column_type::widens_varchar_to_text_and_accepts_longer_values
tests/smoke.sh:683: DONE; targets=alter_singleton::after_set_singleton_second_insert_rejects_with_constraint, smoke_sql::smoke_30_singleton_typedef_crud
tests/smoke.sh:700: DONE (pre-existing, no port needed); targets=schema_apply::apply_creates_declared_type, schema_apply::dry_run_prints_plan_and_creates_nothing, schema_apply::reapply_is_idempotent_noop
tests/smoke.sh:713: DONE; targets=poison_file_reindex::lenient_reindex_skips_poison_file_and_indexes_the_rest, poison_file_reindex::strict_reindex_fails_and_names_the_poison_file, smoke_resilience::smoke_32_cli_answers_after_strict_abort
tests/smoke.sh:743: DONE; targets=smoke_resilience::smoke_33_reindex_report_and_create_warning

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/smoke.sh b/tests/smoke.sh
deleted file mode 100755
index 6584e5c..0000000
--- a/tests/smoke.sh
+++ /dev/null
@@ -673,97 +0,0 @@
-SMOKE_AT_ID=$($DDB query "INSERT INTO alter_type_smoke (title, url) VALUES ('start', '1234567890')")
-echo "$SMOKE_AT_ID" | grep -qE "^[0-9]{14}$"
-$DDB query "ALTER TABLE alter_type_smoke ALTER COLUMN url TYPE TEXT" >/dev/null
-LONG_URL=$(printf 'x%.0s' $(seq 1 500))
-sleep 1
-SMOKE_AT_ID2=$($DDB query "INSERT INTO alter_type_smoke (title, url) VALUES ('post', '$LONG_URL')")
-echo "$SMOKE_AT_ID2" | grep -qE "^[0-9]{14}$"
-$DDB query "SELECT id FROM alter_type_smoke" | grep -q "$SMOKE_AT_ID2"
-pass "ALTER TABLE ALTER COLUMN TYPE widening (VARCHAR -> TEXT)"
-
-# 30. SINGLETON typedef CRUD (PRD 00139)
-$DDB query "CREATE TABLE smoke_singleton (theme TEXT) SINGLETON" | grep -q "table smoke_singleton created"
-SS_ID=$($DDB query "INSERT INTO smoke_singleton (title, theme) VALUES ('cfg', 'dark')")
-echo "$SS_ID" | grep -qE "^[0-9]{14}$"
-# Capture stderr of the failing second INSERT. `|| true` keeps set -e happy;
-# the grep below asserts the structured SINGLETON_VIOLATION code surfaces.
-SS_DUP=$($DDB query "INSERT INTO smoke_singleton (title, theme) VALUES ('cfg2', 'light')" 2>&1 || true)
-# CLI surfaces the human-readable message ("SINGLETON constraint violated: ...");
-# the structured `SINGLETON_VIOLATION` code only appears via GraphQL
-# `extensions.code` (covered by integration.sh §A in T20).
-echo "$SS_DUP" | grep -q "SINGLETON constraint"
-# UPDATE the existing singleton row still works after the rejected duplicate.
-$DDB query "UPDATE smoke_singleton SET theme = 'auto' WHERE id = '$SS_ID'" | grep -q "1 row(s) affected"
-$DDB query "SELECT theme FROM smoke_singleton WHERE id = '$SS_ID'" | grep -q "auto"
-$DDB query "DROP TABLE smoke_singleton CASCADE" | grep -q "dropped"
-pass "SINGLETON typedef: first INSERT, second rejects, UPDATE survives (PRD 00139)"
-
-# 31. declarative schema apply/diff (PRD 00161)
-printf 'types:\n  - name: smoke_widget\n    columns:\n      - name: wlabel\n        data_type: VARCHAR(255)\n        zone: frontmatter\n        required: true\n' > "$TMPDIR/smoke_schema.yaml"
-# Dry-run prints a create_type plan naming the declared column; mutates nothing.
-$DDB schema apply "$TMPDIR/smoke_schema.yaml" --dry-run | grep -q "create_type"
-$DDB schema apply "$TMPDIR/smoke_schema.yaml" --dry-run | grep -q "CREATE TABLE"
-! $DDB query "SELECT wlabel FROM smoke_widget" 2>/dev/null
-# Real apply creates the type; the column is queryable afterwards.
-$DDB schema apply "$TMPDIR/smoke_schema.yaml" >/dev/null
-$DDB query "SELECT wlabel FROM smoke_widget" >/dev/null
-# Re-apply is a converged no-op (no create/add/drop op).
-$DDB schema apply "$TMPDIR/smoke_schema.yaml" | grep -qv "create_type"
-pass "schema apply/diff: dry-run plan, real create, idempotent re-apply (PRD 00161)"
-
-# 32. poison-file reindex resilience (PRD 00169)
-POISON_PATH="ddb/29990101000000.md"
-printf '%s\n' '---' ': invalid yaml [' '---' 'body' > "$POISON_PATH"
-git -C "$TMPDIR" add -A && git -C "$TMPDIR" commit -m "add poison doogat" >/dev/null
-
-REINDEX_OUTPUT=$($DDB reindex 2>&1)
-echo "$REINDEX_OUTPUT" | grep -q "$POISON_PATH"
-pass "lenient reindex skips poison file and names its path"
-
-# Capture the exit code explicitly rather than using `! $DDB ...`: bash exempts
-# a `!`-inverted command from errexit, so a `--strict` that regressed to lenient
-# (exit 0) would NOT stop the script here, and the grep below would still match
-# the poison path in stderr — the warning is logged either way. That combination
-# would print a passing "strict reindex fails" line for a broken --strict.
-STRICT_RC=0
-$DDB reindex --strict >/dev/null 2>"$TMPDIR/reindex_strict.err" || STRICT_RC=$?
-[ "$STRICT_RC" -ne 0 ]
-grep -q "$POISON_PATH" "$TMPDIR/reindex_strict.err"
-pass "strict reindex fails and names the poison path"
-
-# NOTE: this asserts the CLI stays usable after a strict abort, NOT that the
-# abort was non-destructive. `ddb query` calls `ensure_fresh` (service/sql.rs),
-# which would silently rebuild a dropped index before answering, so this check
-# cannot fail on the wipe-then-error scenario. The non-destructive property is
-# bound properly at unit level by
-# `indexer::tests::rebuild_strict_aborting_leaves_previously_indexed_rows_intact`.
-# Do not relabel this as an index-preservation check.
-$DDB query "SELECT id FROM doogats WHERE id = '$ID1'" | grep -q "$ID1"
-pass "cli still answers queries after a strict reindex abort"
-
-# 33. reindex report + ddb create AppWarning surface skipped files (PRD 00169 gap closure)
-
-# Gap 1: `ddb reindex`'s OWN report (the outln! lines, not the tracing
-# subscriber on stderr) must name skipped paths. With RUST_LOG=error the
-# tracing channel is silenced, so this binds the command's own report output,
-# not the channel section 32 binds. Written fail-first: against the pre-fix
-# binary reindex() printed only "indexed N doogats" / "N warning(s)" and this
-# assertion failed; the per-warning lines it now binds ship in the same change.
-QUIET_REINDEX_OUTPUT=$(RUST_LOG=error $DDB reindex 2>&1)
-echo "$QUIET_REINDEX_OUTPUT" | grep -q "$POISON_PATH"
-pass "reindex names skipped path in its own report even with RUST_LOG=error"
-
-# Gap 2: the AppWarning envelope (write_warnings, printed to stderr for verbs
-# like `ddb create`) is a DIFFERENT channel from the tracing output bound
-# above and in section 32. Commit a NEW poison file and make `ddb create` the
-# FIRST ddb invocation after that commit: the freshness reindex that surfaces
-# REINDEX_SKIPPED_FILES fires once per staleness, and section 32 already
-# consumed it for $POISON_PATH.
-POISON_PATH2="ddb/29990101000001.md"
-printf '%s\n' '---' ': invalid yaml [' '---' 'body' > "$POISON_PATH2"
-git -C "$TMPDIR" add -A && git -C "$TMPDIR" commit -m "add second poison doogat" >/dev/null
-
-$DDB create --title "After poison" --body "triggers freshness reindex" >/dev/null 2>"$TMPDIR/create_after_poison.err"
-grep -q "REINDEX_SKIPPED_FILES" "$TMPDIR/create_after_poison.err"
-pass "ddb create surfaces REINDEX_SKIPPED_FILES AppWarning after a poison commit"
-
-echo "=== all smoke tests passed ==="

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


