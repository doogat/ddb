
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references

Description:
Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

Partition context:
This partition is the complete deletion patch for tests/smoke.ps1, original lines 1-635, segment 1/2. The file is deleted in full; other segments are reviewed separately. No source line is omitted across the partitions. Hunk range is adjusted to make this segment independently locatable. Do not interpret a segment boundary as a surviving file or missing setup.

The previously audited source-to-runner mapping rows overlapping this segment are:
tests/smoke.ps1:66: DONE; targets=smoke_core::smoke_01_init
tests/smoke.ps1:70: DONE; targets=; aliases=['tests/smoke.sh:30']
tests/smoke.ps1:87: DONE; targets=; aliases=['tests/smoke.sh:42']
tests/smoke.ps1:92: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:47']
tests/smoke.ps1:98: DONE; targets=; aliases=['tests/smoke.sh:52']
tests/smoke.ps1:104: DONE; targets=; aliases=['tests/smoke.sh:58']
tests/smoke.ps1:109: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:62']
tests/smoke.ps1:122: DONE; targets=; aliases=['tests/smoke.sh:73']
tests/smoke.ps1:127: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:77']
tests/smoke.ps1:134: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:83']
tests/smoke.ps1:141: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:89']
tests/smoke.ps1:151: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:100']
tests/smoke.ps1:156: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:104']
tests/smoke.ps1:161: DONE; targets=; aliases=['tests/smoke.sh:108']
tests/smoke.ps1:168: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:113']
tests/smoke.ps1:173: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:117']
tests/smoke.ps1:184: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:128']
tests/smoke.ps1:193: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:136']
tests/smoke.ps1:209: DONE; targets=; aliases=['tests/smoke.sh:146']
tests/smoke.ps1:226: DONE; targets=; aliases=['tests/smoke.sh:160']
tests/smoke.ps1:241: DONE; targets=; aliases=['tests/smoke.sh:170']
tests/smoke.ps1:250: DONE; targets=; aliases=['tests/smoke.sh:176']
tests/smoke.ps1:259: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:182']
tests/smoke.ps1:275: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:193']
tests/smoke.ps1:291: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:204']
tests/smoke.ps1:301: DONE; targets=; aliases=['tests/smoke.sh:211']
tests/smoke.ps1:306: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:215']
tests/smoke.ps1:316: DONE; targets=; aliases=['tests/smoke.sh:222']
tests/smoke.ps1:322: DONE; targets=; aliases=['tests/smoke.sh:227']
tests/smoke.ps1:334: DONE; targets=; aliases=['tests/smoke.sh:237']
tests/smoke.ps1:342: DONE; targets=; aliases=['tests/smoke.sh:243']
tests/smoke.ps1:348: DONE; targets=; aliases=['tests/smoke.sh:249']
tests/smoke.ps1:355: DONE; targets=; aliases=['tests/smoke.sh:259']
tests/smoke.ps1:363: DONE; targets=; aliases=['tests/smoke.sh:267']
tests/smoke.ps1:382: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:283']
tests/smoke.ps1:409: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:305']
tests/smoke.ps1:430: DONE; targets=; aliases=['tests/smoke.sh:321']
tests/smoke.ps1:531: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:418']
tests/smoke.ps1:554: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:441']
tests/smoke.ps1:581: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:465']
tests/smoke.ps1:600: DONE (pre-existing, no port needed); targets=; aliases=['tests/smoke.sh:485']
tests/smoke.ps1:627: DONE; targets=; aliases=['tests/smoke.sh:511']

Acceptance criteria:
No live retired-script references; preserved jink-feedback instructions; replacement tests unchanged apart from provenance comments; complete Rust e2e baseline passes; green exact-revision replacement CI before deletion and follow-up push CI after deletion. This is build-time per-task review only; full PRD acceptance remains for a fresh review session.

## Diff under review

```diff
diff --git a/tests/smoke.ps1 b/tests/smoke.ps1
deleted file mode 100644
index 188f1ed..0000000
--- a/tests/smoke.ps1
+++ /dev/null
@@ -1,635 +0,0 @@
-#!/usr/bin/env pwsh
-
-# Smoke test: fast CLI validation (init, CRUD, search, SQL, types, compact).
-# For full integration tests (server, sync, CRDT), run tests/integration.ps1.
-
-$ErrorActionPreference = "Stop"
-
-# Build when DDB_BIN is not injected.
-$prepLabel = "prebuilt binary"
-if (-not $env:DDB_BIN) {
-    cargo build --quiet
-    $prepLabel = "build"
-}
-
-if ($env:DDB_BIN) {
-    $DDB = $env:DDB_BIN
-} else {
-    $meta = cargo metadata --format-version=1 --no-deps | ConvertFrom-Json
-    $DDB = Join-Path $meta.target_directory "debug" "ddb.exe"
-}
-
-# Work in temp directories, clean up on exit
-function New-TempDir {
-    $p = Join-Path ([System.IO.Path]::GetTempPath()) ([System.IO.Path]::GetRandomFileName())
-    New-Item -ItemType Directory -Path $p | Out-Null
-    return $p
-}
-
-$TMPDIR = New-TempDir
-
-function Cleanup {
-    # On CI, skip cleanup — the runner wipes the workspace. Local Remove-Item on
-    # Windows git repos can hang for minutes due to file locks and antivirus scans.
-    if ($env:CI) { return }
-    if (Test-Path $TMPDIR) { Remove-Item -Recurse -Force $TMPDIR -ErrorAction SilentlyContinue }
-}
-
-trap { Cleanup }
-
-Push-Location $TMPDIR
-
-function pass($msg) { Write-Host "  ✓ $msg" }
-
-function ddb {
-    $raw = & $DDB @args 2>&1
-    # Filter out tracing log lines that leak from stderr via 2>&1 on Windows.
-    # ErrorRecord objects from stderr may contain ANSI escapes, so strip those
-    # before matching the timestamp pattern.
-    $lines = @($raw) | ForEach-Object { "$_" -replace '\x1b\[[0-9;]*m', '' } |
-        Where-Object { $_ -notmatch '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}' -and $_ -ne '' }
-    $text = [string]::Join("`n", @($lines))
-    if ($LASTEXITCODE -ne 0) { throw "ddb $($args -join ' ') failed: $text" }
-    return $text
-}
-
-# Expect failure: returns true if command fails
-function ddb-fails {
-    & $DDB @args 2>&1 | Out-Null
-    return ($LASTEXITCODE -ne 0)
-}
-
-Write-Host "=== smoke test ==="
-
-pass $prepLabel
-
-# 1. init
-ddb init . | Out-Null
-pass "init"
-
-# 2. create doogats
-$ID1 = ddb create --title "First note" --tags "test,smoke" --body "Hello world"
-$ID2 = ddb create --title "Links to first" --body "See [[$ID1]]"
-# ID3 uses an unregistered type (`project`, no `ddb type install`). PRD 00155
-# restores the lenient base-only create and emits an UNREGISTERED_TYPE_BASE_ONLY
-# warning on stderr. Bypass the `ddb` wrapper (it folds stderr into stdout and
-# would merge the warning into the id); capture stderr to a file instead.
-$createErr = Join-Path $TMPDIR "create_unregistered.err"
-$ID3 = "$(& $DDB create --title "Project Alpha" --type project --tags "active" --body "A project doogat" 2>$createErr)".Trim()
-if ($LASTEXITCODE -ne 0) { throw "create --type project (unregistered) should succeed: $(Get-Content $createErr -Raw)" }
-if ($ID1 -eq $ID2 -or $ID2 -eq $ID3 -or $ID1 -eq $ID3) { throw "IDs not unique" }
-pass "create (3 unique IDs: $ID1 $ID2 $ID3)"
-if ((Get-Content $createErr -Raw) -notmatch "UNREGISTERED_TYPE_BASE_ONLY") {
-    throw "create --type <unregistered> should warn UNREGISTERED_TYPE_BASE_ONLY, got: $(Get-Content $createErr -Raw)"
-}
-pass "create --type <unregistered> warns UNREGISTERED_TYPE_BASE_ONLY (PRD 00155 base-only create restored)"
-
-# 3. read
-$output = ddb read $ID1
-if ($output -notmatch "First note") { throw "read failed" }
-pass "read"
-
-# 4. update
-ddb update $ID1 --title "First note (edited)" --tags "test,smoke,updated"
-$output = ddb read $ID1
-if ($output -notmatch "First note \(edited\)") { throw "update failed" }
-pass "update"
-
-# 5. delete
-ddb delete $ID3
-if (-not (ddb-fails read $ID3)) { throw "read after delete should fail" }
-if (-not (ddb-fails delete "99999999999999")) { throw "delete nonexistent should fail" }
-pass "delete"
-
-# 6. status
-$output = ddb status
-if ($output -notmatch "^head:") { throw "status missing head" }
-pass "status"
-
-# 6b. broken backlink report on delete
-$BL_TARGET = ddb create --title "Backlink Target" --body "I will be deleted"
-Start-Sleep -Seconds 1
-$BL_SOURCE = ddb create --title "Backlink Source" --body "See [[$BL_TARGET]]"
-ddb reindex | Out-Null
-$output = ddb delete $BL_TARGET
-if ($output -notmatch "broken backlinks") { throw "delete missing broken backlink report" }
-$output = ddb status
-if ($output -notmatch "broken backlinks") { throw "status missing broken backlinks" }
-# Clean up: delete source so broken backlinks don't affect later tests
-ddb delete $BL_SOURCE | Out-Null
-pass "broken backlink report on delete"
-
-# 7. reindex
-$output = ddb reindex
-if ($output -notmatch "indexed 2 doogats") { throw "reindex count wrong" }
-pass "reindex"
-
-# 7b. hashtag extraction
-ddb update $ID1 --body "Updated with #gtd/act/next hashtag"
-ddb reindex | Out-Null
-$output = ddb query "SELECT tag, source FROM _ddb_tags WHERE tag = 'gtd/act/next'"
-if ($output -notmatch "body") { throw "hashtag not indexed" }
-pass "hashtag extraction and indexing"
-
-# 7c. checkbox parsing
-ddb update $ID1 --body "- [ ] open task`n- [x] done task`n- [i] 2026-01-01 10:00 - info note"
-ddb reindex | Out-Null
-$output = ddb query "SELECT state, content FROM _ddb_checkboxes WHERE state = 'open'"
-if ($output -notmatch "open task") { throw "checkbox not indexed" }
-pass "checkbox parsing and indexing"
-
-# 7d. folder namespace
-& $DDB query "CREATE TABLE widget (color TEXT)" | Out-Null
-$widgetTypedef = Get-ChildItem "$TMPDIR/ddb/_typedef/*.md" | Where-Object { (Get-Content $_) -match "title: widget" } | Select-Object -First 1
-(Get-Content $widgetTypedef.FullName -Raw) -replace "type: _typedef", "type: _typedef`nfolder: true" | Set-Content $widgetTypedef.FullName
-git -C $TMPDIR add -A 2>$null; git -C $TMPDIR commit -m "add folder to widget" 2>$null | Out-Null
-& $DDB reindex | Out-Null
-$widgetId = (& $DDB query "INSERT INTO widget (color) VALUES ('red')").Trim()
-if (-not (Test-Path "$TMPDIR/ddb/widget/$widgetId.md")) { throw "folder namespace: file not in subdirectory" }
-pass "folder namespace: typed doogat in subdirectory"
-
-# 8. full-text search
-$output = ddb search "First note"
-if ($output -notmatch $ID1) { throw "search failed" }
-pass "search"
-
-# 8b. paginated search
-$output = ddb search "First note" --limit 1 --offset 0
-if ($output -notmatch "Showing 1-1 of") { throw "paginated search failed" }
-pass "paginated search"
-
-# 9. SQL queries
-$output = ddb query "SELECT id, title FROM doogats"
-if ($output -notmatch "First note \(edited\)") { throw "sql select failed" }
-$output = ddb query "SELECT z.id, z.title FROM doogats z JOIN _ddb_tags t ON t.doogat_id = z.id WHERE t.tag LIKE '%smoke%'"
-if ($output -notmatch $ID1) { throw "sql join failed" }
-pass "sql queries"
-
-# 10. wikilinks
-$output = ddb query "SELECT * FROM _ddb_links"
-if ($output -notmatch $ID1) { throw "wikilinks failed" }
-pass "wikilinks"
-
-# 10a. link kinds (wikilink, markdown, embed, bare_url)
-$lkBody = "See [[$ID1]] wiki.`n[md link](target.md)`n![[$ID2]]`nhttps://example.com"
-$LK_ID = ddb create --title "Link Kinds" --body $lkBody
-ddb reindex | Out-Null
-$lkOut = ddb query "SELECT kind FROM _ddb_links WHERE source_id = '$LK_ID' ORDER BY kind"
-if ($lkOut -notmatch "\burl\b") { throw "url kind missing" }
-if ($lkOut -notmatch "embed") { throw "embed kind missing" }
-if ($lkOut -notmatch "markdown") { throw "markdown kind missing" }
-if ($lkOut -notmatch "wikilink") { throw "wikilink kind missing" }
-pass "link kinds (4 types indexed)"
-
-# 10b. rename with backlink rewrite
-$RENAME_TARGET = ddb create --title "Rename Target" --body "I will move."
-ddb create --title "Rename Linker" --body "See [[$RENAME_TARGET|Target]]." | Out-Null
-ddb reindex | Out-Null
-$output = ddb rename $RENAME_TARGET "ddb/contact/${RENAME_TARGET}.md"
-if ($output -notmatch "1 backlinks updated") { throw "rename failed" }
-if (-not (Test-Path "ddb/contact/${RENAME_TARGET}.md")) { throw "renamed file missing" }
-pass "rename with backlink rewrite"
-
-# 11. SQL DDL/DML
-$output = ddb query "CREATE TABLE foo (bar TEXT, baz INTEGER)"
-if ($output -notmatch "table foo created") { throw "create table failed" }
-$FOO_ID = ddb query "INSERT INTO foo (title, bar, baz) VALUES ('test row', 'hello', 42)"
-if ($FOO_ID -is [array]) { Write-Host "DEBUG: FOO_ID is array with $($FOO_ID.Count) elements: $($FOO_ID -join '|')"; $FOO_ID = $FOO_ID[-1] }
-if ($FOO_ID -notmatch "^\d{14}$") { throw "insert returned bad id: [$FOO_ID] (type=$($FOO_ID.GetType().Name))" }
-$output = ddb query "SELECT bar, baz FROM foo"
-if ($output -notmatch "hello") { throw "select from foo failed" }
-$output = ddb query "UPDATE foo SET baz = 99 WHERE id = '$FOO_ID'"
-if ($output -notmatch "1 row\(s\) affected") { throw "update failed" }
-$output = ddb query "SELECT baz FROM foo WHERE id = '$FOO_ID'"
-if ($output -notmatch "99") { throw "select after update failed" }
-$output = ddb query "DELETE FROM foo WHERE id = '$FOO_ID'"
-if ($output -notmatch "1 row\(s\) affected") { throw "delete failed" }
-pass "sql ddl/dml"
-
-# 11c. Ghost-row + cross-mutation recovery pin (PRD 00124 group A1, issue #4).
-$output = ddb query "CREATE TABLE smokeghost (name TEXT, UNIQUE(name))"
-if ($output -notmatch "table smokeghost created") { throw "smokeghost create failed" }
-$SG_ID = ddb query "INSERT INTO smokeghost (title, name) VALUES ('first', 'uq_a')"
-if ($SG_ID -is [array]) { $SG_ID = $SG_ID[-1] }
-if ($SG_ID -notmatch "^\d{14}$") { throw "smokeghost insert returned bad id: [$SG_ID]" }
-$dup = & $DDB query "INSERT INTO smokeghost (title, name) VALUES ('dup', 'uq_a')" 2>&1 | Out-String
-if ($LASTEXITCODE -eq 0) { throw "smokeghost duplicate should have failed, got: $dup" }
-if ($dup -notmatch "UNIQUE") { throw "smokeghost duplicate should error with UNIQUE, got: $dup" }
-$output = ddb query "UPDATE smokeghost SET title = 'recovered' WHERE id = '$SG_ID'"
-if ($output -notmatch "1 row\(s\) affected") { throw "smokeghost post-failure UPDATE failed: $output" }
-$output = ddb query "SELECT title FROM smokeghost WHERE id = '$SG_ID'"
-if ($output -notmatch "recovered") { throw "smokeghost SELECT returned unexpected: $output" }
-$output = ddb query "DROP TABLE smokeghost CASCADE"
-if ($output -notmatch "dropped") { throw "smokeghost DROP failed" }
-pass "smoke-ghost: UNIQUE rollback + cross-mutation recovery (issue #4 A1)"
-
-# 11d. JOIN works smoke pin (PRD 00124 group E1, issue #8 obsolete).
-$output = ddb query "CREATE TABLE smokelink (url TEXT)"
-if ($output -notmatch "table smokelink created") { throw "smokelink create failed" }
-$output = ddb query "CREATE TABLE smokenum (count INTEGER)"
-if ($output -notmatch "table smokenum created") { throw "smokenum create failed" }
-ddb query "INSERT INTO smokelink (title, url) VALUES ('a', 'https://a.com')" | Out-Null
-ddb query "INSERT INTO smokenum (title, count) VALUES ('a', 1)" | Out-Null
-$output = ddb query "SELECT l.title, n.count FROM smokelink l JOIN smokenum n ON l.title = n.title"
-if ($output -notmatch "a \| 1") { throw "smoke-join: expected 'a | 1', got: $output" }
-$output = ddb query "DROP TABLE smokelink CASCADE"
-if ($output -notmatch "dropped") { throw "smokelink DROP failed" }
-$output = ddb query "DROP TABLE smokenum CASCADE"
-if ($output -notmatch "dropped") { throw "smokenum DROP failed" }
-pass "smoke-join: SELECT ... JOIN returns joined rows (issue #8 obsolete)"
-
-# 11a. ALTER TABLE SET ZONE and TITLE TEMPLATE
-$output = ddb query "ALTER TABLE foo SET ZONE frontmatter FOR bar"
-if ($output -notmatch "zone set to frontmatter") { throw "SET ZONE failed" }
-$output = ddb query "ALTER TABLE foo SET TITLE TEMPLATE 'my-template'"
-if ($output -notmatch "title template set") { throw "SET TITLE TEMPLATE failed" }
-$output = ddb query "ALTER TABLE foo DROP TITLE TEMPLATE"
-if ($output -notmatch "title template dropped") { throw "DROP TITLE TEMPLATE failed" }
-pass "alter table zone overrides and title template"
-
-# 11b. CREATE TABLE IF NOT EXISTS (idempotent)
-$output = ddb query "CREATE TABLE IF NOT EXISTS foo (bar TEXT, baz INTEGER)"
-if ($output -notmatch "already exists") { throw "IF NOT EXISTS on existing table failed" }
-$output = ddb query "CREATE TABLE IF NOT EXISTS newifne (x TEXT)"
-if ($output -notmatch "table newifne created") { throw "IF NOT EXISTS new table failed" }
-$output = ddb query "CREATE TABLE IF NOT EXISTS newifne (x TEXT)"
-if ($output -notmatch "already exists") { throw "IF NOT EXISTS idempotent failed" }
-pass "create table if not exists (idempotent)"
-
-# 11e. ALTER TABLE RENAME TO (PRD 00132)
-$output = ddb query "CREATE TABLE smokerename_src (note TEXT)"
-if ($output -notmatch "table smokerename_src created") { throw "rename src create failed" }
-ddb query "INSERT INTO smokerename_src (title, note) VALUES ('hi', 'first')" | Out-Null
-$output = ddb query "ALTER TABLE smokerename_src RENAME TO smokerename_dst"
-if ($output -notmatch "renamed to smokerename_dst") { throw "rename to failed: $output" }
-$output = ddb query "SELECT count(*) FROM smokerename_dst"
-if ($output -notmatch "1") { throw "row count after rename failed: $output" }
-# Bypass the throwing `ddb` wrapper and call the binary directly so a non-zero
-# exit (the expected reserved-name rejection) doesn't abort the script.
-$output = (& $DDB query "ALTER TABLE smokerename_dst RENAME TO doogats" 2>&1 | Out-String)
-if ($output -notmatch "reserved") { throw "expected reserved-name rejection, got: $output" }
-$output = ddb query "DROP TABLE smokerename_dst CASCADE"
-if ($output -notmatch "dropped") { throw "rename cleanup drop failed" }
-pass "alter table rename to + reserved-name rejection"
-
-# 11f. Cross-process FK freshness on `ddb create` (PRD 00136, #16).
-# Each `ddb` call here spawns a fresh process. The second `ddb create`
-# must resolve the FK against the category created by the first call
-# WITHOUT an intermediate `ddb reindex` — that's the whole point of #16.
-# The `ddb` wrapper at the top of this file checks $LASTEXITCODE and
-# throws on non-zero exit, so a regression where the second `ddb create`
-# rejects with REFERENCES_VIOLATION aborts this script via the wrapper.
-$output = ddb query "CREATE TABLE smoke136cat (fqn VARCHAR(255))"
-if ($output -notmatch "table smoke136cat created") { throw "smoke136cat create failed" }
-$output = ddb query "CREATE TABLE smoke136link (url TEXT, category TEXT REFERENCES smoke136cat)"
-if ($output -notmatch "table smoke136link created") { throw "smoke136link create failed" }
-$SMOKE136_CAT = (ddb create --type smoke136cat --title "Cat 136" --set "fqn=test.fqn").Trim()
-if ($SMOKE136_CAT -notmatch '^\d{14}$') { throw "category id malformed: $SMOKE136_CAT" }
-ddb create --type smoke136link --title "Link 136" --set "url=https://a" --set "category=$SMOKE136_CAT" | Out-Null
-pass "cross-process FK freshness on ddb create (#16)"
-
-# 11g. Inline column ZONE at CREATE TABLE (PRD 00160)
-$output = ddb query "CREATE TABLE smokezone (summary TEXT ZONE frontmatter, body_note TEXT)"
-if ($output -notmatch "table smokezone created") { throw "inline zone create failed" }
-$SZ_ID = (ddb query "INSERT INTO smokezone (summary, body_note) VALUES ('recap', 'long notes')").Trim()
-$output = ddb read $SZ_ID
-if ($output -notmatch "summary: recap") { throw "inline zone did not materialize summary to frontmatter: $output" }
-$output = ddb query "DROP TABLE smokezone CASCADE"
-if ($output -notmatch "dropped") { throw "inline zone cleanup drop failed" }
-pass "inline column zone at create table (PRD 00160)"
-
-# 12. install bundled type
-$output = ddb type install contact
-if ($output -notmatch "installed type") { throw "type install failed" }
-pass "type install"
-
-# 12a. hyphenated type SQL (quoted identifiers)
-$output = ddb type install meeting-minutes
-if ($output -notmatch "installed type") { throw "meeting-minutes install failed" }
-$HYP_ID = (ddb query 'INSERT INTO "meeting-minutes" (date, attendees) VALUES (''2026-03-10'', ''alice,bob'')').Trim()
-$output = ddb query "SELECT date FROM `"meeting-minutes`" WHERE id = '$HYP_ID'"
-if ($output -notmatch "2026-03-10") { throw "hyphenated select failed" }
-$output = ddb query "DELETE FROM `"meeting-minutes`" WHERE id = '$HYP_ID'"
-if ($output -notmatch "1 row") { throw "hyphenated delete failed" }
-pass "hyphenated type sql (quoted identifiers)"
-
-# 13. type suggest
-ddb query "INSERT INTO foo (title, bar, baz) VALUES ('for suggest', 'val', 1)" | Out-Null
-$output = ddb type suggest foo
-if ($output -notmatch "bar") { throw "type suggest failed" }
-pass "type suggest"
-
-# 14. register node + compact
-$output = ddb register-node "smoke-test-laptop"
-if ($output -notmatch "registered node") { throw "register-node failed" }
-$output = ddb status
-if ($output -notmatch "registered nodes: 1") { throw "status missing node" }
-$output = ddb compact --force
-if ($output -notmatch "backup:") { throw "compact missing backup path" }
-if ($output -notmatch "gc: ok") { throw "compact failed" }
-if ($output -notmatch "crdt temp:") { throw "compact missing crdt temp stats" }
-if ($output -notmatch "repo \(\.git\):") { throw "compact missing repo stats" }
-pass "register-node + compact"
-
-# 15. node list + retire
-$output = ddb node list
-if ($output -notmatch "smoke-test-laptop") { throw "node list failed" }
-$NODE_UUID = (($output -split "\r?\n") | Select-String "smoke-test-laptop").ToString().Split()[0]
-$output = ddb node retire $NODE_UUID
-if ($output -notmatch "retired node") { throw "node retire failed" }
-pass "node list + retire"
-
-# 16. compact --dry-run
-$output = ddb compact --dry-run
-if ($output -notmatch "dry run") { throw "compact dry-run failed" }
-if ($output -notmatch "backup would write:") { throw "dry-run missing backup info" }
-pass "compact --dry-run"
-
-# 16a. compact --no-backup
-ddb register-node "no-backup-test" | Out-Null
-$output = ddb compact --no-backup --force
-if ($output -notmatch "gc: ok") { throw "compact --no-backup failed" }
-if ($output -match "backup:") { throw "--no-backup should suppress backup" }
-pass "compact --no-backup"
-
-# 16b. compact --backup-path
-$customBackup = Join-Path $env:TEMP "custom-backup.bundle.tar"
-$output = ddb compact --force --backup-path $customBackup
-if ($output -notmatch "backup:") { throw "compact --backup-path missing backup line" }
-if ($output -notmatch [regex]::Escape($customBackup)) { throw "compact --backup-path wrong path" }
-if (-not (Test-Path $customBackup)) { throw "custom backup file not created" }
-pass "compact --backup-path"
-
-# 16c. maintenance
-$output = ddb maintenance run
-if ($output -notmatch "maintenance:") { throw "maintenance run missing output" }
-pass "maintenance run"
-
-$output = ddb maintenance auto status
-if ($output -notmatch "off") { throw "maintenance auto status should default to off" }
-pass "maintenance auto status (default off)"
-
-ddb maintenance auto on | Out-Null
-$output = ddb maintenance auto status
-if ($output -notmatch "on") { throw "maintenance auto status should be on" }
-pass "maintenance auto on"
-
-ddb maintenance auto off | Out-Null
-$output = ddb maintenance auto status
-if ($output -notmatch "off") { throw "maintenance auto status should be off" }
-pass "maintenance auto off"
-
-# 16d. discover
-ddb discover stale | Out-Null
-pass "discover stale"
-
-$output = ddb discover orphans
-if ($output -notmatch "\d{14}") { throw "discover orphans returned nothing" }
-pass "discover orphans"
-
-# Create a doogat that mentions ID1's title without linking
-$MENTION_ID = ddb create --title "Review notes" --body "About First note (edited) topic"
-ddb reindex | Out-Null
-$output = ddb discover mentions $ID1
-if ($output -notmatch $MENTION_ID) { throw "discover mentions failed" }
-pass "discover mentions"
-
-$output = ddb discover similar $ID1
-if ($output -notmatch "\d{14}") { throw "discover similar returned nothing" }
-pass "discover similar"
-
-$output = ddb discover recent --days 30
-if ($output -notmatch $ID1) { throw "discover recent should include $ID1" }
-pass "discover recent"
-
-$output = ddb discover link-density
-if ($output -notmatch "density:") { throw "discover link-density output missing density:" }
-pass "discover link-density"
-
-# 16e. consistency fix
-$FIX_ID = ddb create --title "Fix Test" --tags "#gtd,zebra,apple"
-$beforeHead = git rev-parse HEAD
-$fixDry = ddb fix --dry-run
-if ($fixDry -notmatch "would fix") { throw "dry run should report fixes" }
-$afterHead = git rev-parse HEAD
-if ($beforeHead -ne $afterHead) { throw "dry run should not commit" }
-pass "fix dry-run"
-
-$fixApply = ddb fix
-if ($fixApply -notmatch "fixed") { throw "fix should report applied" }
-pass "fix apply"
-
-$fixAgain = ddb fix
-if ($fixAgain -notmatch "no issues") { throw "second fix should find nothing" }
-pass "fix idempotent"
-
-$fixContent = ddb read $FIX_ID
-if ($fixContent -notmatch "  - apple") { throw "tags should be sorted" }
-pass "fix result verified"
-
-# 16f. sequence navigation
-$SEQ_ROOT = ddb create --title "Seq Root"
-$SEQ_CHILD1 = ddb create --title "Seq Child 1"
-$SEQ_CHILD1_PATH = "ddb/$SEQ_CHILD1.md"
-@"
----
-id: $SEQ_CHILD1
-title: Seq Child 1
-sequence: $SEQ_ROOT
----
-
-"@ | Set-Content -Path $SEQ_CHILD1_PATH -NoNewline
-git add $SEQ_CHILD1_PATH
-git commit -m "add sequence field" --quiet
-
-$SEQ_CHILD2 = ddb create --title "Seq Child 2"
-$SEQ_CHILD2_PATH = "ddb/$SEQ_CHILD2.md"
-@"
----
-id: $SEQ_CHILD2
-title: Seq Child 2
-sequence: $SEQ_ROOT
----
-
-"@ | Set-Content -Path $SEQ_CHILD2_PATH -NoNewline
-git add $SEQ_CHILD2_PATH
-git commit -m "add sequence field" --quiet
-
-ddb reindex | Out-Null
-$output = ddb sequence tree $SEQ_ROOT
-if ($output -notmatch $SEQ_CHILD1) { throw "sequence tree missing child" }
-pass "sequence tree"
-
-$output = ddb sequence breadcrumb $SEQ_CHILD1
-if ($output -notmatch $SEQ_ROOT) { throw "sequence breadcrumb missing root" }
-pass "sequence breadcrumb"
-
-$SEQ_BROKEN = ddb create --title "Seq Broken"
-$SEQ_BROKEN_PATH = "ddb/$SEQ_BROKEN.md"
-@"
----
-id: $SEQ_BROKEN
-title: Seq Broken
-sequence: "99999999999999"
----
-
-"@ | Set-Content -Path $SEQ_BROKEN_PATH -NoNewline
-git add $SEQ_BROKEN_PATH
-git commit -m "broken sequence ref" --quiet
-ddb reindex | Out-Null
-$output = ddb sequence broken
-if ($output -notmatch "not found") { throw "sequence broken not detected" }
-pass "sequence broken"
-
-# --log-level flag accepted
-ddb --log-level debug status *>$null
-pass "--log-level flag accepted"
-
-# app-building end-to-end flow
-$output = ddb query "CREATE TABLE abcategory (name VARCHAR(100), priority ENUM('low','medium','high'))"
-if ($output -notmatch "table abcategory created") { throw "create abcategory failed" }
-$AB_CAT_ID = ddb query "INSERT INTO abcategory (name, priority) VALUES ('work', 'high')"
-if ($AB_CAT_ID -notmatch "^\d{14}$") { throw "insert abcategory bad id: $AB_CAT_ID" }
-$output = ddb query "CREATE TABLE abbookmark (url VARCHAR(2048), description TEXT, abcategory TEXT REFERENCES abcategory)"
-if ($output -notmatch "table abbookmark created") { throw "create abbookmark failed" }
-$output = ddb query "ALTER TABLE abbookmark SET ZONE reference FOR url"
-if ($output -notmatch "zone set to reference") { throw "SET ZONE failed" }
-$output = ddb query "ALTER TABLE abbookmark SET TITLE TEMPLATE '{url}'"
-if ($output -notmatch "title template set") { throw "SET TITLE TEMPLATE failed" }
-# Insert with explicit title
-Start-Sleep -Seconds 1
-$AB_BM1 = ddb query "INSERT INTO abbookmark (title, url, description) VALUES ('Rust Book', 'https://doc.rust-lang.org', 'The official Rust book')"
-if ($AB_BM1 -notmatch "^\d{14}$") { throw "insert bookmark1 bad id: $AB_BM1" }
-# Insert with template-derived title (no explicit title)
-Start-Sleep -Seconds 1
-$AB_BM2 = ddb query "INSERT INTO abbookmark (url, description) VALUES ('https://crates.io', 'Rust package registry')"
-if ($AB_BM2 -notmatch "^\d{14}$") { throw "insert bookmark2 bad id: $AB_BM2" }
-# Link both bookmarks to category via junction table
-$output = ddb query "INSERT INTO abbookmark_abcategory (abbookmark_id, abcategory_id) VALUES ('$AB_BM1', '$AB_CAT_ID')"
-if ($output -notmatch "1 row") { throw "junction insert bm1 failed: $output" }
-$output = ddb query "INSERT INTO abbookmark_abcategory (abbookmark_id, abcategory_id) VALUES ('$AB_BM2', '$AB_CAT_ID')"
-if ($output -notmatch "1 row") { throw "junction insert bm2 failed: $output" }
-# SELECT from main table
-$output = ddb query "SELECT url FROM abbookmark"
-if ($output -notmatch "rust-lang") { throw "select bookmark failed" }
-# SELECT from junction table — both bookmarks linked
-$output = ddb query "SELECT COUNT(*) FROM abbookmark_abcategory"
-if ($output -notmatch "2") { throw "junction count wrong: $output" }
-# Verify ENUM allowed_values stored in typedef
-$output = ddb query "SELECT priority FROM abcategory"
-if ($output -notmatch "high") { throw "ENUM priority not stored: $output" }
-# help create-app guide available
-$output = ddb help create-app
-if ($output -notmatch "CREATE TABLE") { throw "help create-app failed" }
-# Clean up
-$output = ddb query "DROP TABLE abbookmark CASCADE"
-if ($output -notmatch "dropped") { throw "drop abbookmark failed" }
-$output = ddb query "DROP TABLE abcategory CASCADE"
-if ($output -notmatch "dropped") { throw "drop abcategory failed" }
-pass "app-building end-to-end flow"
-
-# 17. cascade delete
-ddb query "CREATE TABLE cdcategory (label VARCHAR(100))" | Out-Null
-ddb query "CREATE TABLE cdbookmark (url TEXT, cdcategory TEXT REFERENCES cdcategory)" | Out-Null
-$CAT_ID = ddb query "INSERT INTO cdcategory (label) VALUES ('work')"
-Start-Sleep -Seconds 1
-$BM_ID = ddb query "INSERT INTO cdbookmark (url) VALUES ('https://example.com')"
-ddb query "INSERT INTO cdbookmark_cdcategory (cdbookmark_id, cdcategory_id) VALUES ('$BM_ID', '$CAT_ID')" | Out-Null
-# Verify junction row exists
-$output = ddb query "SELECT COUNT(*) FROM cdbookmark_cdcategory WHERE cdcategory_id = '$CAT_ID'"
-if ($output -notmatch "1") { throw "junction row not created" }
-# Delete the category — should cascade
-ddb query "DELETE FROM cdcategory WHERE id = '$CAT_ID'" | Out-Null
-# Junction row should be gone
-$output = ddb query "SELECT COUNT(*) FROM cdbookmark_cdcategory WHERE cdcategory_id = '$CAT_ID'"
-if ($output -notmatch "0") { throw "junction row not cascaded: $output" }
-# Wikilink to deleted category should be removed from bookmark
-$output = ddb read $BM_ID
-if ($output -match "\[\[$CAT_ID\]\]") { throw "wikilink to deleted category still present in bookmark" }
-# Clean up
-ddb query "DROP TABLE cdbookmark CASCADE" | Out-Null
-ddb query "DROP TABLE cdcategory CASCADE" | Out-Null
-pass "cascade delete"
-
-# 17b. cascade delete (parent direction, PRD 00137)
-# Mirrors §17 but deletes the *owner* of the auto-junction row instead of
-# the referenced target. Pre-fix the junction row stayed dangling; post-fix
-# the same DELETE removes it in the same transaction. Junction is populated
-# end-to-end by setting the parent's REFERENCES column (auto-materialization
-# from PRD 00134) so the CLI surface exercises the same round-trip the unit
-# test pins.
-ddb query "CREATE TABLE pdc_cat (label VARCHAR(100))" | Out-Null
-ddb query "CREATE TABLE pdc_bm (url TEXT, pdc_cat TEXT REFERENCES pdc_cat)" | Out-Null
-$PDC_CAT_ID = ddb query "INSERT INTO pdc_cat (label) VALUES ('alpha')"
-Start-Sleep -Seconds 1
-$PDC_BM_ID = ddb query "INSERT INTO pdc_bm (url, pdc_cat) VALUES ('https://pdc.example.com', '$PDC_CAT_ID')"
-# Sanity: junction holds the owner-side row.
-$output = ddb query "SELECT COUNT(*) FROM pdc_bm_pdc_cat WHERE pdc_bm_id = '$PDC_BM_ID'"
-if ($output -notmatch "1") { throw "PRD 00137: junction row not created: $output" }
-# Delete the bookmark (parent direction).
-ddb query "DELETE FROM pdc_bm WHERE id = '$PDC_BM_ID'" | Out-Null
-# Owner-side junction row must be gone.
-$output = ddb query "SELECT COUNT(*) FROM pdc_bm_pdc_cat WHERE pdc_bm_id = '$PDC_BM_ID'"
-if ($output -notmatch "0") { throw "PRD 00137: owner-side junction not cascaded: $output" }
-# Whole junction empty (only row was the deleted parent's).
-$output = ddb query "SELECT COUNT(*) FROM pdc_bm_pdc_cat"
-if ($output -notmatch "0") { throw "PRD 00137: junction table not empty after parent delete: $output" }
-ddb query "DROP TABLE pdc_bm CASCADE" | Out-Null
-ddb query "DROP TABLE pdc_cat CASCADE" | Out-Null
-pass "PRD 00137: parent-delete clears owned auto-junction rows"
-
-# 18. cascade delete via ddb delete (service path)
-ddb query "CREATE TABLE cdcat2 (label VARCHAR(100))" | Out-Null
-ddb query "CREATE TABLE cdbm2 (url TEXT, cdcat2 TEXT REFERENCES cdcat2)" | Out-Null
-$CAT2_ID = ddb query "INSERT INTO cdcat2 (label) VALUES ('svc')"
-Start-Sleep -Seconds 1
-$BM2_ID = ddb query "INSERT INTO cdbm2 (url) VALUES ('https://svc.example.com')"
-ddb query "INSERT INTO cdbm2_cdcat2 (cdbm2_id, cdcat2_id) VALUES ('$BM2_ID', '$CAT2_ID')" | Out-Null
-# Delete via ddb delete (service path)
-ddb delete $CAT2_ID 2>$null
-# Junction row should be gone
-$output = ddb query "SELECT COUNT(*) FROM cdbm2_cdcat2 WHERE cdcat2_id = '$CAT2_ID'"
-if ($output -notmatch "0") { throw "junction row not cascaded (service path): $output" }
-# Wikilink removed from bookmark
-$output = ddb read $BM2_ID
-if ($output -match "\[\[$CAT2_ID\]\]") { throw "wikilink to deleted category still present (service path)" }
-ddb query "DROP TABLE cdbm2 CASCADE" | Out-Null
-ddb query "DROP TABLE cdcat2 CASCADE" | Out-Null
-pass "cascade delete (service path)"
-
-# 18b. RESTRICT on NOT NULL REFERENCES (#10)
-ddb query "CREATE TABLE r10link (url VARCHAR(255) NOT NULL)" | Out-Null
-ddb query "CREATE TABLE r10cat (name VARCHAR(255) NOT NULL)" | Out-Null
-ddb query 'CREATE TABLE "r10-mem" (link_id VARCHAR(255) NOT NULL REFERENCES r10link(id), cat_id VARCHAR(255) NOT NULL REFERENCES r10cat(id), UNIQUE(link_id, cat_id))' | Out-Null
-$R10_L = ddb query "INSERT INTO r10link (title, url) VALUES ('L', 'https://r10.example')"
-Start-Sleep -Seconds 1
-$R10_C = ddb query "INSERT INTO r10cat (title, name) VALUES ('C', 'c')"
-ddb query "INSERT INTO `"r10-mem`" (title, link_id, cat_id) VALUES ('M', '$R10_L', '$R10_C')" | Out-Null
-# SQL DELETE of parent must fail with the RESTRICT message
-$R10_ERR = & $DDB query "DELETE FROM r10link WHERE id = '$R10_L'" 2>&1
-if ($LASTEXITCODE -eq 0) { throw "DELETE of parent with NOT NULL REFERENCES child should have failed" }
-$R10_ERR_TEXT = [string]::Join("`n", (@($R10_ERR) | ForEach-Object { "$_" }))
-if ($R10_ERR_TEXT -notmatch "NOT NULL REFERENCES") { throw "expected RESTRICT error, got: $R10_ERR_TEXT" }
-if ($R10_ERR_TEXT -notmatch "r10-mem") { throw "expected blocking table name in error, got: $R10_ERR_TEXT" }
-# Parent still present
-$output = ddb query "SELECT COUNT(*) FROM r10link WHERE id = '$R10_L'"
-if ($output -notmatch "1") { throw "parent deleted despite RESTRICT: $output" }
-# `ddb delete` of parent must also fail
-if (-not (ddb-fails delete $R10_L)) { throw "ddb delete of parent with NOT NULL REFERENCES child should fail" }
-# After removing the child, parent delete succeeds
-ddb query "DELETE FROM `"r10-mem`" WHERE link_id = '$R10_L'" | Out-Null
-ddb query "DELETE FROM r10link WHERE id = '$R10_L'" | Out-Null
-ddb query "DROP TABLE `"r10-mem`" CASCADE" | Out-Null
-ddb query "DROP TABLE r10link CASCADE" | Out-Null
-ddb query "DROP TABLE r10cat CASCADE" | Out-Null
-pass "issue-10: RESTRICT blocks delete with NOT NULL REFERENCES child"
-
-# 19. boolean consistency in SQL responses
-ddb query "CREATE TABLE booltest (label TEXT, active BOOLEAN)" | Out-Null
-ddb query "INSERT INTO booltest (label, active) VALUES ('on', true)" | Out-Null
-Start-Sleep -Seconds 1
-ddb query "INSERT INTO booltest (label, active) VALUES ('off', false)" | Out-Null
-# Boolean true should be "true", not "1"
-$output = ddb query "SELECT active FROM booltest WHERE active = 1"
-if ($output -notmatch "true") { throw "boolean true not coerced: $output" }
-# Boolean false should be "false", not "0"

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Deletion revision c8b72bd9126c83d054264ce6ac3738e8f6d0abda, pushed master.

Pre-deletion gate at base5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4: FullValidation33991344845 completed success; all six jobs succeeded, including Linux e2e, macOS full and Windows full. Push Test33991275129 succeeded, including the replacement smoke_ step. Shell steps were already removed in that base revision. All391 Bash/PowerShell source rows were independently audited against original source assertions, registered target modules and565 runner-discovered test names; zero TODO rows. Task12's five patch reviews and two actual adversarial rounds completed, repairs committed and reverified before the green replacement CI. Mapping aliases denote equivalent pre-existing tests or fixture scaffolding, not silently skipped sections.

At deletion revision:
- cargo build: exit0, finished1m03s. No source edits occurred after this snapshot was committed during compilation.
- cargo build -p ddb-cli: exit0, finished0.15s.
- CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e: exit0; 565 passed;0 failed;0 ignored;0 measured;0 filtered out;53.60s test time,66.90s real. This is the actual full baseline run, not a focused subset or older CI result.
- git diff --check HEAD: exit0 before commit.
- All changed Rust additions/deletions are comment lines or whitespace; no Rust assertions or runtime tokens changed.
- Exact original jink-feedback trailing instructions in AGENTS remain byte-identical.
- All23 SQL scenario references resolve in actual runner discovery. Repo-wide rg with explicit root and hidden files finds no retired-script reference in live files; ignored historical dev/local artifacts excluded.
- Reflow tripwire exit0; no Python style/split candidates; self-deslop skipped by the net-negative change rule.

Post-deletion push Test34016441899 is running on exact deletion SHA. Task completion remains pending until it is green and final Clippy/test-ci and actual adversarial experiments finish. Those pending checks are not claimed as passed here. The four shell files are removed in full, with no survivors. The fresh full-PRD review will occur after build handoff; this is only the mandatory per-task patch review.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


