# Completed tasks — PRD 00171 (migrate shell scenarios to the Rust e2e crate)

All 16 tasks are `completed`. Tasks 1-14 are the original build plan (reviewed in
full during cycle 1, diff range `b1e7853..c8b72bd`). Tasks 15-16 are the cycle-1
decision-gate rework tasks — **these two are the subject of this incremental
cycle-2 review**.

| Task | Name | Tier | Implementor | Commit(s) |
|------|------|------|-------------|-----------|
| 1 | Build e2e mapping table: smoke.sh + smoke.ps1 sections | sonnet | claude | (cycle-1 range) |
| 2 | Build e2e mapping table: integration.sh sections | sonnet | claude | (cycle-1 range) |
| 3 | Build e2e mapping table: integration.ps1 sections | sonnet | claude | (cycle-1 range) |
| 4 | Verify ServerGuard spawn/health/teardown round-trip | haiku | claude | (cycle-1 range) |
| 5 | Port smoke.sh + smoke.ps1 sections to tests/e2e/smoke_*.rs | sonnet | codex | (cycle-1 range) |
| 6 | Port integration §17-20: GraphQL server setup, jink schema, expanded GraphQL ops, REST CRUD, PgWire basic | sonnet | codex | (cycle-1 range) |
| 7 | Port integration §37-38i: WebSocket auth, read-under-write, extended GraphQL ops | sonnet | claude | (cycle-1 range) |
| 8 | Port integration §42-45: base field filters, SQL INSERT+constraints, JOIN/auto-junction, DDL, createMany + ghost-row pins | sonnet | claude | (cycle-1 range) |
| 9 | Port integration §46-53: structured-error codes, ALTER TABLE RENAME across protocols, SINGLETON GraphQL flow | sonnet | claude | (cycle-1 range) |
| 10 | Port integration §56-60: REST/GraphQL warnings envelopes, update warning shape, REST typed create, typed where-filter completeness | sonnet | claude | (cycle-1 range) |
| 11 | Port integration Part B: sync/CRDT conflicts, bundle export/import, SQL schema evolution, ID minting, poison-file warnings | sonnet | claude | (cycle-1 range) |
| 12 | Port integration §54-55/61: PgWire/SINGLETON cross-protocol parity, SINGLETON write races, cross-process write-lock races | opus | codex | (cycle-1 range) |
| 13 | Rewire test.yml + full-validation.yml to run e2e replacements; dispatch manual full-validation | sonnet | qwen | (cycle-1 range) |
| 14 | Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references | opus | codex | (cycle-1 range) |
| **15** | **[D1] Restore complete per-push e2e coverage** | sonnet | orchestrator | **`103c8ab`** |
| **16** | **[D1] Restore exact scenario assertions and share existing test helpers** | sonnet | claude | **`74644b8`** |

## Cycle-1 rework scope (what tasks 15 and 16 were asked to fix)

Eight actionable findings from cycle 1:

1. **HIGH** — per-push CI coverage dropped: `test.yml`'s `Smoke test (e2e)` step
   ran only the 30 `smoke_*` tests of 565, but ~26 of smoke.sh's 56 sections had
   been mapped to pre-existing modules outside that filter. Fix: run the whole
   e2e suite per push; drop the redundant `--exact` steps and the obsolete
   `DDB_BIN` env; correct the AGENTS.md sentence. → task 15, commit `103c8ab`.
2. **MEDIUM** — §42 `totalCount` assertions dropped in `tests/e2e/serve.rs`.
3. **MEDIUM** — §44.E1 JOIN pin degraded to single-character containment in
   `tests/e2e/integration_junction_sync.rs`.
4. **MEDIUM** — §59.A cross-process read-back dropped in `tests/e2e/rest.rs`.
5. **MEDIUM** — §18d2 eq-exactness fixture lost in `tests/e2e/serve.rs`.
6. **MEDIUM** — §38b2b raw-scalar pin with multiple junction rows lost in
   `tests/e2e/reference_raw_id.rs`.
7. **MEDIUM** — §17.J2 numeric-id assertion weakened in
   `tests/e2e/integration_graphql_jink.rs`.
8. **LOW** — duplicated `stdout()` / 14-digit-id helpers across e2e modules;
   consolidate into `tests/e2e/common.rs`.

Findings 2-8 → task 16, commit `74644b8`.

## Concurrent, separately owned commits in the same history window

`dbc128f`, `bd3e7f0`, `4a248cb`, `876a153` were authored by a different live
session (the fast-track hazard lane). They are **not** PRD 00171 work and are
excluded from this review's migration diff. They remain relevant surrounding
code: `dbc128f` adds six ignored hazard regression tests (two of which are the
two `ignored` e2e tests visible in current CI output), and the other three are
production-code fixes in `ddb-core`.
