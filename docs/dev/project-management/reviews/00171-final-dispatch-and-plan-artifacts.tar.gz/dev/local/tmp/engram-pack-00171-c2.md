Portfolio freshness: NOT refreshed this cycle (PRD 00002 pending)

## Similar code

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-server/src/auth.rs:60-87
  mod tests {
    use super::*;

    #[test]
    fn validate_bearer_accepts_matching_token() {
        assert!(validate_bearer("Bearer secret123", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_wrong_token() {
        assert!(!validate_bearer("Bearer wrong", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_empty_string() {
        assert!(!validate_bearer("", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_missing_prefix() {
        assert!(!validate_bearer("secret123", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_lowercase_prefix() {
        assert!(!validate_bearer("bearer secret123", "secret123"));
    }
}

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/indexer/materialize.rs:1311-1352
  mod tests {
    use super::*;

    #[test]
    fn junction_table_name_joins_type_and_column() {
        assert_eq!(junction_table_name("link", "category"), "link_category");
    }

    #[test]
    fn junction_table_name_with_different_inputs() {
        assert_eq!(junction_table_name("project", "owner"), "project_owner");
    }

    #[test]
    fn junction_parent_id_column_appends_id_suffix() {
        assert_eq!(junction_parent_id_column("link"), "link_id");
    }

    #[test]
    fn junction_parent_id_column_with_different_type() {
        assert_eq!(junction_parent_id_column("project"), "project_id");
    }

    #[test]
    fn junction_ref_id_column_appends_id_suffix() {
        assert_eq!(junction_ref_id_column("category"), "category_id");
    }

    #[test]
    fn junction_ref_id_column_with_different_column() {
        assert_eq!(junction_ref_id_column("owner"), "owner_id");
    }

    #[test]
    fn junction_table_ddl_regression_output_preserved() {
        let ddl = junction_table_ddl("link", "category");
        assert_eq!(
            ddl,
            "CREATE TABLE IF NOT EXISTS \"link_category\" (\"link_id\" TEXT NOT NULL, \"category_id\" TEXT NOT NULL, PRIMARY KEY (\"link_id\", \"category_id\"))"
        );
    }
}

## Reuse precedent

- container-images:/Users/bob/git/src/github.com/buvis/container-images/apps/exchanger/frontend/tests/e2e.spec.ts:3-44
  test.describe('Exchanger E2E Tests', () => {
  test.beforeEach(async ({ page }) => {
    // Mock API responses - register specific routes before wildcards
    await page.route('**/api/health', async route => route.fulfill({ json: { status: 'ok' } }));
    await page.route('**/api/favorites', async route => route.fulfill({ json: [
      { provider: 'cnb', provider_symbol: 'EUR' },
      { provider: 'cnb', provider_symbol: 'USD' }
    ]}));
    await page.route('**/api/providers/status', async route => route.fulfill({ json: [
      { name: 'CNB', healthy: true, symbol_count: 10, symbol_counts_by_type: {} },
      { name: 'FCS', healthy: false, symbol_count: 0, symbol_counts_by_type: {} }
    ]}));
    await page.route('**/api/task_status', async route => route.fulfill({ json: {} }));
    await page.route('**/api/backups', async route => route.fulfill({ json: [] }));
    await page.route('**/api/symbols/list*', async route => route.fulfill({ json: [] }));
    await page.route('**/api/rates/coverage*', async route => route.fulfill({ json: {} }));
    await page.route('**/api/rates/missing*', async route => route.fulfill({ json: {} }));
    await page.route('**/api/rates/history*', async route => route.fulfill({ json: [] }));
    await page.route('**/api/rates/list*', async route => route.fulfill({ json: [] }));
    await page.route('**/api/rates*', async route => route.fulfill({ json: [] }));
  });

  test('Dashboard loads and health indicator is visible', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'System Status' })).toBeVisible();
    await expect(page.getByText('ok', { exact: true })).toBeVisible();
  });

  test('Rates page navigates and calendar picker exists', async ({ page }) => {
    await page.goto('/rates');
    await expect(page.getByRole('heading', { name: 'Rates Explorer' })).toBeVisible();
    // Verify calendar headers exist
    await expect(page.getByText('Su', { exact: true })).toBeVisible();
    await expect(page.getByText('Mo', { exact: true })).toBeVisible();
  });

  test('Admin page shows backfill form', async ({ page }) => {
    await page.goto('/admin');
    // Default tab shows backfill form
    await expect(page.getByRole('heading', { name: 'Trigger Backfill' })).toBeVisible();
  });
});

- gems:/Users/bob/git/src/github.com/buvis/gems/src/rust/src/parser/key_normalizer.rs:38-65
  mod tests {
    use super::*;

    #[test]
    fn test_simple_lowercase() {
        assert_eq!(as_note_field_name("title"), "title");
    }

    #[test]
    fn test_camel_case() {
        assert_eq!(as_note_field_name("SomeValue"), "some-value");
    }

    #[test]
    fn test_space_separated() {
        assert_eq!(as_note_field_name("Note Title"), "note-title");
    }

    #[test]
    fn test_already_kebab() {
        assert_eq!(as_note_field_name("some-value"), "some-value");
    }

    #[test]
    fn test_mixed() {
        assert_eq!(as_note_field_name("zkn-id"), "zkn-id");
    }
}

- claude-warden:/Users/bob/git/src/github.com/buvis/claude-warden/dist/cli.cjs:5095-5119
      function parsePrelude(prelude) {
      let comment = "";
      let atComment = false;
      let afterEmptyLine = false;
      for (let i = 0; i < prelude.length; ++i) {
        const source = prelude[i];
        switch (source[0]) {
          case "#":
            comment += (comment === "" ? "" : afterEmptyLine ? "\n\n" : "\n") + (source.substring(1) || " ");
            atComment = true;
            afterEmptyLine = false;
            break;
          case "%":
            if (prelude[i + 1]?.[0] !== "#")
              i += 1;
            atComment = false;
            break;
          default:
            if (!atComment)
              afterEmptyLine = true;
            atComment = false;
        }
      }
      return { comment, afterEmptyLine };
    }

## Findings precedent

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00029-cartographer-evaluate-phase-4-6-reactivation-v1-review-1.md
  `.json` ledgers.

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00128-discarded-reviews-and-lost-alerts-v1-review-2.md
  directly. So the seven `assertEqual(result, True/False)` sites in

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00129-autoclaude-suite-stubs-do-not-intercept-v1-review-1.md
  **FIX:**

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00129-autoclaude-suite-stubs-do-not-intercept-v1-review-2.md
  **VERIFY:**

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00130-hook-gates-fail-open-silently-v1-review-2.md
  ## Follow-up Tasks Created

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00133-cut-hook-and-suite-overhead-v1-review-2.md
  **Blake 🟡 "Success Metric says one repo-root resolution, implementation still

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  ### Medium (🟡) — deferred

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  - **[Alice, Carl, Quinn] `tests.rs` (963) and `mod.rs` (846) exceed the 800-line style guideline; the merge test (~88 lines) exceeds the 50-line function guideline.** `mod.rs` overage is pre-existing (846 at work-start, 2 lines changed here); `tests.rs` crossed 800 due to this PRD's test additions (767→963). Not a CI gate (clippy clean; test-ci passes). Reviewers agree the concurrency test should not be force-split. → **Deferred**: soft style guideline on test/pre-existing files; a `git_ops` test-file split is a reasonable future cleanup, out of scope for a surgical P0 fix.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  - **⚪ "cannot statically verify build/clippy/tests"** (Bob, Alice) — resolved: `cargo test-ci` → 1662 passed, 0 failed, 0 ignored, exit 0; `cargo clippy --workspace --all-targets` clean (Alice).

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-02.md
  - **[1/5] ⚪ scenario-62 comment still overclaimed** (Bob): the named core regressions (`id_mint_collision.rs`, `raw_create_mint_collision.rs`) exercise `create_doogat_raw`, not `install_bundled_type`, so listing both as "pinned by" them was imprecise. **Fixed inline** (commit `56befa7`): the comment now states `create_doogat_raw` collisions are pinned by those regressions while `install_bundled_type` routes through the same shared oracle (`id_minting.rs` unit tests). Comment-only, zero runtime impact — no further review cycle warranted.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00166-make-hlc-load-bearing-v1-review-01.md
  - **[1/3] ⚪ Low — Stale tie-break doc comments in `sync_manager`.** `resolve_add_add_collision`'s comment says "theirs on tie/missing" and `resolve_lww`'s says "falls back to 'ours'", but both now call `lww_pick` (higher content key on tie/missing). The comments assert the old opposite defaults the PRD required reconciled. File: `ddb-core/src/sync_manager/mod.rs`. Found by: Blake.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00167-sync-collision-reassignment-atomicity-v1-review-01.md
  | [4/5] | 🔴 | `git rev-list --count PRE..POST` without `--first-parent` returns 4 (merge + bookkeeping + the two fetched peer commits), not the asserted 2. Under `set -euo pipefail` this aborts integration.sh at section 27a, so 27a2 and every later section (bundle sync, server, advanced SQL) never runs. The e2e twin uses `--first-parent` and comments that it is required. | tests/integration.sh:3149 | 7 | ALICE, BLAKE, BOB, EVE |

## Task prose

### Batch 202607161128 (autopilot, IN PROGRESS — started 2026-07-16)

- [x] **00163 git-tree-construction-correctness-v1** (DONE 2026-07-17, in `done/`) — delete-freshness + merge-lock legs of the git write-path data-loss class.
- [x] **00200 make-merge-tree-three-way-v1** (DONE 2026-07-18, in `done/`) — true three-way conflicted-merge tree (Alternative B), closing the last data-loss leg.
- [x] **00164 unify-id-minting-v1** (DONE 2026-07-18, in `done/`) — one repo-aware existence oracle for all mint paths.
- [x] **00165 deterministic-crdt-resolution-v1** (DONE 2026-07-18, in `done/`) — content-derived Automerge actor IDs, deterministic list-field ordering.
- [x] **00166 make-hlc-load-bearing-v1** (DONE 2026-07-19, in `done/`) — machine-local `HlcClock`, HLC trailer on every write, unified `lww_pick` tie-break.
- [x] **00167 sync-collision-reassignment-atomicity-v1** (DONE 2026-08-15, in `done/`) — folded winner + loser + backlink rewrites into one atomic `commit_merge`, loser ID derive

# Migrate smoke/integration shell scenarios to the Rust e2e crate

**Priority:** P2 (leverage; ends the 4-file authoring tax before the contract block) · **Roadmap:** inserted 2026-07-16 by maintainer decision (assessment F5) — runs after P0/P1, before the contract block · **Depends on:** none (00162 done; builds its own server-spawn helper — do NOT depend on 00188 ephemeral-serve, a higher number; that PRD may later simplify the helper's internals).

Source: `dev/local/audit-results/evolution-assessment-2026-07-16.md` F5 (lens 7, commit-history mining). Maintainer decisions 2026-07-16: migrate soon, inserted early; later PRDs' scenario tasks were rewritten to target the e2e harness directly (backlog review 2026-07-16, Decision 1).

## Overview

### Problem Statement

Every smoke/integration scenario is authored twice, in two shell dialects: `tests/smoke.sh`/`smoke.ps1` and `tests/integration.sh`/`integration.ps1`. History quantifies the tax: the .sh↔.ps1 pairs co-change in 75/69 com
