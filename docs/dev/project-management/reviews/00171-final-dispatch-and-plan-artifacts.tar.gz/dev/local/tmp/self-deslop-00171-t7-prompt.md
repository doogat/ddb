A diff has been written to satisfy this task. The implementation passed its
tests. Your job: prune slop from the diff while keeping every test green.
This is best-effort cleanup, not a correctness rework — do not change
behavior, do not modify tests, do not refactor.

Task: Port integration §37-38i: WebSocket auth, read-under-write, extended GraphQL ops

Description:
Port tests/integration.sh:1179-1497 and the corresponding tests/integration.ps1 section (§37, §38, §38b, §38b2, §38b2b, §38b3, §38b4, §38c, §38c2, §38d, §38e, §38f, §38g, §38h, §38i) to Rust e2e tests, per the mapping table's integration rows for this range.

Location: new files tests/e2e/integration_*.rs (e.g. integration_ws_auth.rs, integration_graphql_refs.rs, integration_graphql_batch.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `ServerGuard` for WebSocket (`.ws_*` methods) and GraphQL/REST calls — all sections in this range are server-backed. `MultiNodeSetup`/`TwoNodeSetup` (tests/e2e/common.rs:404-594) if §38 (read-under-write: concurrent read + write) needs more than one client against the same server.

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "integration_NN_slug, NN zero-padded."
- ServerGuard's public API is unchanged — do not add new methods without a genuine gap.
- Timing-sensitive within-test ordering (e.g. §38's concurrent read+write interleaving) is expressed with `std::thread::scope` + explicit joins, not a serial marker — same pattern as tests/e2e/singleton_cross_process_upsert.rs.

Details:
- Follow the mapping table row-by-row for this line range; skip rows marked ALREADY COVERED (verify, mark DONE, no duplicate).
- §38b-§38i (multi-value references, DISTINCT/GROUP BY, executeBatch/batchUpdate/createMany, typed field updates via GraphQL) must preserve exact response-shape assertions (field presence/absence, ordering, aggregate values).
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Only 5 of the ~15 sections in this range needed new tests — the mapping table
(dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md) shows
everything else as ALREADY COVERED by pre-existing tests. The diff in scope
here is exactly those 5 gap tests.

Acceptance criteria:
each ported test green locally; the mapping table marks every section in this range DONE.

Tests that the diff made pass (do NOT modify):
tests/e2e/integration_graphql_batch.rs, tests/e2e/integration_graphql_refs.rs

Files in the diff:
tests/e2e/integration_graphql_batch.rs, tests/e2e/integration_graphql_refs.rs, tests/e2e/main.rs

Procedure:

1. Read the diff for each file in scope (`git diff HEAD~1..HEAD <file>` or
   equivalent in your environment).
2. For each line, block, helper, comment, docstring, or test added in the
   diff, ask:
     "Does this trace to a failing test, an acceptance criterion, or
     existing-behavior preservation?"
   If the answer is no, mark the construct for removal.
3. Apply removals one at a time. After each individual removal, re-run:
   `cargo test -p ddb-e2e --test e2e integration_38`
   If it fails, restore that single removal and move on to the next
   candidate. Never delete the test that fails — the test is authoritative.
4. If no removal survived its test re-run, exit WITHOUT committing. Return
   the literal string "no slop found" so the caller can record a noop.
5. If at least one removal survived, commit with message:
     chore: prune slop from Port integration §37-38i: WebSocket auth, read-under-write, extended GraphQL ops
   No CHANGELOG entry. No HEREDOC. No Co-Authored-By trailer. One commit
   only — do not split into multiple cleanup commits.

Rules:

- **Do not modify tests.** If a test reads as weak, that is the per-task
  reviewer's call (step 5.7), not yours. Leave it.
- **Do not change behavior.** Tests prove behavior; if you cannot satisfy
  the tests, the deletion is wrong. Restore.
- **Do not refactor.** This pass deletes; it does not move code around,
  rename symbols, or extract helpers. If a slop pattern would only resolve
  through restructuring, note it in the return message instead of acting.
- **Do not touch files outside the diff.** The cleanup is scoped to what
  the implementor just produced. Adjacent slop in untouched files is out
  of scope here — the post-session codex pass catches it separately.

Slop patterns to look for (catalog inlined from `prompts/de-sloppify.md`):

### 1. Language/framework verification tests

Tests that only prove the runtime or framework works, not the project's behavior.

### 2. Weak or tautological tests

Replace existence checks, mock-confirming tests, self-referential assertions, and unexplained magic assertions with behavior-focused assertions. If an important boundary or failure case is missing, add the smallest useful test.

### 3. Redundant type checks

Remove runtime checks that duplicate compile-time guarantees, except at system boundaries.

### 4. Impossible-state error handling

Remove defensive handling for states that cannot occur from the current control flow. Keep validation and error handling at boundaries.

### 5. Swallowed errors and empty catch blocks

Do not hide failures. Re-throw, surface, or handle them meaningfully.

### 6. Debug statements

Remove development-only prints and logs.

### 7. Commented-out code

Delete dead code kept in comments.

### 8. Obvious comments

Remove comments that restate the code. Keep comments that explain intent, constraints, workarounds, or why.

### 9. Over-abstraction and unnecessary indirection

Inline abstractions that have only one consumer and no current testability or architectural value.

### 10. Duplicate code

Reuse existing code or standard library helpers instead of introducing parallel logic.

### 11. Suspicious dependencies

Verify any newly added dependency exists, is used, and is justified. Remove hallucinated, unused, or speculative dependencies.

### 12. Hardcoded secrets and placeholder credentials

Replace with environment variables, secret storage, or project-approved configuration.

### 13. Deprecated APIs and outdated patterns

Modernize only when the newer approach is already supported by the project and the change stays in scope.

### 14. Naive performance patterns

Fix only if the code is on a hot path or clearly scales poorly with input size.

### 15. Leftover artifacts

Remove temp files, scratch scripts, backup files, unrelated lockfile churn, and agent-generated planning docs.

### 16. AI-style docstrings

Remove multi-paragraph docstrings on trivial functions. Remove docstrings that paraphrase the function name or restate its arguments — when the function is well-named, the docstring is noise. Remove "this function does X by calling Y" preambles that describe implementation rather than contract. Keep docstrings that capture non-obvious intent, invariants, or constraints.

### 17. Trivial-type validation

Remove runtime type guards, JSON schemas, or pydantic models that duplicate compile-time guarantees in a fully-typed file. Examples: `isinstance(x, int)` inside a function whose signature is `x: int`; a pydantic model declared for a function-internal dict whose shape is already pinned by the caller's types. Keep validation at real system boundaries (request bodies, file inputs, external API responses).

### 18. Single-instantiation factories

Inline factory functions, builders, or wrapper classes called from exactly one place where direct construction reads more clearly. A factory pattern only earns its complexity when multiple call sites benefit; before there are multiple call sites, the abstraction is speculative.

### 19. Speculative configuration

Remove config flags, env vars, options parameters that have exactly one used value across the codebase. Configuration is a contract with future readers — exposing one without a current consumer adds maintenance burden for no benefit.

### 20. Restating comments

Remove comments that say what the next line of code already says. Examples: `// increment counter` above `counter += 1`; `# parse the response` above `data = json.loads(raw)`. Keep comments that explain non-obvious why (invariants, workarounds, constraints).

### 21. Framework-verification tests

A more explicit subsection of #2. Remove tests asserting only "import works", "function exists", "method returns truthy" without exercising business logic. Remove mock-confirming tests (the only assertion is `mock.assert_called_with(...)`). Remove snapshot tests where the shape itself is not the contract — they catch any change, including correct ones. Keep behavior assertions that fail when business logic changes.

Return one of:
  - "no slop found" — exited without commit, nothing to clean.
  - "committed {sha}" — committed `chore: prune slop from ...` at {sha},
    test suite green.
  - "errored: {short reason}" — dispatch problem; do not commit, just
    explain so the caller can record the failure.
