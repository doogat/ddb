Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-context-00171-c2.md for review context, and /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00171-c2.diff for the full diff.

Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/engram-pack-00171-c2.md and treat its full content as prepended context: similar code, reuse precedent, findings precedent, and task prose for this diff's changed symbols.

Use this review checklist:
# Review Dimensions

Detailed checklist for reviewing completed work.

## Plan Compliance

- [ ] Implementation matches task description
- [ ] All acceptance criteria met
- [ ] No scope creep (extra features not requested)
- [ ] No missing pieces from original task

## PRD Coverage

- [ ] All "must have" requirements addressed
- [ ] Success metrics achievable with implementation
- [ ] No PRD sections left unimplemented
- [ ] Dependencies correctly handled

## Simplification

Hunt actively for simplification — do not just tick boxes. The diff under
review is fresh; this is the cheapest moment to cut complexity before it sets.
For every added or changed file, ask "what would make this simpler to read
without changing what it does?" and flag concrete opportunities.

- [ ] **Reduce complexity** — no needless indirection, dead branches, or
      abstractions built for a single caller; nesting <= 4 levels; functions
      under 50 lines
- [ ] **Eliminate redundancy** — no logic duplicated within the diff or against
      existing code; no helper that reimplements a stdlib or existing utility
- [ ] **Improve naming** — names state intent; no opaque abbreviations;
      action-named functions start with a verb
- [ ] **Follow project standards** — conventions from CLAUDE.md / AGENTS.md and
      the surrounding code; no style drift
- [ ] **No dead code** — no commented-out blocks, unused imports, variables, or
      speculatively-added parameters
- [ ] **Appropriate error handling** — explicit, never silently swallowed

**How to flag a simplification:** give the file:line, the current shape, and
the simpler replacement. Flag concrete behavior-preserving simplifications at
🟡 Medium so the decision gate routes them into the rework loop. Do not inflate
them to 🟠 High; that floods the rework loop and can trip the scope alarm.

**Balance — do not over-simplify:** never propose a change that trades clarity
for brevity, drops error handling, collapses a deliberate boundary, or removes
a documented invariant. Simpler means easier to read and maintain, not shorter
at any cost. If a "simplification" would change behavior, it is out of scope —
do not flag it.

## Testing

- [ ] Unit tests for new logic
- [ ] Edge cases covered
- [ ] Error paths tested
- [ ] Integration tests if crossing boundaries
- [ ] Tests actually run and pass
- [ ] No tautological test — every new or changed test fails against the
      pre-change code (the context's fail-first replay block), and no assert
      is constant, self-comparing, or an either-or hedge (the shapes block)

## Security

- [ ] No hardcoded secrets
- [ ] Input validation at boundaries
- [ ] No SQL/command injection risks
- [ ] Auth/authz correctly applied
- [ ] Sensitive data not logged

## Documentation

- [ ] Public APIs documented
- [ ] Complex logic has comments
- [ ] README updated if needed
- [ ] Breaking changes noted

In addition, work through the numbered rubric:
# Review-Work-Completion Rubric

This rubric defines binary pass/fail criteria for consensus review of completed work. Each rule is numbered and stable for tracking coverage. Reviewers must answer "R{n}: pass|fail" for every rule in their prompt.

## Rules

### Tests

R1: Tests cover every new behavior introduced by the diff.
R2: Tests bind to intent, not just observable behavior; no new or changed test is tautological (passes against the pre-change code, or cannot fail as written).
R3: No skipped or xfail tests mask failures.

### Integration

R4: Changed components integrate with existing callers.

### Security

R6: No hardcoded secrets in the codebase.
R7: All user input is validated and sanitized.
R8: No injection-unsafe queries or commands.

### Domain

R9: Implementation matches PRD feature behavior exactly.
R10: Error handling is explicit and not swallowed.
R11: No debug statements, TODOs, or placeholder markers remain.

### Code Quality

R12: Function sizes respect the 50-line limit.
R13: File sizes respect the 800-line limit.

Review the completed work against PRD requirements. Explore the codebase as needed.

OUTPUT FORMAT IS MANDATORY. Follow exactly:
## Agent Output Format (Single Source of Truth)

Each agent outputs issues in this exact format:

```
[{AGENT_NAME}] {emoji} {description} | File: {path or "N/A"} | Task: {id or "general"}
```

**Severity emojis:** 🔴 Critical, 🟠 High, 🟡 Medium, ⚪ Low

**Rules:**
- One issue per line
- Use "N/A" for file if issue is architectural/cross-cutting
- Use "general" for task if issue spans multiple tasks or is a PRD gap
- If zero issues found: `[{AGENT_NAME}] ✅ No issues found`

Your agent name is CARL. Emit `[CARL]` on every issue line.

PER-RULE VERDICTS ARE MANDATORY. For every rule in the numbered rubric, emit one line:
R{n}: pass   or   R{n}: fail
(one rule per line, no other text on the line, no rationale).

## Frontend & Design Focus

You still review every dimension in the checklist, but you are the panel's
frontend and design specialist. On any UI, component, styling, or
user-facing change, review with extra depth:

- Accessibility: semantic markup, keyboard navigation, focus management,
  ARIA usage, colour contrast, screen-reader labels.
- Responsive behaviour: layout across breakpoints, overflow, touch targets.
- Visual consistency: design-token usage, spacing/typography scale, reuse
  of existing components over one-off styling.
- UX correctness: loading/empty/error states, form validation feedback,
  no layout shift, sensible defaults.
- Component structure: state vs props boundaries, no prop drilling,
  composability, no duplicated markup.

If the change has no frontend surface, review it as a generalist against
the shared checklist - do not invent frontend findings.

---

## This is an INCREMENTAL review (cycle 2 of PRD 00171)

This is an **incremental review** of the rework done since the previous review
cycle — the diff is scoped to changes since then. Two jobs: (1) for each prior
finding listed below, verify it is now resolved in the code; (2) review the
scoped diff for any regression the rework introduced. You need not re-review
unchanged code; the previous cycle already reviewed the full implementation.

**Scope discipline:** the review diff is `bd3e7f0..74644b8` (commits `103c8ab`
and `74644b8`). Four other commits sit in the same history window
(`dbc128f`, `bd3e7f0`, `4a248cb`, `876a153`) and were written by a different,
concurrent session. They are NOT PRD 00171 work. Do not raise findings against
their `ddb-core/src/**` production changes or their `hazard_*.rs` test files.

This diff has no frontend surface: it changes a GitHub Actions workflow, one
AGENTS.md sentence, and Rust integration tests. Review it as a generalist.

### Prior cycle (1) consolidated findings you must verify as resolved

1. 🟠 HIGH — Per-push CI coverage dropped: `.github/workflows/test.yml`'s
   `Smoke test (e2e)` step ran only the 30 `smoke_*` tests of 565, while ~26 of
   smoke.sh's 56 sections had been mapped to pre-existing e2e modules outside
   that filter. Prescribed fix: replace the `smoke_` step and the five
   `--exact` steps with one `cargo test -p ddb-e2e` step, drop the `DDB_BIN`
   env, fix the test.yml sentence in AGENTS.md.
2. 🟡 §42 totalCount assertions dropped — `tests/e2e/serve.rs`
   (`filter_base_field_title_eq`, `filter_base_field_title_contains`).
3. 🟡 §44.E1 JOIN pin degraded to single-character containment —
   `tests/e2e/integration_junction_sync.rs`.
4. 🟡 §59.A cross-process read-back dropped — `tests/e2e/rest.rs`.
5. 🟡 §18d2 eq-exactness fixture lost — `tests/e2e/serve.rs`
   (`search_where_filter_materialized_column_eq`).
6. 🟡 §38b2b raw-scalar pin with multiple junction rows lost —
   `tests/e2e/reference_raw_id.rs`.
7. 🟡 §17.J2 numeric-id assertion weakened —
   `tests/e2e/integration_graphql_jink.rs`.
8. ⚪ Slop — duplicated `stdout()` and 14-digit-id helpers; consolidate into
   `tests/e2e/common.rs`.

Judge each on the actual code, not on the rework report's claims. For each
strengthened assertion, ask whether it would genuinely fail against the weak
pre-change version.

## Settled decisions — do not re-raise

- discarded | low | Review diff bundles unrelated concurrent commits — separately authored; not scope creep by 00171.
- settled-deferral | medium | Multi-process race tests not marked #[serial] — design uses independent TempDirs/ports and order-independent race results instead.
- discarded | low | PRD checklist unchecked and file still in wip/ — intentional until a fresh finalize session accepts it.
- settled-deferral | low | Race test functions exceed the 50-line guideline — cohesive multi-process orchestration retained deliberately.
- settled-deferral | low | Mechanical tautology finder checked 0 functions — the installed checks are Python-only; extending them is outside 00171.
- discarded | low | Tier 2 had not run on the deletion commit — live GitHub confirmed the required runs.
- settled-deferral | low | PRD says §55/§61 are "marked serial" but no serial marker exists — superseded by the design's isolation model.
- settled-deferral | low | PRD spawn helper "polls /health" but ServerGuard waits on stderr — design reuses the existing guard; 00188 owns its internals.
- discarded | low | §54.D/§55.D psql-absent skip semantic not ported — the Rust PgWire client is always present.
- discarded | low | Mapping cites three reserved slugs resolving to no test — documented banner-only sections.

## Runtime evidence already in hand (do not re-run, do not re-dispatch CI)

Reviewed HEAD `876a153b4039128f8052526629773fa189058c71`:
- Test run 34086467208: success. 1819 fast tests passed, 0 failed, 0 ignored.
  Unfiltered e2e 566 passed, 0 failed, 2 ignored. Coverage 79.88% lines.
- Full Validation run 34092612666: all six jobs succeeded; linux-e2e,
  macos-full and windows-full each 566 passed, 0 failed, 2 ignored.
