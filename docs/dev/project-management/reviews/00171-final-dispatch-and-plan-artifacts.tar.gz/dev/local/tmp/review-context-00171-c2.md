# Review Context

## Completed Tasks

# Completed tasks — PRD 00171 (migrate shell scenarios to the Rust e2e crate)

All 16 tasks are `completed`. Tasks 1-14 are the original build plan (reviewed in
full during cycle 1, diff range `b1e7853..c8b72bd`). Tasks 15-16 are the cycle-1
decision-gate rework tasks — **these two are the subject of this incremental
cycle-2 review**.

| Task | Name | Tier | Implementor | Commit(s) |
|------|------|------|-------------|-----------|
| 1 | Build e2e mapping table: smoke.sh + smoke.ps1 sections | sonnet | claude | (cycle-1 range) |
| 2 | Build e2e mapping table: integration.sh sections | sonnet | claude | (cycle-1 range) |
| 3 | Build e2e mapping table: integration.ps1 sections | sonnet | claude | (cycle-1 range) |
| 4 | Verify ServerGuard spawn/health/teardown round-trip | haiku | claude | (cycle-1 range) |
| 5 | Port smoke.sh + smoke.ps1 sections to tests/e2e/smoke_*.rs | sonnet | codex | (cycle-1 range) |
| 6 | Port integration §17-20: GraphQL server setup, jink schema, expanded GraphQL ops, REST CRUD, PgWire basic | sonnet | codex | (cycle-1 range) |
| 7 | Port integration §37-38i: WebSocket auth, read-under-write, extended GraphQL ops | sonnet | claude | (cycle-1 range) |
| 8 | Port integration §42-45: base field filters, SQL INSERT+constraints, JOIN/auto-junction, DDL, createMany + ghost-row pins | sonnet | claude | (cycle-1 range) |
| 9 | Port integration §46-53: structured-error codes, ALTER TABLE RENAME across protocols, SINGLETON GraphQL flow | sonnet | claude | (cycle-1 range) |
| 10 | Port integration §56-60: REST/GraphQL warnings envelopes, update warning shape, REST typed create, typed where-filter completeness | sonnet | claude | (cycle-1 range) |
| 11 | Port integration Part B: sync/CRDT conflicts, bundle export/import, SQL schema evolution, ID minting, poison-file warnings | sonnet | claude | (cycle-1 range) |
| 12 | Port integration §54-55/61: PgWire/SINGLETON cross-protocol parity, SINGLETON write races, cross-process write-lock races | opus | codex | (cycle-1 range) |
| 13 | Rewire test.yml + full-validation.yml to run e2e replacements; dispatch manual full-validation | sonnet | qwen | (cycle-1 range) |
| 14 | Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references | opus | codex | (cycle-1 range) |
| **15** | **[D1] Restore complete per-push e2e coverage** | sonnet | orchestrator | **`103c8ab`** |
| **16** | **[D1] Restore exact scenario assertions and share existing test helpers** | sonnet | claude | **`74644b8`** |

## Cycle-1 rework scope (what tasks 15 and 16 were asked to fix)

Eight actionable findings from cycle 1:

1. **HIGH** — per-push CI coverage dropped: `test.yml`'s `Smoke test (e2e)` step
   ran only the 30 `smoke_*` tests of 565, but ~26 of smoke.sh's 56 sections had
   been mapped to pre-existing modules outside that filter. Fix: run the whole
   e2e suite per push; drop the redundant `--exact` steps and the obsolete
   `DDB_BIN` env; correct the AGENTS.md sentence. → task 15, commit `103c8ab`.
2. **MEDIUM** — §42 `totalCount` assertions dropped in `tests/e2e/serve.rs`.
3. **MEDIUM** — §44.E1 JOIN pin degraded to single-character containment in
   `tests/e2e/integration_junction_sync.rs`.
4. **MEDIUM** — §59.A cross-process read-back dropped in `tests/e2e/rest.rs`.
5. **MEDIUM** — §18d2 eq-exactness fixture lost in `tests/e2e/serve.rs`.
6. **MEDIUM** — §38b2b raw-scalar pin with multiple junction rows lost in
   `tests/e2e/reference_raw_id.rs`.
7. **MEDIUM** — §17.J2 numeric-id assertion weakened in
   `tests/e2e/integration_graphql_jink.rs`.
8. **LOW** — duplicated `stdout()` / 14-digit-id helpers across e2e modules;
   consolidate into `tests/e2e/common.rs`.

Findings 2-8 → task 16, commit `74644b8`.

## Concurrent, separately owned commits in the same history window

`dbc128f`, `bd3e7f0`, `4a248cb`, `876a153` were authored by a different live
session (the fast-track hazard lane). They are **not** PRD 00171 work and are
excluded from this review's migration diff. They remain relevant surrounding
code: `dbc128f` adds six ignored hazard regression tests (two of which are the
two `ignored` e2e tests visible in current CI output), and the other three are
production-code fixes in `ddb-core`.

## Code Changes

### Changed Files

**Diff scope: incremental review of PRD 00171's cycle-1 rework only —
`bd3e7f0..74644b8` (commits `103c8ab` and `74644b8`).**

The raw `--since c8b72bd` range also contains four commits authored by a
different, concurrent session (the fast-track hazard lane): `dbc128f`,
`bd3e7f0`, `4a248cb`, `876a153`. Those are NOT PRD 00171 work and are excluded
from the review diff below. Do not attribute their `ddb-core/src/**` production
changes, their `ddb-core/tests/hazard_*.rs` / `tests/e2e/hazard_*.rs` files, or
their CHANGELOG entries to this migration, and do not raise findings against
them as 00171 defects. They remain readable as surrounding code (see the
secondary diff path below) because two of them add the two `ignored` e2e tests
that appear in current CI output.

```
 .github/workflows/test.yml                | 31 +------------
 AGENTS.md                                 |  2 +-
 tests/e2e/common.rs                       | 18 ++++++++
 tests/e2e/integration_graphql_jink.rs     |  4 +-
 tests/e2e/integration_id_poison.rs        | 17 ++-----
 tests/e2e/integration_junction_sync.rs    | 13 +++---
 tests/e2e/integration_nosql_cli.rs        | 14 +++---
 tests/e2e/integration_singleton_parity.rs |  7 +--
 tests/e2e/integration_singleton_races.rs  |  8 +---
 tests/e2e/reference_raw_id.rs             | 75 +++++++++++++++++++++++++++++++
 tests/e2e/rest.rs                         | 13 ++++++
 tests/e2e/serve.rs                        | 13 +++---
 tests/e2e/smoke_core.rs                   | 10 +----
 tests/e2e/smoke_search.rs                 | 10 +----
 tests/e2e/smoke_sql.rs                    | 18 +-------
 15 files changed, 141 insertions(+), 112 deletions(-)
```

### Diff Content
Review diff (PRD 00171 rework, `bd3e7f0..74644b8`, 519 lines):
/Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00171-c2.diff

Surrounding-code diff (the full `c8b72bd..HEAD` range including the four
concurrent non-00171 commits, 2323 lines) — context only, never the subject of a
finding:
/Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00171-c2-surrounding.diff

### Reviewed HEAD and CI evidence

Reviewed HEAD: `876a153b4039128f8052526629773fa189058c71` (clean tree, pushed;
`master` == `origin/master`).

At this exact SHA:

- Test run 34086467208 succeeded. Fast tests 42 + 1555 + 222 = 1819 passed,
  0 failed, 0 ignored. Unfiltered e2e: 566 passed, 0 failed, 2 ignored (226.21s).
  Sync integration: 6 passed. Coverage 79.88% lines.
- Full Validation run 34092612666 succeeded, all six jobs. linux-e2e, macos-full
  and windows-full each report 566 passed, 0 failed, 2 ignored.
- The 2 ignored e2e tests are the concurrent lane's FT-5 / FT-6 hazard
  regressions, not migrated shell scenarios.

Open observation carried from cycle 1: Nightly 34020494801 (at the older
`c8b72bd`) failed two tests — a Windows `git_ops` log-capture unit test (outside
this PRD) and the migrated macOS
`integration_warnings_update::integration_58_a_graphql_update_warnings_empty`
with a `ConnectionReset` at `tests/e2e/common.rs:186`. Both named tests passed
in the full three-platform suite at the reviewed SHA. The cause was never
confirmed and no retry, skip, readiness change or parallelism reduction was
applied. Give this observation an explicit disposition; do not claim it repaired.

## Mechanical facts (computed, do not re-count)

Function line counts from `ast`. Cite these for countable claims; a
finding that contradicts this block is discarded at the review gate.

- `.github/workflows/test.yml` — skipped (non-python)
- `AGENTS.md` — skipped (non-python)
- `tests/e2e/common.rs` — skipped (non-python)
- `tests/e2e/integration_graphql_jink.rs` — skipped (non-python)
- `tests/e2e/integration_id_poison.rs` — skipped (non-python)
- `tests/e2e/integration_junction_sync.rs` — skipped (non-python)
- `tests/e2e/integration_nosql_cli.rs` — skipped (non-python)
- `tests/e2e/integration_singleton_parity.rs` — skipped (non-python)
- `tests/e2e/integration_singleton_races.rs` — skipped (non-python)
- `tests/e2e/reference_raw_id.rs` — skipped (non-python)
- `tests/e2e/rest.rs` — skipped (non-python)
- `tests/e2e/serve.rs` — skipped (non-python)
- `tests/e2e/smoke_core.rs` — skipped (non-python)
- `tests/e2e/smoke_search.rs` — skipped (non-python)
- `tests/e2e/smoke_sql.rs` — skipped (non-python)

## Tautological test shapes (computed, do not re-judge)

Each `[MECH]` line is a test whose shape cannot fail as written. Raise
it; step 6 adds any line the table lacks. `mech-check` is the finder.


Checked 0 test function(s) in 0 test file(s).

## Mechanical-net limitation (read this before trusting the two blocks above)

Both computed blocks above are **Python-only** and this diff is entirely Rust,
YAML and Markdown, so **neither net fired**. `replay_tests_against_base.py` was
not run at all: it drives pytest, and this project's suite is `cargo test`.

Consequence for this cycle: there is **no automated evidence** that the
assertion changes in `74644b8` actually fail against the pre-change code. Every
strengthened assertion in this diff has to be judged by reading it. Treat any
new or modified assertion that would still pass against the old, weaker
production behaviour as a finding, and say so explicitly — do not assume the
mechanical net cleared it.

## PRD Requirements

# Migrate smoke/integration shell scenarios to the Rust e2e crate

**Priority:** P2 (leverage; ends the 4-file authoring tax before the contract block) · **Roadmap:** inserted 2026-07-16 by maintainer decision (assessment F5) — runs after P0/P1, before the contract block · **Depends on:** none (00162 done; builds its own server-spawn helper — do NOT depend on 00188 ephemeral-serve, a higher number; that PRD may later simplify the helper's internals).

Source: `dev/local/audit-results/evolution-assessment-2026-07-16.md` F5 (lens 7, commit-history mining). Maintainer decisions 2026-07-16: migrate soon, inserted early; later PRDs' scenario tasks were rewritten to target the e2e harness directly (backlog review 2026-07-16, Decision 1).

## Overview

### Problem Statement

Every smoke/integration scenario is authored twice, in two shell dialects: `tests/smoke.sh`/`smoke.ps1` and `tests/integration.sh`/`integration.ps1`. History quantifies the tax: the .sh↔.ps1 pairs co-change in 75/69 commits, 96 fix commits target the four harness files, 21 commits were pure PowerShell-dialect fixes (7 on 2026-03-18 alone: escaping, byte-array decode, `Pop-Location` hangs, `ErrorActionPreference`, ANSI stripping), and one behavior fix routinely touches all four files (`5a55296`). Every remaining backlog PRD that adds user-facing behavior pays this tax again. The cross-platform Rust e2e crate (`tests/e2e/`, assert_cmd) already runs on all three CI platforms and needs each scenario authored once.

### Target Users

Maintainer + autopilot: every subsequent PRD's scenario authoring drops from 4 files in 2 dialects to 1 Rust test. CI keeps identical coverage.

### Success Metrics

- Every scenario currently in the four shell files exists as a Rust e2e test — a section-by-section mapping table proves 100% coverage, no silent drops.
- CI (`test.yml`/`full-validation.yml`) runs the e2e suite where it ran the shell scripts, on all three platforms; a manual full-validation dispatch is green before any deletion.
- The four shell files are deleted (or each survivor is justified in the mapping table).
- AGENTS.md "Per-PRD deliverables" is rewritten: scenario authoring targets `tests/e2e/`; the 4-file mandate is removed.
- No lost semantics: must-fail assertions (`ddb-fails` pattern), server lifecycle scenarios (§54-57 SINGLETON/PgWire/warnings), and multi-process races keep their exact assertions.

## Functional Decomposition

### Capability: e2e server/process harness

#### Feature: Server-spawn helper
- **Description**: a shared helper in `tests/e2e/common.rs` that spawns `ddb serve` on a free port in a tempdir, polls `/health`, and tears down — replacing the shell scripts' server management.
- **Inputs**: the built `ddb` binary (e2e precondition), a tempdir, a free port.
- **Outputs**: a guard struct exposing base URL + token + repo path; teardown on drop.
- **Behavior**: extend the existing `ServerGuard` pattern in `tests/e2e/common.rs`; keep the helper's public API stable so 00188 (`--ephemeral`) can later replace its internals without touching call sites.

### Capability: Scenario ports

#### Feature: Smoke-section ports
- **Description**: every numbered section of `tests/smoke.sh`/`smoke.ps1` becomes a Rust e2e test.
- **Inputs**: the mapping table (Phase 0); the current smoke sections.
- **Outputs**: `tests/e2e/smoke_*.rs` tests named for their source section (`smoke_04_reserved_name_rejection` style).
- **Behavior**: port assertions verbatim in intent; must-fail cases use `assert_cmd`'s failure assertions (the `ddb-fails` equivalent); section identity preserved in test names so the mapping table stays auditable.

#### Feature: Integration-section ports
- **Description**: every numbered section of `tests/integration.sh`/`integration.ps1` becomes a Rust e2e test, server sections included.
- **Inputs**: the mapping table; the spawn helper.
- **Outputs**: `tests/e2e/integration_*.rs` tests.
- **Behavior**: server sections (§54-57 PgWire parity, SINGLETON races, warnings envelopes) port last; the psql-absent graceful degradation of §54.D keeps its semantic (skip-with-note when no client is available); timing-sensitive multi-process sections are marked serial.

### Capability: CI rewiring and retirement

#### Feature: Workflow rewiring
- **Description**: CI runs the e2e replacements where it ran the scripts.
- **Inputs**: `.github/workflows/test.yml`, `full-validation.yml`.
- **Outputs**: workflows invoking the e2e suite on all three platforms; shell-script steps removed.
- **Behavior**: keep job ordering so `cargo build -p ddb-cli` precedes e2e; run one manual `full-validation` dispatch green before deletion.

#### Feature: Shell-file deletion + docs rewrite
- **Description**: delete the four shell files and rewrite the authoring mandate.
- **Inputs**: the green CI run; the mapping table.
- **Outputs**: files deleted (or justified survivors); AGENTS.md "Per-PRD deliverables" + `docs/src/technical/` testing references updated.
- **Behavior**: deletion is the FINAL task, only after CI is green on the replacements. This is a deletion PRD: run `cargo test -p ddb-e2e` per CLAUDE.md.

## Structural Decomposition

### Repository Structure

```text
tests/
├── e2e/common.rs            # Maps to: Server-spawn helper (extend existing ServerGuard)
├── e2e/smoke_*.rs           # Maps to: Smoke-section ports
├── e2e/integration_*.rs     # Maps to: Integration-section ports
├── smoke.sh / smoke.ps1     # Maps to: deletion (Phase 2)
└── integration.sh / integration.ps1  # Maps to: deletion (Phase 2)
.github/workflows/
├── test.yml                 # Maps to: Workflow rewiring
└── full-validation.yml      # Maps to: Workflow rewiring
AGENTS.md                    # Maps to: Shell-file deletion + docs rewrite (per-PRD deliverables)
```

### Module: e2e common (tests/e2e/common.rs)
- **Maps to capability**: e2e server/process harness
- **Responsibility**: server spawn/health/teardown for all ported server scenarios; stable API for the 00188 swap.
- **Exports**: the spawn-helper guard (extends `ServerGuard`).

### Module: smoke/integration ports (tests/e2e/smoke_*.rs, integration_*.rs)
- **Maps to capability**: Scenario ports
- **Responsibility**: one Rust test per shell section, names carrying section identity.
- **Exports**: the test functions (no library surface).

### Module: workflows (.github/workflows/)
- **Maps to capability**: CI rewiring and retirement
- **Responsibility**: run the e2e suite where the scripts ran; keep platform matrix coverage.
- **Exports**: n/a (CI configuration).

## Dependency Graph

### Foundation Layer (Phase 0)
No dependencies - built first.
- **mapping table**: section-by-section inventory; the coverage proof artifact.

### Core Layer (Phase 1)
- **spawn helper**: depends on [mapping table] (identifies which sections need a server).
- **smoke ports**: depends on [mapping table].
- **integration ports**: depends on [spawn helper].

### Integration Layer (Phase 2)
- **CI rewiring**: depends on [smoke ports, integration ports].
- **deletion + docs**: depends on [CI rewiring] (green run first).

## Implementation Phases

### Phase 0: Foundation
**Goal**: the coverage proof exists before any port.

**Tasks**:
- [ ] Build the mapping table: every numbered section in the four files → target e2e test name (or justified survivor), including which sections need a server and which are must-fail assertions. Known quirks to encode (verified at `d77ad58`): section numbering is sparse AND duplicated (both integration files carry two `# 50.` sections — key rows by file:line, not number alone); the `ddb-fails` must-fail helper exists only in PowerShell (`integration.ps1:67` — bash uses bare `!` negation); `tests/smoke.ps1` is invoked by NO workflow, so its port costs zero CI coverage (no deps) - Acceptance: the table is complete with zero unmapped sections (duplicate-numbered sections disambiguated by file:line); it lives in the PRD workdir notes and is referenced by later acceptance checks.

**Exit Criteria**: 100% of shell sections have a mapped target.

### Phase 1: Core
**Goal**: every scenario exists in Rust.

**Tasks**:
- [ ] Extend `tests/e2e/common.rs` with the server-spawn helper (free port, tempdir, health poll, teardown; stable API) (depends on: Phase 0) - Acceptance: one round-trip test spawns, queries `/health`, and tears down cleanly.
- [ ] Port all smoke sections to `tests/e2e/smoke_*.rs` per the mapping table (depends on: Phase 0) - Acceptance: each ported test green locally; must-fail assertions preserved via assert_cmd failure checks.
- [ ] Port all integration sections to `tests/e2e/integration_*.rs`, server sections (§54-57) and multi-process races last, marked serial; keep §54.D's psql-absent graceful skip semantic (depends on: spawn helper) - Acceptance: each ported test green locally; the mapping table marks every section DONE.

**Exit Criteria**: mapping table shows 100% ported; `cargo test -p ddb-e2e` green locally.

### Phase 2: Integration
**Goal**: CI proves parity; the shell files retire.

**Tasks**:
- [ ] Rewire `test.yml` + `full-validation.yml` to run the e2e replacements on all three platforms; dispatch a manual full-validation run (depends on: Phase 1) - Acceptance: all platforms green on the e2e replacements with the shell steps removed.
- [ ] Delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md "Per-PRD deliverables" (scenario authoring targets `tests/e2e/`) and the `docs/src/technical/` testing references; run `cargo test -p ddb-e2e` (deletion PRD per CLAUDE.md) (depends on: CI rewiring) - Acceptance: `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

**Exit Criteria**: shell files gone, CI green, AGENTS.md updated.

## Test Strategy

### Critical Scenarios
- **Happy path**: a ported smoke section (create/query round trip) → Expected: identical assertion outcome to the shell original.
- **Edge case**: a must-fail section (reserved-name rejection) → Expected: assert_cmd failure assertion fires exactly where `ddb-fails` did.
- **Error case**: a timing-sensitive multi-process race section under the cargo test runner → Expected: serial-marked test stays deterministic; no parallelism-induced flake.

## Risks

- **Timing-sensitive multi-process scenarios** (§55 races) may behave differently under cargo's parallel test runner. Mitigation: serial markers / the e2e crate's existing single-thread patterns; port these last.
- **Windows-specific behaviors currently only exercised via PowerShell** (path handling) must be asserted in Rust, not lost. Mitigation: the mapping table calls each out explicitly; CI's windows leg is the oracle.
- **e2e requires the built binary** (`cargo build -p ddb-cli` first). Mitigation: already the documented e2e precondition; CI job ordering respects it.

## Transport Impact

No product surface changes on any of the six transports (CLI, GraphQL, REST, PgWire, FFI, NoSQL HTTP). CI coverage parity is the contract: the mapping table proves CLI/GraphQL/REST/PgWire/NoSQL scenarios survive the port; FFI is untouched (its CI guard is 00194). Cross-interface conformance plan: the mapping table + the green manual full-validation dispatch before deletion are the conformance evidence; no new behavior surface exists to conform.


## Design Doc

# Design: Migrate smoke/integration shell scenarios to the Rust e2e crate

PRD: `dev/local/prds/wip/00171-migrate-shell-scenarios-to-e2e-v1.md`

## Architecture fit

This is test-harness infrastructure, not product code — it touches only the
`tests/` crate (`ddb-e2e`, workspace member `tests/`, single test binary
`tests/e2e/main.rs`) and CI workflow YAML. No `ddb-core`/`ddb-cli`/`ddb-server`
production code changes. The e2e crate already exercises all six transports
(CLI via `assert_cmd`, GraphQL, REST, PgWire via `tokio_postgres`, WebSocket via
`tungstenite`, FFI is out of scope here) through the `ServerGuard`/`DdbTestRepo`
harness in `tests/e2e/common.rs` — this PRD extends that harness's *coverage*,
not its *shape*.

## Module placement

New files only; no existing production or e2e file is restructured.

- `tests/e2e/smoke_*.rs` — one file per `tests/smoke.sh` numbered section (or a
  small cluster of adjacent, related sections), test functions named
  `smoke_NN_slug` (e.g. `smoke_04_reserved_name_rejection`).
- `tests/e2e/integration_*.rs` — same pattern for `tests/integration.sh`,
  functions named `integration_NN_slug`; server-lifecycle sections (§54-57)
  land in `tests/e2e/integration_server_*.rs`.
- `tests/e2e/main.rs` — gains one `mod smoke_*;` / `mod integration_*;` line per
  new file, inserted alphabetically into the existing list (line 1-56 today).
- `.github/workflows/test.yml`, `.github/workflows/full-validation.yml` — edited
  in place (exact diffs below).
- `dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md` — NEW,
  the coverage-proof mapping table (Phase 0 deliverable; durable PRD satellite,
  not deleted until the PRD itself moves to `done/`).
- `AGENTS.md` — "Per-PRD deliverables" bullet rewritten (final task). That
  bullet's trailing sentence about `dev/local/specs/jink-feedback/ddb-repros/`
  is unrelated to the 4-file mandate and must carry into the rewritten text
  unchanged.
- **Every other doc referencing the four shell files** — the PRD's own Phase 2
  acceptance check (`rg -l "smoke.sh"` finds only historical docs) fails
  unless these are also updated in the same task: `CONTRIBUTING.md:42-43`
  (duplicates the exact 4-file mandate AGENTS.md is dropping — rewrite
  identically), `README.md:101-102` (quickstart commands that 404 post-
  deletion — replace with the `cargo test -p ddb-e2e` equivalent),
  `docs/src/technical/walkthrough.md:38,430` (describes the four files as
  "additional test surfaces" — rewrite to describe the e2e crate instead),
  `docs/src/technical/sql-engine.md:622,634` (cites specific shell sections
  for the SQL-engine bug-cluster table — repoint at the mapping table's
  target e2e test names for those rows).
- `tests/smoke.sh`, `tests/smoke.ps1`, `tests/integration.sh`,
  `tests/integration.ps1` — deleted (final task, after CI proves green on the
  replacements).

`tests/e2e/common.rs` is **not modified** unless a ported scenario needs a
capability it genuinely lacks (see Reuse inventory — it already covers spawn,
port allocation, tempdir, multi-node, and every transport client this PRD
needs).

## Interfaces & contracts

**Test naming.** `smoke_NN_slug` / `integration_NN_slug`, `NN` zero-padded to
match the source section number (`04`, not `4`). Two shell files each carry a
duplicate `# 50.` section header (`integration.sh:2159` PRD 00132 rename-across-
protocols, and `integration.sh:3697` PRD 00136 FK-freshness — same duplication
mirrored in `integration.ps1`); the mapping table keys these by `file:line`,
and the Rust side disambiguates by giving each a distinct slug
(`integration_50_alter_table_rename`, `integration_50_cross_process_fk_freshness`)
— never two functions named `integration_50`.

**Must-fail assertions.** The shell `ddb-fails` helper (PowerShell-only,
`integration.ps1:67`; bash negates with bare `!`) maps directly to the existing
`assert_cmd` idiom already used throughout the crate:

```rust
repo.ddb()
    .args(["update", "99999999999999", "--title", "Whatever"])
    .assert()
    .failure()
    .stderr(predicate::str::contains("error:"));
```

(`predicates` is already a `tests/Cargo.toml` dependency; see
`tests/e2e/cli_update_app_error.rs` for the existing pattern this PRD reuses
verbatim, not reinvents.)

**Server-spawn helper.** `ServerGuard::start(&DdbTestRepo)` (already implemented,
`tests/e2e/common.rs:55`) is the contract every server-backed port uses. Its
public API (`start`, `.url()`, `.rest_*`, `.graphql*`, `.ws_*`, `.kill`, `Drop`)
is unchanged by this PRD — no new methods are required for any currently-known
shell scenario (see Reuse inventory). If a specific integration-section port
surfaces a genuine gap during Phase 1, add the method to `ServerGuard` directly
(same file, same struct) rather than a parallel helper.

**Concurrency / "serial" sections.** No `serial_test` crate, no
`--test-threads=1`. Every test gets its own port
(`next_available_port()`'s process-wide `AtomicU16` counter, `common.rs:34`)
and its own `TempDir`-backed repo, so cargo's default parallel test runner is
already safe — this is the existing pattern, not a new one (see
`tests/e2e/singleton_cross_process_upsert.rs` for a live two-server race test
that runs under ordinary `cargo test` parallelism today). Timing-sensitive
*within-test* ordering (two CLI/GraphQL calls that must interleave a specific
way) is expressed with `std::thread::scope` + explicit joins, not a serial
marker — same file, same pattern as the existing race test cited above.

**PgWire sections — psql dependency dropped, not preserved.** The shell scripts'
§54.D/55.D "psql-absent" skip (`integration.sh:2355-2358`,
`integration.sh:2513`) exists only because the shell scripts shell out to the
external `psql` binary and some CI runners (macOS) don't have it. The shell
scripts' own pass messages already point at the replacement:
`"54.D: PgWire parity covered by cargo test -p ddb-e2e --test e2e -- pgwire_singleton (no psql on host)"`.
The Rust e2e crate already ports PgWire scenarios through `tokio_postgres`
(pure-Rust client, already a `tests/Cargo.toml` dependency — see
`tests/e2e/pgwire_singleton.rs`, `tests/e2e/pgwire.rs`), never shelling out to
`psql`. **The port therefore drops the skip entirely**: §54.D/55.D's PgWire
assertions run unconditionally on every platform via `tokio_postgres`, which
exceeds the shell semantic (always-run beats conditional-skip) rather than
merely preserving it. Do not add a `command -v psql` equivalent check in Rust —
there is nothing to check for.

**CI rewiring — exact diffs.**

`test.yml` (fast per-push gate): replace the shell smoke step —

```diff
-      - name: Smoke test
-        env:
-          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
-        run: ./tests/smoke.sh
+      - name: Smoke test (e2e)
+        env:
+          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
+        run: cargo test -p ddb-e2e --test e2e smoke_
```

(cargo test's substring filter on the harness matches every `smoke_*` function;
job ordering is unchanged — this step already runs after "Build CLI binary".)
The five hand-picked `E2E - *` steps and `Sync integration tests` step in
`test.yml` are untouched — they are an independent fast-gate sampling, not this
PRD's concern.

`full-validation.yml`: the `linux-smoke` job's only content is
`./tests/integration.sh`; once ported, that content is a strict subset of what
`linux-e2e`'s unfiltered `cargo test -p ddb-e2e` already runs on the same
platform. **Delete the `linux-smoke` job** (not just its shell step) and remove
it from `mark-validated`'s `needs:` list. `macos-full` and `windows-full` each
run `cargo test-full` (= `cargo test --workspace`, which includes the `tests`
workspace member unfiltered — see `Cargo.toml`/`​.cargo/config.toml`) followed
by a separate `./tests/integration.sh` / `integration.ps1` step; once ported,
that separate step is redundant with the `cargo test-full` step directly above
it on the same job. **Delete the `Integration test` step from `macos-full` and
`windows-full`** (keep every other step, including `Full cargo test suite`,
which now carries the ported coverage). This is a net simplification (3 fewer
CI steps, no coverage lost — `cargo test-full`/`linux-e2e` already run
unfiltered) and satisfies the PRD's Phase 2 acceptance ("all platforms green on
the e2e replacements with the shell steps removed") without inventing new job
structure.

**Mapping table.** `dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md`,
one row per shell section: `file:line | section # | target e2e test (or
"ALREADY COVERED by <existing test>" or "justified survivor: <reason>") |
needs server? | must-fail? | status`. Built in Phase 0 before any port task
starts; updated to DONE per section as Phase 1 tasks land (PRD's own Exit
Criteria requires it show 100% ported before Phase 2).

## Data flow

Unchanged from the existing e2e crate: a test calls `DdbTestRepo::init()`
(spawns `ddb init` in a fresh `TempDir`, disables git commit signing so CI
doesn't need a signing key), optionally `ServerGuard::start(&repo)` (spawns
`ddb serve`, blocks on stderr readiness lines for HTTP+PgWire listeners,
returns a guard exposing base URL/PG port/auth token), then drives the CLI via
`assert_cmd::Command` and/or the server via GraphQL/REST/WS/PgWire clients, and
asserts. `Drop` kills the child process; the `TempDir` cleans up on scope exit.
No new data-flow shape — this PRD is pure coverage porting through the existing
pipes.

## Reuse inventory

- **`ServerGuard`** (`tests/e2e/common.rs:48-334`) — full server lifecycle:
  spawn, free-port allocation (`next_available_port`, an `AtomicU16` counter
  that skips already-bound ports), stderr-based readiness detection for both
  HTTP and PgWire listeners, auth-token capture, GraphQL/REST/WebSocket client
  methods, `kill()`, `Drop`. Covers 100% of the PRD's "Server-spawn helper"
  ask already — used in 30+ existing e2e files (`rg -n "ServerGuard::start"
  tests/e2e/` — 100+ call sites). No extension needed for any scenario
  identified so far.
- **`DdbTestRepo`** (`common.rs:361-401`) — tempdir-backed repo init +
  `ddb()`/`ddb_at()` command builders, git-signing disabled for CI. Direct
  replacement for the shell scripts' per-scenario `mktemp -d` + `ddb init`.
- **`MultiNodeSetup` / `TwoNodeSetup`** (`common.rs:404-594`) — bare-remote +
  N-node clone/register/push/sync helpers, already used for multi-device sync
  scenarios. Covers the PRD's cross-process sections that need >1 clone, not
  just >1 server.
- **`assert_cmd::Command` + `predicates`** — the CLI-invocation and must-fail
  idiom (`.assert().success()/.failure()`, `predicate::str::contains`) used
  everywhere in the crate; direct replacement for shell's `ddb ... || fail` /
  `ddb-fails` patterns. Greps tried: `assert_cmd`, `predicates`, `ddb-fails`,
  `\.failure\(\)` — all confirm the pattern is established, nothing new to
  write.
- **`tokio_postgres`** (`tests/Cargo.toml:22`, used in `pgwire.rs`,
  `pgwire_singleton.rs`) — replaces every shell `psql` invocation; see
  Interfaces & contracts above.
- **Existing PgWire e2e coverage may already satisfy several shell sections
  outright.** `integration.sh` sections 54.D and 55.D literally name
  `pgwire_singleton` as their own replacement in their pass messages
  (`integration.sh:2358`, `:2513`) — the mapping table (Phase 0) must check
  each server-lifecycle section against `tests/e2e/pgwire*.rs`,
  `serve.rs`, `server_mutations.rs`, `subscriptions.rs`, and
  `singleton_cross_process_*.rs` for an existing equivalent before writing a
  new test, to avoid duplicate coverage of the same assertion.
- Nothing found for: a distinct "spawn helper" beyond `ServerGuard`
  (greps: `ServerGuard`, `serve.*spawn`, `health.*poll` — all resolve to the
  existing struct); a `serial_test`-style crate (greps: `serial_test`,
  `#\[serial\]`, `test-threads` — zero hits in `tests/`, `Cargo.toml`,
  workflows — confirms no such dependency exists or is needed, per the
  Concurrency contract above).

## Alternatives considered

1. **Smallest-diff: port only the sections currently reachable from CI** (the
   ~10 sections `test.yml` names explicitly, plus whatever `linux-smoke`/
   `macos-full`/`windows-full` exercise) and leave the rest of the shell files
   in place as a "just in case" archive. Rejected: fails the PRD's own Success
   Metric ("every scenario... exists as a Rust e2e test — no silent drops")
   and leaves the dual-dialect authoring tax exactly as expensive for every
   future PRD, which is the whole point being fixed.
2. **Rewrite the shell scripts as a single shared dialect** (e.g. drop
   PowerShell, keep only bash, run bash-on-Windows via WSL/git-bash in CI).
   Rejected: still a shell-based harness with the same fragility class
   (21 commits of pure PowerShell-dialect fixes were about *shell* fragility,
   not multi-dialect-ness specifically — bash-only still needs its own
   Windows-compatibility workarounds) and does not gain the compile-time
   type-checking, IDE support, and single-authoring-surface `cargo test`
   already gives the existing 100+ e2e tests.
3. **Chosen: full 1:1 port to the existing Rust e2e crate**, reusing
   `ServerGuard`/`DdbTestRepo` as-is (no new abstraction layer), one Rust test
   per shell section, mapping table as the coverage proof, CI rewired to run
   the replacements, shell files deleted last. The extra size over option 1
   buys exactly what the PRD asks for: zero authoring tax for every
   remaining backlog PRD (00172+), which the growth-roadmap memory frames as
   the reason this PRD was inserted ahead of the contract block.

## Risks & edge cases

- **Duplicate `# 50.` section numbers** in both `integration.sh` and
  `integration.ps1` (verified: `integration.sh:2159` and `:3697`, mirrored in
  `.ps1` at `:2026`/`:3654`) — mapping table keys by `file:line`; Rust test
  names disambiguate with distinct slugs (see Interfaces & contracts).
- **`tests/smoke.ps1` has zero CI coverage today** (absent from both
  `test.yml` and `full-validation.yml` — confirmed by grep). Its sections still
  need porting per the PRD's 100%-coverage metric, but the port costs zero
  *additional* CI risk since nothing currently depends on it running.
- **A ported section might duplicate an already-existing e2e test** (see
  Reuse inventory's PgWire finding) — the mapping table must record
  "ALREADY COVERED" rather than write a redundant test; a redundant test
  is not wrong, just wasted authoring effort the PRD is trying to eliminate.
- **Windows-specific path/escaping behavior** currently exercised only via
  PowerShell must still be asserted somewhere in Rust once the `.ps1` files
  are gone. Rust's `std::path::Path` already handles platform separators
  correctly, so most of these sections likely need no special porting beyond
  running on `windows-full`'s existing runner — but any assertion that
  specifically tests *string* path formatting (not just behavior) needs a
  `cfg!(windows)` branch in the ported test, called out explicitly in the
  mapping table per PRD's own Risk note.
- **Next likely follow-ups after this PRD** (do not build now, but this design
  should not box them in): (a) PRD 00188 `ephemeral-serve-test-mode-v1` may
  want to swap `ServerGuard`'s child-process spawn for an in-process embedded
  server — the public API this PRD locks in (`start`/`url`/`graphql`/etc.) is
  exactly what 00188 needs to stay stable across that swap, per the PRD's own
  note; (b) a future PRD may want to run a curated e2e subset per-package
  rather than the whole crate for faster fast-gate feedback — the
  `smoke_`/`integration_` naming convention this design pins is what makes
  substring-filtered `cargo test` invocations like the one added to `test.yml`
  possible without a third mechanism (tags, feature flags, etc.).

## Test strategy outline

This PRD *is* the test suite — there is no separate "tests for the tests"
layer beyond what the PRD's own Success Metrics already specify: the mapping
table is the coverage-completeness proof (100% of shell sections mapped, zero
unmapped rows), each ported test is verified green locally before being marked
DONE in the table, and a green manual `full-validation` dispatch on all three
platforms is the CI-parity proof gate before the shell files are deleted. No
new test-of-tests infrastructure is introduced.

## Review log

**Dispatch 1 (Claude) non-blockers/questions (not fixed):**
- Non-blocking: `windows-full`'s deleted "Integration test" step carried a `timeout-minutes: 15` hang guard (relevant given the PRD's own history of PowerShell `Pop-Location` hangs); the consolidated "Full cargo test suite" step has no equivalent per-step timeout. Consider adding one, or note why the risk is now negligible (no PowerShell process involved).
- Non-blocking: Reuse inventory's "used in 30+ existing e2e files" is imprecise — verified actual count is 21 files (151 call sites, matching the separately-stated "100+ call sites" claim). Doesn't affect the design's conclusion.
- Question: this design supersedes the PRD's own named mitigation for §55 races ("serial markers", PRD line 148) with port/tempdir isolation instead. Well-justified by existing precedent, but the mapping table / Phase 1 task text should say explicitly that this supersedes the PRD's suggestion, so a task planner doesn't add an unneeded `serial_test` dependency.

dispatch 1 (claude): cardinal-sin 0, blocker 1, non-blocker 2, question 1


## Mapping table (coverage proof artifact)

# Mapping: four shell scenario inventories → Rust e2e targets

PRD: `dev/local/prds/wip/00171-migrate-shell-scenarios-to-e2e-v1.md`
Design: `dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-design.md`

Phase 0 coverage-proof artifact. Built by reading every numbered section's
body (not just its header) in both `tests/smoke.sh` (769 lines) and
`tests/smoke.ps1` (932 lines), then cross-checking each candidate target
against `tests/e2e/*.rs` (grep: `rg -n "fn " tests/e2e/*.rs`) before assigning
a new target test name.

Task 12 reconciliation (2026-09-05): all 391 source keys match the four
actual header inventories, and all executable targets resolve to registered
tests in the runner's discovery output. Assertion equivalence was audited
separately; see `dev/local/reviews/00171-task12-smoke-audit.md`,
`dev/local/reviews/00171-task12-parta-audit.md`, and
`dev/local/reviews/00171-task12-partb-audit.md`. Local validation and CI evidence
are recorded in the task verification reports before statuses are finalized.
The initial inventory's NEW/no-existing-test rationale below is historical;
it is not a claim that those tests are still absent. No shell survivor is planned.

## Conventions

- One row per shell section, keyed by `file:line`. `smoke.sh` and `smoke.ps1`
  each get their own row per section (dialect pairs are never merged into one
  row), but where the two dialects are exact mirrors of one scenario they
  share ONE target Rust test — the `smoke.ps1` row says "dialect pair, same
  target as smoke.sh:LINE" instead of repeating the analysis.
- `needs server?` is `No` for every smoke row: neither `smoke.sh` nor
  `smoke.ps1` ever invokes `ddb serve` — both are CLI-only scripts (verified:
  no `serve` token appears in either file). All targets are `DdbTestRepo`
  (`repo.ddb()`), not `ServerGuard`.
- `must-fail?` is `Yes` when the section's body contains at least one
  expected-failure assertion (bash bare `!` / `|| true` + error-text grep,
  PowerShell `ddb-fails` / explicit `$LASTEXITCODE` check), even if the
  section is otherwise a success-path scenario.
- `status` is `TODO` for sections whose implementation or validation is pending.
  Sections
  fully satisfied by an existing test are marked `DONE (pre-existing, no port
  needed)` — the mapping table's job for those rows is to record the
  cross-reference, not to queue a Phase 1 task. (ASSUMPTION: the design doc's
  "updated to DONE per section as Phase 1 tasks land" describes ports; rows
  that need no port are marked DONE now rather than sitting as TODO forever.)
- `smoke.ps1` has zero CI coverage today (absent from `test.yml` and
  `full-validation.yml` — confirmed by the PRD/design's own grep). Its rows
  are still mapped in full per the 100%-coverage metric; this fact is noted
  once here rather than repeated in every `smoke.ps1` row.

## Row count check

`rg -c "^# [0-9]" tests/smoke.sh tests/smoke.ps1` → 56 + 56 = 112 numbered
sections. This table has 112 rows (56 for `smoke.sh`, 56 for `smoke.ps1`),
one per section per file. Zero unmapped sections.

## Table

| file:line | section # | target e2e test | needs server? | must-fail? | status |
|---|---|---|---|---|---|
| tests/smoke.sh:26 | 1. init | `smoke_01_init` (NEW — no existing test asserts bare `ddb init` succeeds) | No | No | DONE |
| tests/smoke.ps1:66 | 1. init | dialect pair, same target as smoke.sh:26 (`smoke_01_init`) | No | No | DONE |
| tests/smoke.sh:30 | 2. create doogats (no sleeps — cross-process ID uniqueness) | compound: `smoke_02_create_unique_ids` (NEW, for the 3-unique-IDs assertion) + ALREADY COVERED (unregistered-type-warning half) by `cli_create_unregistered_type::cli_create_unregistered_type_creates_base_doogat_with_warning` | No | No | DONE |
| tests/smoke.ps1:70 | 2. create doogats | dialect pair, same target as smoke.sh:30 | No | No | DONE |
| tests/smoke.sh:42 | 3. read | `smoke_03_read` (NEW — no dedicated basic-read test found) | No | No | DONE |
| tests/smoke.ps1:87 | 3. read | dialect pair, same target as smoke.sh:42 | No | No | DONE |
| tests/smoke.sh:47 | 4. update | ALREADY COVERED by `cli_update_app_error::cli_update_existing_prints_updated_and_changes_title` + `sync_crdt::non_overlapping_edits_merge_cleanly` (one update supplies both title and tags; merged read preserves both values) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:92 | 4. update | dialect pair, same target as smoke.sh:47 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:52 | 5. delete | `smoke_05_delete` (NEW — delete, then read-after-delete fails, then delete-nonexistent fails; no existing test exercises basic delete + both failure paths together) | No | Yes | DONE |
| tests/smoke.ps1:98 | 5. delete | dialect pair, same target as smoke.sh:52 | No | Yes | DONE |
| tests/smoke.sh:58 | 6. status | `smoke_06_status` (NEW — basic `^head:` line; existing status coverage is scenario-specific, see 6b) | No | No | DONE |
| tests/smoke.ps1:104 | 6. status | dialect pair, same target as smoke.sh:58 | No | No | DONE |
| tests/smoke.sh:62 | 6b. broken backlink report on delete | ALREADY COVERED by `delete_backlinks::delete_reports_broken_backlinks` + `delete_backlinks::status_reports_broken_backlinks_after_delete` | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:109 | 6b. broken backlink report on delete | dialect pair, same target as smoke.sh:62 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:73 | 7. reindex | `smoke_07_reindex` (NEW — basic "indexed N doogats" count; `sql_lifecycle::reindex_preserves_table` asserts a different property) | No | No | DONE |
| tests/smoke.ps1:122 | 7. reindex | dialect pair, same target as smoke.sh:73 | No | No | DONE |
| tests/smoke.sh:77 | 7b. hashtag extraction | ALREADY COVERED by `tags::body_hashtag_indexed_with_source` (same behavior: hashtag extracted with `source` column set; different literal tag string, same assertion shape) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:127 | 7b. hashtag extraction | dialect pair, same target as smoke.sh:77 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:83 | 7c. checkbox parsing | ALREADY COVERED by `checkboxes::checkbox_filter_by_state` (state='open' filter over `_ddb_checkboxes`) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:134 | 7c. checkbox parsing | dialect pair, same target as smoke.sh:83 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:89 | 7d. folder namespace | ALREADY COVERED by `folder_namespace::insert_folder_typedef_creates_subdirectory_path` (SQL `INSERT` into a `folder: true` typedef materializes under `ddb/<type>/<id>.md`) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:141 | 7d. folder namespace | dialect pair, same target as smoke.sh:89 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:100 | 8. full-text search | ALREADY COVERED by `search_links::full_text_search` | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:151 | 8. full-text search | dialect pair, same target as smoke.sh:100 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:104 | 8b. paginated search | ALREADY COVERED by `search_links::paginated_search_shows_header` ("Showing 1-1 of" header) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:156 | 8b. paginated search | dialect pair, same target as smoke.sh:104 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:108 | 9. SQL queries | compound: `smoke_09_sql_queries` (NEW, for the plain `SELECT id, title FROM doogats` listing — no dedicated test asserts this bare shape) — the second query (`doogats JOIN _ddb_tags`) is ALREADY COVERED by `tags::tag_join_filters_doogats` (near-identical SQL) | No | No | DONE |
| tests/smoke.ps1:161 | 9. SQL queries | dialect pair, same target as smoke.sh:108 | No | No | DONE |
| tests/smoke.sh:113 | 10. wikilinks | ALREADY COVERED by `search_links::wikilink_indexed_in_links_table` | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:168 | 10. wikilinks | dialect pair, same target as smoke.sh:113 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:117 | 10a. link kinds (wikilink, markdown, embed, url) | ALREADY COVERED by `link_kinds::all_link_kinds_indexed` | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:173 | 10a. link kinds (wikilink, markdown, embed, bare_url) | dialect pair, same target as smoke.sh:117 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:128 | 10b. rename with backlink rewrite | ALREADY COVERED by `rename::rename_moves_file_and_rewrites_backlinks` | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:184 | 10b. rename with backlink rewrite | dialect pair, same target as smoke.sh:128 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:136 | 11. SQL DDL/DML | ALREADY COVERED by `sql_lifecycle::create_table` + `sql_lifecycle::insert_and_select` + `sql_lifecycle::update_row` + `sql_lifecycle::delete_row` (same CREATE/INSERT/SELECT/UPDATE/DELETE sequence, split across four focused tests) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:193 | 11. SQL DDL/DML | dialect pair, same target as smoke.sh:136 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:146 | 11c. Ghost-row + cross-mutation recovery pin (PRD 00124 group A1, issue #4) | ported regression: `smoke_11c_ghost_row_recovery` (NEW) — regression pin for issue #4 A1; verified no existing e2e test exercises "UNIQUE violation on duplicate INSERT, then a cross-mutation UPDATE recovers, then DROP" over the CLI `query` surface (`rg "UNIQUE\|ghost.row"` across tests/e2e/*.rs found no match) | No | Yes | DONE |
| tests/smoke.ps1:209 | 11c. Ghost-row + cross-mutation recovery pin | dialect pair, same target as smoke.sh:146 | No | Yes | DONE |
| tests/smoke.sh:160 | 11d. JOIN works smoke pin (PRD 00124 group E1, issue #8 obsolete) | ported regression: `smoke_11d_join_smoke_pin` (NEW) — regression pin for issue #8 (obsolete); generic multi-table JOIN is incidentally covered by `sql_lifecycle::multi_table_schema_prd_scenario` and `tags::tag_join_filters_doogats`, but neither pins this specific historical issue, so this stays its own dedicated regression test | No | No | DONE |
| tests/smoke.ps1:226 | 11d. JOIN works smoke pin | dialect pair, same target as smoke.sh:160 | No | No | DONE |
| tests/smoke.sh:170 | 11a. ALTER TABLE SET ZONE and TITLE TEMPLATE | `smoke_11a_alter_zone_title_template` (NEW) — `fix.rs` and `title_template_references.rs` use `SET ZONE`/`SET TITLE TEMPLATE` only as setup for unrelated assertions; none asserts the ALTER command's own success messages ("zone set to frontmatter", "title template set", "title template dropped") | No | No | DONE |
| tests/smoke.ps1:241 | 11a. ALTER TABLE SET ZONE and TITLE TEMPLATE | dialect pair, same target as smoke.sh:170 | No | No | DONE |
| tests/smoke.sh:176 | 11b. CREATE TABLE IF NOT EXISTS (idempotent) | `smoke_11b_create_table_if_not_exists` (NEW — no `IF NOT EXISTS` coverage found anywhere in tests/e2e/*.rs) | No | No | DONE |
| tests/smoke.ps1:250 | 11b. CREATE TABLE IF NOT EXISTS (idempotent) | dialect pair, same target as smoke.sh:176 | No | No | DONE |
| tests/smoke.sh:182 | 11e. ALTER TABLE RENAME TO (PRD 00132) | ALREADY COVERED by `alter_table_rename::cli_alter_table_rename_to_renames_typedef_and_data` (rename + row survives) + `alter_table_rename::cli_alter_table_rename_rejects_reserved_target` (reserved-name rejection) | No | Yes | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:259 | 11e. ALTER TABLE RENAME TO (PRD 00132) | dialect pair, same target as smoke.sh:182 | No | Yes | DONE (pre-existing, no port needed) |
| tests/smoke.sh:193 | 11f. Cross-process FK freshness on `ddb create` (PRD 00136, #16) | ALREADY COVERED by `cli_create_fk_freshness::create_link_after_category_in_separate_process_succeeds_without_reindex` (verified: identical two-process shape, same issue #16) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:275 | 11f. Cross-process FK freshness on `ddb create` (PRD 00136, #16) | dialect pair, same target as smoke.sh:193 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:204 | 11g. Inline column ZONE at CREATE TABLE (PRD 00160) | ALREADY COVERED by `inline_zone::inline_zone_frontmatter_materializes_and_survives_reindex` (verified: same CLI shape — inline `ZONE frontmatter` column, INSERT, `ddb read` shows the field in frontmatter) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:291 | 11g. Inline column ZONE at CREATE TABLE (PRD 00160) | dialect pair, same target as smoke.sh:204 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:211 | 12. install bundled type | `smoke_12_install_bundled_type` (NEW) — the bundled `contact` type is used as setup in several tests (e.g. `set_flag.rs`) but its own `ddb type install contact` → "installed type" success message is never independently asserted | No | No | DONE |
| tests/smoke.ps1:301 | 12. install bundled type | dialect pair, same target as smoke.sh:211 | No | No | DONE |
| tests/smoke.sh:215 | 12a. hyphenated type SQL (quoted identifiers) | ALREADY COVERED by `sql_lifecycle::install_meeting_minutes_type` (verified: identical shape — install `meeting-minutes`, quoted-identifier INSERT, `ddb read`, quoted-identifier DELETE). Note: `hyphenated_types.rs` is a *different* scenario (GraphQL typed-query resolution for a hyphenated type, not this CLI SQL flow) — not the match | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:306 | 12a. hyphenated type SQL (quoted identifiers) | dialect pair, same target as smoke.sh:215 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:222 | 13. type suggest | `smoke_13_type_suggest` (NEW — no `type suggest` coverage found anywhere in tests/e2e/*.rs) | No | No | DONE |
| tests/smoke.ps1:316 | 13. type suggest | dialect pair, same target as smoke.sh:222 | No | No | DONE |
| tests/smoke.sh:227 | 14. register node + compact | `smoke_14_register_node_and_compact` (NEW) — `register-node` appears elsewhere only as multi-device test setup (`common.rs`, `multi_device.rs`, `sync_crdt.rs`), never asserting `status` node count or `compact --force`'s own output lines (backup/gc/crdt temp/repo stats) | No | No | DONE |
| tests/smoke.ps1:322 | 14. register node + compact | dialect pair, same target as smoke.sh:227 | No | No | DONE |
| tests/smoke.sh:237 | 15. node list + retire | `smoke_15_node_list_and_retire` (NEW — no `node list`/`node retire` coverage found anywhere in tests/e2e/*.rs) | No | No | DONE |
| tests/smoke.ps1:334 | 15. node list + retire | dialect pair, same target as smoke.sh:237 | No | No | DONE |
| tests/smoke.sh:243 | 16. compact --dry-run | `smoke_16_compact_dry_run` (NEW) | No | No | DONE |
| tests/smoke.ps1:342 | 16. compact --dry-run | dialect pair, same target as smoke.sh:243 | No | No | DONE |
| tests/smoke.sh:249 | 16a. compact --no-backup | `smoke_16a_compact_no_backup` (NEW) | No | No | DONE |
| tests/smoke.ps1:348 | 16a. compact --no-backup | dialect pair, same target as smoke.sh:249 | No | No | DONE |
| tests/smoke.sh:259 | 16b. compact --backup-path | `smoke_16b_compact_backup_path` (NEW) | No | No | DONE |
| tests/smoke.ps1:355 | 16b. compact --backup-path | dialect pair, same target as smoke.sh:259 | No | No | DONE |
| tests/smoke.sh:267 | 16c. maintenance | `smoke_16c_maintenance` (NEW) — covers `maintenance run`, `maintenance auto status` (default off), `maintenance auto on`, `maintenance auto off`; no existing test exercises the `maintenance` subcommand family (earlier grep hits on the word "maintenance" in `typed_where_filter.rs`/`serve.rs` are unrelated prose, not command coverage) | No | No | DONE |
| tests/smoke.ps1:363 | 16c. maintenance | dialect pair, same target as smoke.sh:267 | No | No | DONE |
| tests/smoke.sh:283 | 16d. discover | ALREADY COVERED by `discover::discover_stale`, `discover::discover_orphans`, `discover::discover_mentions`, `discover::discover_similar`, `discover::discover_recent_shows_new_doogat`, `discover::discover_link_density_shows_hub` (one existing test per `discover` subcommand exercised in this section) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:382 | 16d. discover | dialect pair, same target as smoke.sh:283 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:305 | 16e. consistency fix | ALREADY COVERED by `fix::fix_dry_run_no_changes`, `fix::fix_commits_changes`, `fix::fix_idempotent` (dry-run/apply/idempotent sequence matches) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:409 | 16e. consistency fix | dialect pair, same target as smoke.sh:305 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:321 | 16f. sequence navigation | compound section — its body runs to smoke.sh:417 (next header is `# 17.` at smoke.sh:418) and also carries three *unnumbered* blocks (`--log-level` flag, help guides, app-building end-to-end flow) that have no header of their own. Sequence nav ALREADY COVERED by `sequence::sequence_tree_display`, `sequence::sequence_breadcrumb_display`, `sequence::sequence_broken_list`. Help guides ALREADY COVERED by `help::help_create_app_prints_guide`, `help::help_no_topic_lists_guides`, `help::help_unknown_topic_fails`. Still needed (both ported regressions — no existing test covers either): `smoke_16f_log_level_flag` (`--log-level debug` accepted) and `smoke_16f_app_building_flow` (ENUM column + junction table + `SET TITLE TEMPLATE '{url}'` end-to-end; `sql_lifecycle::multi_table_schema_prd_scenario` is a different fixture — workspace/section/link, no ENUM, no title template — so it does not satisfy this) | No | Yes (help-unknown-fails sub-assertion) | DONE |
| tests/smoke.ps1:430 | 16f. sequence navigation | dialect pair, same target/compound analysis as smoke.sh:321 | No | Yes | DONE |
| tests/smoke.sh:418 | 17. cascade delete | ALREADY COVERED by `cascade_delete::cascade_delete_cleans_junction_table` + `cascade_delete::cascade_delete_removes_wikilink_from_referencing_file` | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:531 | 17. cascade delete | dialect pair, same target as smoke.sh:418 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:441 | 17b. cascade delete (parent direction, PRD 00137) | ALREADY COVERED by `cascade_delete::cascade_delete_cleans_owned_junction_when_parent_deleted` | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:554 | 17b. cascade delete (parent direction, PRD 00137) | dialect pair, same target as smoke.sh:441 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:465 | 18. cascade delete via ddb delete (service path) | ALREADY COVERED by `cascade_delete::cascade_delete_via_ddb_delete_cleans_junction_and_refs` | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:581 | 18. cascade delete via ddb delete (service path) | dialect pair, same target as smoke.sh:465 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:485 | 18b. RESTRICT on NOT NULL REFERENCES (#10) | ALREADY COVERED by `cascade_delete::delete_rejected_by_not_null_references_sql_issue_10` (SQL DELETE path) + `cascade_delete::delete_rejected_by_not_null_references_cli_issue_10` (CLI `ddb delete` path) | No | Yes | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:600 | 18b. RESTRICT on NOT NULL REFERENCES (#10) | dialect pair, same target as smoke.sh:485 | No | Yes | DONE (pre-existing, no port needed) |
| tests/smoke.sh:511 | 19. boolean consistency in SQL responses | `smoke_19_boolean_consistency` (ported regression) — verified: the only existing BOOLEAN-coercion coverage (`server_mutations.rs`, `serve.rs`) is GraphQL-transport-specific; no test asserts the CLI `ddb query` SELECT-side true/false/NULL coercion this section binds | No | No | DONE |
| tests/smoke.ps1:627 | 19. boolean consistency in SQL responses | dialect pair, same target as smoke.sh:511 | No | No | DONE |
| tests/smoke.sh:534 | 20. type tables are self-contained (no JOIN needed for core columns) | `smoke_20_type_table_self_contained` (NEW — no existing test asserts core columns (`id, title, date, updated_at`) are queryable from a typed table without a JOIN) | No | No | DONE |
| tests/smoke.ps1:650 | 20. type tables are self-contained | dialect pair, same target as smoke.sh:534 | No | No | DONE |
| tests/smoke.sh:542 | 21. DEFAULT NEXT auto-increment | ALREADY COVERED by `sql_lifecycle::default_next_auto_increments` (verified: identical shape — sequential 1/2/3, explicit override to 99, next auto-value 100) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:658 | 21. DEFAULT NEXT auto-increment | dialect pair, same target as smoke.sh:542 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:564 | 22. FTS5 search boost (search_boost on typedef columns) | `smoke_22_fts5_search_boost` (ported regression) — verified: the only "FTS5"-adjacent hit in tests/e2e (`sql_lifecycle.rs:702`) is an unrelated comment on a generic search call, not a `search_boost` assertion | No | No | DONE |
| tests/smoke.ps1:680 | 22. FTS5 search boost | dialect pair, same target as smoke.sh:564 | No | No | DONE |
| tests/smoke.sh:571 | 23. SQL expression support (COALESCE, IFNULL, arithmetic in VALUES/SET) | ALREADY COVERED by `sql_expressions_test::insert_with_coalesce`, `update_with_ifnull`, `insert_with_arithmetic`, `nullif_in_insert`, `insert_with_nested_expression`, `insert_rejects_unlisted_function` (verified CLI-based, one test per expression case this section exercises) | No | Yes (unlisted-function-rejection sub-assertion) | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:688 | 23. SQL expression support | dialect pair, same target as smoke.sh:571 | No | Yes | DONE (pre-existing, no port needed) |
| tests/smoke.sh:594 | 24. --set / --unset flags on create and update | ALREADY COVERED by `set_flag::create_with_multiple_set_flags` + `set_flag::update_set_adds_field` + `set_flag::update_unset_removes_field` + `set_flag::update_set_empty_value_clears_field` + `set_flag::create_with_malformed_set_returns_error` (multiple untyped fields, set/unset/clear and malformed-input rejection) | No | Yes (malformed-`--set` sub-assertion) | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:715 | 24. --set / --unset flags | dialect pair, same target as smoke.sh:594 | No | Yes | DONE (pre-existing, no port needed) |
| tests/smoke.sh:610 | 25. SQL INSERT defaults date from doogat ID | ALREADY COVERED by `date_default::insert_without_date_derives_from_id` + `date_default::insert_with_explicit_date_preserves_value` (verified: identical shape) | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:733 | 25. SQL INSERT defaults date from doogat ID | dialect pair, same target as smoke.sh:610 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:619 | 26. FTS negation search | `smoke_26_fts_negation` (ported regression) — verified: no existing test exercises FTS `NOT` query negation (positive-NOT-negative and all-negative shapes) | No | No | DONE |
| tests/smoke.ps1:744 | 26. FTS negation search | dialect pair, same target as smoke.sh:619 | No | No | DONE |
| tests/smoke.sh:633 | 27. ON CONFLICT DO NOTHING (upsert) | `smoke_27_on_conflict_do_nothing` (ported regression) — verified: `upsert.rs` exercises the same `unique_together` business rule but through the GraphQL `createMany(onConflict: IGNORE)` mutation, not the CLI `ddb query "INSERT ... ON CONFLICT DO NOTHING"` SQL syntax this section binds; different transport, not a duplicate | No | No | DONE |
| tests/smoke.ps1:758 | 27. ON CONFLICT DO NOTHING (upsert) | dialect pair, same target as smoke.sh:633 | No | No | DONE |
| tests/smoke.sh:652 | 28. in-query field filter substring + REFERENCES title resolution (PRD 00133) | `smoke_28_in_query_field_filter` (ported regression) — verified: `search_in_filter.rs` and `search_junction_filter.rs` both test the GraphQL `search(where: [...])` filter DSL, a different feature from the CLI `ddb search "field=value"` inline filter syntax (title substring match + REFERENCES-column title resolution) this section binds | No | No | DONE |
| tests/smoke.ps1:783 | 28. in-query field filter + REFERENCES title resolution | dialect pair, same target as smoke.sh:652 | No | No | DONE |
| tests/smoke.sh:671 | 29. ALTER TABLE ALTER COLUMN TYPE (PRD 00128) | ALREADY COVERED by `alter_column_type::widens_varchar_to_text_and_accepts_longer_values` (verified: identical shape — VARCHAR(N) → TEXT widening, longer value now accepted, persists across a fresh process). Note: `alter_column_type::narrowing_rejects_with_row_count_message` covers a *different* scenario (narrowing) not present in this smoke section — not needed here | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:802 | 29. ALTER TABLE ALTER COLUMN TYPE (PRD 00128) | dialect pair, same target as smoke.sh:671 | No | No | DONE (pre-existing, no port needed) |
| tests/smoke.sh:683 | 30. SINGLETON typedef CRUD (PRD 00139) | ported regression: `smoke_30_singleton_typedef_crud` (NEW) — verified: `alter_singleton::after_set_singleton_second_insert_rejects_with_constraint` uses `ALTER TABLE ... SET SINGLETON` (retrofit) not `CREATE TABLE ... SINGLETON` and never asserts the post-rejection UPDATE-still-works step; `singleton_cross_process_*.rs` cover concurrent-process races, a different scenario from this section's single-process CREATE → duplicate-INSERT-rejected → UPDATE-survives flow | No | Yes | DONE |
| tests/smoke.ps1:815 | 30. SINGLETON typedef CRUD (PRD 00139) | dialect pair, same target as smoke.sh:683 | No | Yes | DONE |
| tests/smoke.sh:700 | 31. declarative schema apply/diff (PRD 00161) | ALREADY COVERED by `schema_apply::dry_run_prints_plan_and_creates_nothing` + `schema_apply::apply_creates_declared_type` + `schema_apply::reapply_is_idempotent_noop` (verified: identical dry-run/apply/idempotent-reapply sequence) | No | Yes (dry-run-creates-nothing sub-assertion) | DONE (pre-existing, no port needed) |
| tests/smoke.ps1:835 | 31. declarative schema apply/diff (PRD 00161) | dialect pair, same target as smoke.sh:700 | No | Yes | DONE (pre-existing, no port needed) |
| tests/smoke.sh:713 | 32. poison-file reindex resilience (PRD 00169) | compound: ALREADY COVERED by `poison_file_reindex::lenient_reindex_skips_poison_file_and_indexes_the_rest` + `poison_file_reindex::strict_reindex_fails_and_names_the_poison_file` (verified: identical two-part scenario, same POISON_PATH constant convention) for the reindex-lenient/reindex-strict halves. The section's trailing "cli still answers queries after a strict reindex abort" assertion is NOT covered by those two tests (they don't run a query after the strict abort) — `smoke_32_cli_answers_after_strict_abort` (ported regression; the smoke test's own comment block explains why this checks CLI usability, not index-preservation, which is bound at unit level instead) | No | Yes | DONE |
| tests/smoke.ps1:859 | 32. poison-file reindex resilience (PRD 00169) | dialect pair, same target/compound analysis as smoke.sh:713 | No | Yes | DONE |
| tests/smoke.sh:743 | 33. reindex report + ddb create AppWarning surface skipped files (PRD 00169 gap closure) | `smoke_33_reindex_report_and_create_warning` (ported regression) — verified via `rg "REINDEX_SKIPPED_FILES"` across tests/e2e/*.rs: zero matches. Neither gap (reindex's own report naming the skipped path under `RUST_LOG=error`; `ddb create`'s AppWarning envelope surfacing `REINDEX_SKIPPED_FILES` after a poison commit) is covered by `poison_file_reindex.rs`, which only exercises the tracing-channel assertions from section 32 | No | No | DONE |
| tests/smoke.ps1:891 | 33. reindex report + ddb create AppWarning surface skipped files | dialect pair, same target as smoke.sh:743 | No | No | DONE |
| tests/integration.sh:52 | 17. GraphQL server | compound: ALL sub-assertions ALREADY COVERED — auth-reject-401 by `serve::auth_missing_token_returns_401`, health-endpoint by `serve::health_returns_ok`+`serve::health_no_auth_required`, graphql-query(typeDefs) by `serve::search_and_list` (asserts `{ typeDefs { name } }` succeeds), graphql-create by `serve::crud_lifecycle` (create step asserts title/body on `createDoogat`) | Yes | Yes | DONE (pre-existing, no port needed) |
| tests/integration.sh:160 | 17.J1. Jink schema CREATE TABLE definitions (#9 jink full-sweep section 1) | `integration_17j1_jink_schema_create_tables` (NEW — no jink-port e2e test exists anywhere; `rg -n "jink" tests/e2e/*.rs` returns zero matches, so none of the 7 jink table CREATEs, including the two hyphenated-identifier tables, are pinned outside this shell script) | Yes | No | DONE |
| tests/integration.sh:164 | N/A — comment fragment, not a distinct section | N/A — mid-sentence comment fragment ("# 20 drops them all at the end...") inside `# 17.J1`'s body (tests/integration.sh:160-205), incidentally matches the header regex. Folded into the 17.J1 row (tests/integration.sh:160) — same target, same answers | Yes | No | DONE |
| tests/integration.sh:205 | 17.J2. jink-config singleton + Link CRUD (#9 jink full-sweep sections 3-4) | `integration_17j2_jink_config_singleton_and_link_crud` (NEW; review restores the 14-digit ASCII singleton ID assertion alongside empty-singleton SELECT, singleton INSERT, link CRUD, and compound-predicate UPDATE) | Yes | No | DONE (review assertions restored) |
| tests/integration.sh:243 | 18. expanded GraphQL operations (update, enriched search, doogats list, delete) | compound: ALREADY COVERED — update+delete by `serve::crud_lifecycle`, search-with-enriched-fields (tags/type/fields/created_at) by `serve::search_returns_enriched_fields` (verified: identical field set requested and asserted), doogats-list by `serve::search_and_list` | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:262 | 18b. GraphQL checkbox queries (openActions) | ALREADY COVERED by `checkboxes::checkbox_graphql_queries` (verified: same `{ openActions { state content } }` query, asserts exactly 1 open item returned) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:267 | 18c. GraphQL tag queries (create with tags, `tags{name count}` query, doogats tag filter) | compound: doogats-tag-filter half ALREADY COVERED by `serve::search_and_list` (`doogats(tag: "alpha")` list-by-tag assertion). The top-level `{ tags { name count } }` query and the create-with-tags-value-assertion are NEW — `integration_18c_graphql_tag_queries` (verified: `rg -n "tags \{ name" tests/e2e/*.rs` and `rg -n "\"tags\"" ` return no hits; `serve::crud_lifecycle` requests `tags` on create but never asserts its value) | Yes | No | DONE |
| tests/integration.sh:284 | 18c2. GraphQL updated_at and created_at fields (equality + presence on search hits) | `integration_18c2_updated_at_created_at_fields` (NEW — verified via `rg -n "updated_at" tests/e2e/*.rs`: zero matches anywhere in the e2e suite; no test asserts `doogat(id){updated_at created_at date}` or that `created_at == date`) | Yes | No | DONE |
| tests/integration.sh:305 | 18d. GraphQL search filters (by type, by tag, combined type+tag) | `integration_18d_search_filter_by_type_and_tag` (NEW — verified via `rg -n "search\(query.*types:\|search\(query.*tag:" tests/e2e/*.rs`: only one hit, `serve::search_where_filter_combined_type_and_field` (type + `where:` field filter, a different combination — see 18d2). No test exercises the top-level `search(query, types: [...])` or `search(query, tag: ...)` params alone or combined) | Yes | No | DONE |
| tests/integration.sh:335 | 18d2. Search where field filters (materialized columns + tag) | `serve::search_where_filter_materialized_column_eq` + `serve::search_where_filter_materialized_column_contains` + `serve::search_where_filter_tag` + `serve::search_where_filter_combined_type_and_field` (review strengthens the existing eq case: exact URL versus a /page suffix fixture, one hit and totalCount 1) | Yes | No | DONE (review assertions restored) |
| tests/integration.sh:377 | 18d3. Search where filter: in operator (tag in, materialized column in, empty array) | ALREADY COVERED by `search_in_filter::search_where_in_tag` + `search_in_filter::search_where_in_materialized_column` + `search_in_filter::search_where_in_empty_returns_no_results` (multi-value and single-value tag membership, materialized membership and empty input) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:429 | 18e. Boolean and phrase search queries (AND/OR/NOT/phrase + malformed-query error) | ALREADY COVERED by `serve::search_boolean_and_phrase_queries` (AND/OR/NOT/phrase, identical totalCount assertions) + `serve::search_malformed_query_returns_bad_request` ("AND AND" → "invalid search query") | Yes | Yes | DONE (pre-existing, no port needed) |
| tests/integration.sh:465 | 18g. Search query normalization (AND-sort, field-filter-sort, implicit-AND+lowercase, search() queryNormalized) | `serve::normalize_search_query_standalone` + `serve::search_returns_query_normalized` + `integration_graphql_server::integration_18g_normalize_query_implicit_and_lowercase` (standalone B AND A, field sorting, implicit AND/lowercase, and search queryNormalized) | Yes | No | DONE |
| tests/integration.sh:483 | 18h. In-query field-filter alignment + error-class consistency (PRD 00121) | `integration_18h_in_query_field_filter_and_error_class` (NEW — verified: no test exercises the in-query `search(query: "tag=X")` filter syntax at all (`rg -n "tag=\|prd121"` across tests/e2e/*.rs: only unrelated `?tag=` REST/GraphQL-arg hits, no in-query-string usage), and the `search()`-field error-class pins for bare `*`/`**`/unbalanced-paren/bare-`AND` are only tested via the separate `normalizeSearchQuery()` field (`serve::normalize_search_query_rejects_*`), not via `search()` itself — only "AND AND" is pinned through `search()` (`serve::search_malformed_query_returns_bad_request`), so the other malformed shapes on the `search()` surface this PRD specifically targets remain unpinned) | Yes | Yes | DONE |
| tests/integration.sh:548 | 18i. In-query field-filter substring + REFERENCES title resolution (PRD 00133) | `integration_18i_in_query_substring_and_references_title` (NEW — verified via `rg -n "title=\|int133" tests/e2e/*.rs`: zero matches; no test covers in-query `title=X` substring matching or `<ref_col>=X` resolving through a REFERENCES column's target title) | Yes | No | DONE |
| tests/integration.sh:584 | 18z. UPDATE/DELETE WHERE id no-match GraphQL parity (issue #5 group B) | `integration_18z_update_delete_no_match_parity` (NEW — verified via `rg -n "does_not_exist\|affected.*0" tests/e2e/*.rs`: no hits in any GraphQL-transport test; the B1-B5 no-match/compound-predicate/IN-clause `affected:0`/`affected:1` behaviors are unpinned at the `executeSql` GraphQL surface) | Yes | No | DONE |
| tests/integration.sh:619 | 18z2. executeBatch atomicity (issue #9 group F4) | `integration_18z2_execute_batch_atomicity` (NEW — verified: `serve::execute_batch_format_objects` only exercises `executeBatch`'s `format:"objects"` shape with a single SELECT, not atomicity; `server_mutations::batch_update_atomicity_via_graphql` tests the different `batchUpdate` structured mutation, not `executeBatch`'s raw-SQL-statement array — no test proves a UNIQUE-violating second statement rolls back the first statement's effect) | Yes | Yes | DONE |
| tests/integration.sh:648 | 18z3. updateDoogat tag semantics (#9 F5/F6/F7: clear, dedupe, unicode) | `integration_18z3_update_doogat_tag_semantics` (NEW — verified via `rg -n "tags: \[\]\|dedup\|unicode\|日本語\|café" tests/e2e/*.rs`: zero matches; no test asserts `updateDoogat(tags: [])` clears all tags, duplicate input tags dedupe, or unicode tags round-trip intact) | Yes | No | DONE |
| tests/integration.sh:689 | 18z4. SQL feature coverage pins (#9 F9: COUNT, GROUP BY, ORDER BY, LIMIT, OFFSET, IS NULL, LIKE) | `integration_18z4_sql_feature_coverage_pins` (NEW — verified via `rg -n "COUNT\(\*\)\|GROUP BY\|LIMIT.*OFFSET\|IS NULL" tests/e2e/serve.rs`: zero matches; `sql_lifecycle.rs` pins these features via the CLI, not the GraphQL `sql()` field this section exercises — different transport, not a duplicate) | Yes | No | DONE |
| tests/integration.sh:729 | 18z5. search() limit boundary pins (#9 F10: 0, 10000, 10001, -1) | `integration_18z5_search_limit_boundary_pins` (NEW — verified via `rg -n "limit: 10000\|limit: 0\|limit must not exceed\|limit: -1" tests/e2e/*.rs`: zero matches; no test pins the `search()` field's limit-boundary behavior or the 10000 hard-max rejection message) | Yes | Yes | DONE |
| tests/integration.sh:760 | 18z6. ALTER TABLE ADD COLUMN surfaces in typeDefs introspection (#9 F11) | `integration_18z6_alter_table_add_column_in_typedefs_introspection` (NEW — verified: `serve::alter_table_column_visible_in_graphql` proves the new column is *queryable* via the typed field (`notes { items { priority } }`), a different mechanism from this section's assertion that the `typeDefs { columns { name dataType } }` introspection query reflects the column; `rg -n "typeDefs.*columns\|columns.*dataType"` finds no test using that query shape) | Yes | No | DONE |
| tests/integration.sh:792 | 18z7. GraphQL schema introspection contract (#9 group G: Aggregate field + Connection type shape) | `integration_18z7_graphql_schema_introspection_contract` (NEW — verified: `serve::aggregate_query` calls `tasksAggregate` directly (usage) but never introspects `__schema` to confirm the field exists; `serve::graphql_introspection_hides_internal_tables` uses `__schema.queryType.fields` for a different assertion (hiding internal tables); no test walks `__schema.types` to confirm a `*Connection` type carries `items`+`totalCount`) | Yes | No | DONE |
| tests/integration.sh:830 | 18z8. Category + membership jink port (#9 jink full-sweep section 5) | `integration_18z8_jink_category_membership_port` (NEW — no jink-port e2e test exists; category INSERT, `categories(where:...)` by space/fqn-IN, COALESCE+subquery sort_order INSERT, and `categoryMemberships` filtering by link_id/category_fqn are all unpinned outside this shell script) | Yes | No | DONE |
| tests/integration.sh:870 | 18z9. Jink quotes + saved-searches + pinned-results + jinkConfigs port (#9 jink full-sweep sections 10-12) | `integration_18z9_jink_quotes_saved_searches_pinned_results_config_port` (NEW — no jink-port e2e test exists; quote/saved-search/pinned-result INSERT+query and jink-config compound-predicate UPDATE are all unpinned outside this shell script) | Yes | No | DONE |
| tests/integration.sh:935 | 18z10. Composite UNIQUE duplicate + compound-predicate DELETE jink port (#9 jink full-sweep sections 6+13) | `integration_18z10_jink_composite_unique_and_batch_delete_port` (NEW — no jink-port e2e test exists; composite-UNIQUE-duplicate rejection and `executeBatch` compound-predicate DELETE across category-membership+link are unpinned outside this shell script) | Yes | Yes | DONE |
| tests/integration.sh:974 | 19. REST API CRUD (create/read/update/delete/auth/field-filter/tag-filter/sort) | compound: create/read/update/delete/auth-401/field-filter(+no-match)/tag-filter ALREADY COVERED by `rest::rest_crud_lifecycle` (or `serve::rest_crud_lifecycle`, near-duplicate) + `serve::rest_auth_required` + `serve::rest_filter_by_field` (verified: covers both the match and nonexistent-value-returns-empty cases) + `serve::rest_filter_by_tag`. The `?sort=` parameter (ascending, descending, date-default-descending, invalid-field-400) is NEW — `integration_19_rest_sort_parameter` (verified via `rg -n "sort=\|sort:\|ascending\|descending\|invalid.*sort" tests/e2e/*.rs`: zero matches) | Yes | Yes | DONE |
| tests/integration.sh:1067 | 20. PgWire basic query (body mechanically extends to line 1178, next numbered header at 1179 — absorbs the unrelated NoSQL/compact/maintenance/sync tail with no header of its own) | compound: pgwire-select/auth-reject/`\dt`-hides-internal/direct-internal-access ALREADY COVERED by `pgwire::pgwire_select_with_columns`+`pgwire::pgwire_connect_auth_ok`, `pgwire::pgwire_auth_rejected`, `pgwire::pgwire_pg_catalog_hides_internal_tables` (both `\dt` and direct-access assertions, verified). REST-404 ALREADY COVERED by `rest::rest_get_unknown_id_returns_404`. GraphQL-introspection-hides-internal ALREADY COVERED exactly by `serve::graphql_introspection_hides_internal_tables`. compact/`compact(force)`/`compact(noBackup)`/sync-no-remote-errors ALREADY COVERED by `server_mutations::compact_mutation_returns_result`+`compact_force_mutation`+`compact_no_backup_mutation`+`sync_mutation_no_remote_returns_error`. Additional coverage implemented in: `integration_20_pgwire_boolean_type` (BOOLEAN column t/f coercion via pgwire — `rg -n "BOOLEAN\|boolean" tests/e2e/pgwire*.rs` finds nothing), `integration_20_nosql_endpoints` (GET /nosql/:id, scan-by-tag, type+tag-rejection-400, auth-reject-401 — `rg -n "nosql" tests/e2e/*.rs` only matches unrelated CLI-help-text tests in help.rs), `integration_20_sql_engine_error_descriptive` (malformed-SQL "parse:" message via GraphQL executeSql — no match found), `integration_20_compact_custom_backup_path` (compact's `backupPath` argument override and file creation — only default/noBackup paths are tested), `integration_20_maintenance_mutation` (GraphQL `maintenance` mutation — zero e2e coverage found) | Yes | Yes | DONE |
| tests/integration.sh:1179 | 37. WebSocket payload auth (browser-style, no Authorization header) | ALREADY COVERED by `subscriptions::ws_payload_auth_subscribe_receive` (verified: identical payload-based `connection_init` auth, more thorough — completes a full subscribe→mutate→receive cycle vs. the shell's connection_ack-only check) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:1189 | 38. read-under-write: concurrent read + write | ALREADY COVERED by `read_pool::concurrent_reads_during_write` (verified: concurrent GraphQL+REST reads fired alongside an in-flight write, then both verified to have succeeded — same property, more thorough than the shell's single-read-plus-write) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:1199 | 38b. multi-value references via GraphQL + REST | compound: GraphQL multi-value-ref plural-list-field half ALREADY COVERED by `relation_resolution::batch_plural_references_multiple_items` (verified: same junction-table multi-category-per-bookmark shape). The REST "structured references object" half is NEW — `integration_38b_rest_structured_references_object` (verified via `rg -n "\"references\"" tests/e2e/*.rs`: zero matches; no REST test asserts a `references` key wrapping multi-value REFERENCES data in the GET response body) | Yes | No | DONE (REST-references half only; test passes) |
| tests/integration.sh:1222 | 38b2. REFERENCES relation resolution (singular object, plural list, null+empty) | ALREADY COVERED by `relation_resolution::singular_reference_resolves_as_typed_object` + `relation_resolution::plural_reference_resolves_as_typed_object_list` + `relation_resolution::null_reference_returns_null` (verified: exact match on all three cases — singular resolves object, plural resolves list, unlinked reference returns null/empty-list) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:1248 | 38b2b. raw ID scalar + orderBy/limit on plural references | `reference_raw_id::raw_id_coexists_with_object_resolver` + `reference_raw_id::raw_id_field_pins_first_linked_with_multiple_junction_rows` + `reference_raw_id::plural_resolver_with_order_by` + `reference_raw_id::plural_resolver_with_order_by_desc` + `reference_raw_id::plural_resolver_with_limit` + `reference_raw_id::plural_resolver_with_order_by_and_limit` (preserves one-reference scalar/object coexistence; new three-junction-row variant pins the first-linked scalar independently of ID order; existing plural ordering/limit cases retained) | Yes | No | DONE (review assertions restored) |
| tests/integration.sh:1283 | 38b3. typed connection includes tags | ALREADY COVERED by `relation_resolution::typed_connection_includes_tags` (verified: identical shape — `article`/`tagarticle` typed table, `updateDoogat` tags, tags visible via the typed connection's `items { tags }`) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:1293 | 38b4. tagEntries query with filters (doogatId eq, tag eq, tag contains) | ALREADY COVERED by `tag_entries::tag_entries_filter_by_doogat_id` + `tag_entries::tag_entries_filter_by_tag_eq` + `tag_entries::tag_entries_filter_by_tag_contains` (verified: identical `where: { doogatId: { eq } }` / `{ tag: { eq/contains } }` shapes and totalCount assertions) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:1316 | 38c. sql-materialization (columns, boolean normalization, core fields) | ALREADY COVERED by `serve::sql_default_format_returns_arrays` (verified: identical query `{ sql(query: "SELECT id, title FROM doogats") { columns rows } }`, asserts non-empty array-shaped rows; column-name correctness is additionally pinned by `serve::sql_columns_aliased`/`serve::sql_columns_star_select`) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:1323 | 38c2. sql format:objects returns keyed rows (compound: also asserts BOOLEAN true/false coercion and core-fields-visible-in-type-table) | compound: format:objects-keyed-rows half ALREADY COVERED by `serve::sql_format_objects_returns_keyed_rows` (creates a doogat, queries `sql(format: "objects")`, asserts each row parses as a JSON object keyed by `id`/`title` — identical assertion); core-fields-in-type-table half ALREADY COVERED incidentally by `serve::execute_sql_format_objects` (SELECT of a type-table column via GraphQL returns the inserted value) — but the BOOLEAN true/false coercion half (smokepin.pinned) has zero coverage anywhere in tests/e2e (verified via `rg "bool\|Bool"`, only unrelated `compact.gcSuccess`/`health.index_reachable` hits) → `integration_38c2_boolean_coercion` (NEW) | Yes | No | DONE (boolean-coercion half only; test passes) |
| tests/integration.sh:1347 | 38d. DISTINCT on typed connection queries | `integration_38d_distinct_typed_query` (NEW — zero `distinct:` GraphQL-argument coverage anywhere in tests/e2e/*.rs; confirmed via `rg "distinct\|groupBy"`, only unrelated prose/variable-naming hits) | Yes | No | DONE (test passes) |
| tests/integration.sh:1360 | 38e. GROUP BY on typed aggregate queries | `integration_38e_groupby_aggregate` (NEW — `serve::aggregate_query`/`aggregate_with_filter` exercise `tasksAggregate` without a `groupBy` argument; no test asserts per-group `key`/`count`/`minBaz`/`maxBaz`) | Yes | No | DONE (test passes) |
| tests/integration.sh:1380 | 38f. executeBatch mutation (multi-INSERT, DDL-triggers-reload, failure-rollback) | `integration_38f_execute_batch_multi_statement` (NEW — `serve::execute_batch_format_objects` only covers the `format:"objects"` shape on a single-statement batch; no test covers multi-statement INSERT batches, a DDL statement inside `executeBatch` triggering schema reload, or all-or-nothing rollback on a mid-batch failure) | Yes | Yes | DONE (test passes) |
| tests/integration.sh:1407 | 38g. batchUpdate mutation | ALREADY COVERED by `server_mutations::batch_update_via_graphql` (identical shape: create 3 doogats, `batchUpdate` all 3 titles in one mutation, assert 3 results with correct id/title pairs, re-query each to confirm persistence) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:1429 | 38h. createMany mutation | ALREADY COVERED by `server_mutations::create_many_basic` (3-input createMany, asserts order/titles/distinct ids and re-query persistence) plus `server_mutations::create_many_empty` (empty-input sub-check) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:1457 | 38i. typed field updates via GraphQL (updateDoogat fields/unsetFields, deleteDoogat cleanup) plus trailing unnumbered hyphenated-type-name block | compound: fields/unsetFields/delete-cleanup ALREADY COVERED by `typed_field_mutations::update_doogat_with_fields_updates_materialized_row` + `typed_field_mutations::update_doogat_with_unset_fields_removes_field` + `typed_field_mutations::delete_doogat_cleans_materialized_row` (identical bookmark/url fixture and assertion sequence); the trailing "Hyphenated type names in GraphQL" block is ALREADY COVERED by `hyphenated_types::hyphenated_type_typed_query` (same CREATE/INSERT/typed-query/totalCount/status/priority shape) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:1498 | 42. base field filters on typed queries (id, title) | `serve::filter_base_field_title_eq` + `serve::filter_base_field_id_eq` + `serve::filter_base_field_title_contains` + `serve::filter_base_field_id_nonexistent` (review restores explicit totalCount == 1 assertions to both title-filter cases) | Yes | No | DONE (review assertions restored) |
| tests/integration.sh:1529 | 42b. base-field orderBy (created_at/updated_at/id) + deterministic pagination (PRD 00158) | `integration_orderby_base_fields::integration_42b_orderby_base_fields_deterministic_pagination` — actual spawned-server test; every created_at/updated_at/id ASC/DESC ordering and both deterministic pages match the two source dialects | Yes | No | DONE |
| tests/integration.sh:1603 | 43. SQL INSERT via executeSql defaults date, created_at non-null | `integration_43_sql_insert_defaults_date_graphql` (NEW — `date_default::insert_without_date_derives_from_id`/`insert_with_explicit_date_preserves_value` cover the identical assertion but via the CLI `ddb query` transport only; this section drives it through GraphQL `executeSql`/`executeBatch`, untested per ddb's per-transport parity convention) | Yes | No | DONE |
| tests/integration.sh:1622 | 43.D SQL constraint enforcement on executeSql write path, D1-D6 (PRD 00122 / issue #7) | `integration_43_d_sql_constraint_enforcement` (NEW — zero e2e coverage of the D1-D6 error-message strings, "NOT NULL constraint violated"/"value too long for"/"type mismatch for"/"unknown column:", via GraphQL executeSql; confirmed via `rg "value too long\|type mismatch for\|unknown column"` across tests/e2e/*.rs, no hits) | Yes | Yes | DONE |
| tests/integration.sh:1685 | 44.E1 Pin JOIN as working via GraphQL sql() (issue #8 group E1; PRD 00123 archived as obsolete) | `integration_44_e1_join_pin_graphql` (NEW; JOIN through GraphQL sql(query:), exactly one row parsed as JSON and compared with ["a", "1"] during review) | Yes | No | DONE (review assertions restored) |
| tests/integration.sh:1705 | 44.J Auto-junction tables populated atomically on SQL INSERT and UPDATE via GraphQL executeSql (PRD 00134) | `integration_44_j_auto_junction_atomic_graphql` (NEW — `junction_tables.rs` only exercises manual `INSERT INTO <type>_<ref>` on the junction table itself, never the atomic-population path triggered by a REFERENCES column on the typed INSERT/UPDATE; `cascade_delete::cascade_delete_cleans_owned_junction_when_parent_deleted` incidentally relies on the INSERT-side atomic population as setup but only via CLI, and no test anywhere exercises the UPDATE-side re-sync this section's T2 half pins) | Yes | No | DONE |
| tests/integration.sh:1746 | 44.K GraphQL createDoogat typed-create populates the auto-junction atomically (PRD 00134 cycle-1 review C1 task #4) | `integration_44_k_create_doogat_auto_junction` (NEW — the section's own comment states the plumbing is pinned only at the Rust unit-test level, `service::tests::batch_create_routes_references_to_reference_zone` etc.; no e2e/GraphQL test drives `createDoogat` end-to-end and asserts the resulting junction-table row) | Yes | No | DONE |
| tests/integration.sh:1769 | 44.M Auto-junction parent-direction cleanup on DELETE via GraphQL executeSql (PRD 00137) | `integration_44_m_parent_junction_cleanup_graphql` (NEW — `cascade_delete::cascade_delete_cleans_owned_junction_when_parent_deleted` pins the identical parent-direction cleanup invariant but exclusively via the CLI `ddb query` transport; this section specifically drives CREATE/INSERT/DELETE through GraphQL `executeSql`, untested) | Yes | No | DONE |
| tests/integration.sh:1804 | 44. DDL response consistency (no spurious errors; CREATE/ALTER/DROP TABLE, executeBatch DDL, DML-unchanged regression) | `integration_44_ddl_response_consistency` (NEW — no e2e test asserts the GraphQL DDL response shape invariant, empty `columns`/`rows` arrays with no `errors` field and `message` present, for CREATE/ALTER/DROP TABLE or `executeBatch` DDL statements, nor the accompanying DML-response-unchanged regression check) | Yes | No | DONE |
| tests/integration.sh:1848 | 45. createMany onConflict: IGNORE (upsert via GraphQL) | ALREADY COVERED by `upsert::create_many_on_conflict_ignore_returns_existing` (identical shape: seed one row with a unique code, createMany a duplicate under `onConflict: IGNORE`, assert the returned id/title match the original survivor) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:1870 | 45.G13 issue #13: createDoogat must omit title when the typedef has a title_template (renders server-side); negative case rejects NOT NULL when no template | `integration_45_g13_title_template_omit` (NEW — `title_template_references.rs` exercises `{ref.field}` interpolation entirely via the CLI `ddb query`/SQL INSERT path, never via GraphQL `createDoogat` with an omitted title; no test asserts the NON_NULL-to-nullable GraphQL schema change or the resulting NOT_NULL_VIOLATION when a template-less type omits title) | Yes | Yes | DONE |
| tests/integration.sh:1891 | 45.G12 issue #12: createMany(onConflict: IGNORE) returns the surviving row's ID for an intra-batch duplicate (both inputs in one array share the same unique key) | `integration_45_g12_intra_batch_ignore_surviving_id` (NEW — `upsert::create_many_on_conflict_ignore_mixed_new_and_existing` seeds the duplicate via a separate prior `createMany` call before the conflicting batch; this section's regression is specifically about two inputs in the SAME `createMany` array duplicating each other with neither pre-existing, which no existing test exercises) | Yes | No | DONE |
| tests/integration.sh:1917 | 45.G11 issue #11: TagsFilter operators are nullable (contains-only/containsAll-only/containsAny-only all parse); empty filter and empty arrays rejected at resolve time; schema introspection confirms nullable lists | `integration_45_g11_tags_filter_nullable_operators` (NEW — zero `TagsFilter`/`containsAll`/`containsAny` coverage anywhere in tests/e2e/*.rs, confirmed via targeted `rg`) | Yes | Yes | DONE |
| tests/integration.sh:1969 | 45.A1 Cross-mutation parity after a failed UNIQUE INSERT: updateDoogat/createDoogat/deleteDoogat all still work post-rollback (issue #4 group A1) | `integration_45_a1_cross_mutation_parity_after_unique_failure` (NEW — no e2e test drives all three of updateDoogat/createDoogat/deleteDoogat immediately after a failed UNIQUE `executeSql` INSERT on the same table; `rg "ghost\|UNIQUE.*rollback\|savepoint"` across tests/e2e/*.rs found no match) | Yes | Yes | DONE |
| tests/integration.sh:1998 | 45.A3 Cross-table isolation: a failed UNIQUE INSERT on one table doesn't corrupt a sibling table's GraphQL write path (issue #4 group A3) | `integration_45_a3_cross_table_isolation_after_unique_failure` (NEW — no e2e test proves a failed UNIQUE INSERT on one table leaves a sibling table's GraphQL write path unaffected) | Yes | Yes | DONE |
| tests/integration.sh:2021 | 45.R10 RESTRICT on NOT NULL REFERENCES blocks the parent delete through both the SQL executeSql and deleteDoogat GraphQL surfaces (#10) | `integration_45_r10_restrict_blocks_sql_and_graphql_delete` (NEW — `cascade_delete::delete_rejected_by_not_null_references_sql_issue_10` and `::delete_rejected_by_not_null_references_cli_issue_10` pin the identical RESTRICT invariant but exclusively via the CLI `ddb query`/`ddb delete` transports; this section drives the same DELETE through GraphQL `executeSql` AND the `deleteDoogat` mutation, neither tested anywhere) | Yes | Yes | DONE |
| tests/integration.sh:2073 | 45.A2 Ghost-row fix persists across server restart (issue #4 group A2) | `integration_45_a2_ghost_row_survives_server_restart` (NEW — no e2e test kills and restarts the `ddb serve` process mid-test to prove a ghost-row fix persists to the on-disk index rather than living only in server memory) | Yes | Yes | DONE |
| tests/integration.sh:2109 | 49. PRD 00131: structured-error code propagation through typed mutations (section banner only) | N/A — pure section banner (comment block + one `echo`), no assertions of its own; coverage is decided per sub-section at 49.1-49.4 below. The parent task's pre-assigned slug `integration_49_structured_error_propagation` is NOT used since this line has no independent body to port | No | No | DONE (pre-existing, no port needed) <!-- banner-only line, nothing to port; see 49.1-49.4 --> |
| tests/integration.sh:2120 | 49.1 GraphQL UNIQUE violation on createDoogat carries extensions.code = UNIQUE_VIOLATION (plus extensions.columns/values) | `integration_49_1_unique_violation_extensions_code` (NEW — `cross_transport_error.rs` explicitly scopes UNIQUE_VIOLATION/NOT_NULL_VIOLATION structured codes as out of scope for its REST+GraphQL parity tests since REST has no typed-field input; no other e2e test asserts `extensions.code`/`extensions.columns`/`extensions.values` on a createDoogat UNIQUE violation) | Yes | Yes | DONE |
| tests/integration.sh:2133 | 49.2 GraphQL NOT NULL violation on createDoogat carries extensions.code = NOT_NULL_VIOLATION (plus extensions.column) | `integration_49_2_not_null_violation_extensions_code` (NEW — same gap as 49.1, for the NOT_NULL_VIOLATION code and extensions.column on createDoogat) | Yes | Yes | DONE |
| tests/integration.sh:2142 | 49.3 createMany single-input duplicate under onConflict: ERROR carries extensions.code = UNIQUE_VIOLATION | `integration_49_3_createmany_error_extensions_code` (NEW — no test asserts extensions.code on a createMany(onConflict: ERROR) single-input duplicate) | Yes | Yes | DONE |
| tests/integration.sh:2148 | 49.4 createMany multi-input intra-batch duplicate under onConflict: ERROR carries extensions.code = UNIQUE_VIOLATION | `integration_49_4_createmany_intra_batch_error_extensions_code` (NEW — no test asserts extensions.code on a createMany intra-batch duplicate under onConflict: ERROR) | Yes | Yes | DONE |
| tests/integration.sh:2159 | 50. PRD 00132: ALTER TABLE foo RENAME TO bar across protocols (section banner only) | N/A — pure section banner, zero body of its own (line 2160 immediately begins 50a's code); coverage is fully delegated to 50a/50b/50c below. The parent task's pre-assigned slug `integration_50_alter_table_rename` is NOT used since this line has no independent assertions to port | No | No | DONE (pre-existing, no port needed) <!-- banner-only line, nothing to port; see 50a/50b/50c --> |
| tests/integration.sh:2160 | 50a. ALTER TABLE RENAME TO via GraphQL executeSql | `integration_50a_alter_rename_graphql` (NEW — `alter_table_rename.rs`'s five tests are entirely CLI `ddb query`-based; no test drives ALTER TABLE ... RENAME TO through GraphQL executeSql and confirms the old name errors while the new name resolves) | Yes | Yes | DONE |
| tests/integration.sh:2169 | 50b. MySQL RENAME TABLE alias rejected with explicit message via GraphQL (no internal error leak) | `integration_50b_mysql_rename_alias_rejected_graphql` (NEW — `alter_table_rename::cli_mysql_rename_table_alias_rejected_with_clear_message` pins the identical rejection message but via the CLI transport; no test drives RENAME TABLE ... TO ... through GraphQL and asserts the errors[0].message hint) | Yes | Yes | DONE |
| tests/integration.sh:2174 | 50c. ALTER TABLE RENAME TO via PgWire (when psql is available) | `integration_50c_alter_rename_pgwire` (NEW — no e2e test exercises ALTER TABLE ... RENAME TO through the PgWire/psql transport; `pgwire.rs`'s DDL coverage, `pgwire_ddl_create_table`, doesn't include RENAME) | Yes | No | DONE |
| tests/integration.sh:2188 | 51. SINGLETON GraphQL flow + ALTER + parity, PRD 00139 T20/T22 (section banner only) | N/A — pure section banner (2 comment lines, no code); the actual GraphQL singleton-flow assertions live under the `51.A` sub-header (line 2192, mapped in the next row) | No | No | DONE (banner; assertions under 51.A) |
| tests/integration.sh:2192 | 51.A. GraphQL singleton flow: null before first row, update-on-empty rejects SINGLETON_NOT_FOUND, upsert creates then updates, createDoogat rejects a second row with SINGLETON_VIOLATION (T20 §A) | `integration_singleton_flow::integration_51_a_singleton_graphql_flow` (null on empty, SINGLETON_NOT_FOUND, first upsert created:true with nonempty id, existing upsert created:false, update in place, and second createDoogat rejected) | Yes | Yes | DONE |
| tests/integration.sh:2242 | 52.B. ALTER TABLE SET/DROP SINGLETON (T20 §B) | `integration_singleton_flow::integration_52_b_graphql_alter_set_drop_singleton_reload` + `alter_singleton::set_singleton_rejects_multi_row_typedef_with_count` (CLI multi-row IDs, SET rejection/count, delete-one message, then GraphQL SET/DROP reload and introspection) | Yes | Yes | DONE |
| tests/integration.sh:2273 | 53.C. SINGLETON DEFAULT VALUES auto-seed (T20 §C) | `integration_53_c_singleton_default_values_auto_seed` (NEW — verified via `rg -n "DEFAULT VALUES" tests/e2e/*.rs` → zero hits; no e2e test exercises `CREATE TABLE ... SINGLETON DEFAULT VALUES` auto-seeding one row from column defaults) | No | No | DONE |
| tests/integration.sh:2282 | 54.D. Cross-protocol parity (T22) | compound: CLI-duplicate-INSERT leg ALREADY COVERED by `alter_singleton::after_set_singleton_second_insert_rejects_with_constraint` (CLI `ddb query` duplicate INSERT on a SINGLETON table fails with "SINGLETON constraint") + PgWire leg ALREADY COVERED by `pgwire_singleton::pgwire_singleton_duplicate_insert_keeps_connection_healthy` (duplicate PgWire INSERT errors with "SINGLETON constraint"/"SINGLETON_VIOLATION") + GraphQL executeSql/createDoogat/REST-409/NoSQL-404 legs `integration_54_d_cross_protocol_singleton_duplicate_parity` (NEW — verified: no e2e test performs a sequential duplicate INSERT via GraphQL `executeSql`/`createDoogat` checking `SINGLETON_VIOLATION` + table extensions, cross-checks the two codes/tables for equality, or asserts a REST 409 envelope; `rg -n "409|SINGLETON" tests/e2e/rest.rs` → zero hits) | Yes | Yes | DONE |
| tests/integration.sh:2366 | 55. Cross-process SINGLETON write race + structured-error parity (PRD 00140) | N/A — pure variable-declaration scaffolding (`RACE_CLI_1`..`RACE_PG_SQL` temp-file paths) shared by 55.A-E below; no assertion of its own | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2376 | 55.A — CLI `ddb create` race | ALREADY COVERED by `singleton_cross_process_create::two_concurrent_ddb_create_on_singleton_converge_on_one_row` (verified: identical shape — create a SINGLETON typedef, spawn two concurrent `ddb create` CLI processes before waiting on either, assert exactly one winner and one loser, loser's output contains "SINGLETON constraint violated: <table> already holds row " and never "UNIQUE constraint failed", table converges to exactly one row; the integration.sh variant incidentally runs with a live `ddb serve` in the background, but the raced mechanism — two separate `ddb create` processes — and every assertion match) | Yes | Yes | DONE (pre-existing, no port needed) |
| tests/integration.sh:2400 | 55.B — GraphQL `executeSql` INSERT race | `integration_55_b_graphql_execute_sql_singleton_insert_race` (NEW — verified: no test races two concurrent `executeSql` INSERT statements against one SINGLETON typedef on a single running server; the closest test, `singleton_cross_process_upsert::two_concurrent_graphql_upserts_on_singleton_converge_on_one_row`, races the dedicated `upsert_<type>` mutation where BOTH calls succeed (`created:true`/`created:false`), a different code path from a raw `executeSql INSERT` that must produce exactly one `SINGLETON_VIOLATION` error) | Yes | Yes | DONE |
| tests/integration.sh:2428 | 55.C — GraphQL typed `createDoogat` race | `integration_55_c_graphql_create_doogat_singleton_insert_race` (NEW — verified: no test races two concurrent `createDoogat` mutations against one SINGLETON typedef; `server_mutations::sync_during_writes_serialized_through_actor` races 5 concurrent `createDoogat` calls but against a non-SINGLETON type expecting all 5 to succeed, not this section's SINGLETON_VIOLATION-on-one-loser shape) | Yes | Yes | DONE |
| tests/integration.sh:2454 | 55.D — CLI-vs-PgWire concurrent INSERT race (PRD 00157 determinism contract: winner/loser converge to one row, no raw UNIQUE leak, loser surfaces a SINGLETON-or-transient-contention error) | `integration_55_d_cli_vs_pgwire_singleton_insert_race` (NEW — read `singleton_cross_process_upsert.rs` in full: its `two_concurrent_pgwire_inserts_on_singleton_one_wins_one_gets_singleton_error` races two PgWire *client connections* against each other, both still inside the SAME server process, and demands a deterministic structured message; this section races a genuinely separate `ddb` CLI process — its own SQLite `BEGIN IMMEDIATE` — against the server's PgWire path, and accepts a looser "structured-or-transient-contention" promise. The task's flag that this might already be covered does not hold up: no existing test exercises a CLI-process-vs-PgWire race) | Yes | Yes | DONE |
| tests/integration.sh:2516 | 55.E — convergence parity: every protocol's race left exactly one row | `singleton_cross_process_create::two_concurrent_ddb_create_on_singleton_converge_on_one_row` + `integration_singleton_races::integration_55_b_graphql_execute_sql_singleton_insert_race` + `integration_singleton_races::integration_55_c_graphql_create_doogat_singleton_insert_race` + `integration_singleton_races::integration_55_d_cli_vs_pgwire_singleton_insert_race` — each race asserts its own exact final count of one; all four protocol outcomes retained | Yes | No | DONE |
| tests/integration.sh:2538 | 56. REST warnings envelope pinning AppOutput.warnings on POST /doogats (PRD 00147 doubt-review follow-up) | `integration_warnings_update::integration_56_a_rest_create_titled_warnings_empty` + `integration_warnings_update::integration_56_b_rest_create_omitted_title_title_from_template_warning` (shared fixture asserts CLI CREATE and SET TITLE TEMPLATE success messages before starting server) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2548 | 56.A — caller-supplied title yields warnings: [] (still present, never skipped) | `integration_56_a_rest_create_titled_warnings_empty` (NEW — verified via `rg -n "warnings" tests/e2e/*.rs` → zero matches across the entire e2e suite; no test asserts a REST `POST /doogats` response body carries a `warnings` array at all) | Yes | No | DONE |
| tests/integration.sh:2558 | 56.B. omitted title with a title_template typedef yields a TITLE_FROM_TEMPLATE warning entry carrying code + message | `integration_56_b_rest_create_omitted_title_title_from_template_warning` (NEW — same zero-coverage gap as 56.A; no test asserts the TITLE_FROM_TEMPLATE warning code/message shape) | Yes | No | DONE |
| tests/integration.sh:2572 | 57. GraphQL warnings envelope (PRD 00154), pinning the WarningExtension contract that every response carries extensions.warnings | N/A — pure comment block, no code of its own before 57.A | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2579 | 57.A — caller-supplied title yields extensions.warnings: [] (always present) | `integration_57_a_graphql_create_titled_extensions_warnings_empty` (NEW — zero "warnings" hits in tests/e2e/*.rs; no test asserts GraphQL response `extensions.warnings`) | Yes | No | DONE |
| tests/integration.sh:2586 | 57.B. omitted title with a title_template typedef fires TITLE_FROM_TEMPLATE under extensions.warnings (NOT under data) | `integration_57_b_graphql_create_omitted_title_title_from_template_warning` (NEW — same zero-coverage gap) | Yes | No | DONE |
| tests/integration.sh:2606 | 58. Update warning/error shape (PRD 00149): warnings channel wired end-to-end on updateDoogat, and a not-found update surfaces the structured NOT_FOUND app-error code | N/A — GraphQL DDL fixture setup only (`ddl` CREATE TABLE ig_upd_demo), no independent assertion; behavior covered by 58.A-D below | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2617 | 58.A — GraphQL updateDoogat carries extensions.warnings: [] (always present) and applies the change | `integration_58_a_graphql_update_warnings_empty` (NEW — zero "warnings" coverage in e2e; no test asserts `updateDoogat`'s `extensions.warnings`) | Yes | No | DONE |
| tests/integration.sh:2628 | 58.B — GraphQL updateDoogat on a missing id surfaces extensions.code = NOT_FOUND | `integration_58_b_graphql_update_missing_id_not_found` (NEW — verified: `cross_transport_error.rs` pins NOT_FOUND parity for read (`read_unknown_id_reports_not_found_on_both_transports`) and delete (`delete_unknown_id_reports_not_found_on_both_transports`) only, neither exercises `updateDoogat`; `cli_update_app_error::cli_update_missing_id_reports_app_error` covers the CLI update-missing-id path, not GraphQL) | Yes | Yes | DONE |
| tests/integration.sh:2635 | 58.C — REST PUT /doogats/{id} update response always carries a warnings array (empty today) and applies the change | `integration_58_c_rest_update_warnings_empty` (NEW — zero "warnings" coverage in e2e; `rest::rest_crud_lifecycle` exercises PUT but never inspects a `warnings` field) | Yes | No | DONE |
| tests/integration.sh:2648 | 58.D — REST PUT on a missing id surfaces the structured NOT_FOUND envelope (404) | `integration_58_d_rest_update_missing_id_not_found` (NEW — verified: `rest::rest_get_unknown_id_returns_404` covers GET on a missing id, not PUT; `cross_transport_error::delete_unknown_id_reports_not_found_on_both_transports` covers DELETE, not PUT/update; no existing test exercises REST `PUT /doogats/{missing-id}`) | Yes | Yes | DONE |
| tests/integration.sh:2659 | 59. REST typed create via the `fields` body member (PRD 00149): typed columns populated, malformed fields JSON rejected with 400 + VALIDATION_ERROR | N/A — GraphQL DDL fixture setup only (`ddl` CREATE TABLE ig_rest_typed), no independent assertion; behavior covered by 59.A/59.B below | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2667 | 59.A — POST /doogats with type + fields populates the typed column | `rest::rest_typed_create_populates_typed_columns` (register a type, POST /doogats with type and JSON fields; retain the server executeSql read-back and add an independent CLI ddb query read-back of category=books for the created ID) | Yes | No | DONE (review assertions restored) |
| tests/integration.sh:2680 | 59.B. malformed fields JSON is rejected with 400 + VALIDATION_ERROR before any row is written | ALREADY COVERED by `rest::rest_create_malformed_fields_returns_400` (verified: identical shape — malformed `fields` JSON string on POST /doogats returns 400 + `{"error":"VALIDATION_ERROR"}` before any row is written) | Yes | Yes | DONE (pre-existing, no port needed) |
| tests/integration.sh:2698 | 60. Typed where-filter completeness (PRD 00159): negation/null ops, forward relation sub-filters, reverse membership, and totalCount correlation with pagination | ALREADY COVERED by `typed_where_filter::typed_where_filter_completeness` (calls helper setup_completeness_fixture) (verified: identical fixture — relcat(title,slug) / rellink(url,category REFERENCES relcat), three categories Rust/Python/Empty, three links rust/py/orphan — the e2e test's own doc comment enumerates "negation, null, inlined target columns, junction quantifiers, reverse membership, pagination + totalCount correlation", the same list this section's header comment gives) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2739 | 60.A — Negation: notIn / nin | ALREADY COVERED by `typed_where_filter::typed_where_filter_completeness` (calls helper assert_negation_filters) (verified: identical — `rellinks(where: { id: { notIn: [...] } })` and the `nin` alias, both asserting totalCount 2) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2750 | 60.B — Null operators | ALREADY COVERED by `typed_where_filter::typed_where_filter_completeness` (calls helper assert_null_filters) (verified: identical `url: { isNull: true/false }` totalCount 1/2 checks) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2761 | 60.C — Forward relation sub-filter (inlined target columns) | ALREADY COVERED by `typed_where_filter::typed_where_filter_completeness` (calls helper assert_forward_filters) (verified: identical `category: { title: { eq: "Rust" } }` and `category: { slug: { eq: "py" } }` inlined-column sub-filter checks) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2772 | 60.D — Forward id-ops (back-compatible) | ALREADY COVERED by `typed_where_filter::typed_where_filter_completeness` (calls helper assert_forward_filters) (verified: same function's final block, `category: { eq: cat_rust_id }` back-compatible id-op check) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2778 | 60.E — none / some | ALREADY COVERED by `typed_where_filter::typed_where_filter_completeness` (calls helper assert_quantifier_filters) (verified: identical `category: { none: {} }` / `category: { some: {} }` totalCount 1/2 checks) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2789 | 60.F — Reverse membership | ALREADY COVERED by `typed_where_filter::typed_where_filter_completeness` (calls helper assert_reverse_filters) (verified: identical `relcats(where: { rellinks: { some: {...} } })` and `{ rellinks: { none: {} } }` reverse-membership checks) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2800 | 60.G — Relation filter + orderBy + pagination + totalCount correlation | ALREADY COVERED by `typed_where_filter::typed_where_filter_completeness` (calls helper assert_pagination) (verified: identical relation-filter + `orderBy: { id: ASC }` + `limit`/`offset` + totalCount correlation across two pages, asserting distinct rows per page) | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2817 | 61. Cross-process write lock: no lost commit under concurrent writers (PRD 00162) | N/A — pure comment plus a `cd "$TMPDIR"` directory change, no assertion of its own; behavior covered by 61.A/61.B below | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2826 | 61.A — N concurrent CLI `ddb update` writers on distinct doogats must all land | ALREADY COVERED by `concurrent_writes::concurrent_cli_update_processes_lose_no_commit` (verified: identical shape — seed N pre-existing doogats sequentially so ids are distinct, fire N concurrent `ddb update` CLI processes (8 in the Rust test vs 6 here) before waiting on any, assert every update is durable in HEAD via `git show`, not the work tree) | No | Yes | DONE (pre-existing, no port needed) |
| tests/integration.sh:2847 | 61.B — a `ddb serve` (GraphQL) write concurrent with a CLI write; both must land | `integration_61_b_concurrent_cli_and_graphql_write_lock` (NEW — verified: no existing e2e test races a separate CLI `ddb update` process against a concurrent `ddb serve` GraphQL `updateDoogat` write on the same repo; `server_mutations::sync_during_writes_serialized_through_actor` races 5 GraphQL creates plus a `sync` mutation, all in-process threads against the SAME server, never a genuinely separate CLI process; `concurrent_writes.rs`'s two tests are CLI-only with no server involved) | Yes | No | DONE |
| tests/integration.sh:2886 | 21. fast-forward sync | `integration_21_clone_reindex_reads_pushed_note` (NEW — verified: `sync_crdt::two_node_fast_forward_sync` covers a related but distinct path — it clones node2 then explicitly runs `ddb sync` before reading; this section never invokes `ddb sync` at all, it clones the bare remote directly with `git clone`, runs plain `ddb reindex`, then reads, proving a fresh index rebuild alone — no merge/sync machinery — already sees content pushed by another node; `rg -n "git clone" tests/e2e/*.rs` → zero matches, confirming no e2e test exercises raw-clone-then-reindex) | No | No | DONE |
| tests/integration.sh:2900 | 22. non-overlapping edits (clean git merge, no CRDT) | ALREADY COVERED by `sync_crdt::non_overlapping_edits_merge_cleanly` (identical shape: node1 title+tags update, node2 body update, sync, "conflicts resolved: 0", merged read shows both changes) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2918 | 23. frontmatter scalar conflict (title) — CRDT resolves | `sync_crdt::frontmatter_conflict_creates_fm_crdt_file` (actual frontmatter conflict, fm.crdt presence before CLI reopen/cleanup, Laptop-or-Desktop title line, compact removes temporary files) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2937 | 24. frontmatter list conflict (tags) — CRDT set-union | ALREADY COVERED by `sync_crdt::concurrent_tag_additions_both_survive` (identical shape: shared base tag + two different per-node additions, sync both ways, final read contains all three tags — same set-union assertion) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2956 | 25. body conflict — Automerge Text CRDT | ALREADY COVERED by `sync_crdt::overlapping_body_edits_resolved_by_crdt` (same shape: both nodes edit the same line with LAPTOP/DESKTOP markers, sync, "conflicts resolved: 1", merged body contains both fragments and preserves unchanged lines) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:2976 | 26. reference section conflict — write files directly, CRDT union | `integration_26_reference_section_conflict` (NEW — no e2e test writes competing reference-section blocks directly via raw git commit and asserts CRDT union on sync; `rg "reference section|laptop note|desktop note"` across tests/e2e/*.rs found no match) | No | No | DONE |
| tests/integration.sh:3002 | 26b. deterministic CRDT convergence smoke (independent-resolution determinism is unit-tested in crdt_determinism.rs) (PRD 00165) | ALREADY COVERED by `multi_device::concurrent_edits_same_doogat` (stronger e2e-level proof of the same claim: 3 nodes concurrently edit the same doogat causing a real conflict, then `assert_eq!` proves all nodes converge to byte-identical content after resolution — the smoke-level "both nodes reach the same value after a real conflict" property this section checks with only 2 nodes and a title field) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3028 | 27b. delete-vs-edit conflict — edit wins, doogat resurrected | `sync_crdt::sync_output_reports_resurrected_count` (initial title, delete versus content/status edit, sync resurrection, edited body and status report includes resurrected) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3056 | 27c. three-way conflicted merge preserves deletion + local edit (PRD 00200) | `integration_27c_three_way_conflicted_merge` (NEW — verified via `rg "00200|three_way|three-way"` across tests/e2e/*.rs: zero matches; no e2e test drives the ours/theirs three-way scenario — edit+delete on theirs, colliding edit + non-conflicting edit on ours — and asserts the deletion, the non-conflicting edit, and the merge winner all survive together) | No | No | DONE |
| tests/integration.sh:3097 | 27a. add-add collision: both doogats survive | ALREADY COVERED by `collision::add_add_collision_both_doogats_survive` ("collisions reassigned: 1", 2 surviving files with distinct ids, both bodies preserved) + `collision::add_add_collision_resolves_in_single_commit` (the exact same `git rev-list --first-parent --count` == 2 commit-count assertion this section makes) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3155 | 27a2. add-add collision: single commit + both nodes converge | ALREADY COVERED by `collision::add_add_collision_both_doogats_survive` (its trailing steps push the resolution back and sync the other node, then assert both nodes' doogat file sets are equal — the same convergence check this section makes) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3168 | 27. bundle export --full + import | ALREADY COVERED by `multi_device::bundle_full_bootstrap` (identical shape: node0 creates content + pushes, `bundle export --full`, fresh node inits + registers, `bundle import`, read confirms content) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3181 | 28. delta bundle export + import | `integration_28_delta_bundle_target_export` (NEW — `multi_device::airgapped_delta_transfer`'s own comment states it deliberately uses `--full` instead: "delta requires knowing remote UUID; full is simpler for testing"; `rg "\-\-target"` across tests/e2e/*.rs found zero matches, so the targeted `bundle export --target <node-uuid>` path this section exercises is untested anywhere in e2e) | No | No | DONE |
| tests/integration.sh:3193 | 28a. bundle-import conflict recovery — nodes diverge WITHOUT git-remote sync, real conflict resolved through bundle import, re-import is a no-op (PRD 00168) | ALREADY COVERED by `bundle_import_conflict_recovery::bundle_import_recovers_real_conflict_and_reimport_is_noop` (identical shape down to the literal "Bundle Laptop Title"/"Bundle Desktop Title" strings: air-gapped divergence, `bundle import` reports "conflicts resolved: 1", read shows one of the two titles, re-import of the same bundle reports "conflicts resolved: 0") | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3215 | 29. update-bin help + rollback | `integration_29_update_bin_help_and_rollback` (NEW — `rg "update-bin|rollback"` across tests/e2e/*.rs matches only an unrelated SQL `transaction_rollback_via_cli` test name; no test exercises `ddb update-bin --help` or `update-bin --rollback`'s no-backup error path) | No | Yes | DONE |
| tests/integration.sh:3225 | 30. ALTER TABLE + DROP TABLE + bulk UPDATE/DELETE (+ WHERE id no-match semantics, issue #5 continuation) | compound: ALREADY COVERED (ALTER ADD COLUMN / RENAME COLUMN / DROP TABLE CASCADE half) by `sql_lifecycle::alter_table_add_column` + `alter_table_rename_column` + `drop_table_cascade` (same "altered"/"renamed"/"dropped" output checks) — but the WHERE-id no-match semantics continuation (issue #5 groups B1-B5: nonexistent-id UPDATE/DELETE return "0 row(s) affected", an IN-clause mixing a missing and a valid id still affects 1 row, a compound predicate with a valid id + wrong column value affects 0 rows) is NOT covered anywhere — verified via `rg "0 row.s. affected|nonexistent_id"` across tests/e2e/*.rs: zero matches. `integration_30_where_id_no_match_semantics` (NEW) + `sql_lifecycle::bulk_update` + `sql_lifecycle::bulk_delete` (basic bulk-operation assertions) | No | No | DONE (no-match-semantics half only) |
| tests/integration.sh:3258 | 30.F1. composite UNIQUE duplicate rejection surfaces a clear error on the CLI (issue #9 group F1) | `integration_30_f1_composite_unique_cli_rejection` (NEW — the section's own comment confirms the engine-level error message is covered by the unit test `ddb-core/src/sql_engine/tests.rs::composite_unique_duplicate_rejected_with_clear_error_issue_9_f1`, not an e2e test; `rg "UNIQUE\("` across tests/e2e/*.rs shows only unrelated `cascade_delete.rs` junction-uniqueness setup, no test drives a composite-UNIQUE duplicate INSERT through the CLI `ddb query` surface and checks the propagated error) | No | Yes | DONE |
| tests/integration.sh:3272 | 31. file attachments | ALREADY COVERED by `attachments::attach_and_list` (attach, list shows name+mime, SQL query confirms `_ddb_attachments` row) + `attachments::detach_removes_file` (detach, list shows "no attachments") — same attach/list/query/detach sequence | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3284 | 32. NoSQL CLI commands (get, scan --tag, scan --type, backlinks) | `integration_32_nosql_cli_commands` (NEW — `rg "\"get\"|\"scan\"|\"backlinks\""` across tests/e2e/*.rs shows `get` used only as cascade-delete setup and `scan`/`backlinks` appearing only in `help.rs`'s `--help` text checks; none of the four NoSQL subcommands' actual output is asserted anywhere in e2e) | No | No | DONE |
| tests/integration.sh:3298 | 33. stale node resync after compaction | compound: ALREADY COVERED (conflict → compact → stale-node-resync-succeeds scenario shape) by `multi_device::compacted_node_resolves_second_conflict` + `multi_device::stale_node_resync_after_compaction` — but the compact command's own byte-stats report lines ("crdt temp:", "repo (.git):") this section greps for are not asserted by any e2e test (`rg "crdt temp|repo \(.git\)"` across tests/e2e/*.rs: zero matches; the closest analog, `compact_creates_recoverable_backup`, only checks for a "backup:" line). `integration_33_compact_byte_stats_report` (NEW) | No | No | DONE (byte-stats-report half only) |
| tests/integration.sh:3347 | 34. multi-row INSERT | ALREADY COVERED by `sql_lifecycle::multi_row_insert` (same shape: 3-row INSERT returns 3 comma-separated ids, all rows present on SELECT; the Rust test additionally verifies per-row values and a single git commit, a stronger check than this section's bare `COUNT(*) = 3`) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3355 | 35. transaction commit + rollback | ALREADY COVERED by `sql_lifecycle::transaction_commit_via_cli` (BEGIN;INSERT;COMMIT, both rows visible) + `sql_lifecycle::transaction_rollback_via_cli` (BEGIN;INSERT;ROLLBACK, row not visible) — same commit/rollback pair this section exercises | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3366 | 36. hyphenated type SQL via quoted identifiers | `integration_36_hyphenated_type_create_table` (NEW — the only existing hyphenated-identifier coverage, `sql_lifecycle::install_meeting_minutes_type`, installs a bundled typedef and never runs a raw `CREATE TABLE "hyphenated-name" (...)` statement; this section's core assertion — that `CREATE TABLE "my-type"` itself parses a quoted hyphenated identifier and reports "table my-type created" — is untested) | No | No | DONE |
| tests/integration.sh:3374 | 37. junction table CRUD (multi-value references) | ALREADY COVERED by `junction_tables::junction_table_round_trip` (identical shape: two REFERENCES-linked tables, insert into the auto-generated junction table, SELECT confirms the row, DELETE the junction row, confirm `COUNT(*) = 0`, re-insert, `DROP TABLE ... CASCADE` removes the junction table, subsequent `SELECT` on it fails) | No | Yes | DONE (pre-existing, no port needed) |
| tests/integration.sh:3390 | 38. title template compliance check | ALREADY COVERED by `fix::fix_verbose_reports_title_noncompliant` (exact match: same table name "widget", same title template `'{name} Widget'`, same insert values 'Foo'/'A foo widget', same `fix --verbose --dry-run` check for "title does not match template") | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3398 | 39. zone migration | ALREADY COVERED by `fix::fix_migrate_rewrites_zones` (exact match: same table name "gadget"/column "notes", `ALTER TABLE ... SET ZONE frontmatter FOR notes`, `fix --migrate` reports "zone-migrated") | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3407 | 40. binary asset LWW conflict resolution | `integration_40_binary_asset_lww` (NEW — `rg "resolve merge|photo.bin|HLC:"` across tests/e2e/*.rs found zero matches; `multi_device::hlc_lww_picks_later_writer` covers typed-field LWW via `ddb update`, a different code path from this section's raw binary file conflict with a manually-authored `HLC:` commit trailer and its "resolve merge" merge-commit-in-history check) | No | No | DONE |
| tests/integration.sh:3464 | 41. auto-register node on first sync | `sync_crdt::sync_auto_registers_node_when_none_exists` (UUID exists and bytes remain identical after two syncs) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3488 | 46. title_template REFERENCES resolution (PRD 00127) | ALREADY COVERED by `title_template_references::membership_title_resolves_from_referenced_doogats` (literal-match setup: link/category/membership tables, dotted template `'{link.title} in {category.fqn}'`, same test data "My Link"/"A/B" composing to "My Link in A/B") + `title_template_references::typedef_with_bad_dotted_path_is_rejected` (bad dotted path `{link.does_not_exist}` rejected at ALTER TABLE with "does not exist on link") | No | Yes | DONE (pre-existing, no port needed) |
| tests/integration.sh:3516 | 47. ALTER TABLE ALTER COLUMN TYPE (PRD 00128) | `alter_column_type::widens_varchar_to_text_and_accepts_longer_values` + `alter_column_type::narrowing_rejects_with_row_count_message` (VARCHAR32 boundary, 80-character rejection, widening to100, narrowing rejection with exact violating-row count, TEXT accepts2000 and fresh-process1500; existing255 boundary retained) | No | Yes | DONE (pre-existing, no port needed) |
| tests/integration.sh:3563 | 48. PRD 00129: typed write blocker & simplification SQL surface (CREATE INDEX no-op/rejection, ON DELETE CASCADE, ON DELETE RESTRICT default, cascade cycle detection) | compound: ALREADY COVERED (RESTRICT-by-default-blocks-parent-delete half) by `cascade_delete::delete_rejected_by_not_null_references_cli_issue_10` (CLI `ddb delete` on a NOT-NULL-REFERENCED parent fails with "NOT NULL REFERENCES" in stderr) — but `CREATE INDEX IF NOT EXISTS` no-op, plain `CREATE INDEX` rejection, explicit `ON DELETE CASCADE` walk, and cascade-cycle detection are NOT covered anywhere (verified: `rg "CREATE INDEX|cascade would form a cycle|ON DELETE CASCADE"` across tests/e2e/*.rs: zero matches). `integration_48_typed_write_blockers_and_cascade` (NEW) | No | Yes | DONE (CREATE INDEX + CASCADE + cycle-detection halves only) |
| tests/integration.sh:3626 | 49. PRD 00133 unify-typed-write-paths: CLI typed `create` populates REFERENCES columns and rejects FK to wrong-type ids | `integration_49_unify_typed_write_paths` (NEW — `cli_create_fk_freshness::create_link_after_category_in_separate_process_succeeds_without_reindex` drives the same `ddb create --type ... --set ref=<id>` shape but only asserts process success and a non-empty id, never reading back the reference-zone content (`link:: [[id]]`) this section checks; and `rg "references non-existent"` across tests/e2e/*.rs found zero matches, so the FK-to-wrong-type-id CLI rejection this section also asserts is untested anywhere) | No | Yes | DONE |
| tests/integration.sh:3674 | 44.L. CLI `ddb create` populates the auto-junction atomically (PRD 00134 cycle-1 review C1 task #4) | `integration_44_l_cli_create_auto_junction` (NEW — `cascade_delete::cascade_delete_cleans_owned_junction_when_parent_deleted` drives the auto-junction materializer via SQL `INSERT INTO ... (ref_col)`, not the CLI `ddb create --type ... --set ref=<id>` entry point this section exercises; no e2e test combines `ddb create --type` with a junction-table JOIN readback) | No | No | DONE |
| tests/integration.sh:3697 | 50. PRD 00136 / #16 — cross-process FK freshness on `ddb create` | ALREADY COVERED by `cli_create_fk_freshness::create_link_after_category_in_separate_process_succeeds_without_reindex` (verified by reading both files: identical two-separate-process shape — process 1 `ddb create`s the parent typedef row, process 2 `ddb create`s a child with `--set ref=<parent-id>` and no intermediate reindex — same issue #16 regression, matching the precedent's smoke.sh:193 finding for the near-identical smoke-test wording) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.sh:3720 | 62. PRD 00164 - unified repo-aware ID minting (end-to-end CLI conformance) | `integration_62_id_minting_no_same_second_collision` (NEW — `tests/e2e/concurrent_writes.rs`'s cold-start test explicitly folds same-second id collisions into its expected set rather than asserting their absence [its own comment: "That is the still-open id-mint race (PRD 00164)... Folding colliding ids into the expected set keeps this test blind to that race"]; the core-level regressions `ddb-core/tests/id_mint_collision.rs` and `raw_create_mint_collision.rs` prove the minting oracle in isolation, not through the CLI. No e2e test does this section's exact sequence — a batch multi-row INSERT immediately followed by a single `ddb create`, no sleep — and asserts all resulting ids are distinct) | No | No | DONE |
| tests/integration.sh:3746 | 63. PRD 00169 - poison-file skip warning through GraphQL extensions | `integration_63_poison_file_graphql_warning` (NEW — `poison_file_reindex.rs`'s two tests exercise only the CLI `ddb reindex`/`ddb reindex --strict` surface, never the server; `REINDEX_SKIPPED_FILES` is defined and unit-tested in `ddb-core/src/service/update.rs` and `ddb-core/src/app_contract/*` but `rg -l "REINDEX_SKIPPED_FILES"` across tests/e2e/*.rs found no match, so the GraphQL `extensions.warnings` surfacing this section asserts is untested at the e2e level) | Yes | No | DONE |

## Row count check — integration.sh

`rg -c "^# [0-9]" tests/integration.sh` → 140 numbered section headers (confirmed). This
append adds exactly 140 rows above (35 rows from each of four research passes covering
lines 52-1316, 1323-2192, 2242-2886, and 2900-3746 respectively), one per matched header,
in file order — including `tests/integration.sh:164`, a mid-sentence comment fragment that
incidentally matches the header regex (`# 20 drops them all...`) and is folded into the
`17.J1` row rather than treated as an independent scenario.

Combined with the 112 smoke.sh/smoke.ps1 rows above, the table now has 252 rows total
(112 + 140), one per numbered section per file, matching `56 + 56 + 140 = 252`.

The file has two number-reuse collisions the task flagged plus two more found during this
pass — `#37`, `#38`, `#49`, and `#50` each appear once in the server-dependent half
(lines ~52-2885, numbered §17-§61) and once more in the CLI/git/sync half (lines
~2886-3803, independently numbered §21-§63):

- `#37`: `tests/integration.sh:1179` (WebSocket payload auth) vs. `tests/integration.sh:3374`
  (junction table CRUD) — both resolved ALREADY COVERED, distinct existing-test citations
  (`subscriptions::ws_payload_auth_subscribe_receive` vs. `junction_tables::junction_table_round_trip`).
- `#38`: `tests/integration.sh:1189` (read-under-write) vs. `tests/integration.sh:3390`
  (title template compliance) — both ALREADY COVERED, distinct citations
  (`read_pool::concurrent_reads_during_write` vs. `fix::fix_verbose_reports_title_noncompliant`).
- `#49`: `tests/integration.sh:2109` (PRD 00131 structured-error propagation, a banner-only
  line — see below) vs. `tests/integration.sh:3626` (PRD 00133 unify-typed-write-paths),
  which carries the reserved slug `integration_49_unify_typed_write_paths`.
- `#50`: `tests/integration.sh:2159` (PRD 00132 ALTER TABLE RENAME, banner-only) vs.
  `tests/integration.sh:3697` (PRD 00136 cross-process FK freshness), pre-assigned
  `integration_50_alter_table_rename` and `integration_50_cross_process_fk_freshness`
  respectively — both slugs went unused because research found both banner lines carry
  no independent assertion (`2159`'s real content lives in `50a`/`50b`/`50c`, which got
  their own targets) and `3697` is ALREADY COVERED (matching the precedent set by the
  near-identical `smoke.sh:193` row). No collision occurred either way. ASSUMPTION: since
  the same reuse pattern also affects `#37`/`#38` (not flagged by name in the task), each
  research pass was given a reserved fallback slug for those pairs too, by extension of the
  task's own `#50` disambiguation rule — see FILES_TOUCHED/ASSUMPTIONS in the delivering
  agent's report.

Zero unmapped sections.

## Conventions — tests/integration.ps1

- Built by reading every one of the 139 numbered section headers in
  `tests/integration.ps1` (`rg -c "^# [0-9]" tests/integration.ps1` → 139,
  confirmed) plus its full body, then cross-referencing the matching-NN row
  already present in this table for `tests/integration.sh` (built by the
  prior task). Per the task contract, dialect pairs are almost always the
  SAME Rust test — every row below says "dialect pair, same target as
  integration.sh:LINE" and reuses that row's target slug(s) verbatim,
  needs-server/must-fail flags included, unless the `.ps1` body's own
  assertions genuinely diverge (two rows do; called out inline below).
- PowerShell's `ddb-fails` helper (`tests/integration.ps1:67`, defined but
  exercised only implicitly through `$LASTEXITCODE`/`try`/`catch` call
  sites across the file) maps to the same `assert_cmd` `.assert().failure()`
  idiom the other mapping tasks already use for must-fail rows. The helper
  itself is not ported — only its call sites' pass/fail assertions are, via
  whatever target test the corresponding `must-fail: Yes` row already names.
- Windows path-string-format check: read every section for literal
  backslash-vs-forward-slash path comparisons (the one case that would need
  a `cfg!(windows)` branch per the design doc's risk note). Found none —
  the file's only backslash literals (`rg "\\\\"` across the file) are
  PowerShell string-escaping for nested-JSON-in-JSON matching (e.g.
  `'\\"id\\":'`) or one JSON-argument escape for a GraphQL `backupPath`
  string (`ps1:1083`, `-replace '\\', '\\\\'`), never a path-format
  *assertion*. No row below needs a `cfg!(windows)` callout.
- Two rows genuinely diverge from their integration.sh counterpart's
  behavior (not just wording) and are flagged inline rather than marked a
  plain dialect pair: `tests/integration.ps1:1006` (§20 PgWire is
  unconditionally skipped, not psql-gated) and `tests/integration.ps1:3372`
  (§40 "help guides" is a genuine `.ps1`-only addition with no
  `integration.sh` counterpart at this position).
- §54.D (`ps1:2166`) and §55.D (`ps1:2364`) each gate their PgWire leg on
  `Get-Command psql -ErrorAction SilentlyContinue`, the same psql-absent
  skip pattern `integration.sh` uses at the same two sections. Per the
  design doc, PgWire e2e coverage drives the protocol via `tokio_postgres`
  directly, not a shelled-out `psql` binary, so this skip logic needs no
  Rust equivalent — noted once here, not repeated in both rows.
- The file carries the same duplicate-number pattern as `integration.sh`
  (`#37`, `#38`, `#49`, `#50` each appear twice, once in the
  server-dependent half and once in the CLI/git half) confirmed by the full
  139-header listing; each second occurrence is disambiguated below by
  cross-referencing its distinct `integration.sh` file:line rather than
  reusing the first occurrence's citation. `integration.sh:2174`'s `50c`
  (ALTER TABLE RENAME via PgWire) has no `.ps1` counterpart at all —
  verified against the full 139-header list, no `# 50c` line exists in
  `tests/integration.ps1` — so `integration_50c_alter_rename_pgwire`
  remains sh-only; no row below maps to it.

## Table — tests/integration.ps1

| tests/integration.ps1:85 | 17. GraphQL server | dialect pair, same target as integration.sh:52 | Yes | Yes | DONE (pre-existing, no port needed) |
| tests/integration.ps1:212 | 17.J1. Jink schema CREATE TABLE definitions (#9 jink full-sweep section 1) | dialect pair, same target as integration.sh:160 (`integration_17j1_jink_schema_create_tables`) | Yes | No | DONE |
| tests/integration.ps1:252 | 17.J2. jink-config singleton + Link CRUD (#9 jink full-sweep sections 3-4) | dialect pair, same target as integration.sh:205 (`integration_17j2_jink_config_singleton_and_link_crud`) | Yes | No | DONE (review assertions restored) |
| tests/integration.ps1:283 | 18. expanded GraphQL operations | dialect pair, same target as integration.sh:243 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:302 | 18b. GraphQL checkbox queries | dialect pair, same target as integration.sh:262 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:307 | 18c. GraphQL tag queries | dialect pair, same target as integration.sh:267 (`integration_18c_graphql_tag_queries`) | Yes | No | DONE |
| tests/integration.ps1:324 | 18c2. GraphQL updated_at and created_at fields | dialect pair, same target as integration.sh:284 (`integration_18c2_updated_at_created_at_fields`) | Yes | No | DONE |
| tests/integration.ps1:343 | 18d. GraphQL search filters | dialect pair, same target as integration.sh:305 (`integration_18d_search_filter_by_type_and_tag`) | Yes | No | DONE |
| tests/integration.ps1:370 | 18d2. Search where field filters (materialized columns + tag) | dialect pair, same target as integration.sh:335 | Yes | No | DONE (review assertions restored) |
| tests/integration.ps1:408 | 18d3. Search where filter: in operator | dialect pair, same target as integration.sh:377 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:456 | 18e. Boolean and phrase search queries | dialect pair, same target as integration.sh:429 | Yes | Yes | DONE (pre-existing, no port needed) |
| tests/integration.ps1:488 | 18g. Search query normalization | dialect pair, same target as integration.sh:465 (`integration_18g_normalize_query_implicit_and_lowercase`) | Yes | No | DONE |
| tests/integration.ps1:506 | 18h. In-query field-filter alignment + error-class consistency (PRD 00121) | dialect pair, same target as integration.sh:483 (`integration_18h_in_query_field_filter_and_error_class`) | Yes | Yes | DONE |
| tests/integration.ps1:573 | 18i. In-query field-filter substring + REFERENCES title resolution (PRD 00133) | dialect pair, same target as integration.sh:548 (`integration_18i_in_query_substring_and_references_title`) | Yes | No | DONE |
| tests/integration.ps1:603 | 18z. UPDATE/DELETE WHERE id no-match GraphQL parity (issue #5 group B) | dialect pair, same target as integration.sh:584 (`integration_18z_update_delete_no_match_parity`) | Yes | No | DONE |
| tests/integration.ps1:636 | 18z2. executeBatch atomicity (issue #9 group F4) | dialect pair, same target as integration.sh:619 (`integration_18z2_execute_batch_atomicity`) | Yes | Yes | DONE |
| tests/integration.ps1:660 | 18z3. updateDoogat tag semantics (#9 F5/F6/F7) | dialect pair, same target as integration.sh:648 (`integration_18z3_update_doogat_tag_semantics`) | Yes | No | DONE |
| tests/integration.ps1:690 | 18z4. SQL feature coverage pins (#9 F9) | dialect pair, same target as integration.sh:689 (`integration_18z4_sql_feature_coverage_pins`) | Yes | No | DONE |
| tests/integration.ps1:720 | 18z5. search() limit boundary pins (#9 F10) | dialect pair, same target as integration.sh:729 (`integration_18z5_search_limit_boundary_pins`) | Yes | Yes | DONE |
| tests/integration.ps1:743 | 18z6. ALTER TABLE ADD COLUMN surfaces in typeDefs introspection (#9 F11) | dialect pair, same target as integration.sh:760 (`integration_18z6_alter_table_add_column_in_typedefs_introspection`) | Yes | No | DONE |
| tests/integration.ps1:756 | 18z7. GraphQL schema introspection contract (#9 group G) | dialect pair, same target as integration.sh:792 (`integration_18z7_graphql_schema_introspection_contract`) | Yes | No | DONE |
| tests/integration.ps1:784 | 18z8. Category + membership jink port (#9 jink full-sweep section 5) | dialect pair, same target as integration.sh:830 (`integration_18z8_jink_category_membership_port`) | Yes | No | DONE |
| tests/integration.ps1:821 | 18z9. Jink quotes + saved-searches + pinned-results + jinkConfigs port (#9 jink full-sweep sections 10-12) | dialect pair, same target as integration.sh:870 (`integration_18z9_jink_quotes_saved_searches_pinned_results_config_port`) | Yes | No | DONE |
| tests/integration.ps1:880 | 18z10. Composite UNIQUE duplicate + compound-predicate DELETE jink port (#9 jink full-sweep sections 6+13) | dialect pair, same target as integration.sh:935 (`integration_18z10_jink_composite_unique_and_batch_delete_port`) | Yes | Yes | DONE |
| tests/integration.ps1:912 | 19. REST API CRUD (create/read/update/delete/auth/field-filter/tag-filter/sort) | dialect pair, same target as integration.sh:974 (sort half only: `integration_19_rest_sort_parameter`) | Yes | Yes | DONE |
| tests/integration.ps1:1006 | 20. PgWire — skip on Windows (psql rarely available) | DIVERGES from integration.sh:1067 — this `.ps1` section unconditionally prints `pass "pgwire: skipped (windows)"` (ps1:1007) and never drives any PgWire client, unlike the psql-`Get-Command`-gated skip pattern used later at 54.D/55.D. The rest of the body (nosql get/scan/reject-400/auth-401, sql-engine-error-descriptive, REST-404, GraphQL-introspection-hides-internal, compact incl. custom backupPath, maintenance mutation, sync-no-remote) is otherwise identical to integration.sh:1067's body. REST-404 ALREADY COVERED by `rest::rest_get_unknown_id_returns_404`; GraphQL-introspection-hides-internal ALREADY COVERED by `serve::graphql_introspection_hides_internal_tables`; compact/maintenance/sync-no-remote ALREADY COVERED by `server_mutations::compact_mutation_returns_result`+`compact_force_mutation`+`compact_no_backup_mutation`+`sync_mutation_no_remote_returns_error`. Reuses 4 of integration.sh:1067's 5 NEW targets — `integration_20_nosql_endpoints`, `integration_20_sql_engine_error_descriptive`, `integration_20_compact_custom_backup_path`, `integration_20_maintenance_mutation` — but NOT `integration_20_pgwire_boolean_type`, which has no `.ps1` source to port (no PgWire code path exists anywhere in this script's §20) | Yes | Yes | DONE |
| tests/integration.ps1:1100 | 37. WebSocket payload auth (browser-style, no Authorization header) | dialect pair, same target as integration.sh:1179 — ps1's own body is a no-op pass-through ("skipped in ps1 — see e2e tests", ps1:1101-1103) that self-documents `subscriptions::ws_payload_auth_subscribe_receive` as the intended coverage, the same citation integration.sh:1179 uses | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:1105 | 38. read-under-write: concurrent read + write | dialect pair, same target as integration.sh:1189 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:1118 | 38b. multi-value references via GraphQL + REST | dialect pair, same target as integration.sh:1199 (REST-references half only: `integration_38b_rest_structured_references_object`) | Yes | No | DONE (REST-references half only; test passes) |
| tests/integration.ps1:1136 | 38b2. REFERENCES relation resolution (singular object, plural list, null+empty) | dialect pair, same target as integration.sh:1222 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:1161 | 38b2b. raw ID scalar + orderBy/limit on plural references | dialect pair, same target as integration.sh:1248 | Yes | No | DONE (review assertions restored) |
| tests/integration.ps1:1192 | 38b3. typed connection includes tags | dialect pair, same target as integration.sh:1283 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:1202 | 38b4. tagEntries query with filters (doogatId eq, tag eq, tag contains) | dialect pair, same target as integration.sh:1293 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:1224 | 38c. sql-materialization (columns, boolean normalization, core fields) | dialect pair, same target as integration.sh:1316 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:1231 | 38c2. sql format:objects returns keyed rows | dialect pair, same target as integration.sh:1323 (boolean-coercion half only: `integration_38c2_boolean_coercion`) | Yes | No | DONE (boolean-coercion half only; test passes) |
| tests/integration.ps1:1255 | 38d. DISTINCT on typed connection queries | dialect pair, same target as integration.sh:1347 (`integration_38d_distinct_typed_query`) | Yes | No | DONE (test passes) |
| tests/integration.ps1:1267 | 38e. GROUP BY on typed aggregate queries | dialect pair, same target as integration.sh:1360 (`integration_38e_groupby_aggregate`) | Yes | No | DONE (test passes) |
| tests/integration.ps1:1286 | 38f. executeBatch mutation (multi-INSERT, DDL-triggers-reload, failure-rollback) | dialect pair, same target as integration.sh:1380 (`integration_38f_execute_batch_multi_statement`) | Yes | Yes | DONE (test passes) |
| tests/integration.ps1:1309 | 38g. batchUpdate mutation | dialect pair, same target as integration.sh:1407 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:1334 | 38h. createMany mutation | dialect pair, same target as integration.sh:1429 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:1361 | 38i. typed field updates via GraphQL (updateDoogat fields/unsetFields, deleteDoogat cleanup) | dialect pair, same target as integration.sh:1457 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:1403 | 42. base field filters on typed queries (id, title) | dialect pair, same target as integration.sh:1498 | Yes | No | DONE (review assertions restored) |
| tests/integration.ps1:1432 | 42b. base-field orderBy (created_at/updated_at/id) + deterministic pagination | `integration_orderby_base_fields::integration_42b_orderby_base_fields_deterministic_pagination` — actual spawned-server test; every created_at/updated_at/id ASC/DESC ordering and both deterministic pages match the two source dialects | Yes | No | DONE |
| tests/integration.ps1:1507 | 43. SQL INSERT via executeSql defaults date, created_at non-null | dialect pair, same target as integration.sh:1603 (`integration_43_sql_insert_defaults_date_graphql`) | Yes | No | DONE |
| tests/integration.ps1:1526 | 43.D SQL constraint enforcement on executeSql write path (PRD 00122 / issue #7) | dialect pair, same target as integration.sh:1622 (`integration_43_d_sql_constraint_enforcement`) | Yes | Yes | DONE |
| tests/integration.ps1:1600 | 44.E1 Pin JOIN as working via GraphQL sql() (issue #8 group E1; PRD 00123 archived as obsolete) | dialect pair, same target as integration.sh:1685 (`integration_44_e1_join_pin_graphql`) | Yes | No | DONE (review assertions restored) |
| tests/integration.ps1:1615 | 44.J Auto-junction tables populated atomically on SQL INSERT and UPDATE via GraphQL executeSql (PRD 00134) | dialect pair, same target as integration.sh:1705 (`integration_44_j_auto_junction_atomic_graphql`) | Yes | No | DONE |
| tests/integration.ps1:1648 | 44.K GraphQL createDoogat typed-create populates the auto-junction atomically (PRD 00134 cycle-1 review C1 task #4) | dialect pair, same target as integration.sh:1746 (`integration_44_k_create_doogat_auto_junction`) | Yes | No | DONE |
| tests/integration.ps1:1669 | 44.M Auto-junction parent-direction cleanup on DELETE via GraphQL executeSql (PRD 00137) | dialect pair, same target as integration.sh:1769 (`integration_44_m_parent_junction_cleanup_graphql`) | Yes | No | DONE |
| tests/integration.ps1:1703 | 44. DDL response consistency (no spurious errors; CREATE/ALTER/DROP TABLE, executeBatch DDL, DML-unchanged regression) | dialect pair, same target as integration.sh:1804 (`integration_44_ddl_response_consistency`) | Yes | No | DONE |
| tests/integration.ps1:1743 | 45. createMany onConflict: IGNORE (upsert via GraphQL) | dialect pair, same target as integration.sh:1848 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:1768 | 45.G13 issue #13: createDoogat must omit title when the typedef has a title_template | dialect pair, same target as integration.sh:1870 (`integration_45_g13_title_template_omit`) | Yes | Yes | DONE |
| tests/integration.ps1:1788 | 45.G12 issue #12: createMany(onConflict: IGNORE) intra-batch surviving id | dialect pair, same target as integration.sh:1891 (`integration_45_g12_intra_batch_ignore_surviving_id`) | Yes | No | DONE |
| tests/integration.ps1:1814 | 45.G11 issue #11: TagsFilter operators are nullable; contains-only/containsAll-only/containsAny-only | dialect pair, same target as integration.sh:1917 (`integration_45_g11_tags_filter_nullable_operators`) | Yes | Yes | DONE |
| tests/integration.ps1:1861 | 45.A1 Cross-mutation parity after a failed UNIQUE INSERT (issue #4 group A1) | dialect pair, same target as integration.sh:1969 (`integration_45_a1_cross_mutation_parity_after_unique_failure`) | Yes | Yes | DONE |
| tests/integration.ps1:1881 | 45.A3 Cross-table isolation (issue #4 group A3) | dialect pair, same target as integration.sh:1998 (`integration_45_a3_cross_table_isolation_after_unique_failure`) | Yes | Yes | DONE |
| tests/integration.ps1:1900 | 45.R10 RESTRICT on NOT NULL REFERENCES blocks delete via SQL and GraphQL (#10) | dialect pair, same target as integration.sh:2021 (`integration_45_r10_restrict_blocks_sql_and_graphql_delete`) | Yes | Yes | DONE |
| tests/integration.ps1:1934 | 45.A2 Ghost-row fix persists across server restart (issue #4 group A2) | dialect pair, same target as integration.sh:2073 (`integration_45_a2_ghost_row_survives_server_restart`) | Yes | Yes | DONE |
| tests/integration.ps1:1964 | 49. PRD 00131: structured-error code propagation through typed mutations (section banner only) | N/A — pure section banner, same as integration.sh:2109; coverage decided per sub-section at 49.1-49.4 below; dialect pair, same resolution as integration.sh:2109 | No | No | DONE (pre-existing, no port needed) <!-- banner-only line, nothing to port; see 49.1-49.4 --> |
| tests/integration.ps1:1971 | 49.1 createDoogat UNIQUE violation carries extensions.code = UNIQUE_VIOLATION (plus extensions.columns/values) | dialect pair, same target as integration.sh:2120 (`integration_49_1_unique_violation_extensions_code`) | Yes | Yes | DONE |
| tests/integration.ps1:1993 | 49.2 createDoogat NOT NULL violation carries extensions.code = NOT_NULL_VIOLATION (plus extensions.column) | dialect pair, same target as integration.sh:2133 (`integration_49_2_not_null_violation_extensions_code`) | Yes | Yes | DONE |
| tests/integration.ps1:2005 | 49.3 createMany single-input duplicate under onConflict: ERROR carries extensions.code = UNIQUE_VIOLATION | dialect pair, same target as integration.sh:2142 (`integration_49_3_createmany_error_extensions_code`) | Yes | Yes | DONE |
| tests/integration.ps1:2014 | 49.4 createMany multi-input intra-batch duplicate under onConflict: ERROR carries extensions.code = UNIQUE_VIOLATION | dialect pair, same target as integration.sh:2148 (`integration_49_4_createmany_intra_batch_error_extensions_code`) | Yes | Yes | DONE |
| tests/integration.ps1:2026 | 50. PRD 00132: ALTER TABLE foo RENAME TO bar across protocols (section banner only) | N/A — pure section banner, same as integration.sh:2159; the reserved slug `integration_50_alter_table_rename` stays unused here too, matching integration.sh's own resolution — coverage is delegated to 50a/50b below; dialect pair, same resolution as integration.sh:2159 | No | No | DONE (pre-existing, no port needed) <!-- banner-only line, nothing to port; see 50a/50b --> |
| tests/integration.ps1:2027 | 50a. via GraphQL executeSql | dialect pair, same target as integration.sh:2160 (`integration_50a_alter_rename_graphql`) | Yes | Yes | DONE |
| tests/integration.ps1:2036 | 50b. MySQL RENAME TABLE alias rejected with explicit message via GraphQL | dialect pair, same target as integration.sh:2169 (`integration_50b_mysql_rename_alias_rejected_graphql`) | Yes | Yes | DONE |
| tests/integration.ps1:2046 | 51. SINGLETON GraphQL flow + ALTER + parity, PRD 00139 T20/T22 (section banner only) | N/A — pure section banner, same as integration.sh:2188; dialect pair, same resolution as integration.sh:2188 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2050 | 51.A GraphQL singleton flow: null before first row, update-on-empty rejects SINGLETON_NOT_FOUND, upsert creates then updates, createDoogat rejects a second row | dialect pair, same target as integration.sh:2192 (complete flow: `integration_51_a_singleton_graphql_flow`) | Yes | Yes | DONE |
| tests/integration.ps1:2117 | 52.B ALTER TABLE SET/DROP SINGLETON (T20 §B) | dialect pair, same target as integration.sh:2242 (CLI setup/rejection and GraphQL reload: `integration_52_b_graphql_alter_set_drop_singleton_reload`) | Yes | Yes | DONE |
| tests/integration.ps1:2155 | 53.C SINGLETON DEFAULT VALUES auto-seed (T20 §C) | dialect pair, same target as integration.sh:2273 (`integration_53_c_singleton_default_values_auto_seed`) | No | No | DONE |
| tests/integration.ps1:2166 | 54.D Cross-protocol parity (T22) | dialect pair, same target as integration.sh:2282 (GraphQL/REST/NoSQL legs only: `integration_54_d_cross_protocol_singleton_duplicate_parity`); this section's psql-absent skip (`Get-Command psql -ErrorAction SilentlyContinue`, ps1:2248-2259) does NOT need porting — see Conventions above | Yes | Yes | DONE |
| tests/integration.ps1:2268 | 55. Cross-process SINGLETON write race + structured-error parity (PRD 00140) | dialect pair, same target as integration.sh:2366 | Yes | Yes | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2270 | 55.A CLI `ddb create` race | dialect pair, same target as integration.sh:2376 | Yes | Yes | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2303 | 55.B GraphQL `executeSql` INSERT race | dialect pair, same target as integration.sh:2400 (`integration_55_b_graphql_execute_sql_singleton_insert_race`) | Yes | Yes | DONE |
| tests/integration.ps1:2335 | 55.C GraphQL typed `createDoogat` race | dialect pair, same target as integration.sh:2428 (`integration_55_c_graphql_create_doogat_singleton_insert_race`) | Yes | Yes | DONE |
| tests/integration.ps1:2364 | 55.D CLI-vs-PgWire concurrent INSERT race (PRD 00157 determinism contract) | dialect pair, same target as integration.sh:2454 (`integration_55_d_cli_vs_pgwire_singleton_insert_race`); this section's psql-absent skip (ps1:2386-2429, explicitly self-documented as "Follow .ps1 section 54.D convention") does NOT need porting — see Conventions above | Yes | Yes | DONE |
| tests/integration.ps1:2432 | 55.E convergence parity: every protocol's race left exactly one row | `singleton_cross_process_create::two_concurrent_ddb_create_on_singleton_converge_on_one_row` + `integration_singleton_races::integration_55_b_graphql_execute_sql_singleton_insert_race` + `integration_singleton_races::integration_55_c_graphql_create_doogat_singleton_insert_race` + `integration_singleton_races::integration_55_d_cli_vs_pgwire_singleton_insert_race` — each race asserts its own exact final count of one; all four protocol outcomes retained | Yes | No | DONE |
| tests/integration.ps1:2449 | 56. REST warnings envelope pinning AppOutput.warnings on POST /doogats (PRD 00147 doubt-review follow-up) | dialect pair, same target as integration.sh:2538; shared fixture asserts both CLI success messages | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2460 | 56.A caller-supplied title yields warnings: [] (still present, never skipped) | dialect pair, same target as integration.sh:2548 (`integration_56_a_rest_create_titled_warnings_empty`) | Yes | No | DONE |
| tests/integration.ps1:2469 | 56.B omitted title with a title_template typedef yields a TITLE_FROM_TEMPLATE warning entry | dialect pair, same target as integration.sh:2558 (`integration_56_b_rest_create_omitted_title_title_from_template_warning`) | Yes | No | DONE |
| tests/integration.ps1:2485 | 57. GraphQL warnings envelope (PRD 00154), pinning the WarningExtension contract | N/A — pure comment block, same as integration.sh:2572; dialect pair, same resolution | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2491 | 57.A caller-supplied title yields extensions.warnings: [] (always present) | dialect pair, same target as integration.sh:2579 (`integration_57_a_graphql_create_titled_extensions_warnings_empty`) | Yes | No | DONE |
| tests/integration.ps1:2503 | 57.B omitted title with a title_template typedef fires TITLE_FROM_TEMPLATE under extensions.warnings | dialect pair, same target as integration.sh:2586 (`integration_57_b_graphql_create_omitted_title_title_from_template_warning`) | Yes | No | DONE |
| tests/integration.ps1:2526 | 58. Update warning/error shape (PRD 00149): warnings channel + structured NOT_FOUND app-error code | dialect pair, same target as integration.sh:2606 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2534 | 58.A GraphQL updateDoogat carries extensions.warnings: [] (always present) and applies the change | dialect pair, same target as integration.sh:2617 (`integration_58_a_graphql_update_warnings_empty`) | Yes | No | DONE |
| tests/integration.ps1:2549 | 58.B GraphQL updateDoogat on a missing id surfaces extensions.code = NOT_FOUND | dialect pair, same target as integration.sh:2628 (`integration_58_b_graphql_update_missing_id_not_found`) | Yes | Yes | DONE |
| tests/integration.ps1:2558 | 58.C REST PUT /doogats/{id} update response always carries a warnings array and applies the change | dialect pair, same target as integration.sh:2635 (`integration_58_c_rest_update_warnings_empty`) | Yes | No | DONE |
| tests/integration.ps1:2570 | 58.D REST PUT on a missing id surfaces the structured NOT_FOUND envelope (404) | dialect pair, same target as integration.sh:2648 (`integration_58_d_rest_update_missing_id_not_found`) | Yes | Yes | DONE |
| tests/integration.ps1:2578 | 59. REST typed create via the `fields` body member (PRD 00149) | N/A — GraphQL DDL fixture setup only, same as integration.sh:2659; dialect pair, same resolution | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2584 | 59.A POST /doogats with type + fields populates the typed column | dialect pair, same target as integration.sh:2667 | Yes | No | DONE (review assertions restored) |
| tests/integration.ps1:2592 | 59.B malformed fields JSON is rejected with 400 + VALIDATION_ERROR before any row is written | dialect pair, same target as integration.sh:2680 | Yes | Yes | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2606 | 60. Typed where-filter completeness (PRD 00159) | dialect pair, same target as integration.sh:2698 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2649 | 60.A Negation: notIn / nin | dialect pair, same target as integration.sh:2739 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2660 | 60.B Null operators | dialect pair, same target as integration.sh:2750 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2671 | 60.C Forward relation sub-filter (inlined target columns) | dialect pair, same target as integration.sh:2761 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2683 | 60.D Forward id-ops (back-compatible) | dialect pair, same target as integration.sh:2772 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2689 | 60.E none / some | dialect pair, same target as integration.sh:2778 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2700 | 60.F Reverse membership | dialect pair, same target as integration.sh:2789 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2713 | 60.G Relation filter + orderBy + pagination + totalCount correlation | dialect pair, same target as integration.sh:2800 | Yes | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2732 | 61. Cross-process write lock: no lost commit under concurrent writers (PRD 00162) | N/A — pure comment plus a directory change, same as integration.sh:2817; dialect pair, same resolution | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2741 | 61.A N concurrent CLI `ddb update` writers on distinct doogats must all land | dialect pair, same target as integration.sh:2826 | No | Yes | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2767 | 61.B a `ddb serve` (GraphQL) write concurrent with a CLI write; both must land | dialect pair, same target as integration.sh:2847 (`integration_61_b_concurrent_cli_and_graphql_write_lock`) | Yes | No | DONE |
| tests/integration.ps1:2809 | 21. fast-forward sync | dialect pair, same target as integration.sh:2886 (`integration_21_clone_reindex_reads_pushed_note`) | No | No | DONE |
| tests/integration.ps1:2823 | 22. non-overlapping edits (clean git merge, no CRDT) | dialect pair, same target as integration.sh:2900 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2842 | 23. frontmatter scalar conflict (title) — CRDT resolves | dialect pair, same target as integration.sh:2918 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2861 | 24. frontmatter list conflict (tags) — CRDT set-union | dialect pair, same target as integration.sh:2937 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2880 | 25. body conflict — Automerge Text CRDT | dialect pair, same target as integration.sh:2956 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2900 | 26. reference section conflict — write files directly, CRDT union | dialect pair, same target as integration.sh:2976 (`integration_26_reference_section_conflict`) | No | No | DONE |
| tests/integration.ps1:2926 | 26b. deterministic CRDT convergence smoke (PRD 00165) | dialect pair, same target as integration.sh:3002 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2953 | 27b. delete-vs-edit conflict — edit wins, doogat resurrected | dialect pair, same target as integration.sh:3028 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:2983 | 27c. three-way conflicted merge preserves deletion + local edit (PRD 00200) | dialect pair, same target as integration.sh:3056 (`integration_27c_three_way_conflicted_merge`) | No | No | DONE |
| tests/integration.ps1:3026 | 27a. add-add collision: both doogats survive | dialect pair, same target as integration.sh:3097 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3081 | 27a2. add-add collision: single commit + both nodes converge | dialect pair, same target as integration.sh:3155 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3096 | 27. bundle export --full + import | dialect pair, same target as integration.sh:3168 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3110 | 28. delta bundle export + import | dialect pair, same target as integration.sh:3181 (`integration_28_delta_bundle_target_export`) | No | No | DONE |
| tests/integration.ps1:3125 | 28a. bundle-import conflict recovery (PRD 00168) | dialect pair, same target as integration.sh:3193 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3144 | 29. update-bin help + rollback | dialect pair, same target as integration.sh:3215 (`integration_29_update_bin_help_and_rollback`) | No | Yes | DONE |
| tests/integration.ps1:3155 | 30. ALTER TABLE + DROP TABLE + bulk UPDATE/DELETE (+ WHERE id no-match semantics, issue #5 continuation) | dialect pair, same target as integration.sh:3225 (no-match-semantics half only: `integration_30_where_id_no_match_semantics`) + `sql_lifecycle::bulk_update` + `sql_lifecycle::bulk_delete` (basic bulk-operation assertions) | No | No | DONE (no-match-semantics half only) |
| tests/integration.ps1:3205 | 30.F1 composite UNIQUE duplicate rejection surfaces a clear error on the CLI (issue #9 group F1) | dialect pair, same target as integration.sh:3258 (`integration_30_f1_composite_unique_cli_rejection`) | No | Yes | DONE |
| tests/integration.ps1:3218 | 31. file attachments | dialect pair, same target as integration.sh:3272 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3235 | 32. NoSQL CLI commands (get, scan --tag, scan --type, backlinks) | dialect pair, same target as integration.sh:3284 (`integration_32_nosql_cli_commands`) | No | No | DONE |
| tests/integration.ps1:3252 | 33. stale node resync after compaction | dialect pair, same target as integration.sh:3298 (byte-stats-report half only: `integration_33_compact_byte_stats_report`) | No | No | DONE (byte-stats-report half only) |
| tests/integration.ps1:3301 | 34. multi-row INSERT | dialect pair, same target as integration.sh:3347 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3310 | 35. transaction commit + rollback | dialect pair, same target as integration.sh:3355 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3323 | 36. hyphenated type SQL via quoted identifiers | dialect pair, same target as integration.sh:3366 (`integration_36_hyphenated_type_create_table`) | No | No | DONE |
| tests/integration.ps1:3333 | 37. junction table CRUD (multi-value references) | dialect pair, same target as integration.sh:3374 — second `#37`, distinct from the WebSocket §37 above (ps1:1100), matching integration.sh's own collision note | No | Yes | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3354 | 38. title template compliance check | dialect pair, same target as integration.sh:3390 — second `#38`, distinct from the read-under-write §38 above (ps1:1105) | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3363 | 39. zone migration | dialect pair, same target as integration.sh:3398 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3372 | 40. help guides | .ps1-only addition — no corresponding integration.sh section at this position (integration.sh's own `#40` is "binary asset LWW conflict resolution" at line 3407, mapped in the next row). Re-runs `ddb help create-app`, `ddb help` (list), `ddb help nonexistent` (fails) — the same three assertions ALREADY COVERED by `help::help_create_app_prints_guide` + `help::help_no_topic_lists_guides` + `help::help_unknown_topic_fails` (the same trio cited for smoke.sh:321's "help guides" sub-block). Existing Rust coverage; no shell survivor needed | No | Yes | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3387 | 40. binary asset LWW conflict resolution | dialect pair, same target as integration.sh:3407 (`integration_40_binary_asset_lww`) | No | No | DONE |
| tests/integration.ps1:3438 | 41. auto-register node on first sync | dialect pair, same target as integration.sh:3464 | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3466 | 46. title_template REFERENCES resolution (PRD 00127) | dialect pair, same target as integration.sh:3488 | No | Yes | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3498 | 47. ALTER TABLE ALTER COLUMN TYPE (PRD 00128) | dialect pair, same target as integration.sh:3516 | No | Yes | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3538 | 48. PRD 00129: typed write blockers (CREATE INDEX no-op/rejection, ON DELETE CASCADE, ON DELETE RESTRICT default, cascade cycle detection) | dialect pair, same target as integration.sh:3563 (CREATE INDEX + CASCADE + cycle-detection halves only: `integration_48_typed_write_blockers_and_cascade`) | No | Yes | DONE (CREATE INDEX + CASCADE + cycle-detection halves only) |
| tests/integration.ps1:3595 | 49. PRD 00133 unify-typed-write-paths: CLI typed create populates REFERENCES columns and rejects FK to wrong-type ids | dialect pair, same target as integration.sh:3626 — second `#49`, distinct from the structured-error-propagation §49 above (ps1:1964) (`integration_49_unify_typed_write_paths`) | No | Yes | DONE |
| tests/integration.ps1:3633 | 44.L CLI `ddb create` populates the auto-junction atomically (PRD 00134 cycle-1 review C1 task #4) | dialect pair, same target as integration.sh:3674 (`integration_44_l_cli_create_auto_junction`) | No | No | DONE |
| tests/integration.ps1:3654 | 50. PRD 00136 / #16 cross-process FK freshness on `ddb create` | dialect pair, same target as integration.sh:3697 — second `#50`, distinct from the ALTER TABLE RENAME §50 banner above (ps1:2026); reserved slug `integration_50_cross_process_fk_freshness` stays unused here too, matching integration.sh's own resolution — ALREADY COVERED by `cli_create_fk_freshness::create_link_after_category_in_separate_process_succeeds_without_reindex` | No | No | DONE (pre-existing, no port needed) |
| tests/integration.ps1:3678 | 62. PRD 00164 unified repo-aware ID minting (end-to-end CLI conformance) | dialect pair, same target as integration.sh:3720 (`integration_62_id_minting_no_same_second_collision`) | No | No | DONE |
| tests/integration.ps1:3703 | 63. PRD 00169 poison-file skip warning through GraphQL extensions | dialect pair, same target as integration.sh:3746 (`integration_63_poison_file_graphql_warning`) | Yes | No | DONE |

## Row count check — integration.ps1

`rg -c "^# [0-9]" tests/integration.ps1` → 139 numbered section headers
(confirmed). This append adds exactly 139 rows above, one per matched
header, in file order.

Combined with the 252 rows already in the table (56 smoke.sh + 56
smoke.ps1 + 140 integration.sh), the table now has 391 rows total
(252 + 139).

The file carries the same `#37`/`#38`/`#49`/`#50` duplicate-number pattern
as `integration.sh` (each appears once in the server-dependent half,
lines ~85-2847, and once more in the CLI/git half, lines ~2809-3781) plus
one additional duplicate not present in `integration.sh`: `#40`
(`ps1:3372` "help guides", a `.ps1`-only addition, vs. `ps1:3387` "binary
asset LWW conflict resolution", the dialect pair of `integration.sh:3407`).
Every duplicate is disambiguated above by file:line and cross-referenced to
its distinct `integration.sh` counterpart (or, for `#40`'s first
occurrence, marked a `.ps1`-only reuse of existing Rust help tests with no `integration.sh`
counterpart to reference).

`integration.sh:2174`'s `50c` (ALTER TABLE RENAME TO via PgWire) has no
`.ps1` counterpart — confirmed against the full 139-header listing, no
`# 50c` header exists in `tests/integration.ps1`. `integration_50c_alter_rename_pgwire`
remains sh-only.

Two rows diverge in actual behavior from their `integration.sh` dialect
pair rather than merely restating it: `ps1:1006` (§20 PgWire is
unconditionally skipped, not psql-gated — 4 of the 5 sh-side gap targets
still apply, `integration_20_pgwire_boolean_type` does not) and `ps1:3372`
(§40 "help guides", a genuine `.ps1`-only addition resolved as a justified
reuse). Every other row is a straight dialect pair reusing its
integration.sh counterpart's target, needs-server, and must-fail values
verbatim.

Zero unmapped sections.

Task 12 local coverage gate completed at `36c0687`: 391 audited source rows, 565 registered tests, no remaining TODO rows. Exact validation results and prior failure repairs are in `dev/local/reviews/00171-task12-verification.md`; discovery proof is `dev/local/reviews/00171-mapping-discovery.json`. Shell retirement remains gated on task 13 replacement CI.

Review repair `32aa884` retains the pre-existing GraphQL auto-seed path alongside section 53C CLI coverage. `integration_` rerun: 83 passed, 0 failed, 15.95s. No source row or registered test was removed.

Task 13 replacement CI passed at `5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4`: Full Validation run `33991344845`, all six jobs successful including Linux e2e, macOS full, and Windows full; push Test run `33991275129` successful. Evidence is `dev/local/reviews/00171-task13-ci-green.json`. This satisfied the pre-deletion gate.

Task 14 retired all four source scripts in `c8b72bd9126c83d054264ce6ac3738e8f6d0abda`; there are no survivors. The source paths/line numbers above are historical references into parent revision `5cf4c36`. Replacement Rust edits in task 14 are comments only, and the complete post-deletion e2e baseline passed: 565 tests, zero failed or ignored. Final task 14 review, local gates, and post-deletion push CI are recorded in `dev/local/reviews/00171-task14-verification.md`. PRD acceptance still requires the fresh review session after build handoff.
