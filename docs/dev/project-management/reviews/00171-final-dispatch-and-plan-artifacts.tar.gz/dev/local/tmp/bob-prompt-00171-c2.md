Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-context-00171-c2.md for review context, and /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00171-c2.diff for the full diff.

Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/engram-pack-00171-c2.md and treat its full content as prepended context: similar code, reuse precedent, findings precedent, and task prose for this diff's changed symbols.

Use this review checklist:
# Review Dimensions

Detailed checklist for reviewing completed work.

## Plan Compliance

- [ ] Implementation matches task description
- [ ] All acceptance criteria met
- [ ] No scope creep (extra features not requested)
- [ ] No missing pieces from original task

## PRD Coverage

- [ ] All "must have" requirements addressed
- [ ] Success metrics achievable with implementation
- [ ] No PRD sections left unimplemented
- [ ] Dependencies correctly handled

## Simplification

Hunt actively for simplification — do not just tick boxes. The diff under
review is fresh; this is the cheapest moment to cut complexity before it sets.
For every added or changed file, ask "what would make this simpler to read
without changing what it does?" and flag concrete opportunities.

- [ ] **Reduce complexity** — no needless indirection, dead branches, or
      abstractions built for a single caller; nesting <= 4 levels; functions
      under 50 lines
- [ ] **Eliminate redundancy** — no logic duplicated within the diff or against
      existing code; no helper that reimplements a stdlib or existing utility
- [ ] **Improve naming** — names state intent; no opaque abbreviations;
      action-named functions start with a verb
- [ ] **Follow project standards** — conventions from CLAUDE.md / AGENTS.md and
      the surrounding code; no style drift
- [ ] **No dead code** — no commented-out blocks, unused imports, variables, or
      speculatively-added parameters
- [ ] **Appropriate error handling** — explicit, never silently swallowed

**How to flag a simplification:** give the file:line, the current shape, and
the simpler replacement. Flag concrete behavior-preserving simplifications at
🟡 Medium so the decision gate routes them into the rework loop. Do not inflate
them to 🟠 High; that floods the rework loop and can trip the scope alarm.

**Balance — do not over-simplify:** never propose a change that trades clarity
for brevity, drops error handling, collapses a deliberate boundary, or removes
a documented invariant. Simpler means easier to read and maintain, not shorter
at any cost. If a "simplification" would change behavior, it is out of scope —
do not flag it.

## Testing

- [ ] Unit tests for new logic
- [ ] Edge cases covered
- [ ] Error paths tested
- [ ] Integration tests if crossing boundaries
- [ ] Tests actually run and pass
- [ ] No tautological test — every new or changed test fails against the
      pre-change code (the context's fail-first replay block), and no assert
      is constant, self-comparing, or an either-or hedge (the shapes block)

## Security

- [ ] No hardcoded secrets
- [ ] Input validation at boundaries
- [ ] No SQL/command injection risks
- [ ] Auth/authz correctly applied
- [ ] Sensitive data not logged

## Documentation

- [ ] Public APIs documented
- [ ] Complex logic has comments
- [ ] README updated if needed
- [ ] Breaking changes noted

In addition, work through the numbered rubric:
# Review-Work-Completion Rubric

This rubric defines binary pass/fail criteria for consensus review of completed work. Each rule is numbered and stable for tracking coverage. Reviewers must answer "R{n}: pass|fail" for every rule in their prompt.

## Rules

### Tests

R1: Tests cover every new behavior introduced by the diff.
R2: Tests bind to intent, not just observable behavior; no new or changed test is tautological (passes against the pre-change code, or cannot fail as written).
R3: No skipped or xfail tests mask failures.

### Integration

R4: Changed components integrate with existing callers.

### Security

R6: No hardcoded secrets in the codebase.
R7: All user input is validated and sanitized.
R8: No injection-unsafe queries or commands.

### Domain

R9: Implementation matches PRD feature behavior exactly.
R10: Error handling is explicit and not swallowed.
R11: No debug statements, TODOs, or placeholder markers remain.

### Code Quality

R12: Function sizes respect the 50-line limit.
R13: File sizes respect the 800-line limit.

Review the completed work against PRD requirements. Explore the codebase as needed.

OUTPUT FORMAT IS MANDATORY. Follow exactly:
## Agent Output Format (Single Source of Truth)

Each agent outputs issues in this exact format:

```
[{AGENT_NAME}] {emoji} {description} | File: {path or "N/A"} | Task: {id or "general"}
```

**Severity emojis:** 🔴 Critical, 🟠 High, 🟡 Medium, ⚪ Low

**Rules:**
- One issue per line
- Use "N/A" for file if issue is architectural/cross-cutting
- Use "general" for task if issue spans multiple tasks or is a PRD gap
- If zero issues found: `[{AGENT_NAME}] ✅ No issues found`

**Examples:**
```
[ALICE] 🔴 SQL injection in query builder | File: src/db/query.ts | Task: 3
[BOB] 🟠 Missing error handling strategy | File: N/A | Task: general
[CARL] 🟡 PRD section 2.3 not implemented | File: N/A | Task: 5
```

Your agent name is BOB. Emit `[BOB]` on every issue line.

PER-RULE VERDICTS ARE MANDATORY. For every rule in the numbered rubric, emit one line:
R{n}: pass   or   R{n}: fail
(one rule per line, no other text on the line, no rationale).

## Sandbox Constraints

You run in a restricted sandbox. You CANNOT execute code, tests, linters, or package managers.

Perform STATIC analysis only:
- Read code for logical correctness, patterns, naming, structure
- Check for missing imports, dead code, type mismatches
- Review against PRD requirements by reading, not executing
- Trace data flow and control flow by reading source

If a criterion requires runtime verification (e.g. "tests pass", "linter clean"), output:
[BOB] ⚪ Cannot statically verify: {criterion description} | File: N/A | Task: {id}

Do NOT attempt to run commands. Do NOT report failures from blocked execution.

## Two lenses, applied to every changed file

Treat the following findings precedent as already recorded for this diff's changed symbols. Weigh it when applying both lenses and the rubric verdicts rather than re-litigating known prior findings.

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00029-cartographer-evaluate-phase-4-6-reactivation-v1-review-1.md
  `.json` ledgers.

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00128-discarded-reviews-and-lost-alerts-v1-review-2.md
  directly. So the seven `assertEqual(result, True/False)` sites in

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00129-autoclaude-suite-stubs-do-not-intercept-v1-review-1.md
  **FIX:**

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00129-autoclaude-suite-stubs-do-not-intercept-v1-review-2.md
  **VERIFY:**

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00130-hook-gates-fail-open-silently-v1-review-2.md
  ## Follow-up Tasks Created

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00133-cut-hook-and-suite-overhead-v1-review-2.md
  **Blake 🟡 "Success Metric says one repo-root resolution, implementation still

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  ### Medium (🟡) — deferred

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  - **[Alice, Carl, Quinn] `tests.rs` (963) and `mod.rs` (846) exceed the 800-line style guideline; the merge test (~88 lines) exceeds the 50-line function guideline.** `mod.rs` overage is pre-existing (846 at work-start, 2 lines changed here); `tests.rs` crossed 800 due to this PRD's test additions (767→963). Not a CI gate (clippy clean; test-ci passes). Reviewers agree the concurrency test should not be force-split. → **Deferred**: soft style guideline on test/pre-existing files; a `git_ops` test-file split is a reasonable future cleanup, out of scope for a surgical P0 fix.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  - **⚪ "cannot statically verify build/clippy/tests"** (Bob, Alice) — resolved: `cargo test-ci` → 1662 passed, 0 failed, 0 ignored, exit 0; `cargo clippy --workspace --all-targets` clean (Alice).

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-02.md
  - **[1/5] ⚪ scenario-62 comment still overclaimed** (Bob): the named core regressions (`id_mint_collision.rs`, `raw_create_mint_collision.rs`) exercise `create_doogat_raw`, not `install_bundled_type`, so listing both as "pinned by" them was imprecise. **Fixed inline** (commit `56befa7`): the comment now states `create_doogat_raw` collisions are pinned by those regressions while `install_bundled_type` routes through the same shared oracle (`id_minting.rs` unit tests). Comment-only, zero runtime impact — no further review cycle warranted.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00166-make-hlc-load-bearing-v1-review-01.md
  - **[1/3] ⚪ Low — Stale tie-break doc comments in `sync_manager`.** `resolve_add_add_collision`'s comment says "theirs on tie/missing" and `resolve_lww`'s says "falls back to 'ours'", but both now call `lww_pick` (higher content key on tie/missing). The comments assert the old opposite defaults the PRD required reconciled. File: `ddb-core/src/sync_manager/mod.rs`. Found by: Blake.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00167-sync-collision-reassignment-atomicity-v1-review-01.md
  | [4/5] | 🔴 | `git rev-list --count PRE..POST` without `--first-parent` returns 4 (merge + bookkeeping + the two fetched peer commits), not the asserted 2. Under `set -euo pipefail` this aborts integration.sh at section 27a, so 27a2 and every later section (bundle sync, server, advanced SQL) never runs. The e2e twin uses `--first-parent` and comments that it is required. | tests/integration.sh:3149 | 7 | ALICE, BLAKE, BOB, EVE |

### 1. Doubt lens (correctness)
Surface residual findings a confident reviewer would wave past:
- spec gaps: PRD says X, code does Y (wrong field names, enum values,
  thresholds, artifact kind);
- missing or incomplete features the PRD requires;
- edge cases, error paths, and failure modes left unhandled;
- tests that cannot fail: they assert the implementation rather than the intent,
  or still pass against the pre-change code (the caller's mechanical test checks
  list every one it found; each is behavior left unpinned).

### 2. De-slop lens (quality)
Flag slop introduced by the changes (do not propose broad refactors):
- over-abstraction / single-caller indirection with no current testability or
  architectural need;
- dead code, code kept in comments, unreachable branches;
- defensive guards for states that cannot occur;
- restating docstrings, "robust" error messages with no context, premature
  configuration, framework-verification tests;
- speculative generality (parameters, hooks, or layers nothing uses yet).
Bias: aggressive on newly-created files (slop concentrates there), conservative
on lightly-touched files (do not destabilize existing behavior).

## Rubric verdicts (REQUIRED — emit verbatim, one per line)

Apply the doubt-review rubric. A rule you cannot evaluate is `fail`; never omit
a line.
- D1: every residual finding is in exactly one of FIX/VERIFY/KNOWN.
- D2: all FIX items are genuinely fixable now (bounded, in-scope, actionable).
- D3: all VERIFY items name the exact check needed (not vague).
- D4: all KNOWN items carry a written out-of-scope justification.
- D5: input finding count equals FIX + VERIFY + KNOWN counts.

Emit exactly:

```
D1: pass|fail
D2: pass|fail
D3: pass|fail
D4: pass|fail
D5: pass|fail
```

Do not modify any files. This is a review only — produce findings and the
rubric verdict lines. No commits.

---

## This is an INCREMENTAL review (cycle 2 of PRD 00171)

This is an **incremental review** of the rework done since the previous review
cycle — the diff is scoped to changes since then. Two jobs: (1) for each prior
finding listed below, verify it is now resolved in the code; (2) review the
scoped diff for any regression the rework introduced. You need not re-review
unchanged code; the previous cycle already reviewed the full implementation.

**Scope discipline:** the review diff is `bd3e7f0..74644b8` (commits `103c8ab`
and `74644b8`). Four other commits sit in the same history window
(`dbc128f`, `bd3e7f0`, `4a248cb`, `876a153`) and were written by a different,
concurrent session. They are NOT PRD 00171 work. Do not raise findings against
their `ddb-core/src/**` production changes or their `hazard_*.rs` test files.

### Prior cycle (1) consolidated findings you must verify as resolved

The eight actionable ones, all claimed fixed by `103c8ab` (task 15) and
`74644b8` (task 16):

1. 🟠 HIGH — Per-push CI coverage dropped: `.github/workflows/test.yml`'s
   `Smoke test (e2e)` step ran only the 30 `smoke_*` tests of 565, while ~26 of
   smoke.sh's 56 sections had been mapped to pre-existing e2e modules outside
   that filter (delete_backlinks, tags, checkboxes, folder_namespace,
   search_links, link_kinds, rename, sql_lifecycle, alter_table_rename,
   cli_create_fk_freshness, inline_zone, discover, fix, sequence, help,
   cascade_delete, sql_expressions_test, set_flag, date_default,
   alter_column_type, schema_apply, poison_file_reindex,
   cli_create_unregistered_type, cli_update_app_error, sync_crdt). Those ran on
   every push under smoke.sh and would now run nightly only, contradicting the
   PRD's "CI keeps identical coverage". Prescribed fix: replace the `smoke_`
   step and the five `--exact` steps with one `cargo test -p ddb-e2e` step, drop
   the `DDB_BIN` env, and fix the test.yml sentence in AGENTS.md.
2. 🟡 §42 totalCount assertions dropped — `tests/e2e/serve.rs` around
   `filter_base_field_title_eq` and `filter_base_field_title_contains`: bash
   1505/1517 asserted `totalCount == 1`; the Rust tests requested the field but
   never read it.
3. 🟡 §44.E1 JOIN pin degraded to single-character containment —
   `tests/e2e/integration_junction_sync.rs:35-43` used `row_str.contains('a')` /
   `contains('1')`, which also pass on `["abc","10"]`; bash 1699-1700 grepped
   the quoted tokens.
4. 🟡 §59.A cross-process read-back dropped — `tests/e2e/rest.rs:153-154`: bash
   2667-2677 read the typed column back through a separate `ddb query` process;
   the Rust target read through the same server's executeSql.
5. 🟡 §18d2 eq-exactness fixture lost — `tests/e2e/serve.rs`
   `search_where_filter_materialized_column_eq`: bash 341-346 seeded
   `https://example.com/page` so a prefix/LIKE `eq` would fail; the Rust test
   seeded two identical `https://example.com`, so a prefix match still passed.
6. 🟡 §38b2b raw-scalar pin with multiple junction rows lost —
   `tests/e2e/reference_raw_id.rs`: bash 1260-1265 linked three categories and
   asserted `rlcat_id == <first-linked>`; the Rust test linked one.
7. 🟡 §17.J2 numeric-id assertion weakened —
   `tests/e2e/integration_graphql_jink.rs:158`: bash 217 required
   `"message":"[0-9]+"`, Rust asserted `!config_id.is_empty()`.
8. ⚪ Slop — `stdout()` copy-pasted in smoke_core.rs, smoke_sql.rs,
   smoke_search.rs; the 14-digit-id check reimplemented as `assert_doogat_id`,
   `is_14_digit_id` and inline in several modules. Consolidate into
   `tests/e2e/common.rs`.

**Judge each of these on the actual code, not on the rework report's claims.**
For each strengthened assertion, ask the load-bearing question: would this
assertion actually fail against the weak pre-change version? An assertion that
was "restored" but still cannot distinguish the failure mode is not resolved.

## Settled decisions — do not re-raise

These calls were already made in an earlier cycle of this same review, with
the reasons given. Do not re-raise them. Raise a NEW finding only if you can
show the settled reason no longer holds.

- discarded | low | "Review diff/commit range for PRD 00171 bundles unrelated PRD 00202 HLC-logic commits (git_ops/read.rs, tests.rs) — a process/traceability issue, not a defect in 00171's own work" | ddb-core/src/git_ops/read.rs | Git history identifies interleaved, separately authored PRD 00202 commits; not scope creep by 00171. Full work_start_sha is intentionally preserved.
- settled-deferral | medium | "Multi-process race tests not marked #[serial] as PRD explicitly requires (mitigated by per-test port/tempdir isolation)" | tests/e2e/integration_singleton_races.rs | Existing reviewed design deliberately uses independent TempDirs/ports and order-independent race results instead of serial markers. Retain parallel execution; record the stale PRD wording.
- discarded | low | "PRD checklist unchecked and file still in wip/ despite verifiably complete, CI-green implementation" | dev/local/prds/wip/00171-migrate-shell-scenarios-to-e2e-v1.md | PRD is intentionally wip until review converges and a fresh finalize session accepts it.
- settled-deferral | low | "Several newly-ported multi-process race test functions run well past the 50-line guideline (integration_61_b_concurrent_cli_and_graphql_write_lock ≈145 lines, integration_55_d_cli_vs_pgwire_singleton_insert_race ≈152 lines)" | tests/e2e/integration_write_lock_races.rs | Keep cohesive multi-process scenario orchestration and HEAD durability checks; shared operations are already helpers. The project Rust instructions have no hard function-size limit, and broad test fragmentation is outside this coverage repair.
- settled-deferral | low | "The mechanical fail-first/tautology finder for this cycle reports 'Checked 0 test function(s)' ... the automated tautology net did not fire for this diff" | N/A | Installed mechanical checks are explicitly Python-only. Extending shared tooling is outside 00171; this cycle used Rust source audits and same-HEAD runtime evidence.
- discarded | low | "[VERIFY] Tier 2 has not run on the deletion commit ..." | N/A | Live GitHub confirmed the contract-required full validation before deletion and Test after deletion. A fixed duration and old exact test count are not validity gates. Rework will be pushed for fresh CI. Not queued: command shape.
- settled-deferral | low | "[KNOWN] PRD says the §55/§61 race sections are 'marked serial'; no serial marker exists" | tests/e2e/integration_singleton_races.rs | Existing reviewed design deliberately uses independent TempDirs/ports and order-independent race results instead of serial markers. Retain parallel execution; record the stale PRD wording.
- settled-deferral | low | "[KNOWN] PRD spawn helper 'polls /health'; ServerGuard::start waits on the stderr 'listening on' lines plus a 50 ms sleep, no /health poll" | tests/e2e/common.rs | Design deliberately reuses existing ServerGuard readiness; health_returns_ok tests its lifecycle. Internals are reserved for 00188, outside this test migration.
- discarded | low | "[KNOWN] §54.D/§55.D psql-absent skip semantic not ported" | tests/e2e/pgwire_singleton.rs | Rust PgWire client is a declared dependency; every platform runs the assertions, so no missing-client branch remains.
- discarded | low | "[KNOWN] The mapping table cites three reserved slugs that resolve to no test" | dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md | Mapping explicitly labels these as non-executable banner sections and maps their executable subrows to registered tests.

## Runtime evidence already in hand (do not re-run, do not re-dispatch CI)

Reviewed HEAD `876a153b4039128f8052526629773fa189058c71`:
- Test run 34086467208: success. 1819 fast tests passed, 0 failed, 0 ignored.
  Unfiltered e2e 566 passed, 0 failed, 2 ignored. Coverage 79.88% lines.
- Full Validation run 34092612666: all six jobs succeeded; linux-e2e,
  macos-full and windows-full each 566 passed, 0 failed, 2 ignored.
- The 2 ignored e2e tests belong to the concurrent hazard lane, not to 00171.
