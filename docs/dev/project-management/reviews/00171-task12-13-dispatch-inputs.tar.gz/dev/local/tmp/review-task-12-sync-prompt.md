
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Port integration §54-55/61: PgWire/SINGLETON cross-protocol parity, SINGLETON write races, cross-process write-lock races (port LAST); reconcile remaining source assertions before shell retirement

Description:
Port tests/integration.sh:2282-2537 + 2817-2885 and the corresponding tests/integration.ps1 section (§54.D, §55, §55.A-E, §61, §61.A-B) to Rust e2e tests. This is the riskiest, timing-sensitive slice of the PRD (concurrent multi-process races) and is deliberately sequenced LAST among the port tasks, after every other integration/smoke section has already landed, per the PRD's own Phase 1 instruction ("server sections §54-57 and multi-process races port last").

Location: new files tests/e2e/integration_*.rs (e.g. integration_pgwire_singleton_parity.rs, integration_singleton_races.rs, integration_write_lock_races.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `tests/e2e/singleton_cross_process_upsert.rs` — a live two-server race test that already runs under ordinary `cargo test` parallelism today; this is the existing pattern for every race in this range, not a new one. `ServerGuard` (each test gets its own port via `next_available_port`'s AtomicU16 counter, and its own TempDir-backed repo).

Contract (verbatim from the design doc's Interfaces & contracts — this design DELIBERATELY SUPERSEDES the PRD's own suggested mitigation of "serial markers" for these sections, per the design doc's review log; do not add a serial_test dependency):
- "No serial_test crate, no --test-threads=1. Every test gets its own port and its own TempDir-backed repo, so cargo's default parallel test runner is already safe."
- "Timing-sensitive within-test ordering (two CLI/GraphQL calls that must interleave a specific way) is expressed with std::thread::scope + explicit joins, not a serial marker — same file, same pattern as the existing race test."
- "PgWire sections — psql dependency dropped, not preserved. The Rust e2e crate already ports PgWire scenarios through tokio_postgres (pure-Rust client), never shelling out to psql. The port therefore drops the skip entirely: §54.D's PgWire assertions run unconditionally on every platform via tokio_postgres. Do not add a command -v psql equivalent check in Rust — there is nothing to check for."

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying (the design doc's Reuse inventory flags §54.D/§55.D as likely already covered by tests/e2e/pgwire_singleton.rs — check before writing new coverage).
- §55.A-D (CLI/GraphQL executeSql/typed-createDoogat/PgWire concurrent INSERT races) must each assert exactly one row survives the race (structured-error parity on the loser). §55.E asserts convergence across every protocol's race.
- §61.A-B (cross-process write lock: N concurrent CLI writers on distinct doogats, and a `ddb serve` write concurrent with a CLI write) must assert no lost commit under concurrency — this is PRD 00162's write-lock guarantee, a P0 data-safety invariant per AGENTS.md.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally, run at least twice to catch flake from the concurrency changes; mapping table shows 100% of §54-55/61 rows (both dialects) as DONE.
User additionally required reconciliation of all391 mapping rows against actual shell assertions and registered test bodies, including stale PowerShell17/18 rows. Existing tests were extended for missing assertions; no product code changes. This is one partition of the task diff; other partitions receive the same independent review. Do not infer file coverage from this partition alone.


Acceptance criteria:
All original assertions retained across CLI/GraphQL/REST/PgWire/NoSQL/sync tests and both source dialects; tests registered; exact-one singleton losers/convergence and committed write durability; repeated local scope green; no shell files deleted before replacement CI.


## Diff under review

```diff
diff --git a/tests/e2e/bundle_import_conflict_recovery.rs b/tests/e2e/bundle_import_conflict_recovery.rs
index 85569ae..1cbc58c 100644
--- a/tests/e2e/bundle_import_conflict_recovery.rs
+++ b/tests/e2e/bundle_import_conflict_recovery.rs
@@ -31,18 +31,22 @@ fn bundle_import_recovers_real_conflict_and_reimport_is_noop() {
         .arg(&bundle_path)
         .assert()
         .success()
-        .stdout(predicate::str::contains("conflicts resolved: 1"));
+        .stdout(predicate::str::contains("imported: conflicts resolved: 1"));
 
     // Read the doogat on node 1: either LWW winner title is acceptable — the point
     // is a real merge landed, not which side won.
     let result = DdbTestRepo::ddb_at(&setup.nodes[1])
         .args(["read", &id])
-        .output()
-        .unwrap();
-    let output = String::from_utf8_lossy(&result.stdout);
+        .assert()
+        .success();
+    let output = String::from_utf8_lossy(&result.get_output().stdout);
+    let title = output
+        .lines()
+        .find_map(|line| line.strip_prefix("title: "))
+        .expect("merged doogat must contain a title line");
     assert!(
-        output.contains("Bundle Laptop Title") || output.contains("Bundle Desktop Title"),
-        "merged doogat should contain one of the two titles, got: {output}"
+        matches!(title, "Bundle Laptop Title" | "Bundle Desktop Title"),
+        "merged title must match one of the conflicting values, got: {title:?}"
     );
 
     // Re-import the SAME bundle: its commits are already ancestors of local HEAD,
@@ -52,5 +56,5 @@ fn bundle_import_recovers_real_conflict_and_reimport_is_noop() {
         .arg(&bundle_path)
         .assert()
         .success()
-        .stdout(predicate::str::contains("conflicts resolved: 0"));
+        .stdout(predicate::str::contains("imported: conflicts resolved: 0"));
 }
diff --git a/tests/e2e/multi_device.rs b/tests/e2e/multi_device.rs
index 90c245c..f3446f6 100644
--- a/tests/e2e/multi_device.rs
+++ b/tests/e2e/multi_device.rs
@@ -1,4 +1,5 @@
 use crate::common::{DdbTestRepo, MultiNodeSetup};
+use predicates::prelude::*;
 use rand::prelude::*;
 
 /// Round-robin sync: push from one node, pull on all others
@@ -186,6 +187,51 @@ fn stale_node_resync_after_compaction() {
         out.contains("Edit from") || out.contains("Shared"),
         "stale node should have a resolved doogat after resync"
     );
+    assert!(
+        out.lines().any(|line| line.starts_with("title: ")),
+        "resolved doogat must retain its title line: {out}"
+    );
+}
+
+#[test]
+fn compacted_node_resolves_second_conflict() {
+    let setup = MultiNodeSetup::new(2);
+    let id = MultiNodeSetup::create(&setup.nodes[0], "Stale shared", "original content");
+    MultiNodeSetup::sync(&setup.nodes[0]);
+    MultiNodeSetup::sync(&setup.nodes[1]);
+
+    MultiNodeSetup::update(&setup.nodes[0], &id, "Stale shared", "body from node0");
+    MultiNodeSetup::sync(&setup.nodes[0]);
+    MultiNodeSetup::update(&setup.nodes[1], &id, "Stale shared", "body from node1");
+    DdbTestRepo::ddb_at(&setup.nodes[1])
+        .arg("sync")
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("conflicts resolved: 1"));
+
+    DdbTestRepo::ddb_at(&setup.nodes[1])
+        .args(["compact", "--force"])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("crdt temp:"))
+        .stdout(predicate::str::contains("repo (.git):"));
+
+    // Both nodes branch from the first merge; the compacted node resolves again.
+    MultiNodeSetup::sync(&setup.nodes[0]);
+    MultiNodeSetup::update(&setup.nodes[0], &id, "Stale shared", "second edit node0");
+    MultiNodeSetup::sync(&setup.nodes[0]);
+    MultiNodeSetup::update(&setup.nodes[1], &id, "Stale shared", "second edit node1");
+    DdbTestRepo::ddb_at(&setup.nodes[1])
+        .arg("sync")
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("conflicts resolved: 1"));
+
+    let out = MultiNodeSetup::read(&setup.nodes[1], &id);
+    assert!(
+        out.lines().any(|line| line.starts_with("title: ")),
+        "compacted node must retain a readable title after the second merge: {out}"
+    );
 }
 
 // ── Test: stale node returns with edits to deleted doogat after compaction ──
@@ -399,7 +445,45 @@ fn bundle_full_bootstrap() {
 
     // Create content on node0
     let id = MultiNodeSetup::create(&setup.nodes[0], "Bundle test", "bundle body");
-    MultiNodeSetup::push(&setup.nodes[0]);
+    MultiNodeSetup::sync(&setup.nodes[0]);
+    MultiNodeSetup::sync(&setup.nodes[1]);
+
+    // Export a resolved reference union, matching the shell bootstrap fixture.
+    let relative_path = format!("ddb/{id}.md");
+    for (node, label) in [(&setup.nodes[0], "laptop"), (&setup.nodes[1], "desktop")] {
+        let path = node.join(&relative_path);
+        let content = std::fs::read_to_string(&path).unwrap();
+        std::fs::write(
+            &path,
+            format!(
+                "{}\n---\n- {label} note:: Added from {label}\n",
+                content.trim_end_matches('\n')
+            ),
+        )
+        .unwrap();
+        let added = std::process::Command::new("git")
+            .current_dir(node)
+            .args(["add", &relative_path])
+            .output()
+            .unwrap();
+        assert!(added.status.success(), "git add failed: {added:?}");
+        let committed = std::process::Command::new("git")
+            .current_dir(node)
+            .args(["commit", "-m", &format!("add {label} reference")])
+            .output()
+            .unwrap();
+        assert!(
+            committed.status.success(),
+            "git commit failed: {committed:?}"
+        );
+    }
+    MultiNodeSetup::sync(&setup.nodes[0]);
+    DdbTestRepo::ddb_at(&setup.nodes[1])
+        .arg("sync")
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("conflicts resolved: 1"));
+    MultiNodeSetup::sync(&setup.nodes[0]);
 
     // Export full bundle from node0
     let bundle_path = setup.remote_dir.path().join("full.bundle.tar");
@@ -429,7 +513,8 @@ fn bundle_full_bootstrap() {
         .args(["bundle", "import"])
         .arg(&bundle_path)
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("imported"));
 
     // Verify the doogat exists on node3
     let out = MultiNodeSetup::read(&path3, &id);
@@ -437,6 +522,14 @@ fn bundle_full_bootstrap() {
         out.contains("Bundle test"),
         "bootstrapped node should have the doogat"
     );
+    assert!(
+        out.contains("laptop note:: Added from laptop"),
+        "bootstrapped node must retain the merged laptop reference: {out}"
+    );
+    assert!(
+        out.contains("desktop note:: Added from desktop"),
+        "bootstrapped node must retain the merged desktop reference: {out}"
+    );
 }
 
 // ── Test: bundle-based recovery after compaction ─────────────────
@@ -680,7 +773,7 @@ fn concurrent_edits_same_doogat() {
 
     // Node0 creates a doogat, sync to all
     let id = MultiNodeSetup::create(&setup.nodes[0], "Shared doogat", "original body");
-    MultiNodeSetup::push(&setup.nodes[0]);
+    MultiNodeSetup::sync(&setup.nodes[0]);
     MultiNodeSetup::sync(&setup.nodes[1]);
     MultiNodeSetup::sync(&setup.nodes[2]);
 
@@ -689,6 +782,13 @@ fn concurrent_edits_same_doogat() {
     MultiNodeSetup::update(&setup.nodes[1], &id, "Edit from node1", "body from node1");
     MultiNodeSetup::update(&setup.nodes[2], &id, "Edit from node2", "body from node2");
 
+    MultiNodeSetup::sync(&setup.nodes[0]);
+    DdbTestRepo::ddb_at(&setup.nodes[1])
+        .arg("sync")
+        .assert()
+        .success()
+        .stdout(predicate::str::is_match(r"(?m)^sync:.*conflicts resolved: [1-9]").unwrap());
+
     // Sync cascade: 3 rounds to ensure full convergence
     for _ in 0..3 {
         sync_round_robin(&setup);
@@ -701,6 +801,17 @@ fn concurrent_edits_same_doogat() {
 
     assert_eq!(content0, content1, "node0 and node1 diverged");
     assert_eq!(content1, content2, "node1 and node2 diverged");
+    let title = content0
+        .lines()
+        .find_map(|line| line.strip_prefix("title: "))
+        .expect("converged doogat must contain a title line");
+    assert!(
+        matches!(
+            title,
+            "Edit from node0" | "Edit from node1" | "Edit from node2"
+        ),
+        "converged title must be one of the conflicting values, got: {title:?}"
+    );
 }
 
 // ── Test: delete-vs-edit across 3 nodes ──────────────────────────
diff --git a/tests/e2e/sync_crdt.rs b/tests/e2e/sync_crdt.rs
index cf4040b..cb9619e 100644
--- a/tests/e2e/sync_crdt.rs
+++ b/tests/e2e/sync_crdt.rs
@@ -371,6 +371,21 @@ fn frontmatter_conflict_creates_fm_crdt_file() {
     let data = std::fs::read(fm_files[0].path()).unwrap();
     assert!(!data.is_empty(), "_fm.crdt file should not be empty");
 
+    // Reopening the repo through the CLI cleans up the temporary CRDT files.
+    let read = DdbTestRepo::ddb_at(&node2_path)
+        .args(["read", &id])
+        .assert()
+        .success();
+    let content = String::from_utf8_lossy(&read.get_output().stdout);
+    let title = content
+        .lines()
+        .find_map(|line| line.strip_prefix("title: "))
+        .expect("merged doogat must contain a title line");
+    assert!(
+        matches!(title, "Laptop Title" | "Desktop Title"),
+        "merged title must equal one of the conflicting titles, got: {title:?}"
+    );
+
     // Run compaction — should handle _fm.crdt files
     DdbTestRepo::ddb_at(&node2_path)
         .args(["compact", "--force"])
@@ -413,7 +428,13 @@ fn sync_auto_registers_node_when_none_exists() {
     );
 
     // Subsequent sync should reuse registration
+    let uuid_before = std::fs::read(&node_file).unwrap();
     node.ddb().arg("sync").assert().success();
+    assert_eq!(
+        std::fs::read(&node_file).unwrap(),
+        uuid_before,
+        "subsequent sync must preserve the registered node UUID"
+    );
 }
 
 #[test]
@@ -438,6 +459,12 @@ fn sync_output_reports_resurrected_count() {
         .success()
         .stdout(predicate::str::contains("resurrected:").not());
 
+    DdbTestRepo::ddb_at(&node2_path)
+        .args(["read", &id])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("title: Doomed"));
+
     // Node1 deletes the doogat and pushes the deletion
     setup.node1.ddb().args(["delete", &id]).assert().success();
     setup.node1.ddb().arg("sync").assert().success();
@@ -455,4 +482,15 @@ fn sync_output_reports_resurrected_count() {
         .assert()
         .success()
         .stdout(predicate::str::contains("resurrected: 1"));
+
+    DdbTestRepo::ddb_at(&node2_path)
+        .args(["read", &id])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("edited on desktop"));
+    DdbTestRepo::ddb_at(&node2_path)
+        .arg("status")
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("resurrected"));
 }

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Reviewed head: 36c0687; task's own range 75cde1c..36c0687. The prior unrelated 00202 commit is excluded.
cargo build -> exit 0; Finished dev profile in 37.23s.
cargo clippy --workspace --all-targets -> exit 0; Finished dev profile in 16.36s.
cargo test-ci -> exit 0; 42 CLI passed (1.55s), 1555 core passed (952.80s), 222 server passed (0.58s); all 0 failed / 0 ignored.
cargo test -p ddb-e2e --test e2e integration_ -> exit 0, twice: each 83 passed; 0 failed; 0 ignored; 482 filtered out; 16.04s and 15.34s.
cargo test -p ddb-e2e --test e2e -- smoke_ alter_column_type:: alter_table_rename:: bundle_import_conflict_recovery:: cascade_delete:: checkboxes:: cli_create_fk_freshness:: delete_backlinks:: discover:: fix:: folder_namespace:: hyphenated_types:: inline_zone:: junction_tables:: link_kinds:: multi_device:: pgwire:: reference_raw_id:: rename:: schema_apply:: search_in_filter:: search_links:: sequence:: serve:: server_mutations:: set_flag:: sql_expressions_test:: sql_lifecycle:: sync_crdt:: tags:: typed_field_mutations:: -> exit 0; 278 passed; 0 failed; 0 ignored; 287 filtered out; 33.66s.
Actual runner --list: 565 tests, 0 benchmarks. All 391 source mapping keys match four source inventories; all target tests or audited aliases resolve to registered runner names. Source assertions were compared separately, not inferred from runner discovery.
Independent Devon actually ran wrong CLI facades. Discarded updates were caught; body-to-title corruption survived, then was repaired with committed parsed field assertions and caught on replay. SQL INSERT value suffix corruption survived substring equality, then exact seed theme equality caught the same mutant on replay (4 passed, 1 failed, intentional exit101). All facades neutralized. No demonstrated surviving mutant remains.
Earlier real test failures from sync fixture setup and the new REST assertion were repaired; all targeted reruns are green. REST source checks the returned custom value anywhere in response, not core title.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


