
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Port integration §54-55/61: PgWire/SINGLETON cross-protocol parity, SINGLETON write races, cross-process write-lock races (port LAST); reconcile remaining source assertions before shell retirement

Description:
Port tests/integration.sh:2282-2537 + 2817-2885 and the corresponding tests/integration.ps1 section (§54.D, §55, §55.A-E, §61, §61.A-B) to Rust e2e tests. This is the riskiest, timing-sensitive slice of the PRD (concurrent multi-process races) and is deliberately sequenced LAST among the port tasks, after every other integration/smoke section has already landed, per the PRD's own Phase 1 instruction ("server sections §54-57 and multi-process races port last").

Location: new files tests/e2e/integration_*.rs (e.g. integration_pgwire_singleton_parity.rs, integration_singleton_races.rs, integration_write_lock_races.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `tests/e2e/singleton_cross_process_upsert.rs` — a live two-server race test that already runs under ordinary `cargo test` parallelism today; this is the existing pattern for every race in this range, not a new one. `ServerGuard` (each test gets its own port via `next_available_port`'s AtomicU16 counter, and its own TempDir-backed repo).

Contract (verbatim from the design doc's Interfaces & contracts — this design DELIBERATELY SUPERSEDES the PRD's own suggested mitigation of "serial markers" for these sections, per the design doc's review log; do not add a serial_test dependency):
- "No serial_test crate, no --test-threads=1. Every test gets its own port and its own TempDir-backed repo, so cargo's default parallel test runner is already safe."
- "Timing-sensitive within-test ordering (two CLI/GraphQL calls that must interleave a specific way) is expressed with std::thread::scope + explicit joins, not a serial marker — same file, same pattern as the existing race test."
- "PgWire sections — psql dependency dropped, not preserved. The Rust e2e crate already ports PgWire scenarios through tokio_postgres (pure-Rust client), never shelling out to psql. The port therefore drops the skip entirely: §54.D's PgWire assertions run unconditionally on every platform via tokio_postgres. Do not add a command -v psql equivalent check in Rust — there is nothing to check for."

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying (the design doc's Reuse inventory flags §54.D/§55.D as likely already covered by tests/e2e/pgwire_singleton.rs — check before writing new coverage).
- §55.A-D (CLI/GraphQL executeSql/typed-createDoogat/PgWire concurrent INSERT races) must each assert exactly one row survives the race (structured-error parity on the loser). §55.E asserts convergence across every protocol's race.
- §61.A-B (cross-process write lock: N concurrent CLI writers on distinct doogats, and a `ddb serve` write concurrent with a CLI write) must assert no lost commit under concurrency — this is PRD 00162's write-lock guarantee, a P0 data-safety invariant per AGENTS.md.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally, run at least twice to catch flake from the concurrency changes; mapping table shows 100% of §54-55/61 rows (both dialects) as DONE.
User additionally required reconciliation of all391 mapping rows against actual shell assertions and registered test bodies, including stale PowerShell17/18 rows. Existing tests were extended for missing assertions; no product code changes. This is one partition of the task diff; other partitions receive the same independent review. Do not infer file coverage from this partition alone.


Acceptance criteria:
All original assertions retained across CLI/GraphQL/REST/PgWire/NoSQL/sync tests and both source dialects; tests registered; exact-one singleton losers/convergence and committed write durability; repeated local scope green; no shell files deleted before replacement CI.


## Diff under review

```diff
diff --git a/tests/e2e/hyphenated_types.rs b/tests/e2e/hyphenated_types.rs
index 177d76a..be76939 100644
--- a/tests/e2e/hyphenated_types.rs
+++ b/tests/e2e/hyphenated_types.rs
@@ -21,10 +21,11 @@ fn hyphenated_type_typed_query() {
     assert!(r.get("errors").is_none(), "INSERT test-widget failed: {r}");
 
     // Query via the typed query field (test-widget -> testWidgets)
-    let r = server.graphql(r#"{ testWidgets { items { id title status priority } } }"#);
+    let r = server.graphql(r#"{ testWidgets { items { id title status priority } totalCount } }"#);
     assert!(r.get("errors").is_none(), "testWidgets query failed: {r}");
     let items = r["data"]["testWidgets"]["items"].as_array().unwrap();
     assert_eq!(items.len(), 1, "expected 1 test-widget: {r}");
+    assert_eq!(r["data"]["testWidgets"]["totalCount"], 1);
     assert_eq!(items[0]["status"].as_str().unwrap(), "active");
     assert_eq!(items[0]["priority"].as_i64().unwrap(), 1);
 }
diff --git a/tests/e2e/integration_alter_rename.rs b/tests/e2e/integration_alter_rename.rs
index 7dc9b5b..2b920e3 100644
--- a/tests/e2e/integration_alter_rename.rs
+++ b/tests/e2e/integration_alter_rename.rs
@@ -40,6 +40,10 @@ fn integration_50a_alter_rename_graphql() {
     );
 
     let new_name = select(&server, "SELECT count(*) FROM rngql_dst");
+    assert!(
+        new_name.get("data").is_some(),
+        "new table must return data: {new_name}"
+    );
     assert!(
         new_name.get("errors").is_none(),
         "SELECT on new table name should succeed: {new_name}"
@@ -57,19 +61,13 @@ fn integration_50b_mysql_rename_alias_rejected_graphql() {
     let repo = DdbTestRepo::init();
     let server = ServerGuard::start(&repo);
 
-    let create = ddl(
-        &server,
-        "CREATE TABLE rngql_alias_src (title VARCHAR(64))",
-    );
+    let create = ddl(&server, "CREATE TABLE rngql_alias_src (title VARCHAR(64))");
     assert!(
         create.get("errors").is_none(),
         "CREATE TABLE failed: {create}"
     );
 
-    let rename = ddl(
-        &server,
-        "RENAME TABLE rngql_alias_src TO rngql_alias_dst",
-    );
+    let rename = ddl(&server, "RENAME TABLE rngql_alias_src TO rngql_alias_dst");
     assert!(
         rename.get("errors").is_some(),
         "MySQL RENAME TABLE alias should be rejected: {rename}"
diff --git a/tests/e2e/integration_graphql_refs.rs b/tests/e2e/integration_graphql_refs.rs
index e1f85f3..a7f876d 100644
--- a/tests/e2e/integration_graphql_refs.rs
+++ b/tests/e2e/integration_graphql_refs.rs
@@ -72,6 +72,20 @@ fn integration_38c2_boolean_coercion() {
         serde_json::json!({ "sql": "INSERT INTO smokepin (title, pinned) VALUES ('PinTest', true)" }),
     );
     assert!(r.get("errors").is_none(), "INSERT PinTest failed: {r}");
+    assert!(!r["data"]["executeSql"]["message"]
+        .as_str()
+        .unwrap()
+        .is_empty());
+
+    let result = server.graphql(r#"{ sql(query: "SELECT title FROM smokepin") { rows } }"#);
+    assert!(
+        result.get("errors").is_none(),
+        "base title query failed: {result}"
+    );
+    let rows = result["data"]["sql"]["rows"].as_array().unwrap();
+    assert_eq!(rows.len(), 1, "expected the inserted row: {rows:?}");
+    let row: serde_json::Value = serde_json::from_str(rows[0].as_str().unwrap()).unwrap();
+    assert_eq!(row, serde_json::json!(["PinTest"]));
 
     std::thread::sleep(std::time::Duration::from_secs(1));
 
@@ -89,7 +103,8 @@ fn integration_38c2_boolean_coercion() {
     );
     let rows = result["data"]["sql"]["rows"].as_array().unwrap();
     assert!(
-        rows.iter().any(|row| row.as_str().unwrap().contains("true")),
+        rows.iter()
+            .any(|row| row.as_str().unwrap().contains("true")),
         "expected a row containing \"true\": {rows:?}"
     );
 
diff --git a/tests/e2e/integration_graphql_server.rs b/tests/e2e/integration_graphql_server.rs
index 6b367a0..3d1852f 100644
--- a/tests/e2e/integration_graphql_server.rs
+++ b/tests/e2e/integration_graphql_server.rs
@@ -192,6 +192,10 @@ fn integration_18g_normalize_query_implicit_and_lowercase() {
     let repo = DdbTestRepo::init();
     let server = ServerGuard::start(&repo);
 
+    let result = server.graphql(r#"{ normalizeSearchQuery(query: "B AND A") }"#);
+    assert_graphql_ok(&result);
+    assert_eq!(result["data"]["normalizeSearchQuery"], "a and b");
+
     let result = server.graphql(r#"{ normalizeSearchQuery(query: "  MEETING   Minutes  ") }"#);
     assert_graphql_ok(&result);
     assert_eq!(
@@ -435,6 +439,7 @@ fn integration_18z3_update_doogat_tag_semantics() {
         &server,
         json!({ "title": "F5 tag clear", "tags": ["a", "b", "c"] }),
     );
+    assert_eq!(clear["tags"], json!(["a", "b", "c"]));
     let result = server.graphql_with_vars(
         r#"mutation($input: UpdateDoogatInput!) { updateDoogat(input: $input) { id } }"#,
         json!({ "input": { "id": clear["id"], "tags": [] } }),
diff --git a/tests/e2e/integration_id_poison.rs b/tests/e2e/integration_id_poison.rs
index c4d9cec..91d5b96 100644
--- a/tests/e2e/integration_id_poison.rs
+++ b/tests/e2e/integration_id_poison.rs
@@ -69,7 +69,13 @@ fn integration_62_id_minting_no_same_second_collision() {
     let single_assert = repo
         .ddb()
         .args([
-            "create", "--type", "int164", "--title", "single 164", "--set", "label=d",
+            "create",
+            "--type",
+            "int164",
+            "--title",
+            "single 164",
+            "--set",
+            "label=d",
         ])
         .assert()
         .success();
@@ -136,13 +142,17 @@ fn integration_63_poison_file_graphql_warning() {
 
     // First mutation since server start / since the poison commit — this is
     // where the warning fires.
-    let result =
-        server.graphql(r#"mutation { createDoogat(input: { title: "after poison" }) { id title } }"#);
+    let result = server
+        .graphql(r#"mutation { createDoogat(input: { title: "after poison" }) { id title } }"#);
 
     assert!(
         result.get("errors").is_none(),
         "mutation should succeed despite the poison file elsewhere in the repo: {result}"
     );
+    assert!(
+        result.get("data").is_some(),
+        "mutation response must contain data: {result}"
+    );
 
     let warnings = result["extensions"]["warnings"]
         .as_array()
diff --git a/tests/e2e/integration_junction_sync.rs b/tests/e2e/integration_junction_sync.rs
index 3595424..07215b4 100644
--- a/tests/e2e/integration_junction_sync.rs
+++ b/tests/e2e/integration_junction_sync.rs
@@ -60,7 +60,10 @@ fn integration_44_j_auto_junction_atomic_graphql() {
     let cat_a = server.graphql(
         r#"mutation { executeSql(sql: "INSERT INTO j134_cat (title, label) VALUES (\"alpha\", \"alpha\")") { message } }"#,
     );
-    assert!(cat_a.get("errors").is_none(), "insert cat_a failed: {cat_a}");
+    assert!(
+        cat_a.get("errors").is_none(),
+        "insert cat_a failed: {cat_a}"
+    );
     let cat_a_id = cat_a["data"]["executeSql"]["message"]
         .as_str()
         .unwrap()
@@ -69,11 +72,19 @@ fn integration_44_j_auto_junction_atomic_graphql() {
     let cat_b = server.graphql(
         r#"mutation { executeSql(sql: "INSERT INTO j134_cat (title, label) VALUES (\"beta\", \"beta\")") { message } }"#,
     );
-    assert!(cat_b.get("errors").is_none(), "insert cat_b failed: {cat_b}");
+    assert!(
+        cat_b.get("errors").is_none(),
+        "insert cat_b failed: {cat_b}"
+    );
     let cat_b_id = cat_b["data"]["executeSql"]["message"]
         .as_str()
         .unwrap()
         .to_string();
+    assert!(!cat_a_id.is_empty() && !cat_b_id.is_empty());
+    assert_ne!(
+        cat_a_id, cat_b_id,
+        "category inserts must return distinct ids"
+    );
 
     let bm = server.graphql(&format!(
         r#"mutation {{ executeSql(sql: "INSERT INTO j134_bm (url, category) VALUES ('https://j134.example', '{cat_a_id}')") {{ message }} }}"#
@@ -200,10 +211,7 @@ fn integration_44_m_parent_junction_cleanup_graphql() {
     let bm = server.graphql(&format!(
         r#"mutation {{ executeSql(sql: "INSERT INTO pdc_bm (url, pdc_cat) VALUES ('https://pdc.example', '{cat_id}')") {{ message }} }}"#
     ));
-    assert!(
-        bm.get("errors").is_none(),
-        "insert pdc_bm row failed: {bm}"
-    );
+    assert!(bm.get("errors").is_none(), "insert pdc_bm row failed: {bm}");
     let bm_id = bm["data"]["executeSql"]["message"]
         .as_str()
         .unwrap()
diff --git a/tests/e2e/integration_nosql_cli.rs b/tests/e2e/integration_nosql_cli.rs
index a808c87..7e14a7e 100644
--- a/tests/e2e/integration_nosql_cli.rs
+++ b/tests/e2e/integration_nosql_cli.rs
@@ -38,6 +38,10 @@ fn integration_32_nosql_cli_commands() {
         .output()
         .unwrap();
     let id3 = String::from_utf8_lossy(&id3_out.stdout).trim().to_string();
+    assert!(
+        id3.len() == 14 && id3.chars().all(|c| c.is_ascii_digit()),
+        "typed fixture must return a 14-digit id, got: {id3:?}"
+    );
 
     let id1_out = repo
         .ddb()
@@ -57,11 +61,16 @@ fn integration_32_nosql_cli_commands() {
     // Reindex so the wikilink lands in _ddb_links before `backlinks` can see it.
     repo.ddb().arg("reindex").assert().success();
 
+    repo.ddb()
+        .args(["update", &id1, "--title", "First note (edited)"])
+        .assert()
+        .success();
+
     repo.ddb()
         .args(["get", &id1])
         .assert()
         .success()
-        .stdout(predicate::str::contains("First note"));
+        .stdout(predicate::str::contains("First note (edited)"));
 
     repo.ddb()
         .args(["scan", "--tag", "test"])
@@ -69,11 +78,18 @@ fn integration_32_nosql_cli_commands() {
         .success()
         .stdout(predicate::str::contains(id1.clone()));
 
-    repo.ddb()
+    let scan = repo
+        .ddb()
         .args(["scan", "--type", "foo"])
         .assert()
         .success()
         .stdout(predicate::str::contains(id3));
+    assert!(
+        String::from_utf8_lossy(&scan.get_output().stdout)
+            .lines()
+            .any(|line| line.len() == 14 && line.chars().all(|c| c.is_ascii_digit())),
+        "scan --type must print a 14-digit id on its own line"
+    );
 
     repo.ddb()
         .args(["backlinks", &id2])
diff --git a/tests/e2e/integration_singleton_flow.rs b/tests/e2e/integration_singleton_flow.rs
index c768e3f..89ba9b0 100644
--- a/tests/e2e/integration_singleton_flow.rs
+++ b/tests/e2e/integration_singleton_flow.rs
@@ -1,7 +1,8 @@
 //! Port of tests/integration.sh:2188-2281 (PRD 00139 T20/T22 SINGLETON
 //! GraphQL flow, ALTER SET/DROP SINGLETON, DEFAULT VALUES auto-seed).
 
-use crate::common::{select_scalar, DdbTestRepo, ServerGuard};
+use crate::common::{DdbTestRepo, ServerGuard};
+use predicates::prelude::*;
 
 /// Run a DDL/DML statement via `executeSql`, selecting `message`.
 fn execute_sql(server: &ServerGuard, sql: &str) -> serde_json::Value {
@@ -30,6 +31,10 @@ fn integration_51_a_singleton_graphql_flow() {
     );
 
     let empty_query = server.graphql(r#"{ ig_app_config { id theme } }"#);
+    assert!(
+        empty_query.get("data").is_some(),
+        "expected data key: {empty_query}"
+    );
     assert!(
         empty_query.get("errors").is_none(),
         "query before any row exists failed: {empty_query}"
@@ -68,6 +73,7 @@ fn integration_51_a_singleton_graphql_flow() {
         .as_str()
         .expect("first upsert should return an id")
         .to_string();
+    assert!(!id.is_empty(), "first upsert must return a nonempty id");
 
     let after_first_upsert = server.graphql(r#"{ ig_app_config { theme } }"#);
     assert!(
@@ -130,20 +136,31 @@ fn integration_51_a_singleton_graphql_flow() {
 #[test]
 fn integration_52_b_graphql_alter_set_drop_singleton_reload() {
     let repo = DdbTestRepo::init();
+    repo.ddb()
+        .args(["query", "CREATE TABLE ig_alter_cfg (theme TEXT)"])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("table ig_alter_cfg created"));
+    repo.ddb()
+        .args([
+            "query",
+            "INSERT INTO ig_alter_cfg (title, theme) VALUES ('cfg-a', 'dark'), ('cfg-b', 'light')",
+        ])
+        .assert()
+        .success()
+        .stdout(predicate::str::is_match(r"^\d{14},\d{14}\s*$").unwrap());
+    repo.ddb()
+        .args(["query", "ALTER TABLE ig_alter_cfg SET SINGLETON"])
+        .assert()
+        .failure()
+        .stderr(predicate::str::contains("typedef holds 2 rows"));
+    repo.ddb()
+        .args(["query", "DELETE FROM ig_alter_cfg WHERE title = 'cfg-b'"])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("1 row"));
     let server = ServerGuard::start(&repo);
 
-    let create = execute_sql(&server, "CREATE TABLE ig_alter_cfg (theme TEXT)");
-    assert!(
-        create.get("errors").is_none(),
-        "CREATE TABLE failed: {create}"
-    );
-
-    let insert = execute_sql(
-        &server,
-        "INSERT INTO ig_alter_cfg (title, theme) VALUES ('cfg-a', 'dark')",
-    );
-    assert!(insert.get("errors").is_none(), "INSERT failed: {insert}");
-
     let set_singleton = execute_sql(&server, "ALTER TABLE ig_alter_cfg SET SINGLETON");
     assert!(
         set_singleton.get("errors").is_none(),
@@ -192,29 +209,25 @@ fn integration_52_b_graphql_alter_set_drop_singleton_reload() {
 #[test]
 fn integration_53_c_singleton_default_values_auto_seed() {
     let repo = DdbTestRepo::init();
-    let server = ServerGuard::start(&repo);
-
-    let create = execute_sql(
-        &server,
-        "CREATE TABLE ig_seed_cfg (theme TEXT DEFAULT 'system', schema_version INTEGER DEFAULT 1) SINGLETON DEFAULT VALUES",
-    );
-    assert!(
-        create.get("errors").is_none(),
-        "CREATE TABLE ... SINGLETON DEFAULT VALUES failed: {create}"
-    );
-
-    let count = select_scalar(&server, "SELECT COUNT(*) FROM ig_seed_cfg");
-    assert_eq!(
-        count, "1",
-        "expected exactly one auto-seeded row from DEFAULT VALUES"
-    );
-
-    let theme = select_scalar(&server, "SELECT theme FROM ig_seed_cfg");
-    assert_eq!(theme, "system", "expected DEFAULT-clause theme value");
-
-    let schema_version = select_scalar(&server, "SELECT schema_version FROM ig_seed_cfg");
-    assert_eq!(
-        schema_version, "1",
-        "expected DEFAULT-clause schema_version value"
-    );
+    repo.ddb()
+        .args(["query", "CREATE TABLE ig_seed_cfg (theme TEXT DEFAULT 'system', schema_version INTEGER DEFAULT 1) SINGLETON DEFAULT VALUES"])
+        .assert().success()
+        .stdout(predicate::str::contains("table ig_seed_cfg created"));
+    for (sql, expected) in [
+        ("SELECT COUNT(*) FROM ig_seed_cfg", "1"),
+        ("SELECT theme FROM ig_seed_cfg", "system"),
+        ("SELECT schema_version FROM ig_seed_cfg", "1"),
+    ] {
+        let output = repo.ddb().args(["query", sql]).assert().success();
+        assert_eq!(
+            String::from_utf8_lossy(&output.get_output().stdout).trim(),
+            expected,
+            "{sql}"
+        );
+    }
+    repo.ddb()
+        .args(["query", "DROP TABLE ig_seed_cfg CASCADE"])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("dropped"));
 }
diff --git a/tests/e2e/integration_typed_write_cli.rs b/tests/e2e/integration_typed_write_cli.rs
index f83eee3..d6d3eb7 100644
--- a/tests/e2e/integration_typed_write_cli.rs
+++ b/tests/e2e/integration_typed_write_cli.rs
@@ -94,6 +94,10 @@ fn integration_48_typed_write_blockers_and_cascade() {
         ])
         .output()
         .unwrap();
+    assert!(
+        after_link.status.success(),
+        "post-CASCADE parent SELECT failed: {after_link:?}"
+    );
     let after_link_combined = format!(
         "{}{}",
         String::from_utf8_lossy(&after_link.stdout),
@@ -109,6 +113,10 @@ fn integration_48_typed_write_blockers_and_cascade() {
         ])
         .output()
         .unwrap();
+    assert!(
+        after_mem.status.success(),
+        "post-CASCADE child SELECT failed: {after_mem:?}"
+    );
     let after_mem_combined = format!(
         "{}{}",
         String::from_utf8_lossy(&after_mem.stdout),
@@ -209,6 +217,11 @@ fn integration_49_unify_typed_write_paths() {
         .output()
         .unwrap();
     let cat2_id = String::from_utf8_lossy(&cat2_out.stdout).trim().to_string();
+    assert!(!cat1_id.is_empty(), "first category seed must return an id");
+    assert!(
+        !cat2_id.is_empty(),
+        "second category seed must return an id"
+    );
 
     // CLI create on a typedef with two REFERENCES columns must populate the
     // reference zone.
@@ -287,6 +300,10 @@ fn integration_49_unify_typed_write_paths() {
         String::from_utf8_lossy(&bad_out.stdout),
         String::from_utf8_lossy(&bad_out.stderr)
     );
+    assert!(
+        !bad_out.status.success(),
+        "wrong-type FK create must fail: {bad_combined}"
+    );
     assert!(bad_combined.contains("references non-existent tw_category"));
 }
 
diff --git a/tests/e2e/integration_typed_write_polish.rs b/tests/e2e/integration_typed_write_polish.rs
index 5fafc8f..9829b6d 100644
--- a/tests/e2e/integration_typed_write_polish.rs
+++ b/tests/e2e/integration_typed_write_polish.rs
@@ -67,24 +67,17 @@ fn integration_44_ddl_response_consistency() {
     let alter = server.graphql(
         r#"mutation { executeSql(sql: "ALTER TABLE ddltest ADD COLUMN age INTEGER") { columns rows message } }"#,
     );
-    assert!(
-        alter.get("errors").is_none(),
-        "ALTER TABLE failed: {alter}"
-    );
+    assert!(alter.get("errors").is_none(), "ALTER TABLE failed: {alter}");
     assert_eq!(
         alter["data"]["executeSql"]["columns"],
         serde_json::json!([])
     );
     assert_eq!(alter["data"]["executeSql"]["rows"], serde_json::json!([]));
 
-    let drop = server.graphql(
-        r#"mutation { executeSql(sql: "DROP TABLE ddltest") { columns rows message } }"#,
-    );
+    let drop = server
+        .graphql(r#"mutation { executeSql(sql: "DROP TABLE ddltest") { columns rows message } }"#);
     assert!(drop.get("errors").is_none(), "DROP TABLE failed: {drop}");
-    assert_eq!(
-        drop["data"]["executeSql"]["columns"],
-        serde_json::json!([])
-    );
+    assert_eq!(drop["data"]["executeSql"]["columns"], serde_json::json!([]));
     assert_eq!(drop["data"]["executeSql"]["rows"], serde_json::json!([]));
 
     let batch = server.graphql(
@@ -201,6 +194,10 @@ fn integration_45_g12_intra_batch_ignore_surviving_id() {
 
     let results = result["data"]["createMany"].as_array().unwrap();
     assert_eq!(results.len(), 2, "should return 2 results: {result}");
+    assert!(
+        !results[0]["id"].as_str().unwrap().is_empty(),
+        "survivor id must be nonempty: {result}"
+    );
     assert_eq!(
         results[0]["id"].as_str().unwrap(),
         results[1]["id"].as_str().unwrap(),
diff --git a/tests/e2e/integration_warnings_update.rs b/tests/e2e/integration_warnings_update.rs
index 182e875..366b954 100644
--- a/tests/e2e/integration_warnings_update.rs
+++ b/tests/e2e/integration_warnings_update.rs
@@ -9,27 +9,21 @@ const SET_IG_WARN_DEMO_TITLE_TEMPLATE: &str =
 const CREATE_IG_UPD_DEMO: &str = "CREATE TABLE ig_upd_demo (note TEXT)";
 
 /// Fresh repo + server with the `ig_warn_demo` typedef (title_template
-/// `'auto-warn'`) already created via `executeSql`. Each test gets its own
+/// `'auto-warn'`) already created via the CLI. Each test gets its own
 /// instance.
 fn setup_ig_warn_demo() -> (DdbTestRepo, ServerGuard) {
     let repo = DdbTestRepo::init();
+    repo.ddb()
+        .args(["query", CREATE_IG_WARN_DEMO])
+        .assert()
+        .success()
+        .stdout(predicates::str::contains("table ig_warn_demo created"));
+    repo.ddb()
+        .args(["query", SET_IG_WARN_DEMO_TITLE_TEMPLATE])
+        .assert()
+        .success()
+        .stdout(predicates::str::contains("title template"));
     let server = ServerGuard::start(&repo);
-    let create = server.graphql_with_vars(
-        r#"mutation($sql: String!) { executeSql(sql: $sql) { message } }"#,
-        serde_json::json!({ "sql": CREATE_IG_WARN_DEMO }),
-    );
-    assert!(
-        create.get("errors").is_none(),
-        "CREATE TABLE ig_warn_demo failed: {create}"
-    );
-    let title_template = server.graphql_with_vars(
-        r#"mutation($sql: String!) { executeSql(sql: $sql) { message } }"#,
-        serde_json::json!({ "sql": SET_IG_WARN_DEMO_TITLE_TEMPLATE }),
-    );
-    assert!(
-        title_template.get("errors").is_none(),
-        "ALTER TABLE ig_warn_demo SET TITLE TEMPLATE failed: {title_template}"
-    );
     (repo, server)
 }
 
@@ -107,15 +101,15 @@ fn integration_57_a_graphql_create_titled_extensions_warnings_empty() {
         serde_json::json!([]),
         "expected empty extensions.warnings: {result}"
     );
+    assert!(result.get("data").is_some(), "expected data key: {result}");
 }
 
 #[test]
 fn integration_57_b_graphql_create_omitted_title_title_from_template_warning() {
     let (_repo, server) = setup_ig_warn_demo();
 
-    let result = server.graphql(
-        r#"mutation { createDoogat(input: { type: "ig_warn_demo" }) { id title } }"#,
-    );
+    let result = server
+        .graphql(r#"mutation { createDoogat(input: { type: "ig_warn_demo" }) { id title } }"#);
     assert!(
         result.get("errors").is_none(),
         "createDoogat should succeed: {result}"
@@ -123,6 +117,7 @@ fn integration_57_b_graphql_create_omitted_title_title_from_template_warning() {
     let warnings = result["extensions"]["warnings"]
         .as_array()
         .unwrap_or_else(|| panic!("extensions.warnings should be an array: {result}"));
+    assert!(result.get("data").is_some(), "expected data key: {result}");
     assert_eq!(warnings.len(), 1, "expected exactly 1 warning: {result}");
     assert_eq!(
         warnings[0]["code"].as_str(),
diff --git a/tests/e2e/integration_write_recovery.rs b/tests/e2e/integration_write_recovery.rs
index 9b5b349..d08a8a2 100644
--- a/tests/e2e/integration_write_recovery.rs
+++ b/tests/e2e/integration_write_recovery.rs
@@ -16,7 +16,10 @@ fn integration_45_a1_cross_mutation_parity_after_unique_failure() {
     let valid = server.graphql(
         r#"mutation { executeSql(sql: "INSERT INTO a1item (title, name) VALUES (\"a\", \"unique1\")") { message } }"#,
     );
-    assert!(valid.get("errors").is_none(), "valid insert failed: {valid}");
+    assert!(
+        valid.get("errors").is_none(),
+        "valid insert failed: {valid}"
+    );
     let valid_id = valid["data"]["executeSql"]["message"]
         .as_str()
         .unwrap()
@@ -65,7 +68,9 @@ fn integration_45_a1_cross_mutation_parity_after_unique_failure() {
         .to_string();
 
     // (c) deleteDoogat still works on the same table
-    let deleted = server.graphql(&format!(r#"mutation {{ deleteDoogat(id: "{created_id}") }}"#));
+    let deleted = server.graphql(&format!(
+        r#"mutation {{ deleteDoogat(id: "{created_id}") }}"#
+    ));
     assert!(
         deleted.get("errors").is_none(),
         "deleteDoogat after UNIQUE failure should succeed: {deleted}"
@@ -157,7 +162,10 @@ fn integration_45_r10_restrict_blocks_sql_and_graphql_delete() {
     let link = server.graphql(
         r#"mutation { executeSql(sql: "INSERT INTO r10link (url) VALUES (\"https://r10.example\")") { message } }"#,
     );
-    assert!(link.get("errors").is_none(), "insert r10link failed: {link}");
+    assert!(
+        link.get("errors").is_none(),
+        "insert r10link failed: {link}"
+    );
     let link_id = link["data"]["executeSql"]["message"]
         .as_str()
         .unwrap()
@@ -255,7 +263,10 @@ fn integration_45_a2_ghost_row_survives_server_restart() {
     let valid = server.graphql(
         r#"mutation { executeSql(sql: "INSERT INTO a2persist (title, name) VALUES (\"a\", \"uniq_a2\")") { message } }"#,
     );
-    assert!(valid.get("errors").is_none(), "valid insert failed: {valid}");
+    assert!(
+        valid.get("errors").is_none(),
+        "valid insert failed: {valid}"
+    );
     let valid_id = valid["data"]["executeSql"]["message"]
         .as_str()
         .unwrap()
@@ -292,4 +303,11 @@ fn integration_45_a2_ghost_row_survives_server_restart() {
         fresh.get("errors").is_none(),
         "fresh insert on the restarted server should succeed: {fresh}"
     );
+    assert!(
+        !fresh["data"]["executeSql"]["message"]
+            .as_str()
+            .unwrap()
+            .is_empty(),
+        "fresh INSERT must return an id: {fresh}"
+    );
 }
diff --git a/tests/e2e/pgwire.rs b/tests/e2e/pgwire.rs
index f6c6f83..4da4894 100644
--- a/tests/e2e/pgwire.rs
+++ b/tests/e2e/pgwire.rs
@@ -293,12 +293,23 @@ fn pgwire_pg_catalog_hides_internal_tables() {
             !table_names.contains("_ddb_fts"),
             "internal table '_ddb_fts' should be hidden"
         );
+        assert!(
+            table_names.iter().all(|name| !name.starts_with("_ddb_")),
+            "internal table leaked: {table_names:?}"
+        );
 
         // Direct access to internal tables should still work
-        let direct = client.simple_query("SELECT COUNT(*) FROM _ddb_tags").await;
+        let direct = client
+            .simple_query("SELECT COUNT(*) FROM _ddb_tags")
+            .await
+            .expect("direct query on internal table should still work");
+        let count = direct.iter().find_map(|message| match message {
+            SimpleQueryMessage::Row(row) => row.get(0),
+            _ => None,
+        });
         assert!(
-            direct.is_ok(),
-            "direct query on internal table should still work"
+            count.unwrap().parse::<u64>().is_ok(),
+            "invalid count: {direct:?}"
         );
     });
 }
diff --git a/tests/e2e/reference_raw_id.rs b/tests/e2e/reference_raw_id.rs
index c7510bb..2723dca 100644
--- a/tests/e2e/reference_raw_id.rs
+++ b/tests/e2e/reference_raw_id.rs
@@ -548,4 +548,16 @@ fn plural_resolver_with_order_by_and_limit() {
         vec!["apple", "banana"],
         "expected first 2 alphabetically: {r}"
     );
+
+    let r = server.graphql(
+        r#"{ olbms { items { olcats(orderBy: "label", orderDir: "DESC", limit: 2) { label } } } }"#,
+    );
+    assert!(r.get("errors").is_none(), "DESC + limit failed: {r}");
+    let cats = r["data"]["olbms"]["items"][0]["olcats"].as_array().unwrap();
+    let labels: Vec<&str> = cats.iter().map(|c| c["label"].as_str().unwrap()).collect();
+    assert_eq!(
+        labels,
+        ["cherry", "banana"],
+        "DESC must order before truncating: {r}"
+    );
 }
diff --git a/tests/e2e/search_in_filter.rs b/tests/e2e/search_in_filter.rs
index c8406a3..0b889e6 100644
--- a/tests/e2e/search_in_filter.rs
+++ b/tests/e2e/search_in_filter.rs
@@ -51,6 +51,18 @@ fn search_where_in_tag() {
         titles.contains(&"Svelte Note"),
         "missing Svelte Note in {titles:?}"
     );
+
+    let result = server.graphql(
+        r#"{ search(query: "infilter", where: [{field: "tag", in: ["python"]}]) { hits { id title } totalCount } }"#,
+    );
+    assert!(
+        result.get("errors").is_none(),
+        "search with a single tag in value failed: {result}"
+    );
+    let hits = result["data"]["search"]["hits"].as_array().unwrap();
+    assert_eq!(hits.len(), 1, "expected one Python hit: {hits:?}");
+    assert_eq!(result["data"]["search"]["totalCount"], 1);
+    assert_eq!(hits[0]["title"], "Python Note");
 }
 
 #[test]
diff --git a/tests/e2e/serve.rs b/tests/e2e/serve.rs
index 63212ca..2a13f4e 100644
--- a/tests/e2e/serve.rs
+++ b/tests/e2e/serve.rs
@@ -248,10 +248,12 @@ fn rest_filter_by_tag() {
     let repo = DdbTestRepo::init();
     let server = ServerGuard::start(&repo);
 
-    server.rest_post(
+    let created = server.rest_post(
         "/doogats",
         serde_json::json!({ "title": "Tagged", "tags": ["alpha"] }),
     );
+    assert_eq!(created.status(), 201);
+    let created: serde_json::Value = created.json().unwrap();
     server.rest_post("/doogats", serde_json::json!({ "title": "Untagged" }));
 
     let resp = server.rest_get("/doogats?tag=alpha");
@@ -260,6 +262,7 @@ fn rest_filter_by_tag() {
     let data = body["data"].as_array().unwrap();
     assert_eq!(data.len(), 1);
     assert_eq!(data[0]["title"].as_str().unwrap(), "Tagged");
+    assert_eq!(data[0]["id"], created["data"]["id"]);
 }
 
 #[test]
@@ -316,6 +319,11 @@ fn rest_filter_by_field() {
     let body: serde_json::Value = resp.json().unwrap();
     let data = body["data"].as_array().unwrap();
     assert_eq!(data.len(), 1, "expected 1 match, got: {data:?}");
+    assert!(
+        data[0].to_string().contains("Beta"),
+        "matching REST row must contain the custom value Beta: {}",
+        data[0]
+    );
 
     // Nonexistent value → empty
     let resp = server.rest_get("/doogats?field.priority=99");
@@ -399,6 +407,15 @@ fn rest_auth_required() {
     let repo = DdbTestRepo::init();
     let server = ServerGuard::start(&repo);
 
+    let resp = server
+        .rest_client()
+        .post(server.rest_url("/doogats"))
+        .json(&serde_json::json!({ "title": "No Auth" }))
+        .timeout(Duration::from_secs(5))
+        .send()
+        .unwrap();
+    assert_eq!(resp.status(), 401);
+
     // No auth header
     let resp = server
         .rest_client()
@@ -975,6 +992,7 @@ fn sql_format_objects_returns_keyed_rows() {
         "sql with format:objects failed: {result}"
     );
     let sql = &result["data"]["sql"];
+    assert_eq!(sql["columns"], serde_json::json!(["id", "title"]));
     let rows = sql["rows"].as_array().expect("rows should be an array");
     assert!(!rows.is_empty(), "expected at least one row");
 
diff --git a/tests/e2e/server_mutations.rs b/tests/e2e/server_mutations.rs
index d306bc0..36700f8 100644
--- a/tests/e2e/server_mutations.rs
+++ b/tests/e2e/server_mutations.rs
@@ -7,7 +7,7 @@ fn compact_mutation_returns_result() {
     let server = ServerGuard::start(&repo);
 
     let result = server
-        .graphql(r#"mutation { compact { filesRemoved crdtDocsCompacted gcSuccess backupPath } }"#);
+        .graphql(r#"mutation { compact { filesRemoved crdtDocsCompacted gcSuccess crdtTempBytesBefore crdtTempBytesAfter crdtTempFilesBefore crdtTempFilesAfter repoBytesBefore repoBytesAfter backupPath } }"#);
     assert!(result.get("errors").is_none(), "compact failed: {result}");
     let compact = &result["data"]["compact"];
     assert!(compact["filesRemoved"].is_i64());
@@ -21,12 +21,21 @@ fn compact_force_mutation() {
     let server = ServerGuard::start(&repo);
 
     let result = server.graphql(
-        r#"mutation { compact(force: true) { filesRemoved crdtDocsCompacted gcSuccess backupPath } }"#,
+        r#"mutation { compact(force: true) { filesRemoved crdtDocsCompacted gcSuccess crdtTempBytesBefore crdtTempBytesAfter repoBytesBefore repoBytesAfter backupPath } }"#,
     );
     assert!(
         result.get("errors").is_none(),
         "compact(force: true) failed: {result}"
     );
+    let compact = &result["data"]["compact"];
+    assert!(
+        compact["gcSuccess"].is_boolean(),
+        "missing gcSuccess: {result}"
+    );
+    assert!(
+        compact.get("backupPath").is_some(),
+        "missing backupPath: {result}"
+    );
 }
 
 #[test]
@@ -66,10 +75,18 @@ fn compact_no_backup_mutation() {
         "compact(noBackup: true) failed: {result}"
     );
     let compact = &result["data"]["compact"];
+    assert!(
+        compact["gcSuccess"].is_boolean(),
+        "missing gcSuccess: {result}"
+    );
     assert!(
         compact["backupPath"].is_null(),
         "compact(noBackup: true) should have null backupPath: {result}"
     );
+    assert!(
+        compact.get("backupPath").is_some(),
+        "missing backupPath: {result}"
+    );
 }
 
 #[test]
diff --git a/tests/e2e/typed_field_mutations.rs b/tests/e2e/typed_field_mutations.rs
index 92fae7e..a45975a 100644
--- a/tests/e2e/typed_field_mutations.rs
+++ b/tests/e2e/typed_field_mutations.rs
@@ -31,7 +31,11 @@ fn update_doogat_with_fields_updates_materialized_row() {
     let server = ServerGuard::start(&repo);
 
     // Create typedef with VARCHAR column (frontmatter zone)
-    exec_sql(&server, "CREATE TABLE bookmark (url VARCHAR(200))");
+    let created = exec_sql(&server, "CREATE TABLE bookmark (url VARCHAR(200))");
+    assert_eq!(
+        created["data"]["executeSql"]["message"],
+        "table bookmark created"
+    );
 
     // Create a typed doogat via SQL INSERT
     let r = exec_sql(
@@ -39,6 +43,7 @@ fn update_doogat_with_fields_updates_materialized_row() {
         "INSERT INTO bookmark (title, url) VALUES ('My Bookmark', 'https://old.com')",
     );
     let id = r["data"]["executeSql"]["message"].as_str().unwrap().trim();
+    assert!(id.len() == 14 && id.bytes().all(|c| c.is_ascii_digit()));
 
     // Verify initial materialized row
     let rows = select_objects(
@@ -111,6 +116,7 @@ fn update_doogat_with_unset_fields_removes_field() {
         r.get("errors").is_none(),
         "updateDoogat with unsetFields failed: {r}"
     );
+    assert_eq!(r["data"]["updateDoogat"]["id"], id);
 
     // Verify materialized row has NULL url
     let rows = select_objects(

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Reviewed head: 36c0687; task's own range 75cde1c..36c0687. The prior unrelated 00202 commit is excluded.
cargo build -> exit 0; Finished dev profile in 37.23s.
cargo clippy --workspace --all-targets -> exit 0; Finished dev profile in 16.36s.
cargo test-ci -> exit 0; 42 CLI passed (1.55s), 1555 core passed (952.80s), 222 server passed (0.58s); all 0 failed / 0 ignored.
cargo test -p ddb-e2e --test e2e integration_ -> exit 0, twice: each 83 passed; 0 failed; 0 ignored; 482 filtered out; 16.04s and 15.34s.
cargo test -p ddb-e2e --test e2e -- smoke_ alter_column_type:: alter_table_rename:: bundle_import_conflict_recovery:: cascade_delete:: checkboxes:: cli_create_fk_freshness:: delete_backlinks:: discover:: fix:: folder_namespace:: hyphenated_types:: inline_zone:: junction_tables:: link_kinds:: multi_device:: pgwire:: reference_raw_id:: rename:: schema_apply:: search_in_filter:: search_links:: sequence:: serve:: server_mutations:: set_flag:: sql_expressions_test:: sql_lifecycle:: sync_crdt:: tags:: typed_field_mutations:: -> exit 0; 278 passed; 0 failed; 0 ignored; 287 filtered out; 33.66s.
Actual runner --list: 565 tests, 0 benchmarks. All 391 source mapping keys match four source inventories; all target tests or audited aliases resolve to registered runner names. Source assertions were compared separately, not inferred from runner discovery.
Independent Devon actually ran wrong CLI facades. Discarded updates were caught; body-to-title corruption survived, then was repaired with committed parsed field assertions and caught on replay. SQL INSERT value suffix corruption survived substring equality, then exact seed theme equality caught the same mutant on replay (4 passed, 1 failed, intentional exit101). All facades neutralized. No demonstrated surviving mutant remains.
Earlier real test failures from sync fixture setup and the new REST assertion were repaired; all targeted reruns are green. REST source checks the returned custom value anywhere in response, not core title.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


