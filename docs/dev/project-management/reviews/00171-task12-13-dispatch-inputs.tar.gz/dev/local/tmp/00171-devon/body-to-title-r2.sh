#!/bin/bash
# Harmless placeholder: forwards all arguments unchanged.
exec /Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb "$@"
