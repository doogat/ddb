#!/bin/bash
# Neutralized known-mutant replay.
exec /Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb "$@"
