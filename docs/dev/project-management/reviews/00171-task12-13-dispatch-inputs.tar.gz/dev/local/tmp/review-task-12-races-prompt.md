
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Port integration §54-55/61: PgWire/SINGLETON cross-protocol parity, SINGLETON write races, cross-process write-lock races (port LAST); reconcile remaining source assertions before shell retirement

Description:
Port tests/integration.sh:2282-2537 + 2817-2885 and the corresponding tests/integration.ps1 section (§54.D, §55, §55.A-E, §61, §61.A-B) to Rust e2e tests. This is the riskiest, timing-sensitive slice of the PRD (concurrent multi-process races) and is deliberately sequenced LAST among the port tasks, after every other integration/smoke section has already landed, per the PRD's own Phase 1 instruction ("server sections §54-57 and multi-process races port last").

Location: new files tests/e2e/integration_*.rs (e.g. integration_pgwire_singleton_parity.rs, integration_singleton_races.rs, integration_write_lock_races.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `tests/e2e/singleton_cross_process_upsert.rs` — a live two-server race test that already runs under ordinary `cargo test` parallelism today; this is the existing pattern for every race in this range, not a new one. `ServerGuard` (each test gets its own port via `next_available_port`'s AtomicU16 counter, and its own TempDir-backed repo).

Contract (verbatim from the design doc's Interfaces & contracts — this design DELIBERATELY SUPERSEDES the PRD's own suggested mitigation of "serial markers" for these sections, per the design doc's review log; do not add a serial_test dependency):
- "No serial_test crate, no --test-threads=1. Every test gets its own port and its own TempDir-backed repo, so cargo's default parallel test runner is already safe."
- "Timing-sensitive within-test ordering (two CLI/GraphQL calls that must interleave a specific way) is expressed with std::thread::scope + explicit joins, not a serial marker — same file, same pattern as the existing race test."
- "PgWire sections — psql dependency dropped, not preserved. The Rust e2e crate already ports PgWire scenarios through tokio_postgres (pure-Rust client), never shelling out to psql. The port therefore drops the skip entirely: §54.D's PgWire assertions run unconditionally on every platform via tokio_postgres. Do not add a command -v psql equivalent check in Rust — there is nothing to check for."

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying (the design doc's Reuse inventory flags §54.D/§55.D as likely already covered by tests/e2e/pgwire_singleton.rs — check before writing new coverage).
- §55.A-D (CLI/GraphQL executeSql/typed-createDoogat/PgWire concurrent INSERT races) must each assert exactly one row survives the race (structured-error parity on the loser). §55.E asserts convergence across every protocol's race.
- §61.A-B (cross-process write lock: N concurrent CLI writers on distinct doogats, and a `ddb serve` write concurrent with a CLI write) must assert no lost commit under concurrency — this is PRD 00162's write-lock guarantee, a P0 data-safety invariant per AGENTS.md.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally, run at least twice to catch flake from the concurrency changes; mapping table shows 100% of §54-55/61 rows (both dialects) as DONE.
User additionally required reconciliation of all391 mapping rows against actual shell assertions and registered test bodies, including stale PowerShell17/18 rows. Existing tests were extended for missing assertions; no product code changes. This is one partition of the task diff; other partitions receive the same independent review. Do not infer file coverage from this partition alone.


Acceptance criteria:
All original assertions retained across CLI/GraphQL/REST/PgWire/NoSQL/sync tests and both source dialects; tests registered; exact-one singleton losers/convergence and committed write durability; repeated local scope green; no shell files deleted before replacement CI.


## Diff under review

```diff
diff --git a/tests/e2e/integration_singleton_parity.rs b/tests/e2e/integration_singleton_parity.rs
index b651053..80caac4 100644
--- a/tests/e2e/integration_singleton_parity.rs
+++ b/tests/e2e/integration_singleton_parity.rs
@@ -192,9 +192,14 @@ fn integration_54_d_cross_protocol_singleton_duplicate_parity() {
         count_stdout.lines().any(|line| line.trim() == "1"),
         "singleton must still hold exactly one row after the rejected duplicates, got: {count_stdout}"
     );
-    repo.ddb()
+    let theme = repo
+        .ddb()
         .args(["query", "SELECT theme FROM ig_parity_cfg"])
         .assert()
-        .success()
-        .stdout(predicate::str::contains("p1"));
+        .success();
+    assert_eq!(
+        String::from_utf8_lossy(&theme.get_output().stdout).trim(),
+        "p1",
+        "rejected duplicate inserts must preserve the seed theme"
+    );
 }
diff --git a/tests/e2e/integration_singleton_races.rs b/tests/e2e/integration_singleton_races.rs
new file mode 100644
index 0000000..c61efad
--- /dev/null
+++ b/tests/e2e/integration_singleton_races.rs
@@ -0,0 +1,342 @@
+//! SINGLETON insert races from integration.sh / integration.ps1 §55.B–E.
+//! Each race includes §55.E's exact row count. The CLI-only §55.A/E leg is
+//! `singleton_cross_process_create::two_concurrent_ddb_create_on_singleton_converge_on_one_row`.
+
+use crate::common::{DdbTestRepo, ServerGuard};
+use serde_json::Value;
+use std::process::Command;
+use std::sync::Barrier;
+use std::time::Duration;
+use tokio_postgres::SimpleQueryMessage;
+
+fn race_graphql(server: &ServerGuard, mutations: &[String; 2]) -> [Value; 2] {
+    let ready = Barrier::new(3);
+    std::thread::scope(|scope| {
+        let first = scope.spawn(|| {
+            ready.wait();
+            server.graphql(&mutations[0])
+        });
+        let second = scope.spawn(|| {
+            ready.wait();
+            server.graphql(&mutations[1])
+        });
+        ready.wait();
+        [
+            first.join().expect("first GraphQL writer panicked"),
+            second.join().expect("second GraphQL writer panicked"),
+        ]
+    })
+}
+
+fn graphql_winner(responses: &[Value; 2], table: &str) -> usize {
+    for response in responses {
+        assert!(
+            !response
+                .to_string()
+                .to_ascii_lowercase()
+                .contains("unique constraint failed"),
+            "raw SQLite UNIQUE error leaked: {response}"
+        );
+    }
+    assert_eq!(
+        responses
+            .iter()
+            .filter(|r| r.get("errors").is_none())
+            .count(),
+        1,
+        "expected exactly one GraphQL success: {responses:?}"
+    );
+    assert_eq!(
+        responses
+            .iter()
+            .filter(|r| r.get("errors").is_some())
+            .count(),
+        1,
+        "expected exactly one GraphQL error response: {responses:?}"
+    );
+    let winner = usize::from(responses[0].get("errors").is_some());
+    let loser = &responses[1 - winner];
+    let errors = loser["errors"].as_array().expect("errors must be an array");
+    assert!(!errors.is_empty(), "loser has no error: {loser}");
+    assert_eq!(errors[0]["extensions"]["code"], "SINGLETON_VIOLATION");
+    assert_eq!(errors[0]["extensions"]["table"], table);
+    winner
+}
+
+/// Bind §55.E's materialized count to the sole committed row and its payload.
+fn assert_survivor(repo: &DdbTestRepo, table: &str, theme: &str) -> String {
+    let count = repo
+        .ddb()
+        .args(["query", &format!("SELECT COUNT(*) FROM {table}")])
+        .assert()
+        .success();
+    assert_eq!(
+        String::from_utf8_lossy(&count.get_output().stdout).trim(),
+        "1",
+        "§55.E: {table} must converge on exactly one row"
+    );
+    let row_id = repo
+        .ddb()
+        .args(["query", &format!("SELECT id FROM {table}")])
+        .assert()
+        .success();
+    let id = String::from_utf8_lossy(&row_id.get_output().stdout)
+        .trim()
+        .to_owned();
+    assert!(
+        id.len() == 14 && id.chars().all(|c| c.is_ascii_digit()),
+        "survivor must have a 14-digit id, got: {id:?}"
+    );
+    let row_theme = repo
+        .ddb()
+        .args(["query", &format!("SELECT theme FROM {table}")])
+        .assert()
+        .success();
+    assert_eq!(
+        String::from_utf8_lossy(&row_theme.get_output().stdout).trim(),
+        theme,
+        "surviving row must match the successful writer"
+    );
+
+    let tree = Command::new("git")
+        .current_dir(repo.path())
+        .args(["ls-tree", "--name-only", "HEAD:ddb"])
+        .output()
+        .expect("git ls-tree failed to run");
+    assert!(tree.status.success(), "git ls-tree failed: {tree:?}");
+    let tree_stdout = String::from_utf8_lossy(&tree.stdout);
+    let committed_ids: Vec<&str> = tree_stdout
+        .lines()
+        .filter_map(|path| path.strip_suffix(".md"))
+        .filter(|stem| stem.len() == 14 && stem.chars().all(|c| c.is_ascii_digit()))
+        .collect();
+    assert_eq!(
+        committed_ids,
+        [id.as_str()],
+        "HEAD must contain exactly the surviving row"
+    );
+    let committed = Command::new("git")
+        .current_dir(repo.path())
+        .args(["show", &format!("HEAD:ddb/{id}.md")])
+        .output()
+        .expect("git show failed to run");
+    assert!(committed.status.success(), "git show failed: {committed:?}");
+    assert!(
+        String::from_utf8_lossy(&committed.stdout).contains(theme),
+        "winner's theme {theme:?} must be durable in HEAD: {committed:?}"
+    );
+    id
+}
+
+#[test]
+fn integration_55_b_graphql_execute_sql_singleton_insert_race() {
+    let repo = DdbTestRepo::init();
+    repo.ddb()
+        .args(["query", "CREATE TABLE ig_race_sql (theme TEXT) SINGLETON"])
+        .assert()
+        .success();
+    let server = ServerGuard::start(&repo);
+    let themes = ["sql-dark", "sql-light"];
+    let mutations = themes.map(|theme| {
+        format!(
+            r#"mutation {{ executeSql(sql: "INSERT INTO ig_race_sql (title, theme) VALUES ('x', '{theme}')") {{ message }} }}"#
+        )
+    });
+    let responses = race_graphql(&server, &mutations);
+    let winner = graphql_winner(&responses, "ig_race_sql");
+    let result = &responses[winner]["data"]["executeSql"];
+    let winner_id = result["message"]
+        .as_str()
+        .expect("INSERT must return an id");
+    let survivor = assert_survivor(&repo, "ig_race_sql", themes[winner]);
+    assert_eq!(survivor, winner_id.trim());
+
+    // §55.B also requires the generated singleton GraphQL field to stay readable.
+    let query = server.graphql("{ ig_race_sql { id theme } }");
+    assert!(
+        query.get("errors").is_none(),
+        "singleton query failed: {query}"
+    );
+    assert_eq!(query["data"]["ig_race_sql"]["id"], survivor);
+    assert_eq!(query["data"]["ig_race_sql"]["theme"], themes[winner]);
+}
+
+#[test]
+fn integration_55_c_graphql_create_doogat_singleton_insert_race() {
+    let repo = DdbTestRepo::init();
+    repo.ddb()
+        .args(["query", "CREATE TABLE ig_race_typed (theme TEXT) SINGLETON"])
+        .assert()
+        .success();
+    let server = ServerGuard::start(&repo);
+    let themes = ["typed-dark", "typed-light"];
+    let mutations = themes.map(|theme| {
+        format!(
+            r#"mutation {{ createDoogat(input: {{ type: "ig_race_typed", title: "x", fields: "{{\"theme\":\"{theme}\"}}" }}) {{ id }} }}"#
+        )
+    });
+    let responses = race_graphql(&server, &mutations);
+    let winner = graphql_winner(&responses, "ig_race_typed");
+    let winner_id = responses[winner]["data"]["createDoogat"]["id"]
+        .as_str()
+        .expect("typed winner must return the created id");
+    assert_eq!(
+        assert_survivor(&repo, "ig_race_typed", themes[winner]),
+        winner_id
+    );
+}
+
+#[test]
+fn integration_55_d_cli_vs_pgwire_singleton_insert_race() {
+    let repo = DdbTestRepo::init();
+    repo.ddb()
+        .args(["query", "CREATE TABLE ig_race_pg (theme TEXT) SINGLETON"])
+        .assert()
+        .success();
+    let server = ServerGuard::start(&repo);
+    let runtime = tokio::runtime::Runtime::new().expect("Tokio runtime failed");
+    let (client, connection) = runtime.block_on(async {
+        tokio::time::timeout(
+            Duration::from_secs(30),
+            tokio_postgres::Config::new()
+                .host("127.0.0.1")
+                .port(server.pg_port)
+                .user("ddb")
+                .password(&server.token)
+                .dbname("ddb")
+                .connect(tokio_postgres::NoTls),
+        )
+        .await
+        .expect("PgWire connect timed out")
+        .expect("PgWire connect failed")
+    });
+    let connection_task = runtime.spawn(connection);
+
+    let ready = Barrier::new(2);
+    let (cli, pg) = std::thread::scope(|scope| {
+        let cli_writer = scope.spawn(|| {
+            ready.wait();
+            repo.ddb()
+                .args([
+                    "create",
+                    "--type",
+                    "ig_race_pg",
+                    "--title",
+                    "x",
+                    "--set",
+                    "theme=cli-dark",
+                ])
+                .timeout(Duration::from_secs(30))
+                .output()
+                .expect("CLI writer failed to run")
+        });
+        ready.wait();
+        let pg = runtime.block_on(async {
+            tokio::time::timeout(
+                Duration::from_secs(30),
+                client
+                    .simple_query("INSERT INTO ig_race_pg (title, theme) VALUES ('x', 'pg-light')"),
+            )
+            .await
+            .expect("PgWire INSERT timed out")
+        });
+        (cli_writer.join().expect("CLI writer panicked"), pg)
+    });
+
+    let successes = [cli.status.success(), pg.is_ok()];
+    assert_eq!(
+        successes.iter().filter(|&&ok| ok).count(),
+        1,
+        "expected one winner: CLI={cli:?}, PgWire={pg:?}"
+    );
+    assert_eq!(
+        successes.iter().filter(|&&ok| !ok).count(),
+        1,
+        "expected one loser: CLI={cli:?}, PgWire={pg:?}"
+    );
+    let loser_message = match &pg {
+        Ok(messages) => {
+            assert!(
+                messages
+                    .iter()
+                    .any(|message| matches!(message, SimpleQueryMessage::CommandComplete(1))),
+                "PgWire winner must report one inserted row: {messages:?}"
+            );
+            format!(
+                "{}\n{}",
+                String::from_utf8_lossy(&cli.stdout),
+                String::from_utf8_lossy(&cli.stderr)
+            )
+        }
+        Err(error) => error
+            .as_db_error()
+            .expect("PgWire loser must return a database error, not lose the connection")
+            .message()
+            .to_owned(),
+    };
+    let normalized = loser_message.to_ascii_lowercase();
+    assert!(
+        !normalized.contains("unique constraint failed"),
+        "raw SQLite UNIQUE error leaked: {loser_message}"
+    );
+    // §55.D deliberately allows recognized transient contention. Do not turn
+    // this into the stronger, actor-serialized §55.B/C error contract.
+    assert!(
+        [
+            "singleton constraint",
+            "locked",
+            "busy",
+            "index.lock",
+            "cannot lock",
+            "unable to create",
+            "file exists",
+            "another git process",
+        ]
+        .iter()
+        .any(|fragment| normalized.contains(fragment)),
+        "unrecognized CLI/PgWire loser error: {loser_message}"
+    );
+
+    // Use the same PgWire connection after either outcome, including a rejected
+    // INSERT. Both protocol convergence and connection usability must hold.
+    let count = runtime.block_on(async {
+        tokio::time::timeout(
+            Duration::from_secs(30),
+            client.simple_query("SELECT COUNT(*) FROM ig_race_pg"),
+        )
+        .await
+        .expect("PgWire count timed out")
+        .expect("PgWire connection must remain usable after the race")
+    });
+    let rows: Vec<_> = count
+        .iter()
+        .filter_map(|message| match message {
+            SimpleQueryMessage::Row(row) => Some(row),
+            _ => None,
+        })
+        .collect();
+    assert_eq!(rows.len(), 1, "COUNT must return exactly one result row");
+    assert_eq!(
+        rows[0].get(0),
+        Some("1"),
+        "§55.E: PgWire must see one survivor"
+    );
+
+    let theme = if cli.status.success() {
+        "cli-dark"
+    } else {
+        "pg-light"
+    };
+    let survivor = assert_survivor(&repo, "ig_race_pg", theme);
+    if cli.status.success() {
+        assert_eq!(String::from_utf8_lossy(&cli.stdout).trim(), survivor);
+    }
+    drop(client);
+    runtime.block_on(async {
+        tokio::time::timeout(Duration::from_secs(30), connection_task)
+            .await
+            .expect("PgWire connection shutdown timed out")
+            .expect("PgWire driver panicked")
+            .expect("PgWire driver failed");
+    });
+}
diff --git a/tests/e2e/integration_write_lock_races.rs b/tests/e2e/integration_write_lock_races.rs
index 04b1740..c0575da 100644
--- a/tests/e2e/integration_write_lock_races.rs
+++ b/tests/e2e/integration_write_lock_races.rs
@@ -20,6 +20,7 @@
 //! them in `HEAD` at the end.
 
 use crate::common::{ddb_bin, DdbTestRepo, ServerGuard};
+use ddb_core::parser::parse;
 use serde_json::Value;
 use std::collections::BTreeSet;
 use std::path::Path;
@@ -188,6 +189,13 @@ fn integration_61_b_concurrent_cli_and_graphql_write_lock() {
             "serve write {k} not durable in HEAD for {id}: HEAD lacks {needle:?}\n\
              HEAD content:\n{head}"
         );
+        let committed = parse(&head, &format!("ddb/{id}.md"))
+            .expect("failed to parse committed GraphQL doogat");
+        assert_eq!(
+            committed.meta.title.as_deref(),
+            Some(needle.as_str()),
+            "serve write {k} must update the committed title for {id}"
+        );
     }
     for (k, id) in cli_ids.iter().enumerate() {
         let head = head_content(repo.path(), id);
@@ -197,5 +205,17 @@ fn integration_61_b_concurrent_cli_and_graphql_write_lock() {
             "CLI write {k} not durable in HEAD for {id}: HEAD lacks {needle:?}\n\
              HEAD content:\n{head}"
         );
+        let committed =
+            parse(&head, &format!("ddb/{id}.md")).expect("failed to parse committed CLI doogat");
+        assert_eq!(
+            committed.body.trim(),
+            needle,
+            "CLI write {k} must update the committed body for {id}"
+        );
+        assert_eq!(
+            committed.meta.title,
+            Some(format!("WL cli seed {k}")),
+            "CLI body write {k} must preserve the committed title for {id}"
+        );
     }
 }
diff --git a/tests/e2e/main.rs b/tests/e2e/main.rs
index 2dfe3ff..3896c79 100644
--- a/tests/e2e/main.rs
+++ b/tests/e2e/main.rs
@@ -38,6 +38,8 @@ mod integration_nosql_cli;
 mod integration_orderby_base_fields;
 mod integration_rest_pgwire;
 mod integration_singleton_flow;
+mod integration_singleton_parity;
+mod integration_singleton_races;
 mod integration_sql_no_match;
 mod integration_sql_writes;
 mod integration_sync;
@@ -46,6 +48,7 @@ mod integration_typed_write_cli;
 mod integration_typed_write_polish;
 mod integration_update_bin;
 mod integration_warnings_update;
+mod integration_write_lock_races;
 mod integration_write_recovery;
 mod junction_tables;
 mod link_kinds;

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Reviewed head: 36c0687; task's own range 75cde1c..36c0687. The prior unrelated 00202 commit is excluded.
cargo build -> exit 0; Finished dev profile in 37.23s.
cargo clippy --workspace --all-targets -> exit 0; Finished dev profile in 16.36s.
cargo test-ci -> exit 0; 42 CLI passed (1.55s), 1555 core passed (952.80s), 222 server passed (0.58s); all 0 failed / 0 ignored.
cargo test -p ddb-e2e --test e2e integration_ -> exit 0, twice: each 83 passed; 0 failed; 0 ignored; 482 filtered out; 16.04s and 15.34s.
cargo test -p ddb-e2e --test e2e -- smoke_ alter_column_type:: alter_table_rename:: bundle_import_conflict_recovery:: cascade_delete:: checkboxes:: cli_create_fk_freshness:: delete_backlinks:: discover:: fix:: folder_namespace:: hyphenated_types:: inline_zone:: junction_tables:: link_kinds:: multi_device:: pgwire:: reference_raw_id:: rename:: schema_apply:: search_in_filter:: search_links:: sequence:: serve:: server_mutations:: set_flag:: sql_expressions_test:: sql_lifecycle:: sync_crdt:: tags:: typed_field_mutations:: -> exit 0; 278 passed; 0 failed; 0 ignored; 287 filtered out; 33.66s.
Actual runner --list: 565 tests, 0 benchmarks. All 391 source mapping keys match four source inventories; all target tests or audited aliases resolve to registered runner names. Source assertions were compared separately, not inferred from runner discovery.
Independent Devon actually ran wrong CLI facades. Discarded updates were caught; body-to-title corruption survived, then was repaired with committed parsed field assertions and caught on replay. SQL INSERT value suffix corruption survived substring equality, then exact seed theme equality caught the same mutant on replay (4 passed, 1 failed, intentional exit101). All facades neutralized. No demonstrated surviving mutant remains.
Earlier real test failures from sync fixture setup and the new REST assertion were repaired; all targeted reruns are green. REST source checks the returned custom value anywhere in response, not core title.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


