
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Port integration §54-55/61: PgWire/SINGLETON cross-protocol parity, SINGLETON write races, cross-process write-lock races (port LAST); reconcile remaining source assertions before shell retirement

Description:
Port tests/integration.sh:2282-2537 + 2817-2885 and the corresponding tests/integration.ps1 section (§54.D, §55, §55.A-E, §61, §61.A-B) to Rust e2e tests. This is the riskiest, timing-sensitive slice of the PRD (concurrent multi-process races) and is deliberately sequenced LAST among the port tasks, after every other integration/smoke section has already landed, per the PRD's own Phase 1 instruction ("server sections §54-57 and multi-process races port last").

Location: new files tests/e2e/integration_*.rs (e.g. integration_pgwire_singleton_parity.rs, integration_singleton_races.rs, integration_write_lock_races.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `tests/e2e/singleton_cross_process_upsert.rs` — a live two-server race test that already runs under ordinary `cargo test` parallelism today; this is the existing pattern for every race in this range, not a new one. `ServerGuard` (each test gets its own port via `next_available_port`'s AtomicU16 counter, and its own TempDir-backed repo).

Contract (verbatim from the design doc's Interfaces & contracts — this design DELIBERATELY SUPERSEDES the PRD's own suggested mitigation of "serial markers" for these sections, per the design doc's review log; do not add a serial_test dependency):
- "No serial_test crate, no --test-threads=1. Every test gets its own port and its own TempDir-backed repo, so cargo's default parallel test runner is already safe."
- "Timing-sensitive within-test ordering (two CLI/GraphQL calls that must interleave a specific way) is expressed with std::thread::scope + explicit joins, not a serial marker — same file, same pattern as the existing race test."
- "PgWire sections — psql dependency dropped, not preserved. The Rust e2e crate already ports PgWire scenarios through tokio_postgres (pure-Rust client), never shelling out to psql. The port therefore drops the skip entirely: §54.D's PgWire assertions run unconditionally on every platform via tokio_postgres. Do not add a command -v psql equivalent check in Rust — there is nothing to check for."

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying (the design doc's Reuse inventory flags §54.D/§55.D as likely already covered by tests/e2e/pgwire_singleton.rs — check before writing new coverage).
- §55.A-D (CLI/GraphQL executeSql/typed-createDoogat/PgWire concurrent INSERT races) must each assert exactly one row survives the race (structured-error parity on the loser). §55.E asserts convergence across every protocol's race.
- §61.A-B (cross-process write lock: N concurrent CLI writers on distinct doogats, and a `ddb serve` write concurrent with a CLI write) must assert no lost commit under concurrency — this is PRD 00162's write-lock guarantee, a P0 data-safety invariant per AGENTS.md.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally, run at least twice to catch flake from the concurrency changes; mapping table shows 100% of §54-55/61 rows (both dialects) as DONE.
User additionally required reconciliation of all391 mapping rows against actual shell assertions and registered test bodies, including stale PowerShell17/18 rows. Existing tests were extended for missing assertions; no product code changes. This is one partition of the task diff; other partitions receive the same independent review. Do not infer file coverage from this partition alone.


Acceptance criteria:
All original assertions retained across CLI/GraphQL/REST/PgWire/NoSQL/sync tests and both source dialects; tests registered; exact-one singleton losers/convergence and committed write durability; repeated local scope green; no shell files deleted before replacement CI.


## Diff under review

```diff
diff --git a/tests/e2e/alter_column_type.rs b/tests/e2e/alter_column_type.rs
index 693228c..ac6c32f 100644
--- a/tests/e2e/alter_column_type.rs
+++ b/tests/e2e/alter_column_type.rs
@@ -1,57 +1,124 @@
 use crate::common::DdbTestRepo;
 use predicates::prelude::*;
 
-// PRD 00128: widen VARCHAR(255) to TEXT, then insert a long value that would
-// have been rejected pre-ALTER. Verify persistence across a fresh process.
+// PRD 00128: preserve the VARCHAR(255) -> TEXT regression and integration
+// section 47's VARCHAR(32) -> VARCHAR(100) -> TEXT sequence in fresh processes.
 
 #[test]
 fn widens_varchar_to_text_and_accepts_longer_values() {
     let repo = DdbTestRepo::init();
 
-    repo.ddb()
-        .args(["query", "CREATE TABLE link (url VARCHAR(255))"])
-        .assert()
-        .success();
+    for (table, limit) in [("link", 255), ("ac_link", 32)] {
+        repo.ddb()
+            .args([
+                "query",
+                &format!("CREATE TABLE {table} (url VARCHAR({limit}))"),
+            ])
+            .assert()
+            .success();
 
-    let url_255 = "a".repeat(255);
-    repo.ddb()
-        .args([
-            "query",
-            &format!("INSERT INTO link (title, url) VALUES ('boundary', '{url_255}')"),
-        ])
-        .assert()
-        .success();
+        let boundary = "a".repeat(limit);
+        let inserted = repo
+            .ddb()
+            .args([
+                "query",
+                &format!("INSERT INTO {table} (title, url) VALUES ('boundary', '{boundary}')"),
+            ])
+            .assert()
+            .success();
+        assert!(!String::from_utf8_lossy(&inserted.get_output().stdout)
+            .trim()
+            .is_empty());
+        let boundary_id = String::from_utf8_lossy(&inserted.get_output().stdout)
+            .trim()
+            .to_owned();
+        assert!(
+            boundary_id.len() == 14 && boundary_id.bytes().all(|byte| byte.is_ascii_digit()),
+            "boundary INSERT must return a 14-digit id: {boundary_id:?}"
+        );
 
-    let url_2000 = "b".repeat(2000);
-    repo.ddb()
-        .args([
-            "query",
-            &format!("INSERT INTO link (title, url) VALUES ('toolong', '{url_2000}')"),
-        ])
-        .assert()
-        .failure();
+        let too_long = "b".repeat(if limit == 32 { 80 } else { 2000 });
+        repo.ddb()
+            .args([
+                "query",
+                &format!("INSERT INTO {table} (title, url) VALUES ('toolong', '{too_long}')"),
+            ])
+            .assert()
+            .failure()
+            .stderr(predicate::str::contains("exceeds limit"));
 
-    repo.ddb()
-        .args(["query", "ALTER TABLE link ALTER COLUMN url TYPE TEXT"])
-        .assert()
-        .success();
+        if limit == 32 {
+            repo.ddb()
+                .args([
+                    "query",
+                    "ALTER TABLE ac_link ALTER COLUMN url TYPE VARCHAR(100)",
+                ])
+                .assert()
+                .success();
+            let inserted = repo
+                .ddb()
+                .args([
+                    "query",
+                    &format!("INSERT INTO ac_link (title, url) VALUES ('now-ok', '{too_long}')"),
+                ])
+                .assert()
+                .success();
+            assert!(!String::from_utf8_lossy(&inserted.get_output().stdout)
+                .trim()
+                .is_empty());
+            repo.ddb()
+                .args([
+                    "query",
+                    "ALTER TABLE ac_link ALTER COLUMN url TYPE VARCHAR(5)",
+                ])
+                .assert()
+                .failure()
+                .stderr(predicate::str::contains("cannot narrow"))
+                .stderr(predicate::str::contains("2 existing rows exceed limit"));
+        }
 
-    repo.ddb()
-        .args([
-            "query",
-            &format!("INSERT INTO link (title, url) VALUES ('now-ok', '{url_2000}')"),
-        ])
-        .assert()
-        .success();
+        repo.ddb()
+            .args([
+                "query",
+                &format!("ALTER TABLE {table} ALTER COLUMN url TYPE TEXT"),
+            ])
+            .assert()
+            .success();
 
-    let url_another = "c".repeat(1500);
-    repo.ddb()
-        .args([
-            "query",
-            &format!("INSERT INTO link (title, url) VALUES ('persisted', '{url_another}')"),
-        ])
-        .assert()
-        .success();
+        let url_2000 = "b".repeat(2000);
+        let inserted = repo
+            .ddb()
+            .args([
+                "query",
+                &format!("INSERT INTO {table} (title, url) VALUES ('text-row', '{url_2000}')"),
+            ])
+            .assert()
+            .success();
+        assert!(!String::from_utf8_lossy(&inserted.get_output().stdout)
+            .trim()
+            .is_empty());
+        let widened_id = String::from_utf8_lossy(&inserted.get_output().stdout)
+            .trim()
+            .to_owned();
+        assert!(
+            widened_id.len() == 14 && widened_id.bytes().all(|byte| byte.is_ascii_digit()),
+            "post-widen INSERT must return a 14-digit id: {widened_id:?}"
+        );
+        repo.ddb()
+            .args(["query", &format!("SELECT id FROM {table}")])
+            .assert()
+            .success()
+            .stdout(predicate::str::contains(&widened_id));
+
+        let url_another = "c".repeat(1500);
+        repo.ddb()
+            .args([
+                "query",
+                &format!("INSERT INTO {table} (title, url) VALUES ('persisted', '{url_another}')"),
+            ])
+            .assert()
+            .success();
+    }
 }
 
 #[test]
diff --git a/tests/e2e/alter_table_rename.rs b/tests/e2e/alter_table_rename.rs
index 7f469b1..a77dc94 100644
--- a/tests/e2e/alter_table_rename.rs
+++ b/tests/e2e/alter_table_rename.rs
@@ -12,7 +12,8 @@ fn cli_alter_table_rename_to_renames_typedef_and_data() {
     repo.ddb()
         .args(["query", "CREATE TABLE rfoo (title VARCHAR(64))"])
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("table rfoo created"));
 
     repo.ddb()
         .args([
@@ -32,7 +33,8 @@ fn cli_alter_table_rename_to_renames_typedef_and_data() {
     repo.ddb()
         .args(["query", "ALTER TABLE rfoo RENAME TO rbar"])
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("renamed to rbar"));
 
     // Old name no longer resolves.
     repo.ddb()
@@ -46,6 +48,11 @@ fn cli_alter_table_rename_to_renames_typedef_and_data() {
         .assert()
         .success()
         .stdout(predicate::str::contains("2"));
+    repo.ddb()
+        .args(["query", "DROP TABLE rbar CASCADE"])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("dropped"));
 }
 
 #[test]
diff --git a/tests/e2e/cascade_delete.rs b/tests/e2e/cascade_delete.rs
index f7343d3..1b941e9 100644
--- a/tests/e2e/cascade_delete.rs
+++ b/tests/e2e/cascade_delete.rs
@@ -23,6 +23,10 @@ fn cascade_delete_cleans_junction_table() {
         .args(["query", "INSERT INTO category (label) VALUES ('tech')"])
         .output()
         .unwrap();
+    assert!(
+        cat_out.status.success(),
+        "fixture command failed: {cat_out:?}"
+    );
     let cat_id = String::from_utf8_lossy(&cat_out.stdout).trim().to_string();
 
     std::thread::sleep(std::time::Duration::from_secs(1));
@@ -35,6 +39,10 @@ fn cascade_delete_cleans_junction_table() {
         ])
         .output()
         .unwrap();
+    assert!(
+        bm_out.status.success(),
+        "fixture command failed: {bm_out:?}"
+    );
     let bm_id = String::from_utf8_lossy(&bm_out.stdout).trim().to_string();
 
     // Link bookmark -> category
@@ -106,6 +114,10 @@ fn cascade_delete_cleans_owned_junction_when_parent_deleted() {
         .args(["query", "INSERT INTO category (label) VALUES ('alpha')"])
         .output()
         .unwrap();
+    assert!(
+        cat_out.status.success(),
+        "fixture command failed: {cat_out:?}"
+    );
     let cat_id = String::from_utf8_lossy(&cat_out.stdout).trim().to_string();
 
     std::thread::sleep(std::time::Duration::from_secs(1));
@@ -124,6 +136,10 @@ fn cascade_delete_cleans_owned_junction_when_parent_deleted() {
         ])
         .output()
         .unwrap();
+    assert!(
+        bm_out.status.success(),
+        "fixture command failed: {bm_out:?}"
+    );
     let bm_id = String::from_utf8_lossy(&bm_out.stdout).trim().to_string();
 
     // Sanity: junction row exists keyed by the bookmark (parent) side.
@@ -186,6 +202,10 @@ fn cascade_delete_removes_wikilink_from_referencing_file() {
         .args(["query", "INSERT INTO category (label) VALUES ('tech')"])
         .output()
         .unwrap();
+    assert!(
+        cat_out.status.success(),
+        "fixture command failed: {cat_out:?}"
+    );
     let cat_id = String::from_utf8_lossy(&cat_out.stdout).trim().to_string();
 
     std::thread::sleep(std::time::Duration::from_secs(1));
@@ -198,6 +218,10 @@ fn cascade_delete_removes_wikilink_from_referencing_file() {
         ])
         .output()
         .unwrap();
+    assert!(
+        bm_out.status.success(),
+        "fixture command failed: {bm_out:?}"
+    );
     let bm_id = String::from_utf8_lossy(&bm_out.stdout).trim().to_string();
 
     // Link bookmark -> category (creates wikilink in reference section)
@@ -257,6 +281,10 @@ fn cascade_delete_via_ddb_delete_cleans_junction_and_refs() {
         .args(["query", "INSERT INTO category (label) VALUES ('tech')"])
         .output()
         .unwrap();
+    assert!(
+        cat_out.status.success(),
+        "fixture command failed: {cat_out:?}"
+    );
     let cat_id = String::from_utf8_lossy(&cat_out.stdout).trim().to_string();
 
     std::thread::sleep(std::time::Duration::from_secs(1));
@@ -269,6 +297,10 @@ fn cascade_delete_via_ddb_delete_cleans_junction_and_refs() {
         ])
         .output()
         .unwrap();
+    assert!(
+        bm_out.status.success(),
+        "fixture command failed: {bm_out:?}"
+    );
     let bm_id = String::from_utf8_lossy(&bm_out.stdout).trim().to_string();
 
     // Link bookmark -> category via junction
@@ -350,6 +382,10 @@ fn delete_rejected_by_not_null_references_sql_issue_10() {
         ])
         .output()
         .unwrap();
+    assert!(
+        link_out.status.success(),
+        "fixture command failed: {link_out:?}"
+    );
     let link_id = String::from_utf8_lossy(&link_out.stdout).trim().to_string();
     std::thread::sleep(std::time::Duration::from_secs(1));
 
@@ -361,6 +397,10 @@ fn delete_rejected_by_not_null_references_sql_issue_10() {
         ])
         .output()
         .unwrap();
+    assert!(
+        cat_out.status.success(),
+        "fixture command failed: {cat_out:?}"
+    );
     let cat_id = String::from_utf8_lossy(&cat_out.stdout).trim().to_string();
 
     repo.ddb()
@@ -400,6 +440,21 @@ fn delete_rejected_by_not_null_references_sql_issue_10() {
         .assert()
         .success()
         .stdout(predicate::str::contains("1"));
+
+    // Removing the blocker restores the same parent's normal delete path.
+    repo.ddb()
+        .args([
+            "query",
+            &format!("DELETE FROM \"category-membership\" WHERE link_id = '{link_id}'"),
+        ])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("1 row(s) affected"));
+    repo.ddb()
+        .args(["query", &format!("DELETE FROM link WHERE id = '{link_id}'")])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("1 row(s) affected"));
 }
 
 #[test]
@@ -437,6 +492,10 @@ fn delete_rejected_by_not_null_references_cli_issue_10() {
         ])
         .output()
         .unwrap();
+    assert!(
+        link_out.status.success(),
+        "fixture command failed: {link_out:?}"
+    );
     let link_id = String::from_utf8_lossy(&link_out.stdout).trim().to_string();
     std::thread::sleep(std::time::Duration::from_secs(1));
     let cat_out = repo
@@ -447,6 +506,10 @@ fn delete_rejected_by_not_null_references_cli_issue_10() {
         ])
         .output()
         .unwrap();
+    assert!(
+        cat_out.status.success(),
+        "fixture command failed: {cat_out:?}"
+    );
     let cat_id = String::from_utf8_lossy(&cat_out.stdout).trim().to_string();
     repo.ddb()
         .args([
@@ -464,5 +527,6 @@ fn delete_rejected_by_not_null_references_cli_issue_10() {
         .args(["delete", &link_id])
         .assert()
         .failure()
-        .stderr(predicate::str::contains("NOT NULL REFERENCES"));
+        .stderr(predicate::str::contains("NOT NULL REFERENCES"))
+        .stderr(predicate::str::contains("category-membership.link_id"));
 }
diff --git a/tests/e2e/junction_tables.rs b/tests/e2e/junction_tables.rs
index f9a6f81..660712f 100644
--- a/tests/e2e/junction_tables.rs
+++ b/tests/e2e/junction_tables.rs
@@ -63,7 +63,8 @@ fn junction_table_round_trip() {
             ),
         ])
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("1 row"));
 
     // Verify junction row exists
     repo.ddb()
@@ -84,7 +85,8 @@ fn junction_table_round_trip() {
             ),
         ])
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("1 row"));
 
     // Verify junction table is empty
     repo.ddb()
diff --git a/tests/e2e/schema_apply.rs b/tests/e2e/schema_apply.rs
index 4fc4cfc..d228910 100644
--- a/tests/e2e/schema_apply.rs
+++ b/tests/e2e/schema_apply.rs
@@ -61,7 +61,11 @@ types:
 ";
     let schema = write_schema(&repo, "diffgadget", yaml);
 
-    let a = repo.ddb().args(["schema", "diff", &schema]).output().unwrap();
+    let a = repo
+        .ddb()
+        .args(["schema", "diff", &schema])
+        .output()
+        .unwrap();
     let b = repo
         .ddb()
         .args(["schema", "apply", &schema, "--dry-run"])
@@ -206,7 +210,8 @@ types:
     repo.ddb()
         .args(["schema", "apply", &schema])
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("create_type").not());
 
     // A diff after convergence shows no create/add/drop op for this table.
     repo.ddb()
diff --git a/tests/e2e/sql_expressions_test.rs b/tests/e2e/sql_expressions_test.rs
index 54062cd..409e3cf 100644
--- a/tests/e2e/sql_expressions_test.rs
+++ b/tests/e2e/sql_expressions_test.rs
@@ -10,7 +10,8 @@ fn insert_with_coalesce() {
             "CREATE TABLE tasks (name TEXT, sort_order INTEGER)",
         ])
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("table tasks created"));
 
     let out = repo
         .ddb()
@@ -25,12 +26,37 @@ fn insert_with_coalesce() {
         "insert with COALESCE failed: {}",
         String::from_utf8_lossy(&out.stderr)
     );
+    let first_id = String::from_utf8_lossy(&out.stdout).trim().to_owned();
+    assert!(
+        first_id.len() == 14 && first_id.bytes().all(|byte| byte.is_ascii_digit()),
+        "COALESCE INSERT must return a 14-digit id: {first_id:?}"
+    );
 
     repo.ddb()
         .args(["query", "SELECT name, sort_order FROM tasks"])
         .assert()
         .success()
         .stdout(predicate::str::contains("first | 0"));
+
+    let second = repo.ddb()
+        .args(["query", "INSERT INTO tasks (name, sort_order) VALUES ('second', COALESCE((SELECT MAX(sort_order) FROM tasks), 0) + 1)"])
+        .assert()
+        .success();
+    let second_id = String::from_utf8_lossy(&second.get_output().stdout)
+        .trim()
+        .to_owned();
+    assert!(
+        second_id.len() == 14 && second_id.bytes().all(|byte| byte.is_ascii_digit()),
+        "COALESCE plus arithmetic INSERT must return a 14-digit id: {second_id:?}"
+    );
+    repo.ddb()
+        .args([
+            "query",
+            &format!("SELECT sort_order FROM tasks WHERE id = '{second_id}'"),
+        ])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("1"));
 }
 
 #[test]
diff --git a/tests/e2e/sql_lifecycle.rs b/tests/e2e/sql_lifecycle.rs
index 6ddb263..16cc321 100644
--- a/tests/e2e/sql_lifecycle.rs
+++ b/tests/e2e/sql_lifecycle.rs
@@ -34,6 +34,7 @@ fn insert_and_select() {
         ])
         .output()
         .unwrap();
+    assert!(id1.status.success(), "first INSERT failed: {id1:?}");
     let id1 = String::from_utf8_lossy(&id1.stdout).trim().to_string();
 
     std::thread::sleep(std::time::Duration::from_secs(1));
@@ -46,7 +47,14 @@ fn insert_and_select() {
         ])
         .output()
         .unwrap();
+    assert!(id2.status.success(), "second INSERT failed: {id2:?}");
     let id2 = String::from_utf8_lossy(&id2.stdout).trim().to_string();
+    for id in [&id1, &id2] {
+        assert!(
+            id.len() == 14 && id.bytes().all(|byte| byte.is_ascii_digit()),
+            "INSERT must return a 14-digit id: {id:?}"
+        );
+    }
 
     // All rows present
     repo.ddb()
@@ -113,6 +121,7 @@ fn update_row() {
         ])
         .output()
         .unwrap();
+    assert!(out.status.success(), "fixture command failed: {out:?}");
     let id = String::from_utf8_lossy(&out.stdout).trim().to_string();
 
     repo.ddb()
@@ -147,6 +156,7 @@ fn delete_row() {
         .args(["query", "INSERT INTO tasks (status) VALUES ('keep')"])
         .output()
         .unwrap();
+    assert!(out1.status.success(), "fixture command failed: {out1:?}");
     let id1 = String::from_utf8_lossy(&out1.stdout).trim().to_string();
     std::thread::sleep(std::time::Duration::from_secs(1));
 
@@ -155,6 +165,7 @@ fn delete_row() {
         .args(["query", "INSERT INTO tasks (status) VALUES ('delete-me')"])
         .output()
         .unwrap();
+    assert!(out2.status.success(), "fixture command failed: {out2:?}");
     let id2 = String::from_utf8_lossy(&out2.stdout).trim().to_string();
 
     repo.ddb()
@@ -266,6 +277,15 @@ fn install_meeting_minutes_type() {
         .success()
         .stdout(predicate::str::contains("attendees: alice,bob"));
 
+    repo.ddb()
+        .args([
+            "query",
+            &format!(r#"SELECT date FROM "meeting-minutes" WHERE id = '{id}'"#),
+        ])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("2026-03-10"));
+
     // DELETE on hyphenated table must work (requires quoted identifiers in SQL)
     repo.ddb()
         .args([
@@ -273,7 +293,8 @@ fn install_meeting_minutes_type() {
             &format!(r#"DELETE FROM "meeting-minutes" WHERE id = '{id}'"#),
         ])
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("1 row(s) affected"));
 }
 
 #[test]
@@ -537,6 +558,43 @@ fn transaction_rollback_via_cli() {
         .assert()
         .success()
         .stdout(predicate::str::contains("0"));
+
+    repo.ddb()
+        .args([
+            "query",
+            "BEGIN; INSERT INTO items (name) VALUES ('committed'); COMMIT",
+        ])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("COMMIT"));
+    repo.ddb()
+        .args([
+            "query",
+            "BEGIN; INSERT INTO items (name) VALUES ('rolled-back'); ROLLBACK",
+        ])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("ROLLBACK"));
+
+    let count = repo
+        .ddb()
+        .args(["query", "SELECT COUNT(*) FROM items"])
+        .assert()
+        .success();
+    assert_eq!(
+        String::from_utf8_lossy(&count.get_output().stdout).trim(),
+        "1"
+    );
+    let remaining = repo
+        .ddb()
+        .args(["query", "SELECT name FROM items"])
+        .assert()
+        .success();
+    assert_eq!(
+        String::from_utf8_lossy(&remaining.get_output().stdout).trim(),
+        "committed",
+        "rollback must preserve the previously committed row"
+    );
 }
 
 #[test]
@@ -776,6 +834,22 @@ fn multi_row_insert() {
     let ids_str = String::from_utf8_lossy(&out.stdout).trim().to_string();
     let ids: Vec<&str> = ids_str.split(',').collect();
     assert_eq!(ids.len(), 3, "expected 3 IDs, got: {ids_str}");
+    for id in &ids {
+        assert!(
+            id.len() == 14 && id.bytes().all(|byte| byte.is_ascii_digit()),
+            "multi-row INSERT must return 14-digit IDs, got: {id:?}"
+        );
+    }
+
+    let count = repo
+        .ddb()
+        .args(["query", "SELECT COUNT(*) FROM items"])
+        .assert()
+        .success();
+    assert_eq!(
+        String::from_utf8_lossy(&count.get_output().stdout).trim(),
+        "3"
+    );
 
     // All rows present
     repo.ddb()
@@ -810,7 +884,8 @@ fn default_next_auto_increments() {
             "CREATE TABLE nexttest (name TEXT, pos INTEGER DEFAULT NEXT)",
         ])
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("table nexttest created"));
 
     // Multi-row insert should assign sequential values
     repo.ddb()

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Reviewed head: 36c0687; task's own range 75cde1c..36c0687. The prior unrelated 00202 commit is excluded.
cargo build -> exit 0; Finished dev profile in 37.23s.
cargo clippy --workspace --all-targets -> exit 0; Finished dev profile in 16.36s.
cargo test-ci -> exit 0; 42 CLI passed (1.55s), 1555 core passed (952.80s), 222 server passed (0.58s); all 0 failed / 0 ignored.
cargo test -p ddb-e2e --test e2e integration_ -> exit 0, twice: each 83 passed; 0 failed; 0 ignored; 482 filtered out; 16.04s and 15.34s.
cargo test -p ddb-e2e --test e2e -- smoke_ alter_column_type:: alter_table_rename:: bundle_import_conflict_recovery:: cascade_delete:: checkboxes:: cli_create_fk_freshness:: delete_backlinks:: discover:: fix:: folder_namespace:: hyphenated_types:: inline_zone:: junction_tables:: link_kinds:: multi_device:: pgwire:: reference_raw_id:: rename:: schema_apply:: search_in_filter:: search_links:: sequence:: serve:: server_mutations:: set_flag:: sql_expressions_test:: sql_lifecycle:: sync_crdt:: tags:: typed_field_mutations:: -> exit 0; 278 passed; 0 failed; 0 ignored; 287 filtered out; 33.66s.
Actual runner --list: 565 tests, 0 benchmarks. All 391 source mapping keys match four source inventories; all target tests or audited aliases resolve to registered runner names. Source assertions were compared separately, not inferred from runner discovery.
Independent Devon actually ran wrong CLI facades. Discarded updates were caught; body-to-title corruption survived, then was repaired with committed parsed field assertions and caught on replay. SQL INSERT value suffix corruption survived substring equality, then exact seed theme equality caught the same mutant on replay (4 passed, 1 failed, intentional exit101). All facades neutralized. No demonstrated surviving mutant remains.
Earlier real test failures from sync fixture setup and the new REST assertion were repaired; all targeted reruns are green. REST source checks the returned custom value anywhere in response, not core title.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


