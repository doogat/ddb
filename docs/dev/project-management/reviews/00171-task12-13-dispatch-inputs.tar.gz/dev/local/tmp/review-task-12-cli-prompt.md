
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: Port integration §54-55/61: PgWire/SINGLETON cross-protocol parity, SINGLETON write races, cross-process write-lock races (port LAST); reconcile remaining source assertions before shell retirement

Description:
Port tests/integration.sh:2282-2537 + 2817-2885 and the corresponding tests/integration.ps1 section (§54.D, §55, §55.A-E, §61, §61.A-B) to Rust e2e tests. This is the riskiest, timing-sensitive slice of the PRD (concurrent multi-process races) and is deliberately sequenced LAST among the port tasks, after every other integration/smoke section has already landed, per the PRD's own Phase 1 instruction ("server sections §54-57 and multi-process races port last").

Location: new files tests/e2e/integration_*.rs (e.g. integration_pgwire_singleton_parity.rs, integration_singleton_races.rs, integration_write_lock_races.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `tests/e2e/singleton_cross_process_upsert.rs` — a live two-server race test that already runs under ordinary `cargo test` parallelism today; this is the existing pattern for every race in this range, not a new one. `ServerGuard` (each test gets its own port via `next_available_port`'s AtomicU16 counter, and its own TempDir-backed repo).

Contract (verbatim from the design doc's Interfaces & contracts — this design DELIBERATELY SUPERSEDES the PRD's own suggested mitigation of "serial markers" for these sections, per the design doc's review log; do not add a serial_test dependency):
- "No serial_test crate, no --test-threads=1. Every test gets its own port and its own TempDir-backed repo, so cargo's default parallel test runner is already safe."
- "Timing-sensitive within-test ordering (two CLI/GraphQL calls that must interleave a specific way) is expressed with std::thread::scope + explicit joins, not a serial marker — same file, same pattern as the existing race test."
- "PgWire sections — psql dependency dropped, not preserved. The Rust e2e crate already ports PgWire scenarios through tokio_postgres (pure-Rust client), never shelling out to psql. The port therefore drops the skip entirely: §54.D's PgWire assertions run unconditionally on every platform via tokio_postgres. Do not add a command -v psql equivalent check in Rust — there is nothing to check for."

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying (the design doc's Reuse inventory flags §54.D/§55.D as likely already covered by tests/e2e/pgwire_singleton.rs — check before writing new coverage).
- §55.A-D (CLI/GraphQL executeSql/typed-createDoogat/PgWire concurrent INSERT races) must each assert exactly one row survives the race (structured-error parity on the loser). §55.E asserts convergence across every protocol's race.
- §61.A-B (cross-process write lock: N concurrent CLI writers on distinct doogats, and a `ddb serve` write concurrent with a CLI write) must assert no lost commit under concurrency — this is PRD 00162's write-lock guarantee, a P0 data-safety invariant per AGENTS.md.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally, run at least twice to catch flake from the concurrency changes; mapping table shows 100% of §54-55/61 rows (both dialects) as DONE.
User additionally required reconciliation of all391 mapping rows against actual shell assertions and registered test bodies, including stale PowerShell17/18 rows. Existing tests were extended for missing assertions; no product code changes. This is one partition of the task diff; other partitions receive the same independent review. Do not infer file coverage from this partition alone.


Acceptance criteria:
All original assertions retained across CLI/GraphQL/REST/PgWire/NoSQL/sync tests and both source dialects; tests registered; exact-one singleton losers/convergence and committed write durability; repeated local scope green; no shell files deleted before replacement CI.


## Diff under review

```diff
diff --git a/tests/e2e/checkboxes.rs b/tests/e2e/checkboxes.rs
index 663a9a5..b10797c 100644
--- a/tests/e2e/checkboxes.rs
+++ b/tests/e2e/checkboxes.rs
@@ -52,6 +52,34 @@ fn checkbox_filter_by_state() {
         .stdout(predicate::str::contains("task one"))
         .stdout(predicate::str::contains("task three"))
         .stdout(predicate::str::contains("task two").not());
+
+    let created = repo
+        .ddb()
+        .args(["create", "--title", "Updated checkboxes"])
+        .assert()
+        .success();
+    let id = String::from_utf8_lossy(&created.get_output().stdout)
+        .trim()
+        .to_owned();
+    repo.ddb()
+        .args([
+            "update",
+            &id,
+            "--body",
+            "- [ ] updated open task\n- [x] updated done task\n- [i] info note",
+        ])
+        .assert()
+        .success();
+    repo.ddb().arg("reindex").assert().success();
+    repo.ddb()
+        .args([
+            "query",
+            "SELECT state, content FROM _ddb_checkboxes WHERE state = 'open'",
+        ])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("updated open task"))
+        .stdout(predicate::str::contains("updated done task").not());
 }
 
 #[test]
diff --git a/tests/e2e/cli_create_fk_freshness.rs b/tests/e2e/cli_create_fk_freshness.rs
index 4e42d53..600a881 100644
--- a/tests/e2e/cli_create_fk_freshness.rs
+++ b/tests/e2e/cli_create_fk_freshness.rs
@@ -16,6 +16,7 @@
 //! call would hide it).
 
 use crate::common::DdbTestRepo;
+use predicates::prelude::*;
 
 #[test]
 fn create_link_after_category_in_separate_process_succeeds_without_reindex() {
@@ -25,19 +26,29 @@ fn create_link_after_category_in_separate_process_succeeds_without_reindex() {
     repo.ddb()
         .args(["query", "CREATE TABLE category (fqn VARCHAR(255))"])
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("table category created"));
     repo.ddb()
         .args([
             "query",
             "CREATE TABLE link (url TEXT, category TEXT REFERENCES category)",
         ])
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("table link created"));
 
     // Process 1: create the parent category via `ddb create`.
     let cat_out = repo
         .ddb()
-        .args(["create", "--type", "category", "--title", "Cat A"])
+        .args([
+            "create",
+            "--type",
+            "category",
+            "--title",
+            "Cat A",
+            "--set",
+            "fqn=test.fqn",
+        ])
         .output()
         .expect("ddb create category failed to spawn");
     assert!(
@@ -48,6 +59,10 @@ fn create_link_after_category_in_separate_process_succeeds_without_reindex() {
     );
     let cat_id = String::from_utf8_lossy(&cat_out.stdout).trim().to_string();
     assert!(!cat_id.is_empty(), "category id should not be empty");
+    assert!(
+        cat_id.len() == 14 && cat_id.chars().all(|c| c.is_ascii_digit()),
+        "category id must contain exactly 14 digits: {cat_id:?}"
+    );
 
     // Process 2: create the child link referencing the just-created
     // category. NO intermediate `ddb reindex` — the whole point of #16
@@ -78,5 +93,9 @@ fn create_link_after_category_in_separate_process_succeeds_without_reindex() {
     );
     let link_id = String::from_utf8_lossy(&link_out.stdout).trim().to_string();
     assert!(!link_id.is_empty(), "link id should not be empty");
+    assert!(
+        link_id.len() == 14 && link_id.chars().all(|c| c.is_ascii_digit()),
+        "link id must contain exactly 14 digits: {link_id:?}"
+    );
     assert_ne!(link_id, cat_id, "link id should differ from category id");
 }
diff --git a/tests/e2e/delete_backlinks.rs b/tests/e2e/delete_backlinks.rs
index 3aaf393..0f57fee 100644
--- a/tests/e2e/delete_backlinks.rs
+++ b/tests/e2e/delete_backlinks.rs
@@ -11,6 +11,7 @@ fn delete_reports_broken_backlinks() {
         .args(["create", "--title", "Target"])
         .output()
         .unwrap();
+    assert!(a_out.status.success(), "fixture command failed: {a_out:?}");
     let a_id = String::from_utf8_lossy(&a_out.stdout).trim().to_string();
     std::thread::sleep(std::time::Duration::from_secs(1));
 
@@ -47,6 +48,7 @@ fn status_reports_broken_backlinks_after_delete() {
         .args(["create", "--title", "Target"])
         .output()
         .unwrap();
+    assert!(a_out.status.success(), "fixture command failed: {a_out:?}");
     let a_id = String::from_utf8_lossy(&a_out.stdout).trim().to_string();
     std::thread::sleep(std::time::Duration::from_secs(1));
 
diff --git a/tests/e2e/discover.rs b/tests/e2e/discover.rs
index 5abba26..b088889 100644
--- a/tests/e2e/discover.rs
+++ b/tests/e2e/discover.rs
@@ -82,6 +82,7 @@ fn discover_mentions() {
         ])
         .output()
         .unwrap();
+    assert!(a_out.status.success(), "fixture command failed: {a_out:?}");
     let a_id = String::from_utf8_lossy(&a_out.stdout).trim().to_string();
     std::thread::sleep(std::time::Duration::from_secs(1));
 
@@ -97,6 +98,7 @@ fn discover_mentions() {
         ])
         .output()
         .unwrap();
+    assert!(b_out.status.success(), "fixture command failed: {b_out:?}");
     let b_id = String::from_utf8_lossy(&b_out.stdout).trim().to_string();
 
     // Reindex so FTS picks up the body text
@@ -163,10 +165,12 @@ fn discover_similar() {
         ])
         .output()
         .unwrap();
+    assert!(a_out.status.success(), "fixture command failed: {a_out:?}");
     let a_id = String::from_utf8_lossy(&a_out.stdout).trim().to_string();
     std::thread::sleep(std::time::Duration::from_secs(1));
 
-    repo.ddb()
+    let similar = repo
+        .ddb()
         .args([
             "create",
             "--title",
@@ -178,6 +182,13 @@ fn discover_similar() {
         ])
         .assert()
         .success();
+    let similar_id = String::from_utf8_lossy(&similar.get_output().stdout)
+        .trim()
+        .to_owned();
+    assert!(
+        similar_id.len() == 14 && similar_id.bytes().all(|byte| byte.is_ascii_digit()),
+        "similar fixture must return a 14-digit id: {similar_id:?}"
+    );
 
     repo.ddb().arg("reindex").assert().success();
 
@@ -186,6 +197,7 @@ fn discover_similar() {
         .args(["discover", "similar", &a_id])
         .assert()
         .success()
+        .stdout(predicate::str::contains(&similar_id))
         .stdout(predicate::str::contains("no suggestions").not())
         .stdout(predicate::str::contains("Rust Advanced"));
 }
@@ -206,7 +218,15 @@ fn discover_orphans() {
         ])
         .output()
         .unwrap();
+    assert!(
+        out.status.success(),
+        "orphan fixture create failed: {out:?}"
+    );
     let id = String::from_utf8_lossy(&out.stdout).trim().to_string();
+    assert!(
+        id.len() == 14 && id.bytes().all(|byte| byte.is_ascii_digit()),
+        "orphan fixture must return a 14-digit id: {id:?}"
+    );
 
     repo.ddb().arg("reindex").assert().success();
 
@@ -263,6 +283,7 @@ fn discover_recent_shows_new_doogat() {
         .args(["create", "--title", "Fresh Note", "--body", "Just created."])
         .output()
         .unwrap();
+    assert!(out.status.success(), "fixture command failed: {out:?}");
     let id = String::from_utf8_lossy(&out.stdout).trim().to_string();
 
     repo.ddb().arg("reindex").assert().success();
@@ -327,6 +348,10 @@ fn discover_link_density_shows_hub() {
         .args(["create", "--title", "Hub", "--body", "Central node."])
         .output()
         .unwrap();
+    assert!(
+        hub_out.status.success(),
+        "fixture command failed: {hub_out:?}"
+    );
     let hub_id = String::from_utf8_lossy(&hub_out.stdout).trim().to_string();
     std::thread::sleep(std::time::Duration::from_secs(1));
 
diff --git a/tests/e2e/fix.rs b/tests/e2e/fix.rs
index 3d85795..0c88980 100644
--- a/tests/e2e/fix.rs
+++ b/tests/e2e/fix.rs
@@ -11,6 +11,7 @@ fn fix_dry_run_no_changes() {
         .args(["create", "--title", "Test", "--tags", "zebra,apple"])
         .output()
         .unwrap();
+    assert!(out.status.success(), "fixture command failed: {out:?}");
     let _id = String::from_utf8_lossy(&out.stdout).trim().to_string();
 
     // Count commits before fix
@@ -19,9 +20,19 @@ fn fix_dry_run_no_changes() {
         .args(["rev-list", "--count", "HEAD"])
         .output()
         .unwrap();
+    assert!(
+        log_before.status.success(),
+        "fixture command failed: {log_before:?}"
+    );
     let count_before = String::from_utf8_lossy(&log_before.stdout)
         .trim()
         .to_string();
+    let head_before = std::process::Command::new("git")
+        .current_dir(repo.path())
+        .args(["rev-parse", "HEAD"])
+        .output()
+        .unwrap();
+    assert!(head_before.status.success());
 
     // Dry run
     repo.ddb()
@@ -36,6 +47,10 @@ fn fix_dry_run_no_changes() {
         .args(["rev-list", "--count", "HEAD"])
         .output()
         .unwrap();
+    assert!(
+        log_after.status.success(),
+        "fixture command failed: {log_after:?}"
+    );
     let count_after = String::from_utf8_lossy(&log_after.stdout)
         .trim()
         .to_string();
@@ -43,6 +58,16 @@ fn fix_dry_run_no_changes() {
         count_before, count_after,
         "dry run should not create commits"
     );
+    let head_after = std::process::Command::new("git")
+        .current_dir(repo.path())
+        .args(["rev-parse", "HEAD"])
+        .output()
+        .unwrap();
+    assert!(head_after.status.success());
+    assert_eq!(
+        head_before.stdout, head_after.stdout,
+        "dry run must preserve HEAD"
+    );
 }
 
 #[test]
@@ -52,9 +77,16 @@ fn fix_commits_changes() {
     // Create doogat with hash-prefixed tag
     let out = repo
         .ddb()
-        .args(["create", "--title", "Test", "--tags", "#gtd,work"])
+        .args([
+            "create",
+            "--title",
+            "Test",
+            "--tags",
+            "#gtd,zebra,apple,work",
+        ])
         .output()
         .unwrap();
+    assert!(out.status.success(), "fixture command failed: {out:?}");
     let id = String::from_utf8_lossy(&out.stdout).trim().to_string();
 
     // Apply fixes
@@ -66,7 +98,15 @@ fn fix_commits_changes() {
 
     // Read back and verify tag is normalized
     let read_out = repo.ddb().args(["read", &id]).output().unwrap();
+    assert!(
+        read_out.status.success(),
+        "read after fix failed: {read_out:?}"
+    );
     let content = String::from_utf8_lossy(&read_out.stdout);
+    assert!(
+        content.contains("  - apple"),
+        "fixed tags must contain apple: {content}"
+    );
     assert!(
         content.contains("  - gtd"),
         "tag should be stripped of #: {content}"
@@ -205,7 +245,7 @@ fn fix_migrate_rewrites_zones() {
 
     // Run zone migration
     repo.ddb()
-        .args(["fix", "--migrate"])
+        .args(["fix", "--migrate", "--verbose"])
         .assert()
         .success()
         .stdout(predicate::str::contains("zone-migrated"));
diff --git a/tests/e2e/folder_namespace.rs b/tests/e2e/folder_namespace.rs
index d6f808c..fea62b8 100644
--- a/tests/e2e/folder_namespace.rs
+++ b/tests/e2e/folder_namespace.rs
@@ -26,16 +26,21 @@ fn insert_folder_typedef_creates_subdirectory_path() {
     std::fs::write(typedef_file.path(), &updated).unwrap();
 
     // Commit the change
-    std::process::Command::new("git")
+    let added = std::process::Command::new("git")
         .current_dir(repo.path())
         .args(["add", "-A"])
         .output()
         .unwrap();
-    std::process::Command::new("git")
+    assert!(added.status.success(), "fixture git add failed: {added:?}");
+    let committed = std::process::Command::new("git")
         .current_dir(repo.path())
         .args(["commit", "-m", "add folder to widget"])
         .output()
         .unwrap();
+    assert!(
+        committed.status.success(),
+        "fixture git commit failed: {committed:?}"
+    );
 
     // Reindex to pick up folder setting
     repo.ddb().arg("reindex").assert().success();
@@ -56,7 +61,7 @@ fn insert_folder_typedef_creates_subdirectory_path() {
     // Verify the file is at ddb/widget/{id}.md
     let expected_path = repo.path().join(format!("ddb/widget/{id}.md"));
     assert!(
-        expected_path.exists(),
+        expected_path.is_file(),
         "expected file at {}",
         expected_path.display()
     );
diff --git a/tests/e2e/inline_zone.rs b/tests/e2e/inline_zone.rs
index 4203571..8c21972 100644
--- a/tests/e2e/inline_zone.rs
+++ b/tests/e2e/inline_zone.rs
@@ -17,7 +17,8 @@ fn inline_zone_frontmatter_materializes_and_survives_reindex() {
             "CREATE TABLE note (summary TEXT ZONE frontmatter, body_notes TEXT)",
         ])
         .assert()
-        .success();
+        .success()
+        .stdout(predicate::str::contains("table note created"));
 
     let out = repo
         .ddb()
@@ -68,6 +69,11 @@ fn inline_zone_frontmatter_materializes_and_survives_reindex() {
         .assert()
         .success()
         .stdout(predicate::str::contains("summary: after reindex"));
+    repo.ddb()
+        .args(["query", "DROP TABLE note CASCADE"])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("dropped"));
 }
 
 /// PRD 00160 (blind review, Critical): two `CREATE TABLE` statements in a single
diff --git a/tests/e2e/link_kinds.rs b/tests/e2e/link_kinds.rs
index cbfad86..974479f 100644
--- a/tests/e2e/link_kinds.rs
+++ b/tests/e2e/link_kinds.rs
@@ -11,6 +11,10 @@ fn all_link_kinds_indexed() {
         .args(["create", "--title", "Wiki Target", "--body", "target"])
         .output()
         .unwrap();
+    assert!(
+        wiki_out.status.success(),
+        "fixture command failed: {wiki_out:?}"
+    );
     let wiki_id = String::from_utf8_lossy(&wiki_out.stdout).trim().to_string();
     std::thread::sleep(std::time::Duration::from_secs(1));
 
@@ -19,6 +23,10 @@ fn all_link_kinds_indexed() {
         .args(["create", "--title", "Embed Target", "--body", "embedded"])
         .output()
         .unwrap();
+    assert!(
+        embed_out.status.success(),
+        "fixture command failed: {embed_out:?}"
+    );
     let embed_id = String::from_utf8_lossy(&embed_out.stdout)
         .trim()
         .to_string();
@@ -36,6 +44,10 @@ fn all_link_kinds_indexed() {
         .args(["create", "--title", "Link Kinds Test", "--body", &body])
         .output()
         .unwrap();
+    assert!(
+        linker_out.status.success(),
+        "fixture command failed: {linker_out:?}"
+    );
     let linker_id = String::from_utf8_lossy(&linker_out.stdout)
         .trim()
         .to_string();
@@ -54,7 +66,7 @@ fn all_link_kinds_indexed() {
         ])
         .assert()
         .success()
-        .stdout(predicate::str::contains("url"))
+        .stdout(predicate::str::is_match(r"\burl\b").unwrap())
         .stdout(predicate::str::contains("embed"))
         .stdout(predicate::str::contains("markdown"))
         .stdout(predicate::str::contains("wikilink"));
diff --git a/tests/e2e/rename.rs b/tests/e2e/rename.rs
index ef76e49..2a06148 100644
--- a/tests/e2e/rename.rs
+++ b/tests/e2e/rename.rs
@@ -11,6 +11,7 @@ fn rename_moves_file_and_rewrites_backlinks() {
         .args(["create", "--title", "Target", "--body", "I am B."])
         .output()
         .unwrap();
+    assert!(b_out.status.success(), "fixture command failed: {b_out:?}");
     let b_id = String::from_utf8_lossy(&b_out.stdout).trim().to_string();
     std::thread::sleep(std::time::Duration::from_secs(1));
 
@@ -26,6 +27,7 @@ fn rename_moves_file_and_rewrites_backlinks() {
         ])
         .output()
         .unwrap();
+    assert!(a_out.status.success(), "fixture command failed: {a_out:?}");
     let a_id = String::from_utf8_lossy(&a_out.stdout).trim().to_string();
     std::thread::sleep(std::time::Duration::from_secs(1));
 
@@ -54,11 +56,15 @@ fn rename_moves_file_and_rewrites_backlinks() {
         .stdout(predicate::str::contains("2 backlinks updated"));
 
     // Verify B is at new path
-    assert!(repo.path().join(&new_path).exists());
+    assert!(repo.path().join(&new_path).is_file());
     assert!(!repo.path().join(format!("ddb/{b_id}.md")).exists());
 
     // Verify A's backlink was rewritten
     let a_content = repo.ddb().args(["read", &a_id]).output().unwrap();
+    assert!(
+        a_content.status.success(),
+        "fixture command failed: {a_content:?}"
+    );
     let a_text = String::from_utf8_lossy(&a_content.stdout);
     let new_target = format!("ddb/contact/{b_id}");
     assert!(
diff --git a/tests/e2e/search_links.rs b/tests/e2e/search_links.rs
index fb2af10..32789f7 100644
--- a/tests/e2e/search_links.rs
+++ b/tests/e2e/search_links.rs
@@ -4,7 +4,8 @@ use predicates::prelude::*;
 #[test]
 fn full_text_search() {
     let repo = DdbTestRepo::init();
-    repo.ddb()
+    let created = repo
+        .ddb()
         .args([
             "create",
             "--title",
@@ -14,6 +15,10 @@ fn full_text_search() {
         ])
         .assert()
         .success();
+    let id = String::from_utf8_lossy(&created.get_output().stdout)
+        .trim()
+        .to_owned();
+    assert!(!id.is_empty(), "search fixture must return an id");
     std::thread::sleep(std::time::Duration::from_secs(1));
     repo.ddb()
         .args([
@@ -32,6 +37,11 @@ fn full_text_search() {
         .success()
         .stdout(predicate::str::contains("Alpha"))
         .stdout(predicate::str::contains("Beta").not());
+    repo.ddb()
+        .args(["search", "Alpha"])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains(&id));
 }
 
 #[test]
@@ -48,6 +58,10 @@ fn wikilink_indexed_in_links_table() {
         ])
         .output()
         .unwrap();
+    assert!(
+        parent_out.status.success(),
+        "fixture command failed: {parent_out:?}"
+    );
     let parent_id = String::from_utf8_lossy(&parent_out.stdout)
         .trim()
         .to_string();
diff --git a/tests/e2e/sequence.rs b/tests/e2e/sequence.rs
index c8e194a..51d17a2 100644
--- a/tests/e2e/sequence.rs
+++ b/tests/e2e/sequence.rs
@@ -22,16 +22,21 @@ fn create_with_sequence(repo: &DdbTestRepo, title: &str, parent_id: &str) -> Str
     );
     std::fs::write(&doogat_path, &content).unwrap();
 
-    std::process::Command::new("git")
+    let added = std::process::Command::new("git")
         .args(["add", "."])
         .current_dir(repo.path())
         .output()
         .unwrap();
-    std::process::Command::new("git")
+    assert!(added.status.success(), "fixture git add failed: {added:?}");
+    let committed = std::process::Command::new("git")
         .args(["commit", "-m", "add sequence field"])
         .current_dir(repo.path())
         .output()
         .unwrap();
+    assert!(
+        committed.status.success(),
+        "fixture git commit failed: {committed:?}"
+    );
 
     id
 }
diff --git a/tests/e2e/set_flag.rs b/tests/e2e/set_flag.rs
index bd777bc..921aa50 100644
--- a/tests/e2e/set_flag.rs
+++ b/tests/e2e/set_flag.rs
@@ -54,6 +54,16 @@ fn update_set_adds_field() {
         .assert()
         .success()
         .stdout(predicate::str::contains("status: done"));
+    repo.ddb()
+        .args(["update", &id, "--set", "status=review"])
+        .assert()
+        .success();
+    repo.ddb()
+        .args(["read", &id])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("status: review"))
+        .stdout(predicate::str::contains("status: done").not());
 }
 
 #[test]
@@ -96,6 +106,10 @@ fn create_with_multiple_set_flags() {
         .unwrap();
     assert!(out.status.success());
     let id = String::from_utf8_lossy(&out.stdout).trim().to_string();
+    assert!(
+        id.len() == 14 && id.bytes().all(|byte| byte.is_ascii_digit()),
+        "--set create must return a 14-digit id: {id:?}"
+    );
 
     repo.ddb()
         .args(["read", &id])
diff --git a/tests/e2e/tags.rs b/tests/e2e/tags.rs
index 3196eef..ac4bf28 100644
--- a/tests/e2e/tags.rs
+++ b/tests/e2e/tags.rs
@@ -35,10 +35,15 @@ fn tag_count_group_by() {
 #[test]
 fn tag_join_filters_doogats() {
     let repo = DdbTestRepo::init();
-    repo.ddb()
+    let created = repo
+        .ddb()
         .args(["create", "--title", "HasRust", "--tags", "rust"])
         .assert()
         .success();
+    let id = String::from_utf8_lossy(&created.get_output().stdout)
+        .trim()
+        .to_owned();
+    assert!(!id.is_empty(), "tagged fixture must return an id");
     std::thread::sleep(std::time::Duration::from_secs(1));
     repo.ddb()
         .args(["create", "--title", "NoPython", "--tags", "python"])
@@ -55,12 +60,24 @@ fn tag_join_filters_doogats() {
         .success()
         .stdout(predicate::str::contains("HasRust"))
         .stdout(predicate::str::contains("NoPython").not());
+
+    repo.ddb()
+        .args([
+            "query",
+            "SELECT z.id, z.title FROM doogats z JOIN _ddb_tags t ON t.doogat_id = z.id WHERE t.tag LIKE '%rust%'",
+        ])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains(&id))
+        .stdout(predicate::str::contains("HasRust"))
+        .stdout(predicate::str::contains("NoPython").not());
 }
 
 #[test]
 fn body_hashtag_indexed_with_source() {
     let repo = DdbTestRepo::init();
-    repo.ddb()
+    let created = repo
+        .ddb()
         .args([
             "create",
             "--title",
@@ -72,6 +89,9 @@ fn body_hashtag_indexed_with_source() {
         ])
         .assert()
         .success();
+    let id = String::from_utf8_lossy(&created.get_output().stdout)
+        .trim()
+        .to_owned();
 
     // Both frontmatter and body tags should be present with correct source
     repo.ddb()
@@ -80,6 +100,25 @@ fn body_hashtag_indexed_with_source() {
         .success()
         .stdout(predicate::str::contains("body-tag"))
         .stdout(predicate::str::contains("frontmatter-tag"));
+
+    repo.ddb()
+        .args([
+            "update",
+            &id,
+            "--body",
+            "Updated with #gtd/act/next hashtag",
+        ])
+        .assert()
+        .success();
+    repo.ddb().arg("reindex").assert().success();
+    repo.ddb()
+        .args([
+            "query",
+            "SELECT tag, source FROM _ddb_tags WHERE tag = 'gtd/act/next'",
+        ])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("gtd/act/next | body"));
 }
 
 #[test]

```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Reviewed head: 36c0687; task's own range 75cde1c..36c0687. The prior unrelated 00202 commit is excluded.
cargo build -> exit 0; Finished dev profile in 37.23s.
cargo clippy --workspace --all-targets -> exit 0; Finished dev profile in 16.36s.
cargo test-ci -> exit 0; 42 CLI passed (1.55s), 1555 core passed (952.80s), 222 server passed (0.58s); all 0 failed / 0 ignored.
cargo test -p ddb-e2e --test e2e integration_ -> exit 0, twice: each 83 passed; 0 failed; 0 ignored; 482 filtered out; 16.04s and 15.34s.
cargo test -p ddb-e2e --test e2e -- smoke_ alter_column_type:: alter_table_rename:: bundle_import_conflict_recovery:: cascade_delete:: checkboxes:: cli_create_fk_freshness:: delete_backlinks:: discover:: fix:: folder_namespace:: hyphenated_types:: inline_zone:: junction_tables:: link_kinds:: multi_device:: pgwire:: reference_raw_id:: rename:: schema_apply:: search_in_filter:: search_links:: sequence:: serve:: server_mutations:: set_flag:: sql_expressions_test:: sql_lifecycle:: sync_crdt:: tags:: typed_field_mutations:: -> exit 0; 278 passed; 0 failed; 0 ignored; 287 filtered out; 33.66s.
Actual runner --list: 565 tests, 0 benchmarks. All 391 source mapping keys match four source inventories; all target tests or audited aliases resolve to registered runner names. Source assertions were compared separately, not inferred from runner discovery.
Independent Devon actually ran wrong CLI facades. Discarded updates were caught; body-to-title corruption survived, then was repaired with committed parsed field assertions and caught on replay. SQL INSERT value suffix corruption survived substring equality, then exact seed theme equality caught the same mutant on replay (4 passed, 1 failed, intentional exit101). All facades neutralized. No demonstrated surviving mutant remains.
Earlier real test failures from sync fixture setup and the new REST assertion were repaired; all targeted reruns are green. REST source checks the returned custom value anywhere in response, not core title.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


