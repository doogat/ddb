Portfolio freshness: NOT refreshed this cycle (PRD 00002 pending)

## Similar code

## Reuse precedent

- container-images:/Users/bob/git/src/github.com/buvis/container-images/apps/clara/backend/src/clara/jobs/git_sync.py:24-74
  def run_git_sync(config_id: str) -> None:
    """Full sync for one git sync config."""
    settings = get_settings()
    r = redis.Redis.from_url(str(settings.redis_url))
    lock_key = f"git_sync:{config_id}"
    lock = r.lock(lock_key, timeout=LOCK_TTL)

    if not lock.acquire(blocking=False):
        logger.info("git_sync_locked", config_id=config_id)
        return

    session = get_sync_session()
    repo: GitRepo | None = None
    try:
        config = session.get(GitSyncConfig, uuid.UUID(config_id))
        if config is None or config.deleted_at is not None or not config.enabled:
            return

        config.last_sync_status = "running"
        session.flush()

        work_dir = f"{settings.git_sync_work_dir}/{config_id}"
        repo = GitRepo(
            work_dir=work_dir,
            repo_url=config.repo_url,
            branch=config.branch,
            auth_type=config.auth_type,
            credential_encrypted=config.credential_encrypted,
        )

        counts = run_sync(session, config, repo)
        session.commit()
        logger.info("git_sync_complete", config_id=config_id, counts=counts)

    except Exception as exc:
        session.rollback()
        try:
            config = session.get(GitSyncConfig, uuid.UUID(config_id))
            if config:
                config.last_sync_status = "error"
                config.last_sync_error = str(exc)[:500]
                session.commit()
        except Exception:
            session.rollback()
        logger.exception("git_sync_failed", config_id=config_id)
    finally:
        if repo:
            repo.cleanup()
        session.close()
        with contextlib.suppress(Exception):
            lock.release()

## Findings precedent

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  - **[Bob] Docs overclaim fresh-index staging across all merge paths.** `git-ops.md`, `CHANGELOG.md`, and `sync.md` say the merge write path "stages the merge tree from `fresh_index()`", but only `commit_merge`'s `build_merge_tree_and_commit` uses `fresh_index()`; the normal 3-way merge (`perform_normal_merge`) stages from libgit2's merge index and fast-forward stages nothing. The lock covers all three; fresh-index staging is specific to the conflicted-merge tree. | File: docs/src/technical/git-ops.md, CHANGELOG.md, docs/src/technical/sync.md | **VERIFIED real** (diff inspection: only `merge.rs:32` swapped to `fresh_index()`).

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  - **[Bob] Bundle import merges via `git merge` subprocess outside the lock** → 00168.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-02.md
  | [1/5] | ⚪ Low | AGENTS.md I1 bullet points the remaining bundle-import lock gap at `git_ops/merge.rs`, but that file shells out nowhere (libgit2 in-process); the `git merge` subprocess lives in `bundle::merge_bundle_and_resolve` (`ddb-core/src/bundle.rs:118`). AGENTS.md now contradicts invariants.md and git-ops.md, which both correctly name `bundle::merge_bundle_and_resolve`. | AGENTS.md | Bob |

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-02.md
  **Orchestrator verification of the finding (CONFIRMED):** `rg` over `git_ops/merge.rs` shows no `Command::new`/`git merge` (all libgit2); `bundle.rs:118-126` spawns `git merge refs/remotes/bundle/master --no-edit --allow-unrelated-histories`. invariants.md I1 (line 14) and git-ops.md both already read `bundle::merge_bundle_and_resolve`. Only AGENTS.md carries the stale `git_ops/merge.rs` reference (perpetuated by D2-1's rewrite of that bullet). Single-site fix. → **cycle-3 auto-fix task [D3-1]**.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-02.md
  1. [D3] Fix AGENTS.md bundle-import module reference (S) — ⚪ Low — change `git_ops/merge.rs` → `bundle::merge_bundle_and_resolve` (`ddb-core/src/bundle.rs`) in the I1 data-safety invariant, matching invariants.md and git-ops.md.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-03.md
  ✅ No issues found. Verified `bundle::merge_bundle_and_resolve` (bundle.rs:113) spawns `git merge` at bundle.rs:118; `git_ops/merge.rs` has no `Command::new`/`git merge` (regex sanity-checked against a known-present term); AGENTS.md line 63 corrected and consistent with invariants.md:14 + git-ops.md:83.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00166-make-hlc-load-bearing-v1-review-01.md
  - **[1/3] 🟡 Medium — Layer-boundary: `HlcClock` is a field of `GitRepo`.** Blake (blind) flags that `HlcClock`, constructed in `GitRepo::init`/`open`, reads `.git/ddb-node` and owns `.git/ddb-hlc`, which he reads as contradicting the PRD Risk "git_ops should not own HLC/node state." **This is the accepted Alt-2 design**, reviewed across 3 design dispatches: `HlcClock` is a bare machine-local monotonic counter (NOT `NodeConfig`/node-registry state); it only reads local `.git/ddb-*` files and constructs no node state. The design explicitly argues this satisfies the guardrail, and the alternative (composing the trailer above `git_ops`) was rejected as the "partial fix" the PRD warns against. Not a rework item — recorded as an already-settled design decision. File: `ddb-core/src/git_ops/mod.rs`. Found by: Blake.

## Task prose

### Batch 202607161128 (autopilot, IN PROGRESS — started 2026-07-16)

- [x] **00163 git-tree-construction-correctness-v1** (DONE 2026-07-17, in `done/`) — delete-freshness + merge-lock legs of the git write-path data-loss class.
- [x] **00200 make-merge-tree-three-way-v1** (DONE 2026-07-18, in `done/`) — true three-way conflicted-merge tree (Alternative B), closing the last data-loss leg.
- [x] **00164 unify-id-minting-v1** (DONE 2026-07-18, in `done/`) — one repo-aware existence oracle for all mint paths.
- [x] **00165 deterministic-crdt-resolution-v1** (DONE 2026-07-18, in `done/`) — content-derived Automerge actor IDs, deterministic list-field ordering.
- [x] **00166 make-hlc-load-bearing-v1** (DONE 2026-07-19, in `done/`) — machine-local `HlcClock`, HLC trailer on every write, unified `lww_pick` tie-break.
- [x] **00167 sync-collision-reassignment-atomicity-v1** (DONE 2026-08-15, in `done/`) — folded winner + loser + backlink rewrites into one atomic `commit_merge`, loser ID derive

# Bundle-import conflict recovery

**Priority:** P1 · **Roadmap:** Phase 1 (convergence) · **Depends on:** 00162 (write lock — merge + resolve + ref-delete run inside the write critical section)

## Overview

### Problem Statement
A conflicted bundle import reports success while silently losing the imported data.

- **Conflict detection reads `stderr`, not state.** `merge_bundle_and_resolve` (`ddb-core/src/bundle.rs:113-138`) shells out to `git merge refs/remotes/bundle/master` (`:118-126`) and, on failure, decides conflict-vs-error by **string-matching `stderr`** for `"CONFLICT"` / `"Automatic merge failed"` (`:132-137`). This is locale- and version-fragile, and there is **no** `git merge --abort` anywhere.
- **A conflicted merge is reported as clean success.** A conflicted `git merge` creates **no commit**, so `resolve_post_merge_conflicts` (`sync_manager/mod.rs:883-887`) → `validate_clean_merge_or_fallback` sees `commit_parent_count < 2` (`:544`) and returns `Ok(0)`: the import re
