# FT-5 scope correction (approved 2026-09-13)

Baseline: clean master at `4fd60524ca3aed2ff633ee9716b14cd8fb19d035`, verified
2026-09-13. No stashes, one worktree. Process/cwd inspection found no foreign
CLI session in this checkout (other active sessions target other repos).

The original FT-5 card cannot compile as specified: `DoogatService<G, I>` uses
`G: GitBackend`, while `with_write_lock` is an inherent private `GitRepo`
method. Crate-private visibility alone does not make that method callable
on `G`. An expected-OID commit fallback would also require a backend hook.
Independent Opus preflight confirmed this; its proposal/log is retained in
`dev/local/tmp/FT-5-opus-preflight.{txt,log}`. No implementation was dispatched.

Maintainer approved this exception with "proceed" on 2026-09-13.

## Approved minimal exception

1. Add one **required** generic closure method to `GitBackend` in
   `ddb-core/src/traits.rs`, preserving object safety with `Self: Sized`:

   ```rust
   fn with_write_lock<T>(&self, f: impl FnOnce() -> Result<T>) -> Result<T>
   where
       Self: Sized;
   ```

   It must share exclusion and reentrancy with that backend's commit paths.
   No unlocked default: silently inheriting one would preserve the hazard.
   Current repo search found one `GitBackend` implementation, for `GitRepo`.
   External implementors must supply the method; document that source-level
   compatibility impact. This adds no client concurrency API or wire change.

2. Extend `git_ops/mod.rs`'s permitted edits beyond visibility: implement the
   trait hook through the existing lock, and defer single-file commit-graph /
   threshold maintenance until the outermost Git lock is released. Existing
   `commit_file -> commit_files` runs both under the lock today, conflicting
   with the card's explicit no-subprocess-under-lock constraint. Preserve
   maintenance configuration, counters, suppression flags and error semantics.

3. Permit matching lock/compatibility documentation in
   `docs/src/technical/git-ops.md` and CHANGELOG. If the final helper changes
   documented data flow, update the relevant paragraph in
   `docs/src/technical/walkthrough.md` as mandated by project instructions.

Original runtime scope otherwise remains single-row field update in
`service/update.rs`, with colocated fail-first regressions. The hazard test
may only lose its ignore attribute; every existing assertion stays intact.
Batch/SQL update rewrites, raw replacement semantics, mint-path changes,
00206, and all other fast-track items stay outside this task.

## Requirements retained for implementation/review

- SQLite outer, Git inner; never enter an index rebuild or subprocess while
  holding the Git write lock.
- The authoritative read, field merge, validation and commit form one locked
  operation. Preserve the current freshness warnings and validation behavior.
- A concurrent type/schema change must not silently reuse stale transaction
  requirements. Re-derive under the lock or refuse before the commit.
- Judge success using committed Git content; keep post-commit index semantics
  explicit. Do not claim arbitrary current HEAD as the update's commit.
- No downcast, concrete backend construction in the service, second lock
  protocol, or broad lock redesign.

## Required gates (driver, sequential foreground; retain logs)

- `cargo +1.89.0 build`
- `cargo +1.89.0 clippy --workspace --all-targets -- -D warnings`
- `cargo +1.89.0 test-ci`
- `cargo +1.89.0 test -p ddb-core --lib service`
- `cargo +1.89.0 build -p ddb-cli`
- `cargo +1.89.0 test -p ddb-e2e --test e2e hazard_concurrent_single_row_update`
- `cargo +1.89.0 test -p ddb-e2e --test e2e integration_write_lock_races`
- Pinned rustfmt on touched files only, docs build for changed docs, diff check.

Before push, the plan's batch-end full e2e gate also applies. No full-workspace
heavy battery substitutes for these checks. Build session ends with a fresh
review handoff; complete isolated roster and closure precede commit/push.

## Unresolved questions

None. Proceed within the approved scope; D2 remains settled.
