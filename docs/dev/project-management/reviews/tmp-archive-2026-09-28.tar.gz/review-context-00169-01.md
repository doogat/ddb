# Review Context

## Completed Tasks

# Completed tasks — PRD 00169 poison-file-reindex-resilience-v1

14 tasks, all `completed`. Diff range under review: `6bb16174fd533b94db0f45016019aa4626b5a16e..f00c4839c1a10391f1355c5a01bb3d5f3c376c14`.

One row per task. Where two tasks share a commit, the shared SHA and the companion task ids are named in the row.

## Task 1 — Add `ConsistencyWarning::UnreadableFile` variant
- Implementor: claude/sonnet. Commits: folded into the task-2 range (no standalone impl commit; variant added ahead of its first consumer).
- Files: `ddb-core/src/types/schema.rs`.
- Acceptance: variant compiles; existing `MalformedYaml` matches unaffected.
- Note: no test authored. The enum derives only `Debug + Clone` (no serde, no `PartialEq`) and nothing constructed the new variant yet, so a test would have been a tautology. Behavioral coverage lands in task 2's read-fail case. The compiler was the gate.

## Task 2 — Make incremental indexing collect-and-skip per-file failures with a strict opt-in
- Implementor: claude/sonnet. Commits: `c972c79` (tests, 11 tests), impl in the same range.
- Files: `ddb-core/src/indexer/rebuild.rs` (+ call-site updates).
- Acceptance: a change-set with one malformed and two valid files indexes the two valid files and returns two survivors + one warning naming the bad path; `strict=true` returns a `DoogatError`; unit tests cover read-fail, parse-fail, strict, all-good.
- Known residual: ~30 lines of duplicated read/parse/strict logic between the two `batch_index_changes` branches, deliberately not extracted (refactor, out of scope).

## Task 3 — Generalize the write-lock helper to take an explicit lock directory and file name
- Implementor: qwen (local model), reviewed by pat. Commits: `fde545b` (tests), `f9c1e26` (impl), `71e718d` (comment cleanup).
- Files: `ddb-core/src/git_ops/write_lock.rs`, `ddb-core/src/git_ops/mod.rs` (visibility `pub(crate) mod write_lock;` + call site), `ddb-core/src/git_ops/tests.rs` (2 callers).
- Acceptance: two handles serialize; the guard releases on drop; the lock-ordering rule vs the git write lock is written down in the module doc.

## Task 4 — Add the ConsistencyWarning → AppWarning summarizing helpers in app_contract
- Implementor: claude/sonnet. Commits: `ef2165c` (tests), `5cd6df2` (impl).
- Files: `ddb-core/src/app_contract/output.rs`, `ddb-core/src/app_contract/mod.rs` (re-export line).
- Acceptance: each variant maps to a stable `code` + human `message`; unit-tested with exact string pins for the four warning codes.
- Orchestrator design-gap fix folded in: `mod output;` is private, so the re-export had to carry `summarize_reindex_warnings` and `REINDEX_SKIPPED_FILES` too, not only the two `describe_*` helpers the design named — otherwise task 5 would not compile.

## Task 5 — Capture reindex warnings in `ensure_fresh` and merge them into the three AppOutput facades
- Implementor: codex. Commits: `7d72015` (tests), `085f096` (impl + CHANGELOG).
- Files: `ddb-core/src/service/mod.rs`, `service/create.rs`, `service/update.rs`, `service/schema_apply.rs`, `ddb-cli/src/commands/crud.rs`.
- Acceptance: after a poison file lands, a create AND a search both succeed and each carries a skip `AppWarning`; the warning reaches CLI stderr and the GraphQL warnings extension.
- Deleted an existing code path: the redundant `svc.rebuild_if_stale()?;` pre-call in `ddb-cli/src/commands/crud.rs` `create`. `cargo test -p ddb-e2e` ran per CLAUDE.md: 449/449.

## Task 6 — Add a `warnings` field to the FFI RebuildReport record
- Implementor: claude/sonnet. Commits: `153c405` (tests), `48b9925` (impl + CHANGELOG).
- Files: `ddb-core/src/ffi/records.rs`, `ddb-core/src/ffi/driver.rs`, `ddb-core/src/app_contract/mod.rs` (a `#[cfg(test)]` gate on the `REINDEX_SKIPPED_FILES` re-export), + 2 more.
- Acceptance: the FFI reindex report exposes the skip as `RebuildWarningRecord { code, message }`.
- Recorded observation: every unparseable file is reported TWICE by `rebuild()` — once from `parallel_parse` (`rebuild.rs:444`), once from `collect_consistency_warnings` (`materialize.rs:598`). Pre-existing; became user-visible in task 9.

## Task 7 — Serialize the destructive full-rebuild path behind a cross-process rebuild lock
- Implementor: claude/opus. Commits: `f0f53e4` (tests, 8 tests, prior session), `f408c30` (impl + CHANGELOG), `08ed093` (deslop).
- Files: `ddb-core/src/indexer/rebuild.rs`, `ddb-core/src/indexer/mod.rs`, `ddb-core/src/traits.rs`, `ddb-core/src/indexer/ports.rs`, `ddb-core/src/service/search.rs`, `ddb-core/src/service/mock_index_tests.rs`.
- Acceptance: concurrent cold-start coverage passes; a waiter that blocked behind another process's rebuild finds a fresh index and does not drop tables; lock timeout is a structured `Err(Conflict)`, never a panic; no behavior change on the warm incremental path.
- Allowlist widened 4→7 mid-task: `DoogatService::reindex` reaches the index through a generic `I: IndexPort`, so `locked_rebuild` had to become a REQUIRED `IndexPort` trait method with no default body.
- Recorded residual: `configure_connection`'s `needs_schema_upgrade` branch was still an unlocked destructive path at this point (closed by task 8).

## Task 8 — Stamp and check an index schema version via `PRAGMA user_version`
- Implementor: claude/sonnet. Commits: `6bc2cde` (tests), `bc328dd` (impl + CHANGELOG), `0537b18` (CRITICAL fix), `9df1643` (doc note).
- Files: `ddb-core/src/indexer/mod.rs` (+ tests).
- Acceptance: opening an index stamped with an older version triggers exactly one locked drop-rebuild; a current version triggers none.
- CRITICAL found by the per-task reviewer and fixed in `0537b18`: the rebuild-lock guard was originally scoped INSIDE the `if needs_drop` block, releasing before the recreate, leaving a window where the DB has no tables and still carries its old version. The guard now binds at function scope (`None` when no upgrade is needed) and lives across drop + recreate + stamp.
- **UNMET FAIL-FIRST OBLIGATION, flagged deliberately**: that CRITICAL shipped WITHOUT a regression test. All 244 tests passed both before and after the fix. Settled in task 14 as an ACCEPTED GAP; the argument is recorded in `dev/local/assumptions.md` and in a comment at `ddb-core/src/indexer/mod.rs:190-210`. This is the weakest load-bearing claim in the PRD.

## Task 9 — Add a `--strict` flag to the `ddb reindex` command
- Implementor: claude/sonnet. Commits: `c255d4d` (tests, 7 tests), `e5ec64a` (impl + CHANGELOG, 9 files).
- Files: `ddb-core/src/indexer/rebuild.rs`, `indexer/mod.rs`, `traits.rs`, `indexer/ports.rs`, `service/search.rs`, `service/mock_index_tests.rs`, `ddb-cli/src/main.rs`, `ddb-cli/src/commands/maintenance.rs`, CHANGELOG.
- Acceptance: strict hard-fails naming the file; lenient exits 0 with a warning count.
- CONFIRMED REGRESSION found and fixed here: task 7 had routed `DoogatService::reindex` through `locked_rebuild`, whose post-lock re-check short-circuits, so explicit `ddb reindex` had become a no-op printing "indexed 0 doogats". Fixed by adding `locked_explicit_rebuild(repo, strict)` (same lock, unconditional rebuild) as a second REQUIRED `IndexPort` method.
- `rebuild` was REORDERED so `list_doogats` + `parallel_parse` run BEFORE `drop_all_tables`, so a strict abort cannot wipe the index first.
- Recorded residual: the `--strict` CLI flag has NO committed automated test in this task; its coverage is task 11 (smoke) + task 14 (e2e).

## Task 10 — Cap frontmatter size at the parse boundary
- Implementor: qwen (local model), reviewed by pat. Commits: `38577e7` (tests, 5 tests), `7d28653` (impl, 14 lines), `b1bc2ed` (review fix).
- Files: `ddb-core/src/parser/mod.rs`, `ddb-core/src/indexer/tests/*`.
- Acceptance: an over-cap frontmatter block is skipped with a warning naming path + reason; normal files unaffected; `--strict` hard-fails it.
- `MAX_FRONTMATTER_BYTES = 256 * 1024`, module-private, strict `>` so exactly-at-cap parses, `yaml.len()` bytes.
- Recorded residual: the cap bounds `serde_yaml` PARSE cost but not the READ — `split_zones` has already pulled the whole file into memory before `parse_frontmatter` can reject it. Whether the PRD line "reindex cost stays bounded" is satisfied by a parse-cost bound alone was NOT decided.

## Task 11 — Document the poison-file skip and `--strict` behavior and add the smoke scenarios
- Implementor: codex. Commits: `ac3cb22` (docs + smoke, 4 files), `865f682` (doc correctness fixes), `886ea27` (errexit fix).
- Files: `docs/src/technical/indexer.md`, `tests/smoke.sh`, `tests/smoke.ps1`, CHANGELOG.
- Acceptance: docs match; scenarios authored and green locally under Tier 1. `tests/smoke.sh` was run END TO END twice locally, both reaching "all smoke tests passed".
- TWO FALSE-PASS ASSERTIONS found and fixed: (1) an assertion labelled "strict reindex failure preserves the existing index" could not fail, because `ddb query` routes through `execute_sql` → `ensure_fresh` and would silently rebuild a dropped index before answering; relabelled with a NOTE naming the unit test that does bind the strong property. (2) `! $DDB reindex --strict` under `set -euo pipefail`: bash exempts a `!`-inverted command from errexit, so a `--strict` regressed to lenient would not stop the script and the following grep would still match. Fixed by capturing the exit code explicitly.
- `tests/smoke.ps1` was NOT executed (no PowerShell on this host).
- Carried: `tests/smoke.sh` still uses the bare `! $DDB ...` idiom in several PRE-EXISTING sections, same errexit exemption, same false-pass risk. Left alone under the surgical-changes rule.

## Task 12 — Add the poison-file GraphQL integration scenario to `tests/integration.sh`
- Implementor: qwen (attempt 1, FAILED the gate), escalated to claude/sonnet fix-forward (attempt 2). Commit: `c2b375a`.
- Files: `tests/integration.sh` (section 63, lines ~3746-3801).
- qwen's failure: sent `createDoogat` an unregistered `type: "doogat"`, so the mutation returned `TYPE_NOT_REGISTERED` and the assertion never reached the warning.
- Verified GREEN independently by the orchestrator: section 63 extracted into a standalone harness and run against a real `ddb` binary and a real server; the server logged the malformed-file skip and the jq assertion on `extensions.warnings` passed. `bash -n` parses clean.

## Task 13 — Add the matching poison-file GraphQL scenario to `tests/integration.ps1`
- Implementor: qwen, first dispatch clean. Commits: `d743027`, `33a235d` (two MEDIUM review fixes).
- Files: `tests/integration.ps1` (section 63).
- **NEVER EXECUTED** — no `pwsh` on this host. Checks available were bash-parity by line-for-line comparison and PowerShell correctness by inspection. Windows CI is its first real run.
- Two MEDIUMs applied: an inline `byte[]` conversion duplicating the file's own `content` helper; an unguarded `Remove-Item` on a temp dir that had hosted a live server under a file-wide `$ErrorActionPreference = Stop`.

## Task 14 — Author the poison-file and concurrent cold-start e2e coverage and record the rebuild-lock invariant
- Implementor: claude/opus. Commits: `f3c42c0` (e2e), `1fd4c6f` (invariants doc), `c3619ba` (deslop), `92e15f7` (name/doc correction), `f00c483` (review fix).
- Files: `tests/e2e/poison_file_reindex.rs` (new), `tests/e2e/concurrent_writes.rs` (warm-up removed), `tests/e2e/main.rs`, `docs/src/technical/invariants.md` (I5 GAP→HOLDS, new I10 rebuild-lock invariant).
- Acceptance: the e2e fails against pre-change code and passes after; the warm-up is gone; the invariants page lists the rebuild lock and its ordering rule.
- Fail-first evidence WAS established: the implementor temporarily neutered the rebuild lock in a scratch edit (since reverted), and the cold-start scenario then failed with `no such table: _ddb_boost` on roughly 1 run in 3. Documented in the test's doc comment.
- Deslop deleted the newly-added cold-start test as a strict duplicate of the (now warm-up-free) original; the survivor was then renamed and its doc rewritten in `92e15f7` because it still claimed to measure "only the write-lock guarantee".
- One HIGH from the per-task reviewer, fixed in `f00c483`: the lenient test's closing `ddb query` read-back could not fail, because `execute_sql` calls `ensure_fresh` and would rebuild a stale index before answering. Removed, replaced by a comment recording the hazard.

## Code Changes

### Changed Files
_Diff scope: incremental review (changes since 6bb16174fd533b94db0f45016019aa4626b5a16e)_

```
 CHANGELOG.md                                    |   10 +
 ddb-cli/src/commands/crud.rs                    |   11 -
 ddb-cli/src/commands/maintenance.rs             |    4 +-
 ddb-cli/src/commands/mod.rs                     |    2 +-
 ddb-cli/src/main.rs                             |    6 +-
 ddb-core/benches/search.rs                      |    4 +-
 ddb-core/src/app_contract/mod.rs                |    5 +
 ddb-core/src/app_contract/output.rs             |  211 +++
 ddb-core/src/ddb.udl                            |    6 +
 ddb-core/src/ffi/driver.rs                      |   11 +-
 ddb-core/src/ffi/mod.rs                         |    4 +-
 ddb-core/src/ffi/records.rs                     |    8 +
 ddb-core/src/ffi/tests.rs                       |  118 ++
 ddb-core/src/git_ops/mod.rs                     |    4 +-
 ddb-core/src/git_ops/tests.rs                   |   14 +-
 ddb-core/src/git_ops/write_lock.rs              |  114 +-
 ddb-core/src/indexer/mod.rs                     |  134 +-
 ddb-core/src/indexer/ports.rs                   |   15 +
 ddb-core/src/indexer/rebuild.rs                 |  218 ++-
 ddb-core/src/indexer/tests/materialize_tests.rs |   12 +-
 ddb-core/src/indexer/tests/mod.rs               | 1851 ++++++++++++++++++++++-
 ddb-core/src/parser/mod.rs                      |   13 +
 ddb-core/src/parser/tests.rs                    |   50 +
 ddb-core/src/service/create.rs                  |   13 +-
 ddb-core/src/service/mock_index_tests.rs        |  305 +++-
 ddb-core/src/service/mod.rs                     |    9 +-
 ddb-core/src/service/schema_apply.rs            |    9 +-
 ddb-core/src/service/search.rs                  |    6 +-
 ddb-core/src/service/update.rs                  |   13 +-
 ddb-core/src/traits.rs                          |   16 +
 ddb-core/src/types/schema.rs                    |    4 +
 docs/src/technical/indexer.md                   |   28 +-
 docs/src/technical/invariants.md                |   13 +-
 docs/src/technical/parser.md                    |    6 +
 tests/e2e/concurrent_writes.rs                  |   63 +-
 tests/e2e/main.rs                               |    1 +
 tests/e2e/poison_file_reindex.rs                |  138 ++
 tests/integration.ps1                           |   77 +
 tests/integration.sh                            |   57 +
 tests/smoke.ps1                                 |   32 +
 tests/smoke.sh                                  |   30 +
 41 files changed, 3484 insertions(+), 161 deletions(-)
```

### Diff Content
Full diff available at: /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00169-01.diff

(4534 lines)

## PRD Requirements

# PRD: Indexer rebuild resilience: poison-file skip and serialized cold-start rebuild

Source: `dev/local/prds/wip/00169-poison-file-reindex-resilience-v1.md`

**Priority:** P1 (availability) · **Roadmap:** Phase 1 (availability) · **Depends on:** none (00162 write-lock helper shipped)

> **Merge note (2026-07-13, backlog review):** absorbed 00169b `serialize-cold-start-index-rebuild` — one PRD now owns indexer rebuild resilience: the lenient incremental path (poison files) AND the serialized destructive full-rebuild path (concurrent cold starts).

> **Provenance:** the index schema-version stamp and the frontmatter-size cap were added by the 2026-07-16 assessment (evidence: evolution-assessment-2026-07-16.md L2/L3) and folded into the body's Features/tasks at the 2026-08-14 backlog review. Probe location re-verified at `d77ad58`: `needs_schema_upgrade` at `indexer/mod.rs:159-180`.

## Overview

### Problem Statement
One malformed markdown file makes the whole database unusable through the service. The incremental reindex path is fatal on the first unreadable/unparsable file, and that path gates almost every read and write:

- **The hot path aborts the whole batch**: `batch_index_changes` (`ddb-core/src/indexer/rebuild.rs:176-198`) does `let content = content_result?;` (`:185`) then `crate::parser::parse(&content, &path)?` (`:186`); the single-file branch propagates the same way (`:191-192`). A single bad file aborts the entire change-set, so the *other* valid files changed in that same sync are also not indexed.
- **The full-rebuild path is already lenient — the hot path is the inconsistent one**: `parallel_parse` (`ddb-core/src/indexer/rebuild.rs:320-357`) is documented "Parse errors are collected, not propagated — one bad doogat doesn't block the rest" (`:322-323`) and partitions failures into `ConsistencyWarning::MalformedYaml` (`:349-353`). Full `rebuild` extends `report.warnings` from it (`:375-376`). Only the incremental path is fatal.
- **The fatal path gates ~40 entry points**: `incremental_reindex` calls `batch_index_changes(...)?` (`:118`), reached from `rebuild_if_stale` (`:420-452`, incremental branch `:443`), reached from `ensure_fresh` (`ddb-core/src/service/mod.rs:116-119`). `ensure_fresh` runs at the top of every public verb module (search / read / create / update / delete / sql / discovery / batch / utility / schema_apply). So one stray file turns every read AND write into an error until a manual full rebuild.
- **The parser is strict on user-editable input**: `parse_frontmatter` rejects missing delimiters (`ddb-core/src/parser/mod.rs:184,190`) and malformed YAML via `serde_yaml::from_str(yaml)?` (`:220`). Users edit `.md` files with other tools and sync brings untrusted content, so malformed input is expected, not exceptional.
- **This violates the AGENTS.md guardrail**: "User-facing read/write/list paths must not silently drop rows, schemas, or parse failures; return errors or structured warnings." Today the path neither indexes the good files nor returns a structured warning — it hard-fails the whole verb.

Note: `ensure_fresh` (`:118`) already discards the `Option<RebuildReport>` returned by `rebuild_if_stale`, so even the lenient full-rebuild warnings never reach a caller today.

A second, independent availability gap sits on the **destructive full-rebuild path**: concurrent writers on a cold repo (no stored HEAD in `_ddb_meta`) each take the destructive branch of `rebuild_if_stale` (`rebuild.rs:449-451` → `rebuild` → `drop_all_tables()` at `:368` + FTS recreation `:369`). Nothing serializes this across processes, so concurrent cold starts stomp on each other's FTS bootstrap and fail with `sql: no such table: _ddb_fts` / `_ddb_boost`. Found while writing the PRD 00162 concurrent-write e2e (8 concurrent `ddb create` on a cold repo); the 00162 git write lock serializes git commits, not the SQLite rebuild. Not data loss — the index is a derived, rebuildable cache — but concurrent cold starts can error. The 00162 e2e currently masks it by warming the index with one sequential create before going concurrent (`tests/e2e/concurrent_writes.rs:102-117`).

The net-new quarantine/index-health *listing* surface (a `ddb doctor` listing, a GraphQL `indexHealth` query, a REST endpoint, and an FFI method) is a follow-up owned by **00181**; this PRD delivers the core lenient-skip behavior, surfaces it on the triggering verb, and serializes the destructive rebuild.

### Target Users
Downstream apps (jink) whose backend syncs untrusted, externally-edited `.md` content; a single bad synced file must not brick reads and writes. Also any deployment where a fresh clone is hit concurrently (serve + CLI): cold starts must not error on FTS bootstrap.

### Success Metrics
- One malformed `.md` in an incremental change-set: the other changed files still index; the bad file is skipped, not fatal; a structured warning names the bad file and reason.
- Subsequent reads AND writes succeed after a poison file lands (no manual full rebuild required to unblock the service).
- The skip warning surfaces on the triggering verb through the existing `AppWarning` channel, asserted present on at least CLI + GraphQL.
- An explicit `--strict` mode preserves the old hard-fail behavior for callers that want it.
- The FFI `RebuildReport` record carries a `warnings` field so FFI callers see the skip.
- N concurrent `ddb create` processes on a cold repo (no stored HEAD) all succeed: zero `no such table: _ddb_fts` / `_ddb_boost` errors; final index row count matches git.
- Double-checked rebuild: a waiter that blocked behind another process's rebuild finds a fresh index and returns without dropping tables; lock acquisition failure/timeout surfaces as a structured error, never a panic.
- The 00162 concurrent-write e2e's warm-up workaround is removed (or demoted to a comment), so that scenario also exercises the cold path.
- An index stamped with an older schema version drop-rebuilds exactly once (version-triggered, under the rebuild lock); a current version never does.
- An oversized frontmatter block degrades into the standard skip warning; reindex cost stays bounded.
- No regression: existing incremental-reindex, full-rebuild, and `AppWarning` tests stay green; no behavior change on the warm incremental path.

## Functional Decomposition

### Capability: Lenient incremental indexing
#### Feature: Collect-and-skip per-file failures
- **Description**: `batch_index_changes` collects per-file read/parse failures into the `RebuildReport` warning list and skips the bad file instead of aborting the batch, matching `parallel_parse`.
- **Inputs**: the change-set paths; the batch read results (`Vec<(path, Result<content>)>`).
- **Outputs**: `(indexed_count, Vec<ParsedDoogat>)` for the good files plus a `Vec<ConsistencyWarning>` for the skipped ones.
- **Behavior**: iterate results; on a read error emit `ConsistencyWarning::UnreadableFile`, on a parse error emit `ConsistencyWarning::MalformedYaml`; push both onto the report; continue with the remaining files; index the survivors.

#### Feature: Strict-mode opt-in
- **Description**: an explicit strict flag restores the hard-fail behavior (first read/parse error aborts).
- **Inputs**: a `strict: bool` on the reindex entry point + a `--strict` CLI flag on `reindex`.
- **Outputs**: on a bad file under strict mode, a `DoogatError` (unchanged old behavior); otherwise collect-and-skip.
- **Behavior**: thread `strict` into `incremental_reindex`/`batch_index_changes`; default is lenient.

### Capability: Skip surfacing on verbs
#### Feature: Warnings ride the verb output
- **Description**: when `ensure_fresh` skips files, the triggering read/write verb returns a structured warning rather than silently continuing.
- **Inputs**: the `RebuildReport` now captured from `rebuild_if_stale`.
- **Outputs**: one or more `AppWarning`s merged into the verb's `AppOutput.warnings`; the FFI `RebuildReport` record gains a `warnings` field.
- **Behavior**: `ensure_fresh` captures the report; map `ConsistencyWarning → AppWarning` (new `From` impl); the app-contract facade merges the skip warnings into the result envelope so the existing per-transport channels forward them.

### Capability: Serialized cold-start rebuild
#### Feature: Cross-process rebuild lock
- **Description**: the destructive full-rebuild path holds a repo-scoped cross-process advisory lock, reusing the lock pattern shipped in 00162 (`ddb-core/src/git_ops/write_lock.rs::acquire(repo_root, timeout)` → RAII guard).
- **Inputs**: the repo root; a rebuild-lock timeout.
- **Outputs**: at most one process executing `drop_all_tables()` + FTS bootstrap at a time; a structured error (never a panic) on acquisition timeout.
- **Behavior**: design decides whether to generalize the existing helper (parameterized lock-file name) or add a sibling index-rebuild lock, and fixes the lock-ordering rule relative to the git write lock so the two can never deadlock. The same guard covers concurrent explicit full-rebuild invocations (`ddb reindex`-style maintenance) — same code path, confirm rather than build.

#### Feature: Double-checked locked rebuild
- **Description**: after acquiring the lock, re-check staleness/integrity before dropping tables; waiters must not redo a rebuild another process just completed.
- **Inputs**: the post-acquisition staleness/integrity state.
- **Outputs**: a fresh index served without a second destructive rebuild; public API unchanged (`rebuild_if_stale()`, `rebuild()` signatures unchanged).
- **Behavior**: acquire → re-verify the rebuild is still needed → rebuild only if still stale/broken → release. Optionally trace/log when a process waits on the rebuild lock, for support diagnostics.

### Capability: Rebuild-adjacent guards
#### Feature: Index schema-version stamp
- **Description**: the index carries a schema version; a mismatch triggers the drop-rebuild path instead of running new `SCHEMA_DDL` code against an old DB.
- **Inputs**: a `SCHEMA_VERSION` constant; the stored version (`PRAGMA user_version` or a `_ddb_meta` key).
- **Outputs**: version-triggered drop-rebuild; the ad-hoc FTS-column probe (`needs_schema_upgrade`, `indexer/mod.rs:159-180`) retired or demoted to a fallback.
- **Behavior**: stamp on every rebuild; compare at connection/configure; mismatch takes the locked destructive-rebuild path (this PRD's rebuild lock), so upgrades and cold starts share one owner.

#### Feature: Frontmatter size cap at the parse boundary
- **Description**: one huge or adversarial synced file cannot blow reindex cost; parse cost is bounded before YAML runs.
- **Inputs**: a generous frontmatter byte-size cap (constant).
- **Outputs**: an over-cap file degrades into the same per-file skip warning path — never fatal, consistent with this PRD's lenient core.
- **Behavior**: check the frontmatter block size before `serde_yaml` parses it; over-cap emits a `ConsistencyWarning` and skips; `--strict` hard-fails it like other poison files.

## Structural Decomposition

### Repository Structure

```
ddb-core/src/indexer/
├── rebuild.rs           # Maps to: Collect-and-skip per-file failures; Strict-mode opt-in; Double-checked locked rebuild (rebuild_if_stale/rebuild take the lock)
├── mod.rs               # Maps to: Index schema-version stamp (retire/demote needs_schema_upgrade :159-180)
ddb-core/src/parser/
└── mod.rs               # Maps to: Frontmatter size cap (checked before serde_yaml parse)
ddb-core/src/git_ops/
└── write_lock.rs        # Maps to: Cross-process rebuild lock (generalize the 00162 helper or add a sibling lock file; lock ordering documented)
ddb-core/src/types/
└── schema.rs            # Maps to: ConsistencyWarning::UnreadableFile variant
ddb-core/src/service/
└── mod.rs               # Maps to: Warnings ride the verb output (ensure_fresh captures report)
ddb-core/src/app_contract/
└── output.rs            # Maps to: ConsistencyWarning → AppWarning mapping
ddb-core/src/ffi/
└── records.rs           # Maps to: FFI RebuildReport gains a warnings field (:173-177)
ddb-cli/src/commands/
└── maintenance.rs       # Maps to: reindex --strict flag
tests/e2e/
└── concurrent_writes.rs # Maps to: cold-start e2e; warm-up workaround removal (:102-117)
```

### Module: rebuild (ddb-core/src/indexer/rebuild.rs)
- **Maps to capability**: Lenient incremental indexing; Serialized cold-start rebuild
- **Responsibility**: collect-and-skip per-file failures in the incremental batch; thread `strict`; take the rebuild lock around the destructive full-rebuild path with a post-acquisition re-check.
- **Exports**:
  - `batch_index_changes(...)` - now returns survivors + collected warnings
  - `incremental_reindex(...)` / `rebuild_if_stale(...)` / `rebuild(...)` - warnings propagated into `RebuildReport`; destructive path lock-guarded; signatures unchanged

### Module: write_lock (ddb-core/src/git_ops/write_lock.rs)
- **Maps to capability**: Serialized cold-start rebuild
- **Responsibility**: repo-scoped advisory file lock with timeout and RAII guard; extended/reused for the index-rebuild lock file.
- **Exports**: `acquire()` (existing), plus whatever parameterization design lands on

### Module: service (ddb-core/src/service/mod.rs)
- **Maps to capability**: Skip surfacing on verbs
- **Responsibility**: capture the reindex report in `ensure_fresh` and merge skip warnings into the verb envelope.
- **Exports**: `ensure_fresh(...)` - returns captured skip warnings for the facade to merge

### Module: app_contract (ddb-core/src/app_contract/output.rs)
- **Maps to capability**: Skip surfacing on verbs
- **Responsibility**: adapter-neutral mapping from `ConsistencyWarning` to `AppWarning`.
- **Exports**: `From<ConsistencyWarning> for AppWarning` (stable `code`, human `message`)

## Dependency Graph

### Foundation Layer (Phase 0)
No dependencies - built first.

- **rebuild (collect-and-skip + strict)**: makes the incremental path non-fatal; independent.
- **schema (UnreadableFile variant)**: additive enum variant the skip path needs.
- **rebuild-lock helper**: extends the shipped 00162 `write_lock.rs`; independent of the leniency work.

### Core Layer (Phase 1)
- **app_contract mapping + ensure_fresh capture + FFI warnings field**: Depends on [rebuild, schema] - surfaces the collected warnings on the verb envelope and the FFI record.
- **locked destructive rebuild**: Depends on [rebuild-lock helper] - wraps `rebuild_if_stale`/`rebuild` with double-checked re-check.
- **rebuild-adjacent guards (schema-version stamp + frontmatter cap)**: Depend on [rebuild, rebuild-lock helper] - the stamp reuses the locked destructive path; the cap feeds the skip warning path.

### Integration Layer (Phase 2)
- **docs + scenarios + e2e**: Depends on [rebuild, service, locked destructive rebuild].

## Implementation Phases

### Phase 0: Foundation
**Goal**: make the incremental path lenient like the full path; a rebuild lock exists.

**Tasks**:
- [ ] Add `ConsistencyWarning::UnreadableFile { path, error }` to `ddb-core/src/types/schema.rs` (no deps) - Acceptance: variant compiles; existing `MalformedYaml` matches unaffected.
- [ ] Make `batch_index_changes` collect-and-skip read/parse failures into the report and thread a `strict` flag through `incremental_reindex` (depends on: UnreadableFile) - Acceptance: a change-set with one malformed and two valid files indexes the two valid files and returns two survivors + one warning naming the bad path; under `strict=true` the same input returns a `DoogatError`; pure-indexer unit tests cover read-fail, parse-fail, strict, and all-good.
- [ ] Extend/reuse the 00162 lock helper (`git_ops/write_lock.rs`) for an index-rebuild lock file; define and document the lock-ordering rule vs the git write lock (no deps) - Acceptance: a unit test proves two handles serialize and the guard releases on drop; the ordering rule is written down (module doc).

**Exit Criteria**: incremental reindex skips bad files and reports them; strict mode preserved; a rebuild lock helper exists with a documented ordering rule; unit-tested.

### Phase 1: Core
**Goal**: surface the skips on the triggering read/write verbs and the FFI record; serialize the destructive rebuild.

**Tasks**:
- [ ] Add `From<ConsistencyWarning> for AppWarning` in `ddb-core/src/app_contract/output.rs` (depends on: Phase 0) - Acceptance: each variant maps to a stable `code` + human `message`; unit-tested.
- [ ] Capture the `RebuildReport` in `ensure_fresh` and merge its skip warnings into the verb `AppOutput.warnings` via the facade; add a `warnings` field to the FFI `RebuildReport` record (`ddb-core/src/ffi/records.rs:173-177`) (depends on: mapping) - Acceptance: after a poison file lands, a create AND a search both succeed and each carries a skip `AppWarning`; the warning reaches CLI stderr (`write_warnings`) and the GraphQL warnings extension (`forward_warnings`); the FFI reindex report exposes the skip.
- [ ] Wrap the destructive full-rebuild path (`rebuild_if_stale`/`rebuild`) in the rebuild lock with a post-acquisition staleness/integrity re-check; surface lock timeout as a structured error, never a panic (depends on: Phase 0 lock helper) - Acceptance: concurrent cold-start unit/integration coverage passes; a waiter that blocked behind another process's rebuild finds a fresh index and does not drop tables; no behavior change on the warm incremental path.
- [ ] Stamp an index schema version (`PRAGMA user_version` or a `_ddb_meta` key) written on every rebuild and checked at connection/configure; a mismatch takes the locked destructive-rebuild path; retire or demote the FTS-column probe (`needs_schema_upgrade`, `indexer/mod.rs:159-180`) (depends on: locked destructive rebuild) - Acceptance: opening an index stamped with an older version triggers exactly one locked drop-rebuild and a current version triggers none; unit-tested.
- [ ] Cap frontmatter size at the parse boundary so an oversized synced file degrades into the lenient skip path, never a fatal error or unbounded parse (depends on: Phase 0 collect-and-skip) - Acceptance: a file with an over-cap frontmatter block is skipped with a warning naming the path and reason; normal files unaffected; `--strict` hard-fails it; unit-tested.

**Exit Criteria**: reads and writes succeed and surface a structured skip warning across CLI + GraphQL + FFI; only one process at a time executes the destructive rebuild.

### Phase 2: Integration
**Goal**: docs and scenarios for the skip/strict behavior and the cold-start guarantee.

**Tasks**:
- [ ] Update `docs/src/technical/indexer.md` (poison-file resilience, `--strict`) + CHANGELOG; add smoke/integration scenarios (`tests/smoke.sh` + `.ps1` for `reindex --strict`; `tests/integration.sh` + `.ps1` for a synced poison file surfacing via GraphQL) and an e2e test under `tests/e2e/` for the skip + `--strict` behavior (depends on: Phase 1) - Acceptance: docs match; scenarios authored and green locally under Tier 1.
- [ ] Author the concurrent cold-start e2e (N concurrent `ddb create` on a cold repo, NO warm-up; verified to fail against pre-change code once); remove (or demote to a comment) the warm-up workaround in the 00162 concurrent-write e2e (`tests/e2e/concurrent_writes.rs:102-117`) so that scenario also exercises the cold path; add the rebuild-lock invariant (with its lock-ordering rule) to `docs/src/technical/invariants.md` alongside the indexer doc updates (depends on: Phase 1) - Acceptance: the e2e fails against pre-change code and passes after; the warm-up is gone; the invariants page lists the rebuild lock and its ordering relative to the git write lock. (Rebuild path is replaced, so run `cargo test -p ddb-e2e` per CLAUDE.md.)

**Exit Criteria**: skip + `--strict` + cold-start behavior documented and scenario-covered.

## Test Strategy

### Critical Scenarios
- **Happy path**: incremental sync brings three changed files, one malformed → Expected: two valid files indexed, one skipped, a warning names the bad path; a subsequent `ddb query` returns the two valid rows.
- **Edge case**: `reindex --strict` over the same change-set → Expected: a `DoogatError` naming the bad file (old fatal behavior preserved on demand).
- **Error case**: after the poison file lands, run a create then a search → Expected: both succeed; each result carries a skip `AppWarning`.
- **Concurrency case**: 8 concurrent `ddb create` on a cold repo (no stored HEAD, no warm-up) → Expected: all succeed; zero FTS bootstrap errors; final index row count matches git; only one destructive rebuild ran.

## Risks

- **Silently masking genuinely broken data**: skipping a bad file means its rows are absent from query results. Mitigation: always emit the structured warning (never silent) and surface it on every triggering verb; `--strict` remains for callers that must fail hard; the 00181 doctor listing (follow-up) enumerates the quarantined files.
- **Warning volume on a large corrupt corpus**: many bad files could flood the verb output. Mitigation: attach a single summary `AppWarning` (count + "see ddb doctor") on the verb envelope; the full per-file list lives in the 00181 doctor surface.
- **Enum variant is a public shape change**: adding `ConsistencyWarning::UnreadableFile` touches every exhaustive match. Mitigation: additive variant; update matches; the `AppWarning` mapping keeps transport codes stable.
- **`ensure_fresh` signature change fans out**: returning warnings touches the facade. Mitigation: keep `ensure_fresh` returning the warnings and merge only at the facade boundary that already builds `AppOutput`; verbs that do not build an envelope are unaffected.
- **Lock ordering vs the git write lock**: a path holding both locks in opposite orders could deadlock. Mitigation: fix ONE acquisition-order rule at design time, document it in `invariants.md`, and enforce it (the rebuild path and the write path never interleave acquisitions in the other order).
- **Waiter staleness**: a waiter serving immediately after another process's rebuild must not see a half-built index. Mitigation: the double-checked re-check validates integrity (tables present) as well as staleness before returning.

## Transport Impact

- **CLI**: Guaranteed — skip warnings print to the stderr warning stream (`ddb-cli/src/warnings.rs::write_warnings`); `reindex --strict` opt-in.
- **GraphQL**: Guaranteed — skip warnings ride the warnings extension (`ddb-server/src/warning_extension.rs::forward_warnings`).
- **REST**: Guaranteed — skip warnings ride the `warnings` field (`ddb-server/src/rest.rs::warnings_to_json`).
- **FFI**: Guaranteed — skip warnings ride the verb-output warning records; the FFI `RebuildReport` record (`ddb-core/src/ffi/records.rs:173-177`) gains a `warnings` field.
- **PgWire**: Specialized — SQL surface returns SQL errors only; malformed-file skips surface through the same index the SQL reads hit, but PgWire has no structured-warning channel. Document the boundary.
- **NoSQL HTTP**: Specialized — read-only document surface; a skipped file is simply absent from `get`/`scan`, consistent with the query index. The structured warning is surfaced via GraphQL/REST/CLI, not the NoSQL read.
- **Cold-start serialization**: no public API, response-shape, or error-code change on any transport — the rebuild lock sits below `DoogatService` in the indexer, so all six transports gain the same cold-start robustness through the shared code path; the CLI-driven e2e is the conformance vehicle.
- **Cross-interface conformance plan**: one poison file is synced into a repo; an integration test asserts (a) a GraphQL mutation + query both succeed and carry the skip warning via the extension, and (b) the CLI verb prints the same skip via stderr; smoke/integration + e2e scenarios pin the collect-and-skip and `--strict` behaviors; the concurrent cold-start e2e pins the rebuild serialization. The net-new quarantine listing and its cross-interface parity are owned by 00181.

---

## Design Doc

Source: `dev/local/designs/00169-poison-file-reindex-resilience-v1-design.md`

**The PRD above is the requirements authority. This design doc is the implementation design (the HOW), not the spec.** Use it to distinguish "implemented as designed" from drift.

### Architecture fit

Two independent availability fixes, both inside the indexer layer (`ddb-core/src/indexer/`), below `DoogatService` and above the six-transport surface. Neither touches git write paths, CRDT resolution, or the write-path data-loss class — the index is a derived, rebuildable cache, and this PRD keeps that invariant.

- **Lenient incremental indexing**: `Index::batch_index_changes` (private, called only from `Index::incremental_reindex`) currently propagates the first read/parse error via `?` and aborts the whole change-set. `Index::parallel_parse` (used by the full-rebuild path) already does collect-and-skip. This design brings the incremental path to parity with the pattern the full-rebuild path already established — no new pattern invented.
- **Skip surfacing**: `DoogatService::ensure_fresh` (`service/mod.rs:116-124`) is the single choke-point every one of ~40 verb functions calls before touching the index, but it discards `Index::rebuild_if_stale`'s `Option<RebuildReport>` entirely. This design makes it capture warnings without changing its signature or any of those ~40 call sites.
- **Serialized cold-start rebuild**: reuses the 00162 `git_ops::write_lock` primitive for a second, independently-scoped lock protecting the SQLite index's destructive drop-and-recreate path, keyed on the `.ddb/` directory rather than `.git/`.

### Module placement

New code, in existing files (no new files):

- `ddb-core/src/types/schema.rs` — add `ConsistencyWarning::UnreadableFile { path: String, error: String }` variant.
- `ddb-core/src/indexer/rebuild.rs` — rewrite `batch_index_changes` to collect-and-skip + gain a `strict: bool` param; `incremental_reindex` gains a `strict: bool` param; `parallel_parse` splits its `Err` handling into `UnreadableFile` (read stage) vs `MalformedYaml` (parse stage); new private `Index::locked_rebuild` wraps the destructive `rebuild()` call with the rebuild lock + a double-checked re-verify; `rebuild_if_stale`'s two destructive branches call `locked_rebuild`; new `pub fn rebuild_strict` sibling to `rebuild`.
- `ddb-core/src/indexer/mod.rs` — `Index` gains a `db_dir: Option<PathBuf>` field; `configure_connection` takes the dir and locks the schema-version-triggered drop+recreate branch the same way; `needs_schema_upgrade`'s FTS-column-text probe is demoted to a fallback behind a new `PRAGMA user_version` check.
- `ddb-core/src/parser/mod.rs` — add `MAX_FRONTMATTER_BYTES: usize` constant and a length check in `parse_frontmatter` before `serde_yaml::from_str`.
- `ddb-core/src/git_ops/write_lock.rs` — generalize `acquire` to take the lock directory and file name as explicit params.
- `ddb-core/src/service/mod.rs` — `ensure_fresh`'s return type changes from `Result<()>` to `Result<Vec<ConsistencyWarning>>`.
- `ddb-core/src/service/create.rs`, `update.rs`, `schema_apply.rs` — the three `AppOutput`-returning facades each gain one explicit `self.ensure_fresh()?` call at the top and merge the result into their existing `warnings` vec.
- `ddb-core/src/app_contract/output.rs` — new `summarize_reindex_warnings(Vec<ConsistencyWarning>) -> Option<AppWarning>`.
- `ddb-core/src/app_contract/mod.rs` — one new `pub(crate) use output::{...}` re-export line, since `output` is a private module.
- `ddb-core/src/service/search.rs` — `reindex()` routes through `locked_rebuild`; new `reindex_strict()` sibling.
- `ddb-core/src/ffi/records.rs` — `RebuildReport` FFI record gains `warnings: Vec<RebuildWarningRecord>`; new `RebuildWarningRecord { code: String, message: String }`.
- `ddb-core/src/ffi/driver.rs` — `reindex()` fills the new field instead of dropping `report.warnings`.
- `ddb-cli/src/main.rs`, `ddb-cli/src/commands/maintenance.rs` — `Reindex` gains a `--strict` flag.
- `ddb-cli/src/commands/crud.rs` — remove the redundant `svc.rebuild_if_stale()?;` pre-call in `create` (it would swallow the new warnings).
- `ddb-core/src/git_ops/tests.rs`, `ddb-core/src/indexer/tests/*`, `ddb-core/benches/search.rs` — call-site updates for the new signatures.
- `docs/src/technical/indexer.md`, `docs/src/technical/invariants.md`, CHANGELOG.

### Key interfaces as designed

```rust
// types/schema.rs
pub enum ConsistencyWarning {
    MalformedYaml { path: String, error: String },
    UnreadableFile { path: String, error: String },   // NEW
    CrossZoneDuplicate { path: String, key: String },
    MissingRequired { path: String, type_name: String, field: String },
}

// indexer/rebuild.rs
fn batch_index_changes(&self, repo: &impl DoogatSource, paths: &[String], strict: bool)
    -> Result<(usize, Vec<ParsedDoogat>, Vec<ConsistencyWarning>)>
pub fn incremental_reindex(&self, repo: &impl DoogatSource, old_head: &str, strict: bool)
    -> Result<crate::types::RebuildReport>

const REBUILD_LOCK_FILE_NAME: &str = "ddb-rebuild.lock";
const REBUILD_LOCK_TIMEOUT: Duration = Duration::from_secs(30);

fn locked_rebuild(&self, repo: &impl DoogatSource) -> Result<crate::types::RebuildReport> {
    let _guard = match &self.db_dir {
        Some(dir) => Some(write_lock::acquire(dir, REBUILD_LOCK_FILE_NAME, REBUILD_LOCK_TIMEOUT)?),
        None => None,
    };
    if self.check_integrity()? && !self.is_stale(repo)? {
        return Ok(crate::types::RebuildReport::default());
    }
    self.rebuild(repo)
}

pub fn rebuild_strict(&self, repo: &impl DoogatSource) -> Result<crate::types::RebuildReport>

// indexer/mod.rs
pub struct Index { pub(crate) conn: Connection, db_dir: Option<PathBuf> }
const SCHEMA_VERSION: i64 = 1;

// parser/mod.rs
const MAX_FRONTMATTER_BYTES: usize = 256 * 1024; // 256 KiB

// git_ops/write_lock.rs
pub fn acquire(lock_dir: &Path, lock_name: &str, timeout: Duration) -> Result<WriteLockGuard>

// service/mod.rs
fn ensure_fresh(&self) -> Result<Vec<ConsistencyWarning>>

// app_contract/output.rs
pub const REINDEX_SKIPPED_FILES: &str = "REINDEX_SKIPPED_FILES";
pub(crate) fn summarize_reindex_warnings(warnings: Vec<ConsistencyWarning>) -> Option<AppWarning>;
pub(crate) fn describe_consistency_warning(w: &ConsistencyWarning) -> String;
pub(crate) fn describe_consistency_warning_code(w: &ConsistencyWarning) -> &'static str;

// service/search.rs
pub fn reindex(&self) -> Result<RebuildReport>;        // -> locked_rebuild
pub fn reindex_strict(&self) -> Result<RebuildReport>; // -> rebuild_strict
```

Three sites reach the destructive `rebuild()` from the implicit/background path and all three go through `locked_rebuild`: `rebuild_if_stale`'s two destructive branches, plus `incremental_reindex`'s `diff_paths`-failure fallback (`rebuild.rs:83`).

`configure_connection`'s upgrade branch reads `PRAGMA user_version`. `0` (SQLite's default — every DB created before this PRD) is "unstamped, check the legacy probe" and falls back to the existing `needs_schema_upgrade` FTS-column-text check; any non-zero value `!= SCHEMA_VERSION` triggers the drop+recreate unconditionally. The destructive branch is wrapped in the SAME rebuild-lock guard, skipped when `db_dir` is `None`. After `SCHEMA_DDL` runs, `PRAGMA user_version = SCHEMA_VERSION` is written unconditionally.

### Alternatives considered

1. **Smallest diff — change `ensure_fresh`'s return type only, do nothing else.** Rejected: no facade reads the new value, so warnings never reach a transport; the PRD's core success metric goes unmet.
2. **RefCell side-channel on `DoogatService`.** Rejected: the actor pattern keeps ONE `DoogatService` alive across many sequential commands, so a leaf command that never drains would leave stale warnings attached to the NEXT unrelated call's `AppOutput` — a real cross-request correctness bug.
3. **(Chosen) Explicit up-front `ensure_fresh()` call in each of the 3 `AppOutput` facades**, return-type change on `ensure_fresh` only. No shared mutable state, no leakage window.

### Risks and accepted residual gaps (as designed)

- **Reindex-skip warnings are lost when the facade's own operation subsequently errors.** `Result::Err` has no warnings channel in this codebase. Accepted; matches the existing warnings-only-ride-`Ok` convention.
- **`REBUILD_LOCK_TIMEOUT = 30s` was an unvalidated starting point** flagged for `/plan-tasks` to justify or make configurable. Planning settled it at 30s: 3× the existing `WRITE_LOCK_TIMEOUT` of 10s and about an order of magnitude above the largest benchmarked full rebuild (`bench_rebuild_5k`). No config knob added.
- **Lock ordering: the git write lock and the index rebuild lock are never held simultaneously by the same call stack.** Stricter than an ordering rule; holds because the two lock scopes (`.git/` for commits, `.ddb/` for the index) protect independent resources. Documented in `write_lock.rs`'s module doc and `docs/src/technical/invariants.md`.
- **`bundle::mod.rs:229`'s `index.rebuild(repo)?` is NOT covered by `locked_rebuild`** — a documented, deliberate gap.
- **`ddb-server`'s `ReadPool` readers bypass the rebuild lock entirely** (`read_pool.rs:253,270` set `skip_stale_check`), so a reader issuing a raw query while another connection is mid-`drop_all_tables()` could still hit `no such table: _ddb_fts` — a second accepted residual gap.
- **Warning message strings have no length cap.** `ConsistencyWarning::{UnreadableFile,MalformedYaml}.error` is an unbounded `String` that can echo a snippet of externally-synced, untrusted content. `summarize_reindex_warnings` caps the warning *count* to one but not that one warning's *size*. Not fixed.
- **`ConsistencyWarning` is a public, non-`#[non_exhaustive]` enum** — adding a variant is source-breaking for any exhaustive `match` outside the crate. No external consumers exist yet.
- **`Index::open`'s new `db_dir`**: `path.parent()` returns `Some("")` for a bare relative filename like `":memory:"`, so an empty-parent filter is required or two `#[cfg(test)]` call sites would lock a cwd-relative file.
- **Frontmatter cap (256 KiB) is a guess**, flagged as a tunable constant.

### Test strategy outline (as designed)

- **Unit (`indexer/rebuild.rs`)**: one malformed + one unreadable + two valid → 2 survivors, 2 warnings (correct variants); `strict=true` → `Err`; all-good → 0 warnings. `locked_rebuild` — two handles serialize; a waiter that blocks behind a completed rebuild returns without dropping tables.
- **Unit (`indexer/mod.rs`)**: `user_version = 0`/absent triggers exactly one drop-rebuild on open; current `SCHEMA_VERSION` triggers none.
- **Unit (`parser/mod.rs`)**: over-cap frontmatter returns `Err`; normal-sized unaffected.
- **Unit (`app_contract/output.rs`)**: `summarize_reindex_warnings` — empty → `None`; one → unsummarized; many → count-suffixed.
- **Integration**: after a poison file lands via a raw commit, a `create` AND a `search` both succeed and `create`'s `AppOutput.warnings` carries exactly one `REINDEX_SKIPPED_FILES` warning; GraphQL `createDoogat` surfaces it via `extensions.warnings`.
- **e2e**: 8 concurrent `ddb create` on a truly cold repo (no warm-up) all succeed with zero FTS bootstrap errors and a row count matching git.
- **Smoke/integration scenarios**: `ddb reindex --strict` on a corpus with a bad file exits non-zero naming it; lenient exits 0 with a warning count; a synced poison file surfaces via GraphQL `extensions.warnings`.

### Design review log (3 dispatches)

- Dispatch 1 (claude): cardinal-sin 0, blocker 2, non-blocker 2, question 1
- Dispatch 2 (claude-fallback): cardinal-sin 0, blocker 3, non-blocker 3, question 1
- Dispatch 3 (claude-fallback): cardinal-sin 0, blocker 2, non-blocker 0, question 0

## Mechanical facts (computed, do not re-count)

Function line counts from `ast`. Cite these for countable claims; a
finding that contradicts this block is discarded at the review gate.

**This is a Rust workspace, so the block covers nothing this cycle** — every
changed file is non-Python and was skipped. No countable claim about this diff
is pre-computed; judge countable claims normally, on the source.

- `CHANGELOG.md` — skipped (non-python)
- `ddb-cli/src/commands/crud.rs` — skipped (non-python)
- `ddb-cli/src/commands/maintenance.rs` — skipped (non-python)
- `ddb-cli/src/commands/mod.rs` — skipped (non-python)
- `ddb-cli/src/main.rs` — skipped (non-python)
- `ddb-core/benches/search.rs` — skipped (non-python)
- `ddb-core/src/app_contract/mod.rs` — skipped (non-python)
- `ddb-core/src/app_contract/output.rs` — skipped (non-python)
- `ddb-core/src/ddb.udl` — skipped (non-python)
- `ddb-core/src/ffi/driver.rs` — skipped (non-python)
- `ddb-core/src/ffi/mod.rs` — skipped (non-python)
- `ddb-core/src/ffi/records.rs` — skipped (non-python)
- `ddb-core/src/ffi/tests.rs` — skipped (non-python)
- `ddb-core/src/git_ops/mod.rs` — skipped (non-python)
- `ddb-core/src/git_ops/tests.rs` — skipped (non-python)
- `ddb-core/src/git_ops/write_lock.rs` — skipped (non-python)
- `ddb-core/src/indexer/mod.rs` — skipped (non-python)
- `ddb-core/src/indexer/ports.rs` — skipped (non-python)
- `ddb-core/src/indexer/rebuild.rs` — skipped (non-python)
- `ddb-core/src/indexer/tests/materialize_tests.rs` — skipped (non-python)
- `ddb-core/src/indexer/tests/mod.rs` — skipped (non-python)
- `ddb-core/src/parser/mod.rs` — skipped (non-python)
- `ddb-core/src/parser/tests.rs` — skipped (non-python)
- `ddb-core/src/service/create.rs` — skipped (non-python)
- `ddb-core/src/service/mock_index_tests.rs` — skipped (non-python)
- `ddb-core/src/service/mod.rs` — skipped (non-python)
- `ddb-core/src/service/schema_apply.rs` — skipped (non-python)
- `ddb-core/src/service/search.rs` — skipped (non-python)
- `ddb-core/src/service/update.rs` — skipped (non-python)
- `ddb-core/src/traits.rs` — skipped (non-python)
- `ddb-core/src/types/schema.rs` — skipped (non-python)
- `docs/src/technical/indexer.md` — skipped (non-python)
- `docs/src/technical/invariants.md` — skipped (non-python)
- `docs/src/technical/parser.md` — skipped (non-python)
- `tests/e2e/concurrent_writes.rs` — skipped (non-python)
- `tests/e2e/main.rs` — skipped (non-python)
- `tests/e2e/poison_file_reindex.rs` — skipped (non-python)
- `tests/integration.ps1` — skipped (non-python)
- `tests/integration.sh` — skipped (non-python)
- `tests/smoke.ps1` — skipped (non-python)
- `tests/smoke.sh` — skipped (non-python)
