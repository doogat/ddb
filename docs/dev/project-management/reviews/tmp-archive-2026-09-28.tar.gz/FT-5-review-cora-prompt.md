Independent FT-5 review. This is a fresh review session; no driving-session conversation is provided. Static read-only review. Do not edit any file, stage, commit, push, spawn agents, invoke skills that edit, or run cargo/tests/linters/builds. Use Read tools for files and only read-only file-search tools as needed. Do not use Bash in Claude sessions; all named repository files can be opened with Read. The driver exclusively owns command execution and verification. Never read build/review/handoff/state files under dev/local except the exact card and diff paths authorized below, and never read other reviewers' output. Report runtime checks you need, without attempting them. If a rubric is not relevant to this change explain that, without demanding unrelated work. Each finding needs stable id, severity CRITICAL/HIGH/MEDIUM/LOW, file:line, exact evidence, failing input/path/consequence, concrete fix, and in-scope vs pre-existing distinction. Every CRITICAL/HIGH needs proof; unsupported concerns remain MEDIUM. Explicitly state no findings if none; empty output is a failed lane.

Repository: /Users/bob/git/src/github.com/doogat/ddb

Approved spec card (decisions settled):
# FT-5 concurrent single-row updates preserve successful writers

## Goal

Implement settled D2: single-row updates read, merge fields, validate and commit
under the existing re-entrant repo write lock. Every successful writer's
non-overlapping field changes must survive in committed Git state; refusal
must be loud and precede publication. The scope exception in
`dev/local/tmp/FT-5-scope-proposal.md` was approved by the maintainer's
"proceed" on 2026-09-13.

1. Add a required `GitBackend` closure hook, implemented through the existing
   `GitRepo` lock. Preserve object safety; no unsafe unlocked default.
2. Move the authoritative single-row read/modify/commit under that lock,
   preserving SQLite-outer/Git-inner order and existing write semantics.
3. Keep commit-graph and threshold maintenance outside the outermost Git
   lock on this path while preserving counters/configuration/suppression.
4. Add colocated fail-first regressions; un-ignore the existing hazard without
   changing any of its assertions. Document backend compatibility and locking.

## Tests

- tests/e2e/hazard_concurrent_single_row_update.rs::concurrent_field_updates_on_one_doogat_keep_both_fields_or_refuse_loudly
- tests/e2e/integration_write_lock_races.rs (existing regression gate; read-only)
- ddb-core/src/service/update.rs (new colocated single-row concurrent-update
  regressions, checking committed Git content; include typed and untyped
  updates and preserved field semantics where the change creates risk)
- ddb-core/src/git_ops/mod.rs (colocated regressions for the new hook and
  deferred maintenance, including nested/error cleanup as relevant)

## Allowlist

- ddb-core/src/service/update.rs (single-row field update and colocated tests;
  no independent batch/SQL/raw-replacement rewrite)
- ddb-core/src/git_ops/mod.rs (backend hook through existing re-entrant lock;
  defer single-file maintenance beyond the outermost lock; colocated tests)
- ddb-core/src/traits.rs (one required GitBackend lock hook and its rustdoc)
- tests/e2e/hazard_concurrent_single_row_update.rs (only remove #[ignore])
- docs/src/technical/git-ops.md (locking and backend compatibility guidance)
- docs/src/technical/walkthrough.md (changed write data-flow paragraph only)
- CHANGELOG.md (FT-5 Fixed line and required backend compatibility note)

## Read-only context

- AGENTS.md
- CLAUDE.md
- ddb-core/src/service/mod.rs
- ddb-core/src/service/validation.rs
- ddb-core/src/service/write_helpers.rs
- ddb-core/src/service/utility.rs
- ddb-core/src/service/create.rs
- ddb-core/src/service/tests.rs
- ddb-core/src/service/update_facade_tests.rs
- ddb-core/src/service/mock_index_tests.rs
- ddb-core/src/git_ops/write_lock.rs
- ddb-core/src/git_ops/read.rs
- ddb-core/src/git_ops/tests.rs
- ddb-core/src/maintenance.rs
- ddb-core/src/indexer/mod.rs
- ddb-core/src/indexer/materialize.rs
- ddb-core/src/error.rs
- ddb-core/src/types/schema.rs
- tests/e2e/integration_write_lock_races.rs
- ddb-core/tests/hazard_update_unique_clobber.rs
- ddb-core/tests/hazard_raw_create_existing_id.rs
- docs/src/technical/invariants.md
- docs/src/technical/solid.md
- docs/src/technical/clean-architecture.md

## Constraints

D2: single-row update reads inside the write lock; if the lock cannot wrap the
read, expected-OID refusal at commit; loud, never silent. No optimistic-
concurrency application API. The required backend hook is the approved narrow
exception to the original no-public-API wording, with documented external
implementor source compatibility impact.

Preserve per-instance reentrancy, fresh staging, SQLite-outer/Git-inner lock
ordering, and I1-I10. Never acquire the index rebuild lock, BEGIN IMMEDIATE,
network, or subprocess under the Git lock. Freshness checking must stay outside
the Git lock. A concurrent type/schema change must not reuse stale transaction
requirements: re-derive safely or refuse before commit. Preserve SINGLETON,
UNIQUE/FK validation, field routing, warnings, timestamps and successful write
semantics. Capture the update's actual commit identity where stored; never
claim an unrelated current HEAD is this operation's indexed commit.

No new concrete adapter construction, downcast, broad lock redesign, unsafe
code, lock bypass, or silent backend default. Batch update and SQL UPDATE are
out of scope unless covered for free by the same helper. Raw replacement
semantics, mint path, PRD 00206, and every other fast-track item are excluded.
The existing hazard test is the spec: retain every assertion and round.
Add colocated tests before the runtime fix and prove the regression fails.
The driver owns all cargo execution; never run cargo concurrently.

## Gate

- cargo +1.89.0 build
- cargo +1.89.0 clippy --workspace --all-targets -- -D warnings
- cargo +1.89.0 test-ci
- cargo +1.89.0 test -p ddb-core --lib service
- cargo +1.89.0 build -p ddb-cli
- cargo +1.89.0 test -p ddb-e2e --test e2e hazard_concurrent_single_row_update
- cargo +1.89.0 test -p ddb-e2e --test e2e integration_write_lock_races
- cargo +1.89.0 test -p ddb-e2e

Commands run sequentially in the foreground, with preserved logs. The full
e2e command is the plan's explicit batch-end requirement, not a substitution
for the targeted gates. No full-workspace heavy battery. Run pinned rustfmt on
touched files only, mdbook for changed docs, and git diff --check.

## Docs and CHANGELOG

Document the authoritative locked single-row read/modify/commit boundary,
SQLite ordering, deferred maintenance, and required backend hook compatibility
in git-ops.md / CHANGELOG. Update the corresponding walkthrough data-flow
paragraph. No new client setup, wire schema, or repository format.

## Transport impact

- CLI: field updates inherit the core guarantee; original two-process hazard.
- GraphQL: updateDoogat inherits it; existing mixed CLI/server lock test.
- REST: field update inherits the same service path, no wire change.
- PgWire: separate SQL UPDATE implementation remains outside FT-5; no new claim.
- FFI: raw replacement semantics remain intact; no field-merge parity claim.
- NoSQL HTTP: no new independent handler behavior or parity claim.

## Model

opus

Fresh implementor receives tests, allowlist, constraints and read-only context,
not Goal acceptance prose or driving-session history. After the build/gates,
END this session with a review handoff. A fresh review session must run the
complete plan roster, Victor verification, at most one review-driven rework,
and per-finding closure. Do not commit/push before approval. Then push master
including 4fd6052 and verify the exact new HEAD's CI. Stop after FT-5.


For diff-aware reviewers only: read the exact reviewed working-tree snapshot at /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/FT-5-build-ready.diff, based on 4fd60524ca3aed2ff633ee9716b14cd8fb19d035. Inspect surrounding source to verify the path. No prior review findings are supplied.

Persona:
You are the CORRECTNESS reviewer of a completed change. Review ONLY through the correctness lens.

Checklist:
- Hunt logic bugs in the diff: off-by-one, wrong boundary, inverted condition, missing await, lost error.
- Trace each changed function on its edge inputs (empty, one element, last element, null).
- Error handling is explicit and never silently swallowed (R10).
- The implementation matches the described behavior exactly (R9).
- No debug statements, TODOs, stubs or placeholder markers remain (R11).

Report only defects you can ground in the diff above. Do not speculate.
Every finding carries: title, severity (CRITICAL|HIGH|MEDIUM|LOW), file, and evidence — the exact snippet you are accusing, quoted from the diff.
Every CRITICAL or HIGH also carries a proof: why the code is REALLY broken (the input, the path, the consequence), not why it looks suspicious. A CRITICAL or HIGH without a proof is demoted to MEDIUM and stops blocking.
Add a fix (the concrete change) and a task id when you know them.
Report nothing at all rather than padding the list.

Output format:


Each agent outputs issues in this exact format:

```
[CORA] {emoji} {description} | File: {path or "N/A"} | Task: {id or "general"}
```

**Severity emojis:** 🔴 Critical, 🟠 High, 🟡 Medium, ⚪ Low

**Rules:**
- One issue per line
- Use "N/A" for file if issue is architectural/cross-cutting
- Use "general" for task if issue spans multiple tasks or is a PRD gap
- If zero issues found: `[CORA] ✅ No issues found`

**Examples:**
```
[ALICE] 🔴 SQL injection in query builder | File: src/db/query.ts | Task: 3
[BOB] 🟠 Missing error handling strategy | File: N/A | Task: general
[CARL] 🟡 PRD section 2.3 not implemented | File: N/A | Task: 5
```


Add the required evidence/proof after each issue line. Finish with APPROVE or CHANGES_REQUESTED and reason. All buckets in Eve's persona need severity and evidence.
