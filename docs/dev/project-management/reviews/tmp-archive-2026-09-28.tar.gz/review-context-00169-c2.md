# Review Context

## Completed Tasks

# Completed Tasks — PRD 00169-poison-file-reindex-resilience-v1

**Review cycle 2 (incremental).** Cycle 1 reviewed tasks 1-14 over the full range
`6bb16174..f00c4839`. THIS cycle's scoped diff covers only the cycle-1 rework —
tasks 15-20, commits `f00c4839..28dda73` (14 commits). Tasks 1-14 are listed for
context; do not re-review their unchanged code.

## Cycle-1 rework tasks (THE SUBJECT OF THIS REVIEW)

| Task | Name | Tier / implementor | Commits |
|------|------|--------------------|---------|
| 15 | `[D1-1]` Evict stale rows for modified files that fail read or parse | opus / claude | `f555cb5`, `6202bcb`, `a946357`, `681b24c` |
| 16 | `[D1-2]` Fix `summarize_reindex_warnings` mislabel, miscount, and the dangling `ddb doctor` pointer | sonnet / claude | `f2dbaf2`, `d5b5a33`, `5e4f5db`, `c732e9a` |
| 17 | `[D1-3]` Add the missing lock-scope regression coverage and a direct index assertion to the cold-start e2e | opus / claude | `0a9a9f5` |
| 18 | `[D1-4]` Extract the triplicated rebuild-lock acquisition and the duplicated batch/singleton read-parse logic | opus / claude | `47c826b` |
| 19 | `[D1-5]` Make `ddb reindex` name the skipped paths and assert the CLI `AppWarning` leg in smoke | sonnet / **codex** | `5b7290d`, `b3a5263`, `8db9688` |
| 20 | `[D1-6]` Correct the overstated invariant, the stale indexer docs, and the CHANGELOG breaking-change entry | sonnet / **codex** | `28dda73` |

### What each rework task was supposed to close (from the cycle-1 decision gate)

**15 `[D1-1]` — 🟠 HIGH, the cycle's most consequential finding.**
`partition_changes` routed both `DiffKind::Added` and `DiffKind::Modified` into
`to_index_paths`; only `DiffKind::Deleted` reached `remove_doogat`. So a *modified*
doogat that fails read/parse was skipped (`continue`) while its previously-indexed
rows in `doogats` and the materialized type tables were never evicted, and
`store_head(&new_head)` then marked the index current — stale pre-edit content
served as current, index claiming freshness. Introduced by the leniency work (before
this PRD the batch aborted, so HEAD never advanced). The PRD's Risk section assumed
skipped rows would be **absent**; the implementation made them **stale-present**.
Acceptance: a skipped modified file's old rows are gone, survivors keep theirs, HEAD
still converges.

**16 `[D1-2]` — 🟡, three defects in one helper.**
(a) `describe_consistency_warning(&warnings[0])` took the first warning regardless of
variant, so on the cold-start/destructive branch an advisory
`CrossZoneDuplicate`/`MissingRequired` for a *successfully indexed* file got labelled
`REINDEX_SKIPPED_FILES`. (b) `warnings.len() - 1` had no dedup, so the known
double-report (each malformed file counted once by `parallel_parse`, again by
`collect_consistency_warnings`) made ONE poison file render `"(+1 more, ...)"`,
naming a second file that does not exist. (c) The message pointed at `ddb doctor`,
which is not a command (PRD 00181 would add it, still in backlog).
Acceptance: filter to `UnreadableFile|MalformedYaml`, dedup by path, name a real remedy.

**17 `[D1-3]` — 🟡, 4/5 consensus; the PRD's known-unmet fail-first obligation.**
The CRITICAL lock-scope fix (`0537b18`) shipped with no regression test. Eve found
the tractable half: the post-lock `read_needs_drop` re-check at `indexer/mod.rs:212-217`
is deterministically testable today with no new dependency (hold the lock, upgrade +
stamp + sentinel out-of-band, release, assert the waiter skipped the drop). Plus Bob's
point that the cold-start e2e compared reported IDs only against git HEAD and never
inspected `.ddb/index.db` directly, so a CLI read-back would self-heal what direct DB
inspection would catch.
Acceptance: a discriminating test that dies when the re-check is reverted; a direct
index-row assertion in the cold-start e2e.

**18 `[D1-4]` — 🟡, 3/5 consensus; behavior-preserving extraction only.**
The rebuild-lock acquisition block was duplicated verbatim three times
(`configure_connection`, `locked_rebuild`, `locked_explicit_rebuild`);
`batch_index_changes` duplicated the read/parse/strict/warning state machine across
its batch and singleton branches and exceeded 50 lines; `indexer/mod.rs` crossed the
800-line cap (749 → 837) and `configure_connection` tripled (26 → ~80 lines).
Acceptance: one lock helper, one per-path parse step, `indexer/mod.rs` back under 800,
**guard lifetime unchanged** (the extraction must not re-introduce the 0537b18 bug).

**19 `[D1-5]` — 🟡.**
`ddb reindex` printed only "N warning(s)"; the skipped paths reached the user only via
tracing stderr, so `RUST_LOG=error` named nothing. Separately, no test anywhere asserted
the **CLI** `AppWarning` leg (`write_warnings` → stderr on `ddb create`) — smoke section
32 bound the `reindex` command's *tracing* output instead, leaving the PRD metric
"asserted present on at least CLI + GraphQL" half-met.
Acceptance: one line per report warning from `ddb reindex`; a smoke scenario binding
the `ddb create` AppWarning leg, in both `.sh` and `.ps1`.

**20 `[D1-6]` — 🟡, 3/5 consensus; docs only.**
`invariants.md` I5 described the skip-warning as reaching "the verb envelope" generally,
without qualifying that only create/update/apply_schema wire it. `docs/src/technical/indexer.md`
still showed the obsolete two-argument `incremental_reindex` signature and never described
the collect-and-skip/strict behavior, the schema-version stamp, or the 256 KiB frontmatter
cap. CHANGELOG omitted the compile-breaking public shape change (`ConsistencyWarning`
gained `UnreadableFile`).
Acceptance: I5 narrowed to its true scope, indexer.md brought current, CHANGELOG
breaking-change entry added.

## Original tasks 1-14 (cycle 1, reviewed already — context only)

| Task | Name |
|------|------|
| 1 | Add `ConsistencyWarning::UnreadableFile` variant |
| 2 | Make incremental indexing collect-and-skip per-file failures with a strict opt-in |
| 3 | Generalize the write-lock helper to take an explicit lock directory and file name |
| 4 | Add the `ConsistencyWarning` to `AppWarning` summarizing helpers in `app_contract` |
| 5 | Capture reindex warnings in `ensure_fresh` and merge them into the three `AppOutput` facades (**codex**-implemented) |
| 6 | Add a `warnings` field to the FFI `RebuildReport` record |
| 7 | Serialize the destructive full-rebuild path behind a cross-process rebuild lock |
| 8 | Stamp and check an index schema version via `PRAGMA user_version` |
| 9 | Add a `--strict` flag to the `ddb reindex` command |
| 10 | Cap frontmatter size at the parse boundary |
| 11 | Document the poison-file skip and `--strict` behavior and add the smoke scenarios (**codex**-implemented) |
| 12 | Add the poison-file GraphQL integration scenario to `tests/integration.sh` |
| 13 | Add the matching poison-file GraphQL scenario to `tests/integration.ps1` |
| 14 | Author the poison-file and concurrent cold-start e2e coverage and record the rebuild-lock invariant |

## Known state the build session reported (raise these only if they are wrong)

- `incremental_reindex`'s `strict: bool` is never `true` on any user-facing path: one
  production call site passes `false`, and `reindex_strict()` routes through
  `locked_explicit_rebuild → rebuild_strict`. Only tests exercise the parameter. Docs now
  say so; the affordance itself was left alone as out of scope for a docs task.
- OPEN, carried from task 15's per-task review: `evict_doogats(&to_delete)` runs BEFORE
  `batch_index_changes`, so a **strict** run over a change-set containing BOTH a deletion
  AND a poison file applies the deletion and then errors. Pre-existing since `e5ec64a`;
  the CHANGELOG wording was corrected instead of the code. A one-line fix exists: fold
  both eviction sites into one call after `batch_index_changes`.
- `tests/smoke.ps1` section 33 was REVIEWED, NOT EXECUTED (`pwsh` does not resolve on this
  host). Its exit-code guard has never run; CI is the first place it executes.
- `Index::drop_all_tables` (`indexer/mod.rs`) is a near-copy of the drop loop now in
  `indexer/schema_version.rs`; the only difference is where `PRAGMA foreign_keys = OFF`
  sits. Flagged, deliberately not unified.
- Task 17's test carries an anti-vacuity guard, but a residual timing gap remains: a waiter
  thread that never reaches its pre-check would also read as "parked". Accepted; the
  twice-proven discrimination (Ivan and Pat each reverted the re-check and saw the sentinel
  die) is the real teeth.

## Tier 1 gate, run at HEAD `28dda73` by the build session

`cargo build` OK · `cargo clippy --workspace --all-targets` clean ·
`cargo test-ci` (ddb-core 1549 passed, ddb-server 222 passed) ·
`cargo test -p ddb-e2e` 451 passed · `bash tests/smoke.sh` all-passed banner ·
`cd docs && mdbook build` OK.

## Code Changes

### Changed Files
_Diff scope: incremental review (changes since f00c4839c1a10391f1355c5a01bb3d5f3c376c14)_

```
 CHANGELOG.md                           |   7 +-
 Cargo.lock                             |   1 +
 ddb-cli/src/commands/maintenance.rs    |   6 +
 ddb-core/src/app_contract/mod.rs       |   6 +-
 ddb-core/src/app_contract/output.rs    | 143 ++++++-
 ddb-core/src/indexer/mod.rs            |  89 +---
 ddb-core/src/indexer/rebuild.rs        | 198 +++++----
 ddb-core/src/indexer/schema_version.rs |  83 ++++
 ddb-core/src/indexer/tests/mod.rs      | 750 +++++++++++++++++++++++++++++++++
 docs/src/technical/indexer.md          |  18 +-
 docs/src/technical/invariants.md       |   2 +-
 tests/Cargo.toml                       |   1 +
 tests/e2e/concurrent_writes.rs         |  24 ++
 tests/smoke.ps1                        |  40 ++
 tests/smoke.sh                         |  26 ++
 15 files changed, 1206 insertions(+), 188 deletions(-)
```

### Diff Content
Full diff available at: /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00169-c2.diff

(1699 lines)

## PRD Requirements

# PRD 00169 — poison-file reindex resilience (requirements authority)

**Full PRD (read it — this is a summary, the file is authoritative):**
`/Users/bob/git/src/github.com/doogat/ddb/dev/local/prds/wip/00169-poison-file-reindex-resilience-v1.md`

**Design doc (the HOW, not the spec):**
`/Users/bob/git/src/github.com/doogat/ddb/dev/local/designs/00169-poison-file-reindex-resilience-v1-design.md`

Title: *Indexer rebuild resilience: poison-file skip and serialized cold-start rebuild.*
P1 (availability), Roadmap Phase 1. Absorbed 00169b `serialize-cold-start-index-rebuild`.

## Problem (verbatim shape)

One malformed markdown file makes the whole database unusable through the service.
`batch_index_changes` did `let content = content_result?;` then `parser::parse(&content, &path)?`,
so a single bad file aborted the entire change-set — and the *other* valid files changed
in that same sync were also not indexed. That fatal path gates ~40 entry points:
`incremental_reindex` ← `rebuild_if_stale` ← `ensure_fresh`, which runs at the top of every
public verb module (search / read / create / update / delete / sql / discovery / batch /
utility / schema_apply). The full-rebuild path was ALREADY lenient (`parallel_parse`
collects failures into `MalformedYaml`), so only the incremental path was inconsistent.
This violated the AGENTS.md guardrail: "User-facing read/write/list paths must not silently
drop rows, schemas, or parse failures; return errors or structured warnings."

Second, independent gap: concurrent writers on a **cold** repo (no stored HEAD in `_ddb_meta`)
each took the destructive branch of `rebuild_if_stale` → `rebuild` → `drop_all_tables()` +
FTS recreation. Nothing serialized this across processes, so concurrent cold starts stomped
each other's FTS bootstrap and failed with `no such table: _ddb_fts` / `_ddb_boost`.

The net-new quarantine/index-health **listing** surface (a `ddb doctor` listing, a GraphQL
`indexHealth` query, a REST endpoint, an FFI method) is explicitly a follow-up owned by
**00181** — out of scope here.

## Success Metrics (verbatim)

- One malformed `.md` in an incremental change-set: the other changed files still index; the bad file is skipped, not fatal; a structured warning names the bad file and reason.
- Subsequent reads AND writes succeed after a poison file lands (no manual full rebuild required to unblock the service).
- The skip warning surfaces on the triggering verb through the existing `AppWarning` channel, asserted present on at least CLI + GraphQL.
- An explicit `--strict` mode preserves the old hard-fail behavior for callers that want it.
- The FFI `RebuildReport` record carries a `warnings` field so FFI callers see the skip.
- N concurrent `ddb create` processes on a cold repo (no stored HEAD) all succeed: zero `no such table: _ddb_fts` / `_ddb_boost` errors; final index row count matches git.
- Double-checked rebuild: a waiter that blocked behind another process's rebuild finds a fresh index and returns without dropping tables; lock acquisition failure/timeout surfaces as a structured error, never a panic.
- The 00162 concurrent-write e2e's warm-up workaround is removed (or demoted to a comment), so that scenario also exercises the cold path.
- An index stamped with an older schema version drop-rebuilds exactly once (version-triggered, under the rebuild lock); a current version never does.
- An oversized frontmatter block degrades into the standard skip warning; reindex cost stays bounded.
- No regression: existing incremental-reindex, full-rebuild, and `AppWarning` tests stay green; no behavior change on the warm incremental path.

## Phase acceptance criteria (verbatim, the ones this cycle's rework touches)

**Phase 0**
- `ConsistencyWarning::UnreadableFile { path, error }`: variant compiles; existing `MalformedYaml` matches unaffected.
- Collect-and-skip + `strict`: a change-set with one malformed and two valid files indexes the two valid files and returns two survivors + one warning naming the bad path; under `strict=true` the same input returns a `DoogatError`; pure-indexer unit tests cover read-fail, parse-fail, strict, and all-good.
- Lock helper: a unit test proves two handles serialize and the guard releases on drop; the ordering rule is written down (module doc).

**Phase 1**
- `ConsistencyWarning → AppWarning`: each variant maps to a stable `code` + human `message`; unit-tested.
- `ensure_fresh` capture: *"after a poison file lands, a create AND a search both succeed and each carries a skip `AppWarning`; the warning reaches CLI stderr (`write_warnings`) and the GraphQL warnings extension (`forward_warnings`); the FFI reindex report exposes the skip."*
- Locked destructive rebuild: concurrent cold-start coverage passes; a waiter that blocked behind another process's rebuild finds a fresh index and does not drop tables; no behavior change on the warm incremental path; lock timeout is a structured error, never a panic.
- Schema-version stamp: opening an index stamped with an older version triggers exactly one locked drop-rebuild and a current version triggers none; unit-tested. The ad-hoc FTS-column probe `needs_schema_upgrade` retired or demoted to a fallback.
- Frontmatter cap: a file with an over-cap frontmatter block is skipped with a warning naming the path and reason; normal files unaffected; `--strict` hard-fails it; unit-tested.

**Phase 2**
- `docs/src/technical/indexer.md` (poison-file resilience, `--strict`) + CHANGELOG; smoke scenarios (`tests/smoke.sh` + `.ps1` for `reindex --strict`); integration scenarios (`tests/integration.sh` + `.ps1` for a synced poison file surfacing via GraphQL); an e2e under `tests/e2e/` for skip + `--strict`. Acceptance: docs match; scenarios authored and green locally under Tier 1.
- Concurrent cold-start e2e (N concurrent `ddb create`, NO warm-up, verified to fail against pre-change code once); the 00162 warm-up workaround removed or demoted; the rebuild-lock invariant + its ordering rule added to `docs/src/technical/invariants.md`.

## Test Strategy — Critical Scenarios (verbatim)

- **Happy path**: incremental sync brings three changed files, one malformed → two valid files indexed, one skipped, a warning names the bad path; a subsequent `ddb query` returns the two valid rows.
- **Edge case**: `reindex --strict` over the same change-set → a `DoogatError` naming the bad file.
- **Error case**: after the poison file lands, run a create then a search → both succeed; each result carries a skip `AppWarning`.
- **Concurrency case**: 8 concurrent `ddb create` on a cold repo (no stored HEAD, no warm-up) → all succeed; zero FTS bootstrap errors; final index row count matches git; only one destructive rebuild ran.

## Risks the PRD itself names (they bound what counts as a defect)

- **Silently masking genuinely broken data**: *"skipping a bad file means its rows are absent from query results."* Mitigation: always emit the structured warning; `--strict` remains; the 00181 doctor listing enumerates quarantined files. **(Cycle 1 found the implementation made skipped rows stale-PRESENT rather than absent — task 15 is the fix; verify it.)**
- **Warning volume on a large corrupt corpus**: mitigation is *"attach a single summary `AppWarning` (count + see ddb doctor) on the verb envelope"* — this is why the implementation uses summarizing free functions rather than a 1:1 `From` impl.
- **Enum variant is a public shape change**: additive variant; update matches; transport codes stay stable.
- **`ensure_fresh` signature change fans out**: merge only at the facade boundary that already builds `AppOutput`; verbs that do not build an envelope are unaffected.
- **Lock ordering vs the git write lock**: fix ONE acquisition-order rule at design time, document it in `invariants.md`, enforce it.
- **Waiter staleness**: the double-checked re-check validates integrity (tables present) as well as staleness.

## Transport Impact (verbatim posture)

- **CLI**: Guaranteed — skip warnings print to stderr (`ddb-cli/src/warnings.rs::write_warnings`); `reindex --strict` opt-in.
- **GraphQL**: Guaranteed — warnings extension (`ddb-server/src/warning_extension.rs::forward_warnings`).
- **REST**: Guaranteed — `warnings` field (`ddb-server/src/rest.rs::warnings_to_json`).
- **FFI**: Guaranteed — verb-output warning records; FFI `RebuildReport` gains a `warnings` field.
- **PgWire**: Specialized — no structured-warning channel; document the boundary.
- **NoSQL HTTP**: Specialized — a skipped file is simply absent from `get`/`scan`.
- **Cold-start serialization**: no public API / response-shape / error-code change on any transport.

## Project guardrails that bind this review

From `AGENTS.md`:
- Keep `ddb-core/src/types/**` adapter-neutral (no `rusqlite`, `git2`, `redb`, `axum`, `async_graphql`).
- No runtime panics in library/FFI code for mutex, database, filesystem, repository, or user-input state.
- User-facing read/write/list paths must not silently drop rows, schemas, or parse failures.
- **P0 data-safety invariant, "One bad file never fails the batch"**: read/list/index paths degrade per-item into structured warnings; only an explicit `--strict` mode hard-fails. (This PRD IS that invariant's implementation.)
- Every git write holds the repo write lock; IDs mint through one repo-aware path; conflict resolution is a pure function of its inputs.
- Every interpolated SQL identifier is escaped; every value is a bound parameter.
- Files: 200-400 lines typical, **800 max**; functions under 50 lines; max 4 levels of nesting.
- Tier 1 per-task gate: `cargo build`, `cargo clippy --workspace --all-targets` clean, `cargo test-ci`, unit tests alongside the module.
- Tier 2 (full workspace tests, e2e, `integration.sh`, `.ps1` ports, property tests, coverage) is **delegated to CI** — authoring is the per-PRD deliverable, local execution is not.
