Adversarial verification of ONE raised finding. Fresh session; no driving-session conversation is provided. Your job: try to REFUTE the finding by tracing the actual code. Uncertainty refutes; only a shown broken path confirms. Do not edit any file, stage, commit, push, spawn agents, or run cargo/tests/linters/builds (the driver owns every cargo command). Read-only file reads and read-only searches (rg) are allowed. Do not read anything under dev/local except the two paths named below. Do not read other reviewers' output.

Repository: /Users/bob/git/src/github.com/doogat/ddb
Base: 4fd60524ca3aed2ff633ee9716b14cd8fb19d035 (master). The working tree currently carries the reviewed FT-5 patch; the exact patch is also at dev/local/tmp/FT-5-build-ready.diff. The approved spec card is dev/local/tmp/FT-5-card.md (read its Goal, Constraints and Allowlist sections; the "Constraints" section is the contract you judge scope against).

## The finding to verify (verbatim from the Codex reviewer)

FT5-BOB-01 — HIGH — FIX — schema revalidation can miss a committed typedef.
Location: ddb-core/src/service/update.rs:85. The locked code calls `self.list_type_schemas()?`, but ddb-core/src/service/utility.rs:41 discovers paths using `SELECT path FROM doogats WHERE type = '_typedef'`. That is the SQLite catalog, not the locked Git tree.

Static proof: seed an existing unregistered `app_config` row and an untyped target. Pause an update retyping the target to `app_config` after its preview: `needs_transaction` is false. Another writer commits an `app_config` SINGLETON typedef but has not indexed it. Resume the updater. The SQLite path query omits that typedef, `schema` remains `None`, and line 96 permits publication. Git now contains two `app_config` rows despite the committed SINGLETON definition. ddb-core/src/service/write_helpers.rs:39 also skips materialization when the supplied schema list lacks the type. The commit-before-index interval exists at ddb-core/src/service/create.rs:510.

The new test closes this interval artificially: ddb-core/src/service/update.rs:883 indexes and materializes the typedef before resuming.

Fix: within the single-row path, discover committed typedefs through existing backend read methods, or detect an untrustworthy catalog and refuse before publication. Keep freshness/rebuild and transaction acquisition outside the Git lock. Add a deterministic regression that resumes after typedef commit but before indexing, asserting refusal and unchanged target content.
Scope: the catalog weakness predates FT-5; relying on it for the new mandatory schema-race safeguard is an in-scope acceptance failure. No raw-create rewrite is needed.

## What you must decide

1. Is the interleaving REAL at the code level? Trace: how typedefs get registered (sql_engine CREATE TABLE path and any other typedef-creating path), whether a commit-then-index window exists, and whether `update_doogat_parsed`'s locked `list_type_schemas()` can observe Git-committed typedefs that SQLite has not indexed. Consider `ensure_fresh()` (runs before the lock), what it compares (stored HEAD vs current HEAD), and whether the typedef writer's commit moves HEAD in a way the updater's freshness check would or would not catch given the timing (updater's ensure_fresh runs BEFORE the typedef commit lands; typedef commit lands; updater takes the git lock and calls list_type_schemas).
2. Even if the catalog lags, what is the CONSEQUENCE compared to the pre-FT-5 baseline (4fd6052)? At baseline the schemas were loaded once, outside any lock, from the same SQLite catalog. Does FT-5 make this worse, the same, or better? Would the pre-existing SINGLETON check at `create.rs` and the pre-FT-5 update path have the identical gap?
3. Does the card's Constraints text ("A concurrent type/schema change must not reuse stale transaction requirements: re-derive safely or refuse before commit") make this an in-scope FT-5 defect, or is it a pre-existing index-freshness class outside the card (which forbids index rebuild under the Git lock and any broad lock redesign)? Quote the exact constraint words your judgement rests on.
4. If a fix were required, is there a bounded one within the allowlist (update.rs, git_ops/mod.rs, traits.rs) that does NOT rebuild the index under the lock and does NOT add a subprocess/transaction under the lock? Sketch it in 5 lines or say none exists.

## Output format

Start with exactly one line: `VERDICT: CONFIRMED` or `VERDICT: REFUTED`.
Then `SCOPE: in-scope-FT-5` or `SCOPE: pre-existing-class` with the quoted constraint words.
Then `SEVERITY: <CRITICAL|HIGH|MEDIUM|LOW>` as you would rate it after verification (a confirmed pre-existing class that FT-5 does not worsen is not HIGH for this diff).
Then the evidence: file:line citations and the concrete step-by-step interleaving you traced, or the exact step where the reviewer's chain breaks. State which runtime check (one exact test name or scenario) the driver should run if you could not settle it statically. Keep it under 60 lines.
