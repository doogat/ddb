You are Blake, a hostile auditor reviewing code you've never seen before.
You know ONLY what was supposed to be built. You must find the code,
read it, and determine if it does what the spec says.

Project root: `/Users/bob/git/src/github.com/doogat/ddb` (Rust workspace, branch `master`).
Never run `ddb` commands inside the project root — use a temp directory.

## The Specification

# Bundle-import conflict recovery

**Priority:** P1 · **Roadmap:** Phase 1 (convergence) · **Depends on:** 00162 (write lock — merge + resolve + ref-delete run inside the write critical section)

## Overview

### Problem Statement
A conflicted bundle import reports success while silently losing the imported data.

- **Conflict detection reads `stderr`, not state.** `merge_bundle_and_resolve` (`ddb-core/src/bundle.rs:113-138`) shells out to `git merge refs/remotes/bundle/master` (`:118-126`) and, on failure, decides conflict-vs-error by **string-matching `stderr`** for `"CONFLICT"` / `"Automatic merge failed"` (`:132-137`). This is locale- and version-fragile, and there is **no** `git merge --abort` anywhere.
- **A conflicted merge is reported as clean success.** A conflicted `git merge` creates **no commit**, so `resolve_post_merge_conflicts` (`sync_manager/mod.rs:883-887`) → `validate_clean_merge_or_fallback` sees `commit_parent_count < 2` (`:544`) and returns `Ok(0)`: the import reports **success with 0 conflicts** while nothing merged.
- **The bundle ref is deleted regardless, pruning the data.** `import_bundle` (`bundle.rs:160-197`) then **unconditionally** deletes `refs/remotes/bundle/master` (`:181-184`), making the unbundled commits unreachable, so auto-gc prunes the offline-synced data.

### Target Users
Multi-device users (jink) syncing offline via bundles; a conflicted import must recover the data through the resolver, not silently discard it.

### Success Metrics
- A conflicted bundle import produces a **real merge commit** via the resolver, reports the **true** conflict count, leaves the bundle data reachable, and never reports false success — pinned by a conflicted-bundle test.
- Conflicts are detected from the **git index / merge state**, never from `stderr` strings — asserted by a test that a locale/wording change in git output does not flip the detection.
- On an unresolvable bundle merge, `git merge --abort` runs and a real `Sync` error surfaces; the repo is left clean (no dangling `MERGE_HEAD`, no partial index) — pinned by a test.
- `refs/remotes/bundle/master` is deleted **only after** a successful merge commit, so unreachable objects never exist for gc to prune — pinned by a reachability test.
- No regression: existing clean-import bundle tests stay green.

## Functional Decomposition

### Capability: Bundle-import conflict recovery

#### Feature: Index-state conflict detection + resolution
- **Description**: bundle-merge conflicts are detected from the git index/merge state and driven through the existing resolver.
- **Inputs**: the unmerged index left by the bundle merge.
- **Outputs**: resolved files committed via `commit_merge`; the true conflict count.
- **Behavior**: read conflicts from the index (unmerged entries / `MERGE_HEAD` presence), not `stderr` strings; run the existing conflict pipeline + `commit_merge`; the returned count reflects real conflicts.

#### Feature: Ref-delete-after-success + abort-on-error
- **Description**: the bundle ref is deleted only after a successful merge commit; any failure aborts and errors.
- **Inputs**: the merge/commit result.
- **Outputs**: bundle data reachable until success; clean repo on error.
- **Behavior**: delete `refs/remotes/bundle/master` only after a real merge commit; on any error run `git merge --abort` (when `MERGE_HEAD` exists, else reset the index) and return a `Sync` error. The merge → resolve → ref-delete sequence runs inside the 00162 write lease.

## Structural Decomposition

### Repository Structure

```
ddb-core/src/
├── bundle.rs          # Maps to: merge_bundle_and_resolve (:113-138) index-state detection + --abort; import_bundle (:160-197) delete ref only after success
ddb-core/src/sync_manager/
└── mod.rs             # Maps to: resolve_post_merge_conflicts (:883-887) / validate_clean_merge_or_fallback (:538-544) stop reporting false success
```

### Module: bundle (ddb-core/src/bundle.rs)
- **Maps to capability**: Bundle-import conflict recovery
- **Responsibility**: detect conflicts from index/merge state, drive the resolver, delete the bundle ref only after a successful merge, abort + error on failure.
- **Exports**: `merge_bundle_and_resolve`, `import_bundle`

### Module: sync_manager (ddb-core/src/sync_manager/mod.rs)
- **Maps to capability**: Bundle-import conflict recovery
- **Responsibility**: refuse to report success when no merge commit exists; report the honest count from real merge state.
- **Exports**: `resolve_post_merge_conflicts` - honest count from real merge state

## Dependency Graph

### Foundation Layer (Phase 0)
Depends on 00162 (write lease) - the merge/resolve/ref-delete critical section acquires it.

- **index-state detection**: read conflicts from the index, not `stderr`; independent of the reassignment work.

### Core Layer (Phase 1)
- **honest recovery + ref-after-success + abort**: Depends on [index-state detection] - drive the resolver, commit, delete the ref only on success, abort on error.

### Integration Layer (Phase 2)
- **conflicted-bundle test + docs + walkthrough**: Depends on [honest recovery].

## Implementation Phases

### Phase 0: Foundation
**Goal**: detect conflicts from state, not strings.

**Tasks**:
- [ ] Replace the `stderr` string-match in `merge_bundle_and_resolve` with index/merge-state detection (unmerged entries / `MERGE_HEAD`) (depends on: 00162) - Acceptance: a conflicted bundle merge is detected from the index; a unit test asserts detection is unaffected by git output wording/locale.

**Exit Criteria**: conflict detection is state-based.

### Phase 1: Core
**Goal**: honest recovery, ref-after-success, abort-on-error.

**Tasks**:
- [ ] Drive the detected conflicts through the existing conflict pipeline + `commit_merge`; report the true count; delete `refs/remotes/bundle/master` only after a successful merge commit; on any error run `git merge --abort` and return a `Sync` error; run the sequence inside the 00162 write lease (depends on: Phase 0) - Acceptance: a conflicted import produces a real merge commit, reports the true count, keeps bundle data reachable, and never reports false success; on an unresolvable merge the repo is left clean and an error surfaces.

**Exit Criteria**: bundle import recovers or aborts honestly; no false success.

### Phase 2: Integration
**Goal**: prove no data loss and document it.

**Tasks**:
- [ ] Conflicted-bundle test (true count, no prune, no false success; abort-on-error leaves a clean repo) + a reachability test (bundle data reachable until success); add a bundle-import scenario to `integration.sh`/`.ps1`; author the import-bundle conflict-recovery e2e under `tests/e2e/` (depends on: Phase 1) - Acceptance: all fail against the old code and pass after.
- [ ] Update `docs/src/technical/sync.md` (bundle-import recovery) + CHANGELOG; add/refresh a showboat walkthrough for bundle import (user-facing behavior change) (depends on: Phase 1) - Acceptance: docs + walkthrough landed.

**Exit Criteria**: conflicted-bundle coverage + docs + walkthrough landed.

## Test Strategy

### Critical Scenarios
- **Happy path**: bundle import with no conflicts → Expected: merge commit, bundle ref deleted after success, data reachable, count 0.
- **Edge case**: git emits differently-worded merge output → Expected: state-based detection still fires; the import does not misclassify the conflict as an error or as false success.
- **Error case**: conflicted bundle import → Expected: real merge commit via the resolver, true conflict count, data not pruned; on an unresolvable merge, `git merge --abort` + surfaced error, repo clean.

## Risks

- **CLI git vs libgit2 index**: reading conflicts after a CLI `git merge` mixes toolchains. Mitigation: read conflicts from the shared `.git/index` via libgit2, or route the bundle merge through the existing libgit2 conflict path; detect from state, never `stderr`.
- **`git merge --abort` preconditions**: abort requires a merge in progress. Mitigation: abort only when `MERGE_HEAD` exists, else reset the index; test the abort path.
- **Auto-gc timing**: pruning happens on gc, not immediately. Mitigation: keep the bundle ref until success so unreachable objects never exist; test reachability post-import.
- **False-success regression is silent**: the old bug reported `Ok(0)`. Mitigation: the conflicted-bundle test asserts a non-zero true count and a real 2-parent merge commit, so a regression fails loudly.

## Transport Impact

- **CLI**: Guaranteed — the bundle-import path is the primary fix site.
- **GraphQL**: Intentionally absent — bundle import is a CLI/FFI workflow, not a GraphQL surface; noted, not regressed.
- **REST**: Intentionally absent — bundle import is not a REST surface.
- **PgWire**: Intentionally absent — no bundle surface.
- **FFI**: Guaranteed — driver bundle import gains conflict recovery.
- **NoSQL HTTP**: Intentionally absent — read-only document mirror; no bundle surface.
- **Cross-interface conformance plan**: `integration.sh`/`.ps1` bundle scenarios exercise CLI + FFI; a conflicted-bundle test pins true count + no prune + no false success + clean abort; a reachability test pins ref-after-success; `tests/e2e/` covers bundle-import conflict recovery. The one public change: a conflicted bundle import now returns a real error instead of false success (CHANGELOG note).

## The Rubric (binary pass/fail rules, spec-only)

### Spec Compliance

B1: The implementation satisfies all specified behaviors and outputs described in the PRD.

B2: All stated data formats and structures in the PRD are preserved in the implementation.

B3: Every API endpoint or interface specified in the PRD is implemented with the correct signature and behavior.

B4: All stated performance requirements and constraints from the PRD are met.

B5: The implementation matches all specified error handling behaviors and status codes.

### Scope Creep

B6: No new functionality or features beyond those explicitly specified in the PRD are present.

B7: No additional parameters, options, or flags are added beyond those in the PRD.

B8: No new external dependencies or libraries are introduced beyond those specified.

### Security

B9: All specified authentication mechanisms from the PRD are implemented and enforced.

B10: Required input validation and sanitization are present as specified in the PRD.

B11: Any specified rate-limiting or throttling controls are implemented as described.

### Data Safety

B12: No destructive operations (delete, update, etc.) are performed without proper safeguards.

B13: All data migrations include rollback or reversal mechanisms as specified.

B14: No unguarded database queries or file operations are present in the implementation.

### Acceptance Criteria

B15: All acceptance criteria for Phase 1 tasks are satisfied in the implementation.

B16: All acceptance criteria for Phase 2 tasks are satisfied in the implementation.

B17: All acceptance criteria for Phase 3 tasks are satisfied in the implementation.

### Out-of-Scope

B18: All items explicitly marked as out-of-scope in the PRD are absent from the implementation.

B19: No features or functionality mentioned in the PRD as out-of-scope are present in the codebase the reviewer inspected.

## Your Job

Read the actual codebase and verify against the spec above.
You have NO implementation context. Find the code yourself.

**Check for:**

1. **Spec compliance** — Every requirement implemented? Anything
   extra? Requirements misinterpreted?

2. **Security and deployment readiness** — Secrets with empty
   defaults? Missing auth checks? Fail-open paths? Race conditions
   (check-then-act)?

3. **Data safety** — Backward compatibility? Migration paths?
   Malformed/missing data handling?

4. **Missing error paths** — Token expiry, network failure, partial
   writes? Retry and recovery?

**IMPORTANT: If you cannot find implementation files, you MUST still
produce a full report.** Enumerate every spec requirement, flag every
security concern derivable from the spec. "Code not found" is a
Critical finding, not a reason to stop.

OUTPUT FORMAT IS MANDATORY. Follow exactly:

```
[BLAKE] {emoji} {description} | File: {path or "N/A"} | Task: {id or "general"}
```

**Severity emojis:** 🔴 Critical, 🟠 High, 🟡 Medium, ⚪ Low

**Rules:**
- One issue per line
- Use "N/A" for file if issue is architectural/cross-cutting
- Use "general" for task if issue spans multiple tasks or is a PRD gap
- If zero issues found: `[BLAKE] ✅ No issues found`

PER-RULE VERDICTS ARE MANDATORY. For every rule in The Rubric above, emit one line:
B{n}: pass   or   B{n}: fail
(one rule per line, no other text on the line, no rationale; a rule you
cannot evaluate counts as fail; never omit the line; never renumber).

## Test-run note (this repo)

`cargo test-ci` and the unfiltered `cargo test -p ddb-core --lib` exceed 10
minutes here (the `sql_engine` tier). Prefer targeted runs:
`cargo test -p ddb-core --lib bundle::`, `... sync_manager::`, `... id_minting::`,
or `cargo test -p ddb-core --lib -- --skip sql_engine` for near-full core coverage
(1102 tests, ~6 min). Live CLI experiments belong in a temp directory, never in
the project root.
