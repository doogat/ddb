Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-context-00169-c2.md for review context, and /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00169-c2.diff for the full diff.

Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/engram-pack-00169-c2.md and treat its full content as prepended context: similar code, reuse precedent, findings precedent, and task prose for this diff's changed symbols.

Use this review checklist:

# Review Dimensions

Detailed checklist for reviewing completed work.

## Plan Compliance

- [ ] Implementation matches task description
- [ ] All acceptance criteria met
- [ ] No scope creep (extra features not requested)
- [ ] No missing pieces from original task

## PRD Coverage

- [ ] All "must have" requirements addressed
- [ ] Success metrics achievable with implementation
- [ ] No PRD sections left unimplemented
- [ ] Dependencies correctly handled

## Simplification

Hunt actively for simplification — do not just tick boxes. The diff under
review is fresh; this is the cheapest moment to cut complexity before it sets.
For every added or changed file, ask "what would make this simpler to read
without changing what it does?" and flag concrete opportunities.

- [ ] **Reduce complexity** — no needless indirection, dead branches, or
      abstractions built for a single caller; nesting <= 4 levels; functions
      under 50 lines
- [ ] **Eliminate redundancy** — no logic duplicated within the diff or against
      existing code; no helper that reimplements a stdlib or existing utility
- [ ] **Improve naming** — names state intent; no opaque abbreviations;
      action-named functions start with a verb
- [ ] **Follow project standards** — conventions from CLAUDE.md / AGENTS.md and
      the surrounding code; no style drift
- [ ] **No dead code** — no commented-out blocks, unused imports, variables, or
      speculatively-added parameters
- [ ] **Appropriate error handling** — explicit, never silently swallowed

**How to flag a simplification:** give the file:line, the current shape, and
the simpler replacement. Flag concrete behavior-preserving simplifications at
🟡 Medium so the decision gate routes them into the rework loop. Do not inflate
them to 🟠 High; that floods the rework loop and can trip the scope alarm.

**Balance — do not over-simplify:** never propose a change that trades clarity
for brevity, drops error handling, collapses a deliberate boundary, or removes
a documented invariant. Simpler means easier to read and maintain, not shorter
at any cost. If a "simplification" would change behavior, it is out of scope —
do not flag it.

## Testing

- [ ] Unit tests for new logic
- [ ] Edge cases covered
- [ ] Error paths tested
- [ ] Integration tests if crossing boundaries
- [ ] Tests actually run and pass

## Security

- [ ] No hardcoded secrets
- [ ] Input validation at boundaries
- [ ] No SQL/command injection risks
- [ ] Auth/authz correctly applied
- [ ] Sensitive data not logged

## Documentation

- [ ] Public APIs documented
- [ ] Complex logic has comments
- [ ] README updated if needed
- [ ] Breaking changes noted

In addition, work through the numbered rubric:

# Review-Work-Completion Rubric

This rubric defines binary pass/fail criteria for consensus review of completed work. Each rule is numbered and stable for tracking coverage. Reviewers must answer "R{n}: pass|fail" for every rule in their prompt.

## Rules

### Tests

R1: Tests cover every new behavior introduced by the diff.
R2: Tests bind to intent, not just observable behavior.
R3: No skipped or xfail tests mask failures.

### Integration

R4: Changed components integrate with existing callers.

### Security

R6: No hardcoded secrets in the codebase.
R7: All user input is validated and sanitized.
R8: No injection-unsafe queries or commands.

### Domain

R9: Implementation matches PRD feature behavior exactly.
R10: Error handling is explicit and not swallowed.
R11: No debug statements, TODOs, or placeholder markers remain.

### Code Quality

R12: Function sizes respect the 50-line limit.
R13: File sizes respect the 800-line limit.

Review the completed work against PRD requirements. Explore the codebase as needed.

OUTPUT FORMAT IS MANDATORY. Follow exactly:

## Agent Output Format

Each agent outputs issues in this exact format:

```
[{AGENT_NAME}] {emoji} {description} | File: {path or "N/A"} | Task: {id or "general"}
```

**Severity emojis:** 🔴 Critical, 🟠 High, 🟡 Medium, ⚪ Low

**Rules:**
- One issue per line
- Use "N/A" for file if issue is architectural/cross-cutting
- Use "general" for task if issue spans multiple tasks or is a PRD gap
- If zero issues found: `[{AGENT_NAME}] ✅ No issues found`

**Examples:**
```
[ALICE] 🔴 SQL injection in query builder | File: src/db/query.ts | Task: 3
[BOB] 🟠 Missing error handling strategy | File: N/A | Task: general
[CARL] 🟡 PRD section 2.3 not implemented | File: N/A | Task: 5
```

YOUR AGENT NAME IS **CARL**. Every issue line must start with `[CARL]`.

PER-RULE VERDICTS ARE MANDATORY. For every rule in the numbered rubric, emit one line:
R{n}: pass   or   R{n}: fail
(one rule per line, no other text on the line, no rationale).

## Frontend & Design Focus

You still review every dimension in the checklist, but you are the panel's
frontend and design specialist. On any UI, component, styling, or
user-facing change, review with extra depth:

- Accessibility: semantic markup, keyboard navigation, focus management,
  ARIA usage, colour contrast, screen-reader labels.
- Responsive behaviour: layout across breakpoints, overflow, touch targets.
- Visual consistency: design-token usage, spacing/typography scale, reuse
  of existing components over one-off styling.
- UX correctness: loading/empty/error states, form validation feedback,
  no layout shift, sensible defaults.
- Component structure: state vs props boundaries, no prop drilling,
  composability, no duplicated markup.

If the change has no frontend surface, review it as a generalist against
the shared checklist - do not invent frontend findings.

(There is no frontend surface in this diff — it is Rust indexer/CLI code, shell
and PowerShell test scripts, and markdown docs. Review as a generalist.)

---

## This is an INCREMENTAL review (cycle 2 of cap 2)

This is an **incremental review** of the rework done since the previous review cycle — the diff is scoped to changes since then (`f00c4839..28dda73`, 14 commits, 15 files, +1206/-188). Two jobs: (1) for each prior finding listed below, verify it is now resolved in the code; (2) review the scoped diff for any regression the rework introduced. You need not re-review unchanged code; the previous cycle already reviewed the full implementation.

**This is the LAST cycle.** `rework_cap` is 2. Findings you raise now either get fixed in a final sweep (Medium/Low), get deferred with a written reason (High), or stall the PRD (Critical). Calibrate severity honestly — do not inflate to force attention, and do not suppress a real defect because the cycle is closing.

**Note on your cycle-1 CRITICAL:** you claimed the loser's drop deletes tables the winner is using. That was verified against source and REFUTED at severity — `_guard` is bound at function scope and held across the drop loop, the `SCHEMA_DDL` recreate, and the `user_version` stamp. You were describing the pre-fix shape that commit `0537b18` had already removed. The *missing regression test* half of your finding was real, carried the review's highest agreement, and is task 17 in this diff. Verify that test rather than re-raising the refuted claim.

### Prior-cycle findings ROUTED TO REWORK — verify each is now closed

1. 🟠 HIGH — A modified doogat that becomes malformed is skipped without removing its previously indexed base/materialized rows, leaving stale content queryable after HEAD is marked current. `ddb-core/src/indexer/rebuild.rs:120`. → task 15.
2. 🟡 — `summarize_reindex_warnings` mislabels (takes `warnings[0]` regardless of variant, so an advisory `CrossZoneDuplicate`/`MissingRequired` for a *successfully indexed* file gets labelled `REINDEX_SKIPPED_FILES`), miscounts (`warnings.len() - 1` with no dedup, so one poison file renders "(+1 more)" naming a file that does not exist), and points at `ddb doctor`, which is not a command. `ddb-core/src/app_contract/output.rs`. → task 16.
3. 🟡 (4/5 consensus) — The schema-upgrade lock-scope fix (`0537b18`) has no discriminating regression test; the deterministically-testable half is the post-lock `read_needs_drop` re-check at `indexer/mod.rs:212-217`. Also: the cold-start e2e compares reported IDs only with git HEAD and never directly verifies the SQLite row count. → task 17.
4. 🟡 (3/5 consensus, YOURS) — The rebuild-lock acquisition block is duplicated verbatim three times (`configure_connection`, `locked_rebuild`, `locked_explicit_rebuild`); `batch_index_changes` duplicates the read/parse/strict/warning state machine across batch and singleton branches and exceeds 50 lines; `indexer/mod.rs` crossed the 800-line cap. → task 18. **The extraction must be behavior-preserving — check the guard lifetime especially, since shortening it is exactly the bug `0537b18` fixed.**
5. 🟡 — `ddb reindex` prints only "N warning(s)"; skipped paths reach the user only via tracing stderr, so `RUST_LOG=error` names nothing. And no test asserted the CLI `AppWarning` leg (`write_warnings` → stderr on `ddb create`). → task 19.
6. 🟡 (3/5 consensus) — Docs: `invariants.md` I5 overstates the envelope scope; `docs/src/technical/indexer.md` shows the obsolete two-argument `incremental_reindex` signature and omits collect-and-skip/strict, the schema-version stamp, and the 256 KiB frontmatter cap; CHANGELOG omits the compile-breaking `ConsistencyWarning::UnreadableFile` addition. → task 20.

## Settled decisions — do not re-raise

These calls were already made in an earlier cycle of this same review, with the reasons given. Do not re-raise them. Raise a NEW finding only if you can show the settled reason no longer holds.

- **settled-deferral / high / `ddb-core/src/service/search.rs`** — the "create AND search both carry a skip AppWarning" criterion is unmet for search and every verb except create/update/apply_schema. Reason: confirmed real, deliberately narrowed at design time, owned by backlog PRD 00176; also unimplementable as literally written because the warning is consume-once. The overstated `invariants.md` I5 wording was corrected in this cycle's rework.
- **settled-deferral / high / `ddb-core/src/parser/mod.rs`** — the 256 KiB cap bounds parse cost, not read cost. Reason: inherent to git2's blob model (the blob is fully materialized before ddb sees it); a real fix needs a streaming blob reader, a separate PRD.
- **settled-deferral / high / `ddb-server/src/read_pool.rs`** — ReadPool bypasses freshness and rebuild-lock coordination. Reason: an explicitly accepted residual gap, named in the design doc's Risks and in `invariants.md` I10.
- **settled-deferral / low / `ddb-core/src/ffi/driver.rs`** — unbounded warning-message strings. Reason: accepted residual, documented in the design doc's Risks before implementation began.
- **settled-deferral / low / `ddb-core/src/app_contract/output.rs`** — free summarizing functions instead of a `From` impl. Reason: deliberate; a 1:1 `From` contradicts the PRD's own "single summary AppWarning" mitigation.
- **settled-deferral / low / `tests/smoke.sh`** — pre-existing `! $DDB` errexit false-pass idioms in untouched sections. Reason: outside this diff's surgical scope; deserves a dedicated sweep PRD.
- **settled-deferral / medium / `ddb-core/src/indexer/tests/mod.rs`** — the test module is a 6,000+ line monolith. Reason: already 4,354 lines before this PRD; splitting it is a wide refactor disproportionate to this cycle.
- **settled-deferral / medium / `tests/e2e/common.rs`** — e2e flake attribution unproven. Reason: proving it needs two full e2e runs at the base commit, which is Tier 2 work.
- **settled-deferral / medium / `tests/integration.sh`** and **`tests/integration.ps1`** — the new sections have never executed locally. Reason: Tier 2 execution is delegated to CI by this repo's Definition of Done, and no `pwsh` resolves on this host.
- **discarded / critical / N/A** — your own "loser's drop deletes tables the winner is using" claim (see the note above).
- **discarded / low / N/A** — "cannot statically verify Tier 1 gates" boilerplate.

## Mechanical facts (computed, do not re-count)

File line counts at HEAD `28dda73`, from `wc -l`. Cite these for countable file-size claims; a finding that contradicts this block is discarded at the review gate. (Per-function line counts are NOT computed for this Rust repo — count those yourself and show your work.)

- `ddb-core/src/indexer/mod.rs` — 788 lines (was 837 at cycle 1; the 800 cap is met)
- `ddb-core/src/indexer/rebuild.rs` — 613 lines
- `ddb-core/src/indexer/schema_version.rs` — 83 lines (new file)
- `ddb-core/src/app_contract/output.rs` — 357 lines
- `ddb-core/src/indexer/tests/mod.rs` — 6784 lines (pre-existing monolith, settled above)

## Known state the build session reported — raise these only if the report is WRONG

- `incremental_reindex`'s `strict: bool` is never `true` on any user-facing path: one production call site passes `false`, and `reindex_strict()` routes through `locked_explicit_rebuild → rebuild_strict`. Only tests exercise the parameter.
- OPEN, carried from task 15's per-task review: `evict_doogats(&to_delete)` runs BEFORE `batch_index_changes`, so a **strict** run over a change-set containing BOTH a deletion AND a poison file applies the deletion and then errors. Pre-existing since `e5ec64a`. One-line fix available: fold both eviction sites into one call after `batch_index_changes`. **Judge whether that is acceptable to ship.**
- `tests/smoke.ps1` section 33 was REVIEWED, NOT EXECUTED (no `pwsh` on this host).
- `Index::drop_all_tables` (`indexer/mod.rs`) is a near-copy of the drop loop now in `indexer/schema_version.rs`; the only difference is where `PRAGMA foreign_keys = OFF` sits. Flagged, deliberately not unified. **Judge whether leaving both is right.**
- Task 17's re-check test carries an anti-vacuity guard, but a residual timing gap remains: a waiter thread that never reaches its pre-check would also read as "parked". Accepted on the grounds the test was proven discriminating twice.

## Tier 1 gate results at HEAD `28dda73`

`cargo build` OK · `cargo clippy --workspace --all-targets` clean · `cargo test-ci` (ddb-core 1549 passed, ddb-server 222 passed) · `cargo test -p ddb-e2e` 451 passed · `bash tests/smoke.sh` all-passed · `cd docs && mdbook build` OK. You need not re-run these.
