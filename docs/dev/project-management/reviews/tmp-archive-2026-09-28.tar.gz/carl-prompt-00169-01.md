Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-context-00169-01.md for review context, and /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00169-01.diff for the full diff.

Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/engram-pack-00169-01.md and treat its full content as prepended context: similar code, reuse precedent, findings precedent, and task prose for this diff's changed symbols.

Use this review checklist:

# Review Dimensions

Detailed checklist for reviewing completed work.

## Plan Compliance

- [ ] Implementation matches task description
- [ ] All acceptance criteria met
- [ ] No scope creep (extra features not requested)
- [ ] No missing pieces from original task

## PRD Coverage

- [ ] All "must have" requirements addressed
- [ ] Success metrics achievable with implementation
- [ ] No PRD sections left unimplemented
- [ ] Dependencies correctly handled

## Simplification

Hunt actively for simplification — do not just tick boxes. The diff under
review is fresh; this is the cheapest moment to cut complexity before it sets.
For every added or changed file, ask "what would make this simpler to read
without changing what it does?" and flag concrete opportunities.

- [ ] **Reduce complexity** — no needless indirection, dead branches, or
      abstractions built for a single caller; nesting <= 4 levels; functions
      under 50 lines
- [ ] **Eliminate redundancy** — no logic duplicated within the diff or against
      existing code; no helper that reimplements a stdlib or existing utility
- [ ] **Improve naming** — names state intent; no opaque abbreviations;
      action-named functions start with a verb
- [ ] **Follow project standards** — conventions from CLAUDE.md / AGENTS.md and
      the surrounding code; no style drift
- [ ] **No dead code** — no commented-out blocks, unused imports, variables, or
      speculatively-added parameters
- [ ] **Appropriate error handling** — explicit, never silently swallowed

**How to flag a simplification:** give the file:line, the current shape, and
the simpler replacement. Flag concrete behavior-preserving simplifications at
🟡 Medium so the decision gate routes them into the rework loop. Do not inflate
them to 🟠 High; that floods the rework loop and can trip the scope alarm.

**Balance — do not over-simplify:** never propose a change that trades clarity
for brevity, drops error handling, collapses a deliberate boundary, or removes
a documented invariant. Simpler means easier to read and maintain, not shorter
at any cost. If a "simplification" would change behavior, it is out of scope —
do not flag it.

## Testing

- [ ] Unit tests for new logic
- [ ] Edge cases covered
- [ ] Error paths tested
- [ ] Integration tests if crossing boundaries
- [ ] Tests actually run and pass

## Security

- [ ] No hardcoded secrets
- [ ] Input validation at boundaries
- [ ] No SQL/command injection risks
- [ ] Auth/authz correctly applied
- [ ] Sensitive data not logged

## Documentation

- [ ] Public APIs documented
- [ ] Complex logic has comments
- [ ] README updated if needed
- [ ] Breaking changes noted

In addition, work through the numbered rubric:

# Review-Work-Completion Rubric

This rubric defines binary pass/fail criteria for consensus review of completed work. Each rule is numbered and stable for tracking coverage. Reviewers must answer "R{n}: pass|fail" for every rule in their prompt.

## Rules

### Tests

R1: Tests cover every new behavior introduced by the diff.
R2: Tests bind to intent, not just observable behavior.
R3: No skipped or xfail tests mask failures.

### Integration

R4: Changed components integrate with existing callers.

### Security

R6: No hardcoded secrets in the codebase.
R7: All user input is validated and sanitized.
R8: No injection-unsafe queries or commands.

### Domain

R9: Implementation matches PRD feature behavior exactly.
R10: Error handling is explicit and not swallowed.
R11: No debug statements, TODOs, or placeholder markers remain.

### Code Quality

R12: Function sizes respect the 50-line limit.
R13: File sizes respect the 800-line limit.

(Note: there is no R5 — the set is R1-R4 and R6-R13, twelve rules. Emit exactly those twelve verdict lines, do not invent an R5.)

Review the completed work against PRD requirements. Explore the codebase as needed.

OUTPUT FORMAT IS MANDATORY. Follow exactly:

## Agent Output Format (Single Source of Truth)

Each agent outputs issues in this exact format:

```
[{AGENT_NAME}] {emoji} {description} | File: {path or "N/A"} | Task: {id or "general"}
```

**Severity emojis:** 🔴 Critical, 🟠 High, 🟡 Medium, ⚪ Low

**Rules:**
- One issue per line
- Use "N/A" for file if issue is architectural/cross-cutting
- Use "general" for task if issue spans multiple tasks or is a PRD gap
- If zero issues found: `[{AGENT_NAME}] ✅ No issues found`

**Examples:**
```
[ALICE] 🔴 SQL injection in query builder | File: src/db/query.ts | Task: 3
[BOB] 🟠 Missing error handling strategy | File: N/A | Task: general
[CARL] 🟡 PRD section 2.3 not implemented | File: N/A | Task: 5
```

YOUR AGENT_NAME IS `CARL`. Every issue line must start with `[CARL]`.

PER-RULE VERDICTS ARE MANDATORY. For every rule in the numbered rubric, emit one line:
R{n}: pass   or   R{n}: fail
(one rule per line, no other text on the line, no rationale).

## Frontend & Design Focus

You still review every dimension in the checklist, but you are the panel's
frontend and design specialist. On any UI, component, styling, or
user-facing change, review with extra depth:

- Accessibility: semantic markup, keyboard navigation, focus management,
  ARIA usage, colour contrast, screen-reader labels.
- Responsive behaviour: layout across breakpoints, overflow, touch targets.
- Visual consistency: design-token usage, spacing/typography scale, reuse
  of existing components over one-off styling.
- UX correctness: loading/empty/error states, form validation feedback,
  no layout shift, sensible defaults.
- Component structure: state vs props boundaries, no prop drilling,
  composability, no duplicated markup.

If the change has no frontend surface, review it as a generalist against
the shared checklist - do not invent frontend findings.

(For this diff: there is NO frontend surface. This is a Rust workspace —
indexer, parser, service, FFI, CLI, and shell/PowerShell test scripts. Review
as a generalist. The nearest thing to a user-facing surface is the `ddb reindex
--strict` CLI flag, its stderr warning output, and the GraphQL warnings
extension — judge those for UX correctness of the messages and exit codes.)

---

# THREE THINGS THIS REVIEW SHOULD SCRUTINISE HARDEST

The build session recorded these deliberately, so they are not hidden from you.
They are leads, not conclusions — confirm or refute each against the source.

1. **A KNOWN-UNMET FAIL-FIRST OBLIGATION.** Task 8 fixed a CRITICAL (commit
   `0537b18`: the rebuild-lock guard was moved out of the `if needs_drop` block
   so it now lives across drop + recreate + version stamp) and shipped it with
   NO regression test. The repo rule (`rules/testing.md`) requires a bug fix to
   ship with a test watched failing against the old code. Task 14 settled this
   as an ACCEPTED GAP, arguing that nothing writes rows between the drop and the
   stamp, so a loser in that window only drops and recreates EMPTY tables —
   leaving an end state indistinguishable from correct, which means no test can
   discriminate the fixed shape from the buggy one. The gap is bound only by a
   comment at `ddb-core/src/indexer/mod.rs:190-210`. **Challenge that argument.**
   It is the weakest load-bearing claim in this PRD.

2. **PRE-EXISTING E2E FLAKINESS.** A full `cargo test -p ddb-e2e` failed 1 of
   451 on each of two runs — a DIFFERENT test each time
   (`typed_where_filter_completeness`, then `serve::execute_batch_format_objects`
   with a reqwest ConnectionRefused). Both pass in isolation. Believed to be port
   contention / server-readiness under 451-way parallelism, NOT caused by this
   PRD. Judge whether that attribution holds.

3. **A RECURRING FALSE-PASS CLASS — it bit three times in this PRD.** Any
   assertion that reads back through a CLI or GraphQL path first calls
   `ensure_fresh`, which self-heals a stale or dropped index before answering —
   so the assertion cannot fail. It was caught in task 11's smoke assertion,
   avoided in task 12, and caught AGAIN by the per-task reviewer in task 14's
   e2e (removed in `f00c483`). Look for any remaining instance. Note also that
   `tests/smoke.sh` still uses the bare `! $DDB ...` idiom in several
   PRE-EXISTING sections; bash exempts a `!`-inverted command from `errexit`,
   which is the same false-pass risk, left alone under the surgical-changes rule.
