Portfolio freshness: NOT refreshed this cycle (PRD 00002 pending)

8 changed symbol(s) omitted (beyond the 40-symbol cap).

## Similar code

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/tests/property_tests.rs:603-635
  impl DoogatSource for MockStore {
    fn list_doogats(&self) -> ddb_core::error::Result<Vec<String>> {
        let mut paths: Vec<String> = self
            .files
            .borrow()
            .keys()
            .filter(|p| p.starts_with("ddb/") && p.ends_with(".md"))
            .cloned()
            .collect();
        paths.sort();
        Ok(paths)
    }

    fn read_file(&self, path: &str) -> ddb_core::error::Result<String> {
        self.files
            .borrow()
            .get(path)
            .cloned()
            .ok_or_else(|| ddb_core::error::DoogatError::NotFound(path.to_string()))
    }

    fn head_oid(&self) -> ddb_core::error::Result<CommitHash> {
        Ok(CommitHash(self.head.clone()))
    }

    fn diff_paths(
        &self,
        _old_oid: &str,
        _new_oid: &str,
    ) -> ddb_core::error::Result<Vec<(DiffKind, String)>> {
        Ok(Vec::new())
    }
}

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/tests/property_tests.rs:1699-1729
  impl DoogatSource for MockSource {
    fn list_doogats(&self) -> ddb_core::error::Result<Vec<String>> {
        let mut paths: Vec<String> = self
            .files
            .keys()
            .filter(|p| p.starts_with("ddb/") && p.ends_with(".md"))
            .cloned()
            .collect();
        paths.sort();
        Ok(paths)
    }

    fn read_file(&self, path: &str) -> ddb_core::error::Result<String> {
        self.files
            .get(path)
            .cloned()
            .ok_or_else(|| ddb_core::error::DoogatError::NotFound(path.to_string()))
    }

    fn head_oid(&self) -> ddb_core::error::Result<CommitHash> {
        Ok(CommitHash(self.head.clone()))
    }

    fn diff_paths(
        &self,
        _old_oid: &str,
        _new_oid: &str,
    ) -> ddb_core::error::Result<Vec<(ddb_core::types::DiffKind, String)>> {
        Ok(Vec::new())
    }
}

## Reuse precedent

- gems:/Users/bob/git/src/github.com/buvis/gems/src/rust/src/parser/key_normalizer.rs:38-65
  mod tests {
    use super::*;

    #[test]
    fn test_simple_lowercase() {
        assert_eq!(as_note_field_name("title"), "title");
    }

    #[test]
    fn test_camel_case() {
        assert_eq!(as_note_field_name("SomeValue"), "some-value");
    }

    #[test]
    fn test_space_separated() {
        assert_eq!(as_note_field_name("Note Title"), "note-title");
    }

    #[test]
    fn test_already_kebab() {
        assert_eq!(as_note_field_name("some-value"), "some-value");
    }

    #[test]
    fn test_mixed() {
        assert_eq!(as_note_field_name("zkn-id"), "zkn-id");
    }
}

- claude-warden:/Users/bob/git/src/github.com/buvis/claude-warden/src/__tests__/glob.test.ts:4-87
  describe('globToRegex', () => {
  it('* matches any string', () => {
    const re = globToRegex('staging-*');
    expect(re.test('staging-1')).toBe(true);
    expect(re.test('staging-foo-bar')).toBe(true);
    expect(re.test('production-1')).toBe(false);
  });

  it('? matches single character', () => {
    const re = globToRegex('dev?');
    expect(re.test('dev1')).toBe(true);
    expect(re.test('devA')).toBe(true);
    expect(re.test('dev')).toBe(false);
    expect(re.test('dev12')).toBe(false);
  });

  it('[abc] character class', () => {
    const re = globToRegex('app-[abc]');
    expect(re.test('app-a')).toBe(true);
    expect(re.test('app-c')).toBe(true);
    expect(re.test('app-d')).toBe(false);
  });

  it('[!abc] negated character class', () => {
    const re = globToRegex('app-[!abc]');
    expect(re.test('app-d')).toBe(true);
    expect(re.test('app-a')).toBe(false);
  });

  it('{a,b,c} brace expansion', () => {
    const re = globToRegex('{dev,staging,prod}-server');
    expect(re.test('dev-server')).toBe(true);
    expect(re.test('staging-server')).toBe(true);
    expect(re.test('prod-server')).toBe(true);
    expect(re.test('test-server')).toBe(false);
  });

  it('unmatched { is escaped', () => {
    const re = globToRegex('test{foo');
    expect(re.test('test{foo')).toBe(true);
    expect(re.test('testfoo')).toBe(false);
  });

  it('regex metacharacters are escaped', () => {
    const re = globToRegex('file.txt');
    expect(re.test('file.txt')).toBe(true);
    expect(re.test('fileXtxt')).toBe(false);
  });

  it('anchored with ^...$', () => {
    const re = globToRegex('foo');
    expect(re.test('foo')).toBe(true);
    expect(re.test('foobar')).toBe(false);
    expect(re.test('barfoo')).toBe(false);
  });

  it('* matches across path separators (not path-aware)', () => {
    const re = globToRegex('*.internal.company.com');
    expect(re.test('staging.internal.company.com')).toBe(true);
    expect(re.test('deep.staging.internal.company.com')).toBe(true);
  });

  it('empty string matches only empty string', () => {
    const re = globToRegex('');
    expect(re.test('')).toBe(true);
    expect(re.test('a')).toBe(false);
  });

  it('consecutive *** treated as single *', () => {
    const re = globToRegex('foo***bar');
    expect(re.test('foo-anything-bar')).toBe(true);
    expect(re.test('foobar')).toBe(true);
  });

  it('unclosed [ produces invalid regex and throws', () => {
    expect(() => globToRegex('test[abc')).toThrow();
  });

  it('literal ] outside character class is escaped', () => {
    const re = globToRegex('foo]bar');
    expect(re.test('foo]bar')).toBe(true);
    expect(re.test('foobar')).toBe(false);
  });
});

- claude-warden:/Users/bob/git/src/github.com/buvis/claude-warden/src/script-eval.ts:225-225
    if (args.some(a => /^-[a-z]*i/.test(a))) {

- claude-warden:/Users/bob/git/src/github.com/buvis/claude-warden/dist/cli.cjs:10053-10055
    set test(v) {
    this.#test = v ?? void 0;
  }

## Findings precedent

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00168-bundle-import-conflict-recovery-v1-review-02.md
  (clean), `cargo test -p ddb-core --lib bundle::` (15 passed), `... sync_manager::`

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00168-bundle-import-conflict-recovery-v1-review-02.md
  (`git show 35e594e:ddb-core/src/bundle.rs` lines 141-157 vs `bundle/mod.rs:187-204`);

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00168-bundle-import-conflict-recovery-v1-review-02.md
  `cargo test -p ddb-core --lib` both exceed the 10-minute per-call ceiling in this repo

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00168-bundle-import-conflict-recovery-v1-review-02.md
  - Calendar validation duplicates standard functionality incompletely — ddb-core/src/types/doogat.rs:19 — implement the test helper with `chrono::NaiveDateTime::parse_from_str`

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00165-deterministic-crdt-resolution-v1-review-01.md
  [BOB] ⚪ New test file uses decorative non-ASCII comment rulers with no value. | File: ddb-core/tests/crdt_determinism.rs | Task: 2

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  - **[Alice, Carl, Quinn] `tests.rs` (963) and `mod.rs` (846) exceed the 800-line style guideline; the merge test (~88 lines) exceeds the 50-line function guideline.** `mod.rs` overage is pre-existing (846 at work-start, 2 lines changed here); `tests.rs` crossed 800 due to this PRD's test additions (767→963). Not a CI gate (clippy clean; test-ci passes). Reviewers agree the concurrency test should not be force-split. → **Deferred**: soft style guideline on test/pre-existing files; a `git_ops` test-file split is a reasonable future cleanup, out of scope for a surgical P0 fix.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  - The slice is **pre-existing** (old code did `filename[..14].chars()`), but this PRD edited this exact line (swapped the predicate to `DoogatId::is_valid_shape`), and it touches the AGENTS.md P0 "no runtime panics in library code on filesystem/user-input state" class. Quinn's proposed `filename.get(..14).filter(|s| DoogatId::is_valid_shape(s))` is panic-safe AND removes his redundant-guard finding in one change. Reachable only via a hand-crafted non-conforming filename (real doogats are 14 ASCII digits, always a char boundary), so downgraded from Carl's 🔴 to 🟠.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  - **[1/5] ⚪ parser tightening makes `meta.id=None` more reachable; indexer stores such docs as `id=""`** (Blake, `parser/mod.rs`) — **verified**: `indexer/mod.rs:257`, `materialize.rs:448`, `rebuild.rs:222` do `meta.id...unwrap_or("")`, so two id-less (malformed/non-native) files collide at `id=""` under `INSERT OR REPLACE`. Pre-existing indexer behavior; index is derived/rebuildable (git is source of truth). Deferred as a hardening follow-up (relates to 00169 poison-file-reindex-resilience).

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  [BLAKE] ⚪ `install_bundled_type` skips the `ensure_fresh()` other create paths run; mint safe (oracle reads HEAD), but subsequent `index_doogat` proceeds against a possibly-stale index. Asymmetry, not a defect. | File: ddb-core/src/service/discovery.rs | Task: general

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  [BOB] 🟡 The repo-only SQL regression seeds `Local::now()` then mints; if the second rolls between commit and mint, an old index-only impl can pass without testing the intended collision. | File: ddb-core/src/sql_engine/tests.rs | Task: 4

## Task prose

### Batch 202607161128 (autopilot, IN PROGRESS — started 2026-07-16)

- [x] **00163 git-tree-construction-correctness-v1** (DONE 2026-07-17, in `done/`) — delete-freshness + merge-lock legs of the git write-path data-loss class.
- [x] **00200 make-merge-tree-three-way-v1** (DONE 2026-07-18, in `done/`) — true three-way conflicted-merge tree (Alternative B), closing the last data-loss leg.
- [x] **00164 unify-id-minting-v1** (DONE 2026-07-18, in `done/`) — one repo-aware existence oracle for all mint paths.
- [x] **00165 deterministic-crdt-resolution-v1** (DONE 2026-07-18, in `done/`) — content-derived Automerge actor IDs, deterministic list-field ordering.
- [x] **00166 make-hlc-load-bearing-v1** (DONE 2026-07-19, in `done/`) — machine-local `HlcClock`, HLC trailer on every write, unified `lww_pick` tie-break.
- [x] **00167 sync-collision-reassignment-atomicity-v1** (DONE 2026-08-15, in `done/`) — folded winner + loser + backlink rewrites into one atomic `commit_merge`, loser ID derive

# Indexer rebuild resilience: poison-file skip and serialized cold-start rebuild

**Priority:** P1 (availability) · **Roadmap:** Phase 1 (availability) · **Depends on:** none (00162 write-lock helper shipped)

> **Merge note (2026-07-13, backlog review):** absorbed 00169b `serialize-cold-start-index-rebuild` — one PRD now owns indexer rebuild resilience: the lenient incremental path (poison files) AND the serialized destructive full-rebuild path (concurrent cold starts).

> **Provenance:** the index schema-version stamp and the frontmatter-size cap were added by the 2026-07-16 assessment (evidence: evolution-assessment-2026-07-16.md L2/L3) and folded into the body's Features/tasks at the 2026-08-14 backlog review. Probe location re-verified at `d77ad58`: `needs_schema_upgrade` at `indexer/mod.rs:159-180`.

## Overview

### Problem Statement
One malformed markdown file makes the whole database unusable through the service. The incremental reindex path is fatal on the first unreadable/
