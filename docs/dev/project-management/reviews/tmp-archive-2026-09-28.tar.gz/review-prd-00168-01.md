# PRD 00168 — Bundle-import conflict recovery (requirements authority)

Source: `dev/local/prds/wip/00168-bundle-import-conflict-recovery-v1.md`

**Priority:** P1 · **Roadmap:** Phase 1 (convergence) · **Depends on:** 00162 (write lock — merge + resolve + ref-delete run inside the write critical section)

## Overview

### Problem Statement
A conflicted bundle import reports success while silently losing the imported data.

- **Conflict detection reads `stderr`, not state.** `merge_bundle_and_resolve` (`ddb-core/src/bundle.rs:113-138`) shells out to `git merge refs/remotes/bundle/master` (`:118-126`) and, on failure, decides conflict-vs-error by **string-matching `stderr`** for `"CONFLICT"` / `"Automatic merge failed"` (`:132-137`). This is locale- and version-fragile, and there is **no** `git merge --abort` anywhere.
- **A conflicted merge is reported as clean success.** A conflicted `git merge` creates **no commit**, so `resolve_post_merge_conflicts` (`sync_manager/mod.rs:883-887`) → `validate_clean_merge_or_fallback` sees `commit_parent_count < 2` (`:544`) and returns `Ok(0)`: the import reports **success with 0 conflicts** while nothing merged.
- **The bundle ref is deleted regardless, pruning the data.** `import_bundle` (`bundle.rs:160-197`) then **unconditionally** deletes `refs/remotes/bundle/master` (`:181-184`), making the unbundled commits unreachable, so auto-gc prunes the offline-synced data.

### Target Users
Multi-device users (jink) syncing offline via bundles; a conflicted import must recover the data through the resolver, not silently discard it.

### Success Metrics
- A conflicted bundle import produces a **real merge commit** via the resolver, reports the **true** conflict count, leaves the bundle data reachable, and never reports false success — pinned by a conflicted-bundle test.
- Conflicts are detected from the **git index / merge state**, never from `stderr` strings — asserted by a test that a locale/wording change in git output does not flip the detection.
- On an unresolvable bundle merge, `git merge --abort` runs and a real `Sync` error surfaces; the repo is left clean (no dangling `MERGE_HEAD`, no partial index) — pinned by a test.
- `refs/remotes/bundle/master` is deleted **only after** a successful merge commit, so unreachable objects never exist for gc to prune — pinned by a reachability test.
- No regression: existing clean-import bundle tests stay green.

## Functional Decomposition

### Capability: Bundle-import conflict recovery

#### Feature: Index-state conflict detection + resolution
- **Description**: bundle-merge conflicts are detected from the git index/merge state and driven through the existing resolver.
- **Inputs**: the unmerged index left by the bundle merge.
- **Outputs**: resolved files committed via `commit_merge`; the true conflict count.
- **Behavior**: read conflicts from the index (unmerged entries / `MERGE_HEAD` presence), not `stderr` strings; run the existing conflict pipeline + `commit_merge`; the returned count reflects real conflicts.

#### Feature: Ref-delete-after-success + abort-on-error
- **Description**: the bundle ref is deleted only after a successful merge commit; any failure aborts and errors.
- **Inputs**: the merge/commit result.
- **Outputs**: bundle data reachable until success; clean repo on error.
- **Behavior**: delete `refs/remotes/bundle/master` only after a real merge commit; on any error run `git merge --abort` (when `MERGE_HEAD` exists, else reset the index) and return a `Sync` error. The merge → resolve → ref-delete sequence runs inside the 00162 write lease.

## Structural Decomposition

```
ddb-core/src/
├── bundle.rs          # merge_bundle_and_resolve (:113-138) index-state detection + --abort; import_bundle (:160-197) delete ref only after success
ddb-core/src/sync_manager/
└── mod.rs             # resolve_post_merge_conflicts (:883-887) / validate_clean_merge_or_fallback (:538-544) stop reporting false success
```

### Module: bundle (ddb-core/src/bundle.rs)
- **Responsibility**: detect conflicts from index/merge state, drive the resolver, delete the bundle ref only after a successful merge, abort + error on failure.
- **Exports**: `merge_bundle_and_resolve`, `import_bundle`

### Module: sync_manager (ddb-core/src/sync_manager/mod.rs)
- **Responsibility**: refuse to report success when no merge commit exists; report the honest count from real merge state.
- **Exports**: `resolve_post_merge_conflicts` - honest count from real merge state

## Implementation Phases

### Phase 0: Foundation
**Goal**: detect conflicts from state, not strings.
- [ ] Replace the `stderr` string-match in `merge_bundle_and_resolve` with index/merge-state detection (unmerged entries / `MERGE_HEAD`) (depends on: 00162) - Acceptance: a conflicted bundle merge is detected from the index; a unit test asserts detection is unaffected by git output wording/locale.

**Exit Criteria**: conflict detection is state-based.

### Phase 1: Core
**Goal**: honest recovery, ref-after-success, abort-on-error.
- [ ] Drive the detected conflicts through the existing conflict pipeline + `commit_merge`; report the true count; delete `refs/remotes/bundle/master` only after a successful merge commit; on any error run `git merge --abort` and return a `Sync` error; run the sequence inside the 00162 write lease (depends on: Phase 0) - Acceptance: a conflicted import produces a real merge commit, reports the true count, keeps bundle data reachable, and never reports false success; on an unresolvable merge the repo is left clean and an error surfaces.

**Exit Criteria**: bundle import recovers or aborts honestly; no false success.

### Phase 2: Integration
**Goal**: prove no data loss and document it.
- [ ] Conflicted-bundle test (true count, no prune, no false success; abort-on-error leaves a clean repo) + a reachability test (bundle data reachable until success); add a bundle-import scenario to `integration.sh`/`.ps1`; author the import-bundle conflict-recovery e2e under `tests/e2e/` (depends on: Phase 1) - Acceptance: all fail against the old code and pass after.
- [ ] Update `docs/src/technical/sync.md` (bundle-import recovery) + CHANGELOG; add/refresh a showboat walkthrough for bundle import (user-facing behavior change) (depends on: Phase 1) - Acceptance: docs + walkthrough landed.

**Exit Criteria**: conflicted-bundle coverage + docs + walkthrough landed.

## Test Strategy

### Critical Scenarios
- **Happy path**: bundle import with no conflicts → Expected: merge commit, bundle ref deleted after success, data reachable, count 0.
- **Edge case**: git emits differently-worded merge output → Expected: state-based detection still fires; the import does not misclassify the conflict as an error or as false success.
- **Error case**: conflicted bundle import → Expected: real merge commit via the resolver, true conflict count, data not pruned; on an unresolvable merge, `git merge --abort` + surfaced error, repo clean.

## Risks

- **CLI git vs libgit2 index**: reading conflicts after a CLI `git merge` mixes toolchains. Mitigation: read conflicts from the shared `.git/index` via libgit2, or route the bundle merge through the existing libgit2 conflict path; detect from state, never `stderr`.
- **`git merge --abort` preconditions**: abort requires a merge in progress. Mitigation: abort only when `MERGE_HEAD` exists, else reset the index; test the abort path.
- **Auto-gc timing**: pruning happens on gc, not immediately. Mitigation: keep the bundle ref until success so unreachable objects never exist; test reachability post-import.
- **False-success regression is silent**: the old bug reported `Ok(0)`. Mitigation: the conflicted-bundle test asserts a non-zero true count and a real 2-parent merge commit, so a regression fails loudly.

## Transport Impact

- **CLI**: Guaranteed — the bundle-import path is the primary fix site.
- **GraphQL**: Intentionally absent — bundle import is a CLI/FFI workflow, not a GraphQL surface; noted, not regressed.
- **REST**: Intentionally absent — bundle import is not a REST surface.
- **PgWire**: Intentionally absent — no bundle surface.
- **FFI**: Guaranteed — driver bundle import gains conflict recovery.
- **NoSQL HTTP**: Intentionally absent — read-only document mirror; no bundle surface.
- **Cross-interface conformance plan**: `integration.sh`/`.ps1` bundle scenarios exercise CLI + FFI; a conflicted-bundle test pins true count + no prune + no false success + clean abort; a reachability test pins ref-after-success; `tests/e2e/` covers bundle-import conflict recovery. The one public change: a conflicted bundle import now returns a real error instead of false success (CHANGELOG note).

---

## Design Doc

Source: `dev/local/designs/00168-bundle-import-conflict-recovery-v1-design.md`. This is the implementation design (the HOW), not the spec. The PRD above remains the requirements authority.

### Architecture fit

`ddb-core/src/bundle.rs` (air-gapped import/export) and `ddb-core/src/sync_manager/mod.rs` (conflict resolution orchestration) are both leaves the network-sync path already depends on for the identical merge→resolve→commit shape. `git_ops/merge.rs` (`GitRepo::merge_remote`, `GitRepo::commit_merge`) is the libgit2, write-lock-covered merge engine that `SyncManager::sync` already drives for network sync. This PRD wires the bundle-import leaf onto the SAME engine instead of a second, ad hoc, CLI-shelling implementation — closing the last unlocked write path named in `docs/src/technical/invariants.md` (I1/I2) and memory `project_data_loss_write_path`.

### Module placement

- **Edit** `ddb-core/src/bundle.rs` — replace `merge_bundle_and_resolve`'s CLI `git merge` + `stderr` string-match body with calls into `GitRepo::merge_remote` + `SyncManager::apply_merge_result` (widened to `pub(crate)`). Change its return type from `Result<usize>` to `Result<SyncReport>`. Update `import_bundle` to thread the fuller report through and call the new `delete_remote_ref` instead of the raw CLI `update-ref -d`.
- **Edit** `ddb-core/src/sync_manager/mod.rs` — widen `fn apply_merge_result` to `pub(crate)` (no body change). Only visibility change.
- **Edit** `ddb-core/src/traits.rs` — add one method to the `GitRemote` trait: `fn delete_remote_ref(&self, remote: &str, branch: &str) -> Result<()>;`.
- **Edit** `ddb-core/src/git_ops/remote.rs` — add inherent `GitRepo::delete_remote_ref` (git2, write-lock-covered).
- **Edit** `ddb-core/src/git_ops/mod.rs` — add the one-line delegating arm to `impl crate::traits::GitRemote for GitRepo`.
- **No new files.** No changes to `unbundle_git_objects`, `export_bundle`, `export_full_bundle`, `verify_bundle`, or tar/checksum machinery.

### Interfaces & contracts (as designed)

```rust
// traits.rs — GitRemote gains:
/// Delete a remote-tracking ref (`refs/remotes/{remote}/{branch}`). A no-op (`Ok(())`)
/// if the ref does not exist — deletion is idempotent. Runs inside the write lock.
fn delete_remote_ref(&self, remote: &str, branch: &str) -> Result<()>;
```

```rust
// git_ops/remote.rs
impl GitRepo {
    pub fn delete_remote_ref(&self, remote: &str, branch: &str) -> Result<()> {
        self.with_write_lock(|| {
            let ref_name = format!("refs/remotes/{remote}/{branch}");
            match self.repo.find_reference(&ref_name) {
                Ok(mut reference) => { reference.delete()?; Ok(()) }
                Err(e) if e.code() == git2::ErrorCode::NotFound => Ok(()),
                Err(e) => Err(e.into()),
            }
        })
    }
}
```

```rust
// bundle.rs — rewritten body, new return type
fn merge_bundle_and_resolve(
    repo: &impl GitBackend,
    sync_mgr: &mut SyncManager<impl GitBackend>,
    index: &crate::indexer::Index,
) -> Result<SyncReport> {
    let merge_result = repo.merge_remote("bundle", "master")?;
    sync_mgr
        .apply_merge_result(merge_result, index)
        .map_err(|e| DoogatError::Sync(format!("bundle merge failed: {e}")))
}
```

```rust
// bundle.rs — import_bundle call sites
let mut report = merge_bundle_and_resolve(repo, sync_mgr, index)?;
import_node_registrations(repo, &work_dir)?;
repo.delete_remote_ref("bundle", "master")?;
index.rebuild(repo)?;
report.direction = "bundle-import".to_string();
Ok(report)
```

`commits_transferred`, `resurrected`, and `collisions_reassigned` are no longer hardcoded to `0` — they come from the real `SyncReport` `apply_merge_result` builds.

### Data flow (as designed)

1. `import_bundle` unpacks the tar, verifies checksum, unbundles git objects into `refs/remotes/bundle/master` (unchanged CLI `git bundle unbundle` + `git fetch`).
2. `merge_bundle_and_resolve` calls `repo.merge_remote("bundle", "master")` — same entry point `SyncManager::sync` uses for `origin/master`. Write-locked, `merge_analysis` → fast-forward / already-up-to-date / `perform_normal_merge`. `perform_normal_merge` computes `merge_commits` **entirely in memory** (no worktree write, no `MERGE_HEAD`); on conflict it extracts `Vec<ConflictFile>` from the in-memory index, calls `cleanup_state()` defensively, and returns `MergeResult::Conflicts(conflicts, theirs_oid)`.
3. `apply_merge_result` dispatches: `AlreadyUpToDate`/`FastForward`/`Clean` as network sync does; `Conflicts` → `resolve_merge_conflicts` → CRDT cascade / collision reassignment / LWW → `create_conflict_commit` → `GitRepo::commit_merge` (write-locked, real 2-parent merge commit).
4. Then node registrations import (unchanged), then `repo.delete_remote_ref("bundle", "master")` — only reached on `Ok`.
5. `index.rebuild(repo)`, `report.direction = "bundle-import"`, returned.

On any `Err`, `merge_bundle_and_resolve` maps it to `DoogatError::Sync`, `import_bundle`'s `?` returns immediately — the bundle ref is never deleted and the repo's on-disk state is untouched (no CLI merge ever ran, so there is nothing to abort).

### Alternatives considered

1. **(chosen) Route bundle import through `merge_remote` + `apply_merge_result`.**
2. **Keep the CLI `git merge`, add index-state detection on top.** Rejected: leaves conflict markers in the worktree, needs a real `--abort`/index-reset step, mixes two git toolchains on the same `.git/index`.
3. **Fix only conflict detection in place, keep `Result<usize>`, no `delete_remote_ref`.** Rejected: leaves ref-delete on an unlocked, error-swallowing CLI call, so it would ship 00168 without closing the write-lock invariant gap it is tracked against.

### Risks & edge cases (as designed) — READ THIS BEFORE FLAGGING A MISSING `git merge --abort`

- **PRD-text reconciliation: this design deliberately does NOT literally run `git merge --abort`.** The PRD's Phase 1 task and Test Strategy say "on any error run `git merge --abort`". Under this design there is no CLI `git merge` in the bundle-import path at all, so there is nothing to abort — `merge_commits` computes the merge entirely in memory and never creates `MERGE_HEAD` or touches the worktree on conflict. The PRD's own **Success Metrics** state the observable contract this design satisfies exactly: "the repo is left clean (no dangling `MERGE_HEAD`, no partial index)" and "a real `Sync` error surfaces" — both true here, achieved by never entering a conflicted git-CLI state in the first place. A reviewer checking for the literal words "git merge --abort" should be pointed at this note rather than raising it as a missing-behavior gap.
- **Unrelated-histories merge via `merge_commits` instead of CLI `--allow-unrelated-histories`.** libgit2's core merge has no unrelated-histories refusal gate. The existing test `full_bundle_import_on_new_repo` exercises this shape and stays in the regression set.
- **`apply_merge_result` visibility (`pub(crate)`)** is a small in-crate API widening, not a public/FFI/CLI/server surface change.
- **The two-lock-acquisition gap** (`merge_remote` releases the lock before `apply_merge_result`'s pure CRDT computation, `commit_merge` re-acquires it) **is not new** — it is the gap the already-shipped network `sync()` path has lived with since 00163.
- **`delete_remote_ref` on an absent ref** returns `Ok(())` (`ErrorCode::NotFound` treated as already-satisfied) — idempotent by design.

### Test strategy outline (as designed)

- **Unit** (`bundle.rs` `#[cfg(test)]`): conflicted-bundle test — two repos diverge on the same doogat path from a shared ancestor, node1 exports a bundle, node2 imports it → assert `report.conflicts_resolved > 0`, a real 2-parent merge commit at HEAD, `refs/remotes/bundle/master` gone, resolved content present. Cover both an auto-mergeable-with-conflict case and an add-add collision case.
- **Reachability test**: import a bundle whose merge is forced to fail → assert `refs/remotes/bundle/master` still exists and resolves, and a `DoogatError::Sync` is returned.
- **Clean-repo-on-error test**: same failure injection → assert no `MERGE_HEAD` under `.git/` and no unmerged index entries.
- **Regression**: existing `full_bundle_export_and_verify`, `checksum_verification_catches_tampering`, `full_bundle_import_on_new_repo`, `delta_export_targets_node_and_uses_known_heads`, `delta_export_fails_for_unknown_node` stay green unmodified.
- **Integration** (`tests/integration.sh` + `.ps1`, `=== bundle sync ===` section): a new numbered scenario — two `ddb` CLI instances diverge, export/import a bundle through a real conflict, assert on the reported conflict count and that a second import (no-op) doesn't error.
- **e2e** (`tests/e2e/bundle_import_conflict_recovery.rs`): drives the `ddb` binary end-to-end through export → conflicting local write → import.
- All new/changed tests must fail against the pre-fix code and pass after.

### Design review log (dispatch 1, Claude) — open questions left to implementation time

- `SyncManager::resolve_post_merge_conflicts` becomes an orphaned `pub fn` once its only caller (bundle.rs's old body) is replaced — delete or repurpose, undecided at design time.
- `unbundle_git_objects`'s CLI `git bundle unbundle`/`git fetch` remain unlocked (deliberately out of scope — a side-ref-only leg, not master).
- Collapsing every resolver error (including `DoogatError::Conflict`) into `DoogatError::Sync` matches the PRD's wording but loses the original variant; whether callers need to distinguish "real conflict, retry" from other failures was left to implementation judgment.
