Independent FT-5 review. This is a fresh review session; no driving-session conversation is provided. Static read-only review. Do not edit any file, stage, commit, push, spawn agents, invoke skills that edit, or run cargo/tests/linters/builds. Use Read tools for files and only read-only file-search tools as needed. Do not use Bash in Claude sessions; all named repository files can be opened with Read. The driver exclusively owns command execution and verification. Never read build/review/handoff/state files under dev/local except the exact card and diff paths authorized below, and never read other reviewers' output. Report runtime checks you need, without attempting them. If a rubric is not relevant to this change explain that, without demanding unrelated work. Each finding needs stable id, severity CRITICAL/HIGH/MEDIUM/LOW, file:line, exact evidence, failing input/path/consequence, concrete fix, and in-scope vs pre-existing distinction. Every CRITICAL/HIGH needs proof; unsupported concerns remain MEDIUM. Explicitly state no findings if none; empty output is a failed lane.

Repository: /Users/bob/git/src/github.com/doogat/ddb

Approved spec card (decisions settled):
# FT-5 concurrent single-row updates preserve successful writers

## Goal

Implement settled D2: single-row updates read, merge fields, validate and commit
under the existing re-entrant repo write lock. Every successful writer's
non-overlapping field changes must survive in committed Git state; refusal
must be loud and precede publication. The scope exception in
`dev/local/tmp/FT-5-scope-proposal.md` was approved by the maintainer's
"proceed" on 2026-09-13.

1. Add a required `GitBackend` closure hook, implemented through the existing
   `GitRepo` lock. Preserve object safety; no unsafe unlocked default.
2. Move the authoritative single-row read/modify/commit under that lock,
   preserving SQLite-outer/Git-inner order and existing write semantics.
3. Keep commit-graph and threshold maintenance outside the outermost Git
   lock on this path while preserving counters/configuration/suppression.
4. Add colocated fail-first regressions; un-ignore the existing hazard without
   changing any of its assertions. Document backend compatibility and locking.

## Tests

- tests/e2e/hazard_concurrent_single_row_update.rs::concurrent_field_updates_on_one_doogat_keep_both_fields_or_refuse_loudly
- tests/e2e/integration_write_lock_races.rs (existing regression gate; read-only)
- ddb-core/src/service/update.rs (new colocated single-row concurrent-update
  regressions, checking committed Git content; include typed and untyped
  updates and preserved field semantics where the change creates risk)
- ddb-core/src/git_ops/mod.rs (colocated regressions for the new hook and
  deferred maintenance, including nested/error cleanup as relevant)

## Allowlist

- ddb-core/src/service/update.rs (single-row field update and colocated tests;
  no independent batch/SQL/raw-replacement rewrite)
- ddb-core/src/git_ops/mod.rs (backend hook through existing re-entrant lock;
  defer single-file maintenance beyond the outermost lock; colocated tests)
- ddb-core/src/traits.rs (one required GitBackend lock hook and its rustdoc)
- tests/e2e/hazard_concurrent_single_row_update.rs (only remove #[ignore])
- docs/src/technical/git-ops.md (locking and backend compatibility guidance)
- docs/src/technical/walkthrough.md (changed write data-flow paragraph only)
- CHANGELOG.md (FT-5 Fixed line and required backend compatibility note)

## Read-only context

- AGENTS.md
- CLAUDE.md
- ddb-core/src/service/mod.rs
- ddb-core/src/service/validation.rs
- ddb-core/src/service/write_helpers.rs
- ddb-core/src/service/utility.rs
- ddb-core/src/service/create.rs
- ddb-core/src/service/tests.rs
- ddb-core/src/service/update_facade_tests.rs
- ddb-core/src/service/mock_index_tests.rs
- ddb-core/src/git_ops/write_lock.rs
- ddb-core/src/git_ops/read.rs
- ddb-core/src/git_ops/tests.rs
- ddb-core/src/maintenance.rs
- ddb-core/src/indexer/mod.rs
- ddb-core/src/indexer/materialize.rs
- ddb-core/src/error.rs
- ddb-core/src/types/schema.rs
- tests/e2e/integration_write_lock_races.rs
- ddb-core/tests/hazard_update_unique_clobber.rs
- ddb-core/tests/hazard_raw_create_existing_id.rs
- docs/src/technical/invariants.md
- docs/src/technical/solid.md
- docs/src/technical/clean-architecture.md

## Constraints

D2: single-row update reads inside the write lock; if the lock cannot wrap the
read, expected-OID refusal at commit; loud, never silent. No optimistic-
concurrency application API. The required backend hook is the approved narrow
exception to the original no-public-API wording, with documented external
implementor source compatibility impact.

Preserve per-instance reentrancy, fresh staging, SQLite-outer/Git-inner lock
ordering, and I1-I10. Never acquire the index rebuild lock, BEGIN IMMEDIATE,
network, or subprocess under the Git lock. Freshness checking must stay outside
the Git lock. A concurrent type/schema change must not reuse stale transaction
requirements: re-derive safely or refuse before commit. Preserve SINGLETON,
UNIQUE/FK validation, field routing, warnings, timestamps and successful write
semantics. Capture the update's actual commit identity where stored; never
claim an unrelated current HEAD is this operation's indexed commit.

No new concrete adapter construction, downcast, broad lock redesign, unsafe
code, lock bypass, or silent backend default. Batch update and SQL UPDATE are
out of scope unless covered for free by the same helper. Raw replacement
semantics, mint path, PRD 00206, and every other fast-track item are excluded.
The existing hazard test is the spec: retain every assertion and round.
Add colocated tests before the runtime fix and prove the regression fails.
The driver owns all cargo execution; never run cargo concurrently.

## Gate

- cargo +1.89.0 build
- cargo +1.89.0 clippy --workspace --all-targets -- -D warnings
- cargo +1.89.0 test-ci
- cargo +1.89.0 test -p ddb-core --lib service
- cargo +1.89.0 build -p ddb-cli
- cargo +1.89.0 test -p ddb-e2e --test e2e hazard_concurrent_single_row_update
- cargo +1.89.0 test -p ddb-e2e --test e2e integration_write_lock_races
- cargo +1.89.0 test -p ddb-e2e

Commands run sequentially in the foreground, with preserved logs. The full
e2e command is the plan's explicit batch-end requirement, not a substitution
for the targeted gates. No full-workspace heavy battery. Run pinned rustfmt on
touched files only, mdbook for changed docs, and git diff --check.

## Docs and CHANGELOG

Document the authoritative locked single-row read/modify/commit boundary,
SQLite ordering, deferred maintenance, and required backend hook compatibility
in git-ops.md / CHANGELOG. Update the corresponding walkthrough data-flow
paragraph. No new client setup, wire schema, or repository format.

## Transport impact

- CLI: field updates inherit the core guarantee; original two-process hazard.
- GraphQL: updateDoogat inherits it; existing mixed CLI/server lock test.
- REST: field update inherits the same service path, no wire change.
- PgWire: separate SQL UPDATE implementation remains outside FT-5; no new claim.
- FFI: raw replacement semantics remain intact; no field-merge parity claim.
- NoSQL HTTP: no new independent handler behavior or parity claim.

## Model

opus

Fresh implementor receives tests, allowlist, constraints and read-only context,
not Goal acceptance prose or driving-session history. After the build/gates,
END this session with a review handoff. A fresh review session must run the
complete plan roster, Victor verification, at most one review-driven rework,
and per-finding closure. Do not commit/push before approval. Then push master
including 4fd6052 and verify the exact new HEAD's CI. Stop after FT-5.


For diff-aware reviewers only: read the exact reviewed working-tree snapshot at /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/FT-5-build-ready.diff, based on 4fd60524ca3aed2ff633ee9716b14cd8fb19d035. Inspect surrounding source to verify the path. No prior review findings are supplied.

You are Codex Bob. Apply both the general code review checklist and the complete doubt/de-slop protocol below. STATIC ONLY: file reading/search only, no runtime execution. Do not edit. This prompt contains all task context; do not read any driver's conversation.

# Review Dimensions

Detailed checklist for reviewing completed work.

## Plan Compliance

- [ ] Implementation matches task description
- [ ] All acceptance criteria met
- [ ] No scope creep (extra features not requested)
- [ ] No missing pieces from original task

## PRD Coverage

- [ ] All "must have" requirements addressed
- [ ] Success metrics achievable with implementation
- [ ] No PRD sections left unimplemented
- [ ] Dependencies correctly handled

## Simplification

Hunt actively for simplification — do not just tick boxes. The diff under
review is fresh; this is the cheapest moment to cut complexity before it sets.
For every added or changed file, ask "what would make this simpler to read
without changing what it does?" and flag concrete opportunities.

- [ ] **Reduce complexity** — no needless indirection, dead branches, or
      abstractions built for a single caller; nesting <= 4 levels; functions
      under 50 lines
- [ ] **Eliminate redundancy** — no logic duplicated within the diff or against
      existing code; no helper that reimplements a stdlib or existing utility
- [ ] **Improve naming** — names state intent; no opaque abbreviations;
      action-named functions start with a verb
- [ ] **Follow project standards** — conventions from CLAUDE.md / AGENTS.md and
      the surrounding code; no style drift
- [ ] **No dead code** — no commented-out blocks, unused imports, variables, or
      speculatively-added parameters
- [ ] **Appropriate error handling** — explicit, never silently swallowed

**How to flag a simplification:** give the file:line, the current shape, and
the simpler replacement. Flag concrete behavior-preserving simplifications at
🟡 Medium so the decision gate routes them into the rework loop. Do not inflate
them to 🟠 High; that floods the rework loop and can trip the scope alarm.

**Balance — do not over-simplify:** never propose a change that trades clarity
for brevity, drops error handling, collapses a deliberate boundary, or removes
a documented invariant. Simpler means easier to read and maintain, not shorter
at any cost. If a "simplification" would change behavior, it is out of scope —
do not flag it.

## Testing

- [ ] Unit tests for new logic
- [ ] Edge cases covered
- [ ] Error paths tested
- [ ] Integration tests if crossing boundaries
- [ ] Tests actually run and pass
- [ ] No tautological test — every new or changed test fails against the
      pre-change code (the context's fail-first replay block), and no assert
      is constant, self-comparing, or an either-or hedge (the shapes block)

## Security

- [ ] No hardcoded secrets
- [ ] Input validation at boundaries
- [ ] No SQL/command injection risks
- [ ] Auth/authz correctly applied
- [ ] Sensitive data not logged

## Documentation

- [ ] Public APIs documented
- [ ] Complex logic has comments
- [ ] README updated if needed
- [ ] Breaking changes noted


---
name: review-with-doubt
description: Use before finalizing work for a skeptical self-review that assumes the solution is incomplete - find concrete doubts, verify or refute each, fix what fails scrutiny. Triggers on "doubt review", "review with doubt", "skeptical self-review".
compatibility: "Portable; pure self-review protocol with no host tool, sub-agent, or config dependency."
---

# Review with Doubt

Before finalizing your work, perform a skeptical self-review. Assume your current solution is incomplete, flawed, or based on weak assumptions.

## Phase 1: Find doubts

Answer each question honestly. Do not defend earlier work. Silence on a question is not allowed - every question must produce at least one concrete doubt or an explicit "checked X, Y, Z and found nothing."

1. What parts of your solution are you least confident about?
2. What assumptions did you make, and which might be wrong? Check each assumption against the actual code or docs.
3. Is the task fully complete? Re-read the original request and diff every requirement against what was delivered.
4. What could fail in practice - edge cases, integration issues, hidden constraints, race conditions, error paths?
5. In retrospect, would you approach anything differently? If not, justify why the current approach survived scrutiny.
6. What tests, checks, or validations are missing or incomplete?

If you found fewer than 3 doubts total, you are not looking hard enough. Go back and scrutinize more carefully.

## Phase 1.5: Slop check

Phase 1 catches correctness doubts — gaps, edge cases, broken assumptions. Phase 1.5 catches aesthetic and structural slop that passes every functional gate. A correct-but-bloated implementation still wastes the reader's time. Answer each question on your diff:

1. **Bloat ratio**: compare your diff size (net lines added) to the acceptance-criteria word count. If your diff is 5-10x larger than the spec suggests, name the bloat as a doubt — quote the specific module/function and how much smaller it should be.
2. **Defensive impossibility**: is any error handling, validation, or guard clause responding to a state that cannot occur from the current control flow? Name each one as a doubt (file:line + the impossible state).
3. **Single-caller abstraction**: is any helper, interface, factory, builder, or layer of indirection used from exactly one call site, with no current testability or architectural justification? Name each one (the abstraction's definition + the single caller).
4. **Comment paraphrasing**: do any comments restate the code on the next line instead of explaining why? Name each one (file:line). Multi-paragraph docstrings on trivial functions count.
5. **Framework-verification tests**: do any tests verify the language/library/framework rather than your code's behavior? Mock-confirming tests (only assertion is `mock.assert_called_with(...)`), existence checks, snapshot tests where shape is not the contract — name each.

If you found fewer than 2 slop items in a non-trivial change (>30 net lines, >1 file touched), you are not looking hard enough. Re-read the diff with the lens of "what would the most minimal correct version look like?" and try again.

Slop items flow through Phase 2 classification (FIX / VERIFY / KNOWN) and Phase 3 actions like any other doubt — no separate handling.

## Phase 2: Classify each doubt

For every doubt surfaced above, classify it:

| Category | Meaning | Required action |
|----------|---------|-----------------|
| **FIX** | Can be resolved now with reasonable effort | Fix it immediately before proceeding |
| **VERIFY** | Uncertain whether it's actually a problem | Run a test, read the code, or check the behavior to confirm or dismiss |
| **KNOWN** | Real limitation that genuinely cannot be fixed in this scope | Document it explicitly with a clear reason why it's out of scope |

Rules:
- Default to FIX. The burden of proof is on NOT fixing.
- "It's probably fine" is not a classification. Prove it's fine (VERIFY) or fix it (FIX).
- KNOWN requires a concrete reason why fixing is impossible or out of scope. Inconvenience is not a reason.
- Small doubts still get classified. A 2-minute fix is still a fix. Ignoring small issues is how bugs ship.

## Phase 3: Act on every doubt

Work through your classified list. No exceptions, no skipping.

1. **FIX items**: Make the changes now. Show what you changed.
2. **VERIFY items**: Run the actual check - execute a test, read the code path, reproduce the scenario. If the doubt is confirmed, reclassify as FIX and fix it. If dismissed, state exactly what you checked and what you observed.
3. **KNOWN items**: List them so the user can decide whether to accept or address them.

## Phase 4: Report

After acting on all items, report:
- Total doubts found
- Fixed (with summary of each change)
- Verified and dismissed (with evidence for each)
- Known limitations remaining (with justification for each)

Do not report a confidence score. Confidence is subjective and unreliable. The work speaks through the actions taken above.

## Iteration

If Phase 3 produced any FIX actions, run one more pass: return to Phase 1 and review the fixes themselves. New code can introduce new doubts.

Maximum 2 passes total. After the second pass, report any remaining doubts as KNOWN limitations and stop. Perfectionism is its own bug.


During review, report FIX items for the authorized fresh implementor; do not perform edits yourself. Explicitly cover every question, at least three concrete correctness doubts and two slop checks on this nontrivial diff, verify/refute by tracing source, and explain dismissed doubts. Output residual findings in FIX/VERIFY/KNOWN with stable IDs and severities/proof. Finish with all five required verdicts:
R1: Every residual finding is in exactly one of FIX/VERIFY/KNOWN.
R2: Every FIX is bounded, in-scope and actionable.
R3: Every VERIFY specifies the exact check needed.
R4: Every KNOWN has a written out-of-scope justification.
R5: Total residual findings equal FIX + VERIFY + KNOWN counts.
Emit each R1-R5 as pass|fail, one per line. These are the requested FT-5 doubt/de-slop output rules, alongside separately labelled consensus verdicts.
