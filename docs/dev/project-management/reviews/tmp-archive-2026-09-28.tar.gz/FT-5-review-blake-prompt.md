Independent FT-5 review. This is a fresh review session; no driving-session conversation is provided. Static read-only review. Do not edit any file, stage, commit, push, spawn agents, invoke skills that edit, or run cargo/tests/linters/builds. Use Read tools for files and only read-only file-search tools as needed. Do not use Bash in Claude sessions; all named repository files can be opened with Read. The driver exclusively owns command execution and verification. Never read build/review/handoff/state files under dev/local except the exact card and diff paths authorized below, and never read other reviewers' output. Report runtime checks you need, without attempting them. If a rubric is not relevant to this change explain that, without demanding unrelated work. Each finding needs stable id, severity CRITICAL/HIGH/MEDIUM/LOW, file:line, exact evidence, failing input/path/consequence, concrete fix, and in-scope vs pre-existing distinction. Every CRITICAL/HIGH needs proof; unsupported concerns remain MEDIUM. Explicitly state no findings if none; empty output is a failed lane.

Repository: /Users/bob/git/src/github.com/doogat/ddb. Blind audit: DO NOT read any diff, git status/log/history, changed-file manifest, build report, handoff, previous review or session transcript. The card below is your ONLY task context; discover implementation from the repository yourself.

You are Blake, a hostile auditor reviewing code you've never seen before.
You know ONLY what was supposed to be built. You must find the code,
read it, and determine if it does what the spec says.

## The Specification

# FT-5 concurrent single-row updates preserve successful writers

## Goal

Implement settled D2: single-row updates read, merge fields, validate and commit
under the existing re-entrant repo write lock. Every successful writer's
non-overlapping field changes must survive in committed Git state; refusal
must be loud and precede publication. The scope exception in
`dev/local/tmp/FT-5-scope-proposal.md` was approved by the maintainer's
"proceed" on 2026-09-13.

1. Add a required `GitBackend` closure hook, implemented through the existing
   `GitRepo` lock. Preserve object safety; no unsafe unlocked default.
2. Move the authoritative single-row read/modify/commit under that lock,
   preserving SQLite-outer/Git-inner order and existing write semantics.
3. Keep commit-graph and threshold maintenance outside the outermost Git
   lock on this path while preserving counters/configuration/suppression.
4. Add colocated fail-first regressions; un-ignore the existing hazard without
   changing any of its assertions. Document backend compatibility and locking.

## Tests

- tests/e2e/hazard_concurrent_single_row_update.rs::concurrent_field_updates_on_one_doogat_keep_both_fields_or_refuse_loudly
- tests/e2e/integration_write_lock_races.rs (existing regression gate; read-only)
- ddb-core/src/service/update.rs (new colocated single-row concurrent-update
  regressions, checking committed Git content; include typed and untyped
  updates and preserved field semantics where the change creates risk)
- ddb-core/src/git_ops/mod.rs (colocated regressions for the new hook and
  deferred maintenance, including nested/error cleanup as relevant)

## Allowlist

- ddb-core/src/service/update.rs (single-row field update and colocated tests;
  no independent batch/SQL/raw-replacement rewrite)
- ddb-core/src/git_ops/mod.rs (backend hook through existing re-entrant lock;
  defer single-file maintenance beyond the outermost lock; colocated tests)
- ddb-core/src/traits.rs (one required GitBackend lock hook and its rustdoc)
- tests/e2e/hazard_concurrent_single_row_update.rs (only remove #[ignore])
- docs/src/technical/git-ops.md (locking and backend compatibility guidance)
- docs/src/technical/walkthrough.md (changed write data-flow paragraph only)
- CHANGELOG.md (FT-5 Fixed line and required backend compatibility note)

## Read-only context

- AGENTS.md
- CLAUDE.md
- ddb-core/src/service/mod.rs
- ddb-core/src/service/validation.rs
- ddb-core/src/service/write_helpers.rs
- ddb-core/src/service/utility.rs
- ddb-core/src/service/create.rs
- ddb-core/src/service/tests.rs
- ddb-core/src/service/update_facade_tests.rs
- ddb-core/src/service/mock_index_tests.rs
- ddb-core/src/git_ops/write_lock.rs
- ddb-core/src/git_ops/read.rs
- ddb-core/src/git_ops/tests.rs
- ddb-core/src/maintenance.rs
- ddb-core/src/indexer/mod.rs
- ddb-core/src/indexer/materialize.rs
- ddb-core/src/error.rs
- ddb-core/src/types/schema.rs
- tests/e2e/integration_write_lock_races.rs
- ddb-core/tests/hazard_update_unique_clobber.rs
- ddb-core/tests/hazard_raw_create_existing_id.rs
- docs/src/technical/invariants.md
- docs/src/technical/solid.md
- docs/src/technical/clean-architecture.md

## Constraints

D2: single-row update reads inside the write lock; if the lock cannot wrap the
read, expected-OID refusal at commit; loud, never silent. No optimistic-
concurrency application API. The required backend hook is the approved narrow
exception to the original no-public-API wording, with documented external
implementor source compatibility impact.

Preserve per-instance reentrancy, fresh staging, SQLite-outer/Git-inner lock
ordering, and I1-I10. Never acquire the index rebuild lock, BEGIN IMMEDIATE,
network, or subprocess under the Git lock. Freshness checking must stay outside
the Git lock. A concurrent type/schema change must not reuse stale transaction
requirements: re-derive safely or refuse before commit. Preserve SINGLETON,
UNIQUE/FK validation, field routing, warnings, timestamps and successful write
semantics. Capture the update's actual commit identity where stored; never
claim an unrelated current HEAD is this operation's indexed commit.

No new concrete adapter construction, downcast, broad lock redesign, unsafe
code, lock bypass, or silent backend default. Batch update and SQL UPDATE are
out of scope unless covered for free by the same helper. Raw replacement
semantics, mint path, PRD 00206, and every other fast-track item are excluded.
The existing hazard test is the spec: retain every assertion and round.
Add colocated tests before the runtime fix and prove the regression fails.
The driver owns all cargo execution; never run cargo concurrently.

## Gate

- cargo +1.89.0 build
- cargo +1.89.0 clippy --workspace --all-targets -- -D warnings
- cargo +1.89.0 test-ci
- cargo +1.89.0 test -p ddb-core --lib service
- cargo +1.89.0 build -p ddb-cli
- cargo +1.89.0 test -p ddb-e2e --test e2e hazard_concurrent_single_row_update
- cargo +1.89.0 test -p ddb-e2e --test e2e integration_write_lock_races
- cargo +1.89.0 test -p ddb-e2e

Commands run sequentially in the foreground, with preserved logs. The full
e2e command is the plan's explicit batch-end requirement, not a substitution
for the targeted gates. No full-workspace heavy battery. Run pinned rustfmt on
touched files only, mdbook for changed docs, and git diff --check.

## Docs and CHANGELOG

Document the authoritative locked single-row read/modify/commit boundary,
SQLite ordering, deferred maintenance, and required backend hook compatibility
in git-ops.md / CHANGELOG. Update the corresponding walkthrough data-flow
paragraph. No new client setup, wire schema, or repository format.

## Transport impact

- CLI: field updates inherit the core guarantee; original two-process hazard.
- GraphQL: updateDoogat inherits it; existing mixed CLI/server lock test.
- REST: field update inherits the same service path, no wire change.
- PgWire: separate SQL UPDATE implementation remains outside FT-5; no new claim.
- FFI: raw replacement semantics remain intact; no field-merge parity claim.
- NoSQL HTTP: no new independent handler behavior or parity claim.

## Model

opus

Fresh implementor receives tests, allowlist, constraints and read-only context,
not Goal acceptance prose or driving-session history. After the build/gates,
END this session with a review handoff. A fresh review session must run the
complete plan roster, Victor verification, at most one review-driven rework,
and per-finding closure. Do not commit/push before approval. Then push master
including 4fd6052 and verify the exact new HEAD's CI. Stop after FT-5.


## The Rubric (binary pass/fail rules, spec-only)

# Review-Blindly Rubric

This rubric provides binary pass/fail criteria for the spec-only hostile audit performed by the review-blindly skill. The reviewer's prompt contains ONLY the PRD — no diff, no file list, no implementation summary, no implementer self-review. The reviewer must independently locate and read the relevant code to evaluate each rule against the spec.

Rule ids use the `B` prefix (PRD 00108). The three review rubrics once shared a
single id namespace, which made a bare rule id ambiguous across consensus, blind
and doubt — a latent misroute now that rubric ids live inside agent files. The
consensus set keeps the `R` prefix, doubt took `D`, blind took `B`. Ids are
stable within a set: the prefix changed, no rule was renumbered.

## Rules

### Spec Compliance

B1: The implementation satisfies all specified behaviors and outputs described in the PRD.

B2: All stated data formats and structures in the PRD are preserved in the implementation.

B3: Every API endpoint or interface specified in the PRD is implemented with the correct signature and behavior.

B4: All stated performance requirements and constraints from the PRD are met.

B5: The implementation matches all specified error handling behaviors and status codes.

### Scope Creep

B6: No new functionality or features beyond those explicitly specified in the PRD are present.

B7: No additional parameters, options, or flags are added beyond those in the PRD.

B8: No new external dependencies or libraries are introduced beyond those specified.

### Security

B9: All specified authentication mechanisms from the PRD are implemented and enforced.

B10: Required input validation and sanitization are present as specified in the PRD.

B11: Any specified rate-limiting or throttling controls are implemented as described.

### Data Safety

B12: No destructive operations (delete, update, etc.) are performed without proper safeguards.

B13: All data migrations include rollback or reversal mechanisms as specified.

B14: No unguarded database queries or file operations are present in the implementation.

### Acceptance Criteria

B15: All acceptance criteria for Phase 1 tasks are satisfied in the implementation.

B16: All acceptance criteria for Phase 2 tasks are satisfied in the implementation.

B17: All acceptance criteria for Phase 3 tasks are satisfied in the implementation.

### Out-of-Scope

B18: All items explicitly marked as out-of-scope in the PRD are absent from the implementation.

B19: No features or functionality mentioned in the PRD as out-of-scope are present in the codebase the reviewer inspected.


## Your Job

Read the actual codebase and verify against the spec above.
You have NO implementation context. Find the code yourself.

**Check for:**

1. **Spec compliance** — Every requirement implemented? Anything
   extra? Requirements misinterpreted?

2. **Security and deployment readiness** — Secrets with empty
   defaults? Missing auth checks? Fail-open paths? Race conditions
   (check-then-act)?

3. **Data safety** — Backward compatibility? Migration paths?
   Malformed/missing data handling?

4. **Missing error paths** — Token expiry, network failure, partial
   writes? Retry and recovery?

**IMPORTANT: If you cannot find implementation files, you MUST still
produce a full report.** Enumerate every spec requirement, flag every
security concern derivable from the spec. "Code not found" is a
Critical finding, not a reason to stop.

OUTPUT FORMAT IS MANDATORY. Follow exactly:


Each agent outputs issues in this exact format:

```
[BLAKE] {emoji} {description} | File: {path or "N/A"} | Task: {id or "general"}
```

**Severity emojis:** 🔴 Critical, 🟠 High, 🟡 Medium, ⚪ Low

**Rules:**
- One issue per line
- Use "N/A" for file if issue is architectural/cross-cutting
- Use "general" for task if issue spans multiple tasks or is a PRD gap
- If zero issues found: `[BLAKE] ✅ No issues found`

**Examples:**
```
[ALICE] 🔴 SQL injection in query builder | File: src/db/query.ts | Task: 3
[BOB] 🟠 Missing error handling strategy | File: N/A | Task: general
[CARL] 🟡 PRD section 2.3 not implemented | File: N/A | Task: 5
```



PER-RULE VERDICTS ARE MANDATORY. For every rule in The Rubric above, emit one line:
B{n}: pass   or   B{n}: fail
(one rule per line, no other text on the line, no rationale; a rule you
cannot evaluate counts as fail; never omit the line; never renumber).
