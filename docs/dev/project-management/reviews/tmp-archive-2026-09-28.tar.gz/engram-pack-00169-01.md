Portfolio freshness: NOT refreshed this cycle (PRD 00002 pending)

140 changed symbol(s) omitted (beyond the 40-symbol cap).

## Similar code

## Reuse precedent

- jink:/Users/bob/git/src/github.com/doogat/jink/src/graphql/mutations/mod.rs:7-7
  pub(crate) mod quote;

## Findings precedent

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  2. [D2] Add `commit_merge` write-lock contention regression test (S) — 🟡 — mirrors `merge_blocks_while_write_lock_held`; proves `commit_merge` holds the write lock.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  - **[2/5] 🟠 (panic-safety) `title_from_path` slices `&filename[..14]`, which panics when byte 14 is inside a multibyte char** | File: `ddb-core/src/consistency/mod.rs:335` | Found by: Carl (🔴 panic), Quinn (🟡 redundant `>=14` guard).

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  - **[1/5] ⚪ parser tightening makes `meta.id=None` more reachable; indexer stores such docs as `id=""`** (Blake, `parser/mod.rs`) — **verified**: `indexer/mod.rs:257`, `materialize.rs:448`, `rebuild.rs:222` do `meta.id...unwrap_or("")`, so two id-less (malformed/non-native) files collide at `id=""` under `INSERT OR REPLACE`. Pre-existing indexer behavior; index is derived/rebuildable (git is source of truth). Deferred as a hardening follow-up (relates to 00169 poison-file-reindex-resilience).

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  [BLAKE] ⚪ `install_bundled_type` skips the `ensure_fresh()` other create paths run; mint safe (oracle reads HEAD), but subsequent `index_doogat` proceeds against a possibly-stale index. Asymmetry, not a defect. | File: ddb-core/src/service/discovery.rs | Task: general

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-02.md
  1. **consistency/mod.rs:335 slice panic** → fixed via `filename.get(..14)` (panic-safe; None on non-char-boundary), redundant `>=14` guard removed, regression test `title_from_path_multibyte_stem_does_not_panic` added and passing. Confirmed by Alice, Bob, Carl, Quinn.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00165-deterministic-crdt-resolution-v1-review-01.md
  [QUINN] ⚪ `value.to_str().unwrap_or_else(|| value.to_string())` silently falls back to Debug-style to_string for non-String values. | File: ddb-core/src/crdt_resolver.rs | Task: 1

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00166-make-hlc-load-bearing-v1-review-01.md
  [BOB] ⚪ persist() uses a fixed shared temp name (ddb-hlc.tmp); unlocked load-time repair in open/init could interleave with a concurrent process → torn/lower cache. Mitigated by lock on tick/recv + floor + re-seed. | File: ddb-core/src/git_ops/hlc_clock.rs | Task: 1

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00166-make-hlc-load-bearing-v1-review-02.md
  [BLAKE] 🟡 Layer-boundary risk realized: `GitRepo` owns and constructs the `HlcClock` (field `hlc_clock` + `HlcClock::load` in `init`/`open`), which the PRD Risk and AGENTS.md guardrail warn against. Behavior is correct and well-tested; architecture deviation, not a functional defect. (NB: accepted Alt-2 design — bare monotonic clock, not node-registry state.) | File: ddb-core/src/git_ops/mod.rs | Task: Phase 0

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00166-make-hlc-load-bearing-v1-review-03.md
  regressions the rework introduced.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00166-make-hlc-load-bearing-v1-review-03.md
  clause).

## Task prose

### Batch 202607161128 (autopilot, IN PROGRESS — started 2026-07-16)

- [x] **00163 git-tree-construction-correctness-v1** (DONE 2026-07-17, in `done/`) — delete-freshness + merge-lock legs of the git write-path data-loss class.
- [x] **00200 make-merge-tree-three-way-v1** (DONE 2026-07-18, in `done/`) — true three-way conflicted-merge tree (Alternative B), closing the last data-loss leg.
- [x] **00164 unify-id-minting-v1** (DONE 2026-07-18, in `done/`) — one repo-aware existence oracle for all mint paths.
- [x] **00165 deterministic-crdt-resolution-v1** (DONE 2026-07-18, in `done/`) — content-derived Automerge actor IDs, deterministic list-field ordering.
- [x] **00166 make-hlc-load-bearing-v1** (DONE 2026-07-19, in `done/`) — machine-local `HlcClock`, HLC trailer on every write, unified `lww_pick` tie-break.
- [x] **00167 sync-collision-reassignment-atomicity-v1** (DONE 2026-08-15, in `done/`) — folded winner + loser + backlink rewrites into one atomic `commit_merge`, loser ID derive

# Indexer rebuild resilience: poison-file skip and serialized cold-start rebuild

**Priority:** P1 (availability) · **Roadmap:** Phase 1 (availability) · **Depends on:** none (00162 write-lock helper shipped)

> **Merge note (2026-07-13, backlog review):** absorbed 00169b `serialize-cold-start-index-rebuild` — one PRD now owns indexer rebuild resilience: the lenient incremental path (poison files) AND the serialized destructive full-rebuild path (concurrent cold starts).

> **Provenance:** the index schema-version stamp and the frontmatter-size cap were added by the 2026-07-16 assessment (evidence: evolution-assessment-2026-07-16.md L2/L3) and folded into the body's Features/tasks at the 2026-08-14 backlog review. Probe location re-verified at `d77ad58`: `needs_schema_upgrade` at `indexer/mod.rs:159-180`.

## Overview

### Problem Statement
One malformed markdown file makes the whole database unusable through the service. The incremental reindex path is fatal on the first unreadable/
