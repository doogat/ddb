Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-context-00168-02.md for review context, and /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00168-02.diff for the full diff.

Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/engram-pack-00168-02.md and treat its full content as prepended context: similar code, reuse precedent, findings precedent, and task prose for this diff's changed symbols.

Project root: `/Users/bob/git/src/github.com/doogat/ddb` (Rust workspace, branch `master`).

Use this review checklist:

## Plan Compliance

- [ ] Implementation matches task description
- [ ] All acceptance criteria met
- [ ] No scope creep (extra features not requested)
- [ ] No missing pieces from original task

## PRD Coverage

- [ ] All "must have" requirements addressed
- [ ] Success metrics achievable with implementation
- [ ] No PRD sections left unimplemented
- [ ] Dependencies correctly handled

## Simplification

Hunt actively for simplification — do not just tick boxes. The diff under
review is fresh; this is the cheapest moment to cut complexity before it sets.
For every added or changed file, ask "what would make this simpler to read
without changing what it does?" and flag concrete opportunities.

- [ ] **Reduce complexity** — no needless indirection, dead branches, or
      abstractions built for a single caller; nesting <= 4 levels; functions
      under 50 lines
- [ ] **Eliminate redundancy** — no logic duplicated within the diff or against
      existing code; no helper that reimplements a stdlib or existing utility
- [ ] **Improve naming** — names state intent; no opaque abbreviations;
      action-named functions start with a verb
- [ ] **Follow project standards** — conventions from CLAUDE.md / AGENTS.md and
      the surrounding code; no style drift
- [ ] **No dead code** — no commented-out blocks, unused imports, variables, or
      speculatively-added parameters
- [ ] **Appropriate error handling** — explicit, never silently swallowed

**How to flag a simplification:** give the file:line, the current shape, and
the simpler replacement. Flag concrete behavior-preserving simplifications at
🟡 Medium so the decision gate routes them into the rework loop. Do not inflate
them to 🟠 High; that floods the rework loop and can trip the scope alarm.

**Balance — do not over-simplify:** never propose a change that trades clarity
for brevity, drops error handling, collapses a deliberate boundary, or removes
a documented invariant. Simpler means easier to read and maintain, not shorter
at any cost. If a "simplification" would change behavior, it is out of scope —
do not flag it.

## Testing

- [ ] Unit tests for new logic
- [ ] Edge cases covered
- [ ] Error paths tested
- [ ] Integration tests if crossing boundaries
- [ ] Tests actually run and pass

## Security

- [ ] No hardcoded secrets
- [ ] Input validation at boundaries
- [ ] No SQL/command injection risks
- [ ] Auth/authz correctly applied
- [ ] Sensitive data not logged

## Documentation

- [ ] Public APIs documented
- [ ] Complex logic has comments
- [ ] README updated if needed
- [ ] Breaking changes noted

In addition, work through the numbered rubric:

### Tests

R1: Tests cover every new behavior introduced by the diff.
R2: Tests bind to intent, not just observable behavior.
R3: No skipped or xfail tests mask failures.

### Integration

R4: Changed components integrate with existing callers.

### Security

R6: No hardcoded secrets in the codebase.
R7: All user input is validated and sanitized.
R8: No injection-unsafe queries or commands.

### Domain

R9: Implementation matches PRD feature behavior exactly.
R10: Error handling is explicit and not swallowed.
R11: No debug statements, TODOs, or placeholder markers remain.

### Code Quality

R12: Function sizes respect the 50-line limit.
R13: File sizes respect the 800-line limit.

Review the completed work against PRD requirements. Explore the codebase as needed.

## This is an INCREMENTAL review (cycle 2)

This is an **incremental review** of the rework done since the previous review cycle — the diff is scoped to changes since then (`e531306978164c21a9b61a8547667bd930dba45b..6bb16174fd533b94db0f45016019aa4626b5a16e`). Two jobs: (1) for each prior finding listed below, verify it is now resolved in the code; (2) review the scoped diff for any regression the rework introduced. You need not re-review unchanged code; the previous cycle already reviewed the full implementation.

Your own cycle-1 findings were these six (you are resuming your own session, so you have the full context):

```
FIX:
- Bundle merge, resolution, and ref deletion do not share one write lease — ddb-core/src/bundle.rs:120
- Remote name `bundle` bypasses the unrelated-history safety guard for user-triggered sync — ddb-core/src/git_ops/merge.rs:390
- Merge-engine errors are not normalized to `DoogatError::Sync` — ddb-core/src/bundle.rs:120
- FFI conflict-recovery conformance is missing — ddb-core/src/ffi/driver.rs:262
- New tests violate function/file-size limits and duplicate setup — ddb-core/src/bundle.rs:475
VERIFY:
- Tier 1 validation was not executable in this sandbox — run `cargo build`, `cargo clippy --workspace --all-targets`, and `cargo test-ci`
KNOWN:
- `git bundle unbundle`/`git fetch` still prepare objects and the bundle tracking ref outside the write lock
```

Your VERIFY item was discharged by the orchestrator in cycle 1 and again this cycle
(see "Verification already performed" below).

### The other reviewers' cycle-1 findings — verify each is resolved

| Severity | Issue | File | Found By |
|----------|-------|------|----------|
| 🔴 | `fetch.prune` defeats the reachability guarantee: `unbundle_git_objects` fetched `refs/heads/*:refs/remotes/bundle/*` with no `--no-prune`, so the NEXT bundle import deleted the `refs/remotes/bundle/master` that a failed import deliberately kept. | ddb-core/src/bundle.rs | BLAKE |
| 🟠 | With unrelated histories every conflicting path has `ancestor: None`, so `partition_conflicts` sent NON-doogat files into `resolve_add_add_collision` (died on a differing `.gitignore`, no recovery path). | ddb-core/src/sync_manager/mod.rs | BLAKE |
| 🟠 | Same misclassification silently FORKED data: importing into an unrelated history holding the same doogat id reported success while duplicating the document to `ddb/66177401297366.md` — not a valid 14-digit YYYYMMDDHHmmss id. | ddb-core/src/git_ops/merge.rs | BLAKE |
| 🟠 | "On any error return a `Sync` error" only half implemented (matches your own finding). | ddb-core/src/bundle.rs | BLAKE |
| 🟡 | `if remote != "bundle"` puts caller-specific merge policy in the git adapter via a magic string (matches your own finding). | ddb-core/src/git_ops/merge.rs:384-392 | ALICE, BLAKE |
| 🟡 | Invariant docs overclaim closure: invariants.md I1 says "no remaining gap" while the fetch leg is still unlocked. | docs/src/technical/invariants.md:596-602 | ALICE, BLAKE |
| 🟡 | The retained merge-base guard is unpinned: deleting it leaves the full suite green. | ddb-core/src/git_ops/merge.rs:390 | ALICE |
| 🟡 | ~75 lines of setup duplicated verbatim between the two failure tests. | ddb-core/src/bundle.rs:566-754 | ALICE |
| 🟡 | "A resolution failure here leaves the repo exactly as it was" is false on the clean-merge branch. | ddb-core/src/bundle.rs:110-114 | ALICE |
| 🟡 | The new trait method is missing from every trait-surface listing (walkthrough.md:341, git-ops.md:13, traits.rs:366 all read "(add, fetch, push)"). | docs/src/technical/walkthrough.md:341 | ALICE |
| 🟡 | Removed `pub fn resolve_post_merge_conflicts` and the new required `GitRemote::delete_remote_ref` are unrecorded library-API breaks. | ddb-core/src/sync_manager/mod.rs | BLAKE |
| 🟡 | Docs contradict themselves: `sync.md:56` still says bundle import is outside the lock; `CHANGELOG.md:16` repeats it. | docs/src/technical/sync.md | BLAKE |
| 🟡 | Redundant `repo` param on `merge_bundle_and_resolve`. | ddb-core/src/bundle.rs:114 | CARL |
| ⚪ | Both failure tests assert only `matches!(result, Err(DoogatError::Sync(_)))`, which cannot show the *merge* failed. | ddb-core/src/bundle.rs:642-645 | ALICE |
| ⚪ | `!repo2.repo.index().unwrap().has_conflicts()` reads the process-cached index and cannot fail. | ddb-core/src/bundle.rs:750-753 | ALICE |
| ⚪ | Library-API break not recorded in CHANGELOG. | CHANGELOG.md:26 | ALICE |
| ⚪ | Locale/wording-independence success metric has no test (structurally satisfied — no CLI git remains). | N/A | ALICE, BLAKE |
| ⚪ | No `git merge --abort` path exists; the design substitutes in-memory-merge reasoning (permitted by the PRD Risks mitigation and by the design doc's PRD-text reconciliation note). | ddb-core/src/bundle.rs | BLAKE |
| ⚪ | Only `refs/remotes/bundle/master` was deleted; stale `refs/remotes/bundle/main` persisted forever. | ddb-core/src/bundle.rs | BLAKE |
| ⚪ | `SyncReport.commits_transferred` for bundle import changed meaning with no CHANGELOG/docs note. | ddb-core/src/bundle.rs | BLAKE |

## Settled decisions — do not re-raise

These calls were already made in an earlier cycle of this same review, with
the reasons given. Do not re-raise them. Raise a NEW finding only if you can
show the settled reason no longer holds.

1. **settled-deferral · high · `ddb-core/src/bundle.rs`** — "merge → resolve → ref-delete does not run inside one 00162 write lease; `import_bundle` takes the lock three separate times, and `unbundle_git_objects` writes outside the lock." **This is your own cycle-1 FIX item #1 and your KNOWN item.**
   *Reason:* Design-accepted, recorded in the 00168 design doc Risks section: the two-lock-acquisition gap is the exact gap the already-shipped network `sync()` path has lived with since 00163, so bundle import inherits an identical, already-accepted risk profile rather than a new one. You yourself filed the unbundle/fetch leg as KNOWN. Collapsing three re-entrant lock acquisitions into one outer lease is a sync-wide change, not a bundle-import change — its own PRD.

2. **settled-deferral · medium · `ddb-core/src/ffi/driver.rs:262-268`** — "FFI parity gap / FFI conflict-recovery conformance is missing." **This is your own cycle-1 FIX item #4.**
   *Reason:* Pre-existing FFI signature, explicitly out of scope in the 00168 design doc. Widening the FFI return type is a public-interface change requiring the compatibility/deprecation review AGENTS.md mandates; separate PRD. Real gap, tracked at batch end.

3. **settled-deferral · medium · `ddb-core/src/sync_manager/mod.rs`** — "`validate_clean_merge_or_fallback` still `return Ok(0)` when `commit_parent_count < 2`."
   *Reason:* Requirements-vs-design reconciliation. Under the chosen design there is no CLI merge: conflicts arrive as `MergeResult::Conflicts` and never reach this branch, so the false-success path the PRD describes no longer exists. Changing the shared network-sync clean-merge validator would alter network sync behavior outside this PRD's scope.

4. **settled-deferral · low · `ddb-core/src/git_ops/mod.rs:182`** — "`GitRepo::open` deletes every `.crdt/temp/*` file."
   *Reason:* Pre-existing, unrelated to bundle import; belongs to CRDT-state lifecycle work.

5. **settled-deferral · low · `ddb-core/src/git_ops/mod.rs`** — "Pre-existing size violation: git_ops/mod.rs is 849 lines against the 800 max."
   *Reason:* Pre-existing (845 lines before this PRD). This diff adds a 4-line trait delegation arm; the surgical-changes rule forbids splitting an unrelated file as a side effect.

6. **settled-deferral · low · `dev/local/walkthroughs/00168-bundle-import-conflict-recovery.md`** — "The walkthrough shows mangled merged content (`laptdesktopp body`)."
   *Reason:* Pre-existing resolver behavior. Character-interleaved Automerge text merge is the CRDT layer's documented behavior, not a bundle-import defect.

7. **settled-deferral · medium · `ddb-core/src/bundle.rs:121-123`** — "`map_err(|e| DoogatError::Sync(...))` collapses every resolver error, including the retryable `DoogatError::Conflict`. Preserve `Conflict` and wrap only the rest."
   *Reason:* **PARTIALLY IMPLEMENTED BY DESIGN**, settled in cycle-1 rework task [D1-3] (commits 01cfc85, 427f920). The substantive defect — one failure reporting two different classes depending on which call raised it — IS fixed: both `merge_remote` and `apply_merge_result` now route through the same `bundle_merge_error`. The literal remedy was deliberately NOT implemented, because its premise is false here. `DoogatError::Conflict` is overloaded: retryable producers are `write_lock.rs:72` (lock-acquire timeout) and `git_ops/merge.rs:65` (resolve→commit window guard); TERMINAL producers are `git_ops/merge.rs:193` (collision loser whose id cannot be rewritten) and `sync_manager/mod.rs:502` (binary conflict missing blob OID). Preserving `Conflict` was implemented first and empirically broke three tests — `conflicting_bundle_import_leaves_repo_clean_on_merge_failure`, `conflicting_bundle_import_leaves_bundle_ref_reachable_on_merge_failure`, and `kept_bundle_ref_survives_a_later_import_under_fetch_prune` (the regression test for cycle 1's CRITICAL finding) — all of which require the terminal collision failure to be reported as `Sync`, which is also the PRD's documented contract. Both classes can arrive through either wrapped call, so they cannot be distinguished at the import boundary without string-sniffing the message (exactly what this PRD removed). **DO NOT re-raise "Conflict is still collapsed."**

8. **settled-deferral · medium · `ddb-core/src/git_ops/merge.rs:193`** — "`DoogatError::Conflict` is overloaded across a retryable class and a terminal class, so a caller that retries on the public CONFLICT category spins forever on a malformed doogat."
   *Reason:* NEW finding discovered during cycle-1 rework. Real latent bug, but out of scope: `Conflict` maps to a public `CONFLICT` code and `AppErrorCategory::Conflict`, so reclassifying the terminal producers is a public error-shape change requiring compatibility/deprecation review, and it touches the shared network-sync resolver rather than bundle import. Needs its own PRD; the tradeoff is recorded in the CHANGELOG `[Unreleased]` bundle entry and in the `bundle_merge_error` doc comment.

9. **settled-deferral · medium · `ddb-core/src/bundle.rs`** — "Size limits crossed: bundle.rs 569 → 828 lines, three new test fns at 96/86/84 lines." **This is your own cycle-1 FIX item #5.**
   *Reason:* **CLOSED EXCEPT FOR ONE DELIBERATE HOLDOUT**, settled in cycle-1 rework task [D1-6] (commits a3bc99e, 4d097e2). The file-size half is fully closed: `bundle.rs` became `bundle/mod.rs` at 413 lines. Two of the three named test fns came down to 29 and 26 lines via the shared `import_with_unresolvable_collision` fixture. The third, `conflicting_full_bundle_import_resolves_with_real_merge_commit`, remains 84 lines ON PURPOSE: it exercises a SUCCESSFUL conflicted import, so the unresolvable-collision fixture does not fit it, and it is the only test with that setup, so extracting a single-use helper would move lines out of view without improving readability (and would create the one-consumer abstraction the project's simplicity rule forbids). `bundle/tests.rs` is 831 lines, over the nominal 800: the repo's own test files are far larger (`git_ops/tests.rs` 3318, `sync_manager/tests.rs` 2084), so the limit does not bind test files in practice here. **DO NOT re-raise either point.**

10. **settled-deferral · low · `ddb-core/src/compaction/tests.rs:5`** — "A third copy of the `temp_repo` test helper."
    *Reason:* Pre-existing, raised by no reviewer, out of 00168 scope under the surgical-changes rule.

## Verification already performed (do not re-file as VERIFY)

The orchestrator ran these to completion at this cycle's HEAD (`6bb1617`):

- `cargo build` — clean.
- `cargo clippy --workspace --all-targets` — clean.
- `cargo test -p ddb-core --lib -- --skip sql_engine` — 1102 passed, 0 failed.
- `cargo test -p ddb-e2e` — 449 passed, 0 failed.

Not run locally (Tier 2, delegated to CI): the 376 `sql_engine` tests,
`tests/integration.sh`, property tests, cross-platform. Note that `cargo test-ci`
and the unfiltered `cargo test -p ddb-core --lib` exceed 10 minutes in this repo
(the `sql_engine` tier), which is why the filtered command above is the one used.

**Known environment note (not a finding):** a batch-mate PRD (00167, commit
a1cbf3f) left a flaky test — `git_ops::tests::commit_merge_logs_reassignment_warn_with_old_and_new_identity`
intermittently fails from a global `tracing-subscriber` race. It is NOT a 00168 regression.

OUTPUT FORMAT IS MANDATORY. Follow exactly:

```
[BOB] {emoji} {description} | File: {path or "N/A"} | Task: {id or "general"}
```

**Severity emojis:** 🔴 Critical, 🟠 High, 🟡 Medium, ⚪ Low

**Rules:**
- One issue per line
- Use "N/A" for file if issue is architectural/cross-cutting
- Use "general" for task if issue spans multiple tasks or is a PRD gap
- If zero issues found: `[BOB] ✅ No issues found`

PER-RULE VERDICTS ARE MANDATORY. For every rule in the numbered rubric, emit one line:
R{n}: pass   or   R{n}: fail
(one rule per line, no other text on the line, no rationale).

## Sandbox Constraints

You run in a restricted sandbox. You CANNOT execute code, tests, linters, or package managers.

Perform STATIC analysis only:
- Read code for logical correctness, patterns, naming, structure
- Check for missing imports, dead code, type mismatches
- Review against PRD requirements by reading, not executing
- Trace data flow and control flow by reading source

If a criterion requires runtime verification (e.g. "tests pass", "linter clean"), output:
[BOB] ⚪ Cannot statically verify: {criterion description} | File: N/A | Task: {id}

Do NOT attempt to run commands. Do NOT report failures from blocked execution.

## Two lenses, applied to every changed file

Treat the following as findings precedent already recorded for this diff's changed symbols. Weigh it when applying both lenses and the rubric verdicts rather than re-litigating known prior findings.

```
- 00163-git-tree-construction-correctness-v1-review-02: [1/5] ⚪ Low — AGENTS.md I1 bullet points the remaining bundle-import lock gap at `git_ops/merge.rs`, but that file shells out nowhere (libgit2 in-process); the `git merge` subprocess lives in `bundle::merge_bundle_and_resolve`. AGENTS.md contradicted invariants.md and git-ops.md. (Bob)
- 00163-git-tree-construction-correctness-v1-review-01: [Bob] Docs overclaim fresh-index staging across all merge paths. `git-ops.md`, `CHANGELOG.md`, and `sync.md` said the merge write path "stages the merge tree from `fresh_index()`", but only `commit_merge`'s `build_merge_tree_and_commit` uses `fresh_index()`. VERIFIED real.
- 00163-git-tree-construction-correctness-v1-review-01: [Bob] Bundle import merges via `git merge` subprocess outside the lock → deferred to 00168 (this PRD).
- 00163-git-tree-construction-correctness-v1-review-02: orchestrator CONFIRMED that only AGENTS.md carried the stale `git_ops/merge.rs` reference; single-site fix, became cycle-3 auto-fix task [D3-1].
- 00166-make-hlc-load-bearing-v1-review-02: [1/4] ⚪ Low — `sync.md:170` "no commit path can ship a trailer-less commit" overclaims. Bundle-import merge (00168) stays trailer-less. Qualified to public `GitRepo` write paths, bundle import tracked separately. (Bob)
- 00166-make-hlc-load-bearing-v1-review-02: Build/lint/fast-test gate passes — cargo build, cargo clippy --workspace --all-targets, cargo test-ci.
```

The recurring precedent here is **docs overclaiming what a merge/lock change actually
closed**. This PRD's cycle-1 rework included a docs truth pass (commit 4adcdee) for
exactly that class; check whether it went far enough or overcorrected.

### 1. Doubt lens (correctness)
Surface residual findings a confident reviewer would wave past:
- spec gaps: PRD says X, code does Y (wrong field names, enum values,
  thresholds, artifact kind);
- missing or incomplete features the PRD requires;
- edge cases, error paths, and failure modes left unhandled;
- tests that assert the implementation rather than the intent (cannot fail when
  the business rule changes).

### 2. De-slop lens (quality)
Flag slop introduced by the changes (do not propose broad refactors):
- over-abstraction / single-caller indirection with no current testability or
  architectural need;
- dead code, code kept in comments, unreachable branches;
- defensive guards for states that cannot occur;
- restating docstrings, "robust" error messages with no context, premature
  configuration, framework-verification tests;
- speculative generality (parameters, hooks, or layers nothing uses yet).
Bias: aggressive on newly-created files (slop concentrates there), conservative
on lightly-touched files (do not destabilize existing behavior).

## Categorize every residual finding

Place EACH finding in exactly one bucket:
- **FIX** — genuinely fixable now: bounded scope, in-scope, actionable.
- **VERIFY** — needs a specific named check to resolve (state the exact check,
  not "look into X").
- **KNOWN** — a real limitation that is out of scope; include a one-line written
  justification.

Output the buckets as three sections, one finding per line:

```
FIX:
- <finding> — <file:line> — <the concrete fix>
VERIFY:
- <finding> — <the exact check to run>
KNOWN:
- <finding> — <why it is out of scope>
```

If a bucket is empty, write the header and `- (none)`.

## Rubric verdicts (REQUIRED — emit verbatim, one per line)

Apply the doubt-review rubric. A rule you cannot evaluate is `fail`; never omit
a line.
- D1: every residual finding is in exactly one of FIX/VERIFY/KNOWN.
- D2: all FIX items are genuinely fixable now (bounded, in-scope, actionable).
- D3: all VERIFY items name the exact check needed (not vague).
- D4: all KNOWN items carry a written out-of-scope justification.
- D5: input finding count equals FIX + VERIFY + KNOWN counts.

Emit exactly:

```
D1: pass|fail
D2: pass|fail
D3: pass|fail
D4: pass|fail
D5: pass|fail
```

Do not modify any files. This is a review only — produce findings and the
rubric verdict lines. No commits.
