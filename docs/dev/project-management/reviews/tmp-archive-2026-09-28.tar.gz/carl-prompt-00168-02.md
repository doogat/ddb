Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-context-00168-02.md for review context, and /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00168-02.diff for the full diff.

Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/engram-pack-00168-02.md and treat its full content as prepended context: similar code, reuse precedent, findings precedent, and task prose for this diff's changed symbols.

Project root: `/Users/bob/git/src/github.com/doogat/ddb` (Rust workspace, branch `master`).

Use this review checklist:

## Plan Compliance

- [ ] Implementation matches task description
- [ ] All acceptance criteria met
- [ ] No scope creep (extra features not requested)
- [ ] No missing pieces from original task

## PRD Coverage

- [ ] All "must have" requirements addressed
- [ ] Success metrics achievable with implementation
- [ ] No PRD sections left unimplemented
- [ ] Dependencies correctly handled

## Simplification

Hunt actively for simplification — do not just tick boxes. The diff under
review is fresh; this is the cheapest moment to cut complexity before it sets.
For every added or changed file, ask "what would make this simpler to read
without changing what it does?" and flag concrete opportunities.

- [ ] **Reduce complexity** — no needless indirection, dead branches, or
      abstractions built for a single caller; nesting <= 4 levels; functions
      under 50 lines
- [ ] **Eliminate redundancy** — no logic duplicated within the diff or against
      existing code; no helper that reimplements a stdlib or existing utility
- [ ] **Improve naming** — names state intent; no opaque abbreviations;
      action-named functions start with a verb
- [ ] **Follow project standards** — conventions from CLAUDE.md / AGENTS.md and
      the surrounding code; no style drift
- [ ] **No dead code** — no commented-out blocks, unused imports, variables, or
      speculatively-added parameters
- [ ] **Appropriate error handling** — explicit, never silently swallowed

**How to flag a simplification:** give the file:line, the current shape, and
the simpler replacement. Flag concrete behavior-preserving simplifications at
🟡 Medium so the decision gate routes them into the rework loop. Do not inflate
them to 🟠 High; that floods the rework loop and can trip the scope alarm.

**Balance — do not over-simplify:** never propose a change that trades clarity
for brevity, drops error handling, collapses a deliberate boundary, or removes
a documented invariant. Simpler means easier to read and maintain, not shorter
at any cost. If a "simplification" would change behavior, it is out of scope —
do not flag it.

## Testing

- [ ] Unit tests for new logic
- [ ] Edge cases covered
- [ ] Error paths tested
- [ ] Integration tests if crossing boundaries
- [ ] Tests actually run and pass

## Security

- [ ] No hardcoded secrets
- [ ] Input validation at boundaries
- [ ] No SQL/command injection risks
- [ ] Auth/authz correctly applied
- [ ] Sensitive data not logged

## Documentation

- [ ] Public APIs documented
- [ ] Complex logic has comments
- [ ] README updated if needed
- [ ] Breaking changes noted

In addition, work through the numbered rubric:

### Tests

R1: Tests cover every new behavior introduced by the diff.
R2: Tests bind to intent, not just observable behavior.
R3: No skipped or xfail tests mask failures.

### Integration

R4: Changed components integrate with existing callers.

### Security

R6: No hardcoded secrets in the codebase.
R7: All user input is validated and sanitized.
R8: No injection-unsafe queries or commands.

### Domain

R9: Implementation matches PRD feature behavior exactly.
R10: Error handling is explicit and not swallowed.
R11: No debug statements, TODOs, or placeholder markers remain.

### Code Quality

R12: Function sizes respect the 50-line limit.
R13: File sizes respect the 800-line limit.

Review the completed work against PRD requirements. Explore the codebase as needed.

**Do not answer R12/R13 by impression.** The review context file carries a
"Mechanical facts (computed, do not re-count)" block with measured line counts for
every changed file at this HEAD. Cite those numbers. A verdict that contradicts them
is discarded.

## This is an INCREMENTAL review (cycle 2)

This is an **incremental review** of the rework done since the previous review cycle — the diff is scoped to changes since then (`e531306978164c21a9b61a8547667bd930dba45b..6bb16174fd533b94db0f45016019aa4626b5a16e`). Two jobs: (1) for each prior finding listed below, verify it is now resolved in the code; (2) review the scoped diff for any regression the rework introduced. You need not re-review unchanged code; the previous cycle already reviewed the full implementation.

Your own cycle-1 finding was: 🟡 redundant `repo` param on `merge_bundle_and_resolve`
(`ddb-core/src/bundle.rs:114`) — replace with `<G: GitBackend>(sync_mgr: &mut SyncManager<G>, ...)`
and use `sync_mgr.repo.merge_remote`. Verify it landed.

### The other reviewers' cycle-1 findings — verify each is resolved

| Severity | Issue | File | Found By |
|----------|-------|------|----------|
| 🔴 | `fetch.prune` defeats the reachability guarantee: `unbundle_git_objects` fetched `refs/heads/*:refs/remotes/bundle/*` with no `--no-prune`, so the NEXT bundle import deleted the `refs/remotes/bundle/master` that a failed import deliberately kept. | ddb-core/src/bundle.rs | BLAKE |
| 🟠 | With unrelated histories every conflicting path has `ancestor: None`, so `partition_conflicts` sent NON-doogat files into `resolve_add_add_collision` (died on a differing `.gitignore`, no recovery path). | ddb-core/src/sync_manager/mod.rs | BLAKE |
| 🟠 | Same misclassification silently FORKED data: importing into an unrelated history holding the same doogat id reported success while duplicating the document to `ddb/66177401297366.md` — not a valid 14-digit YYYYMMDDHHmmss id. | ddb-core/src/git_ops/merge.rs | BLAKE |
| 🟠 | "On any error return a `Sync` error" only half implemented: `merge_bundle_and_resolve` mapped `apply_merge_result` errors to `Sync` but propagated `merge_remote` errors raw. | ddb-core/src/bundle.rs | BLAKE |
| 🟠 | User-controlled remote name `bundle` disabled the unrelated-history guard for ordinary `ddb sync bundle master`. | ddb-core/src/git_ops/merge.rs:390 | BOB |
| 🟡 | `if remote != "bundle"` put caller-specific merge policy in the git adapter via a magic string. | ddb-core/src/git_ops/merge.rs:384-392 | ALICE, BLAKE |
| 🟡 | Invariant docs overclaim closure: invariants.md I1 said "no remaining gap" while the fetch leg is still unlocked. | docs/src/technical/invariants.md:596-602 | ALICE, BLAKE |
| 🟡 | The retained merge-base guard was unpinned: deleting it left the full suite green. | ddb-core/src/git_ops/merge.rs:390 | ALICE |
| 🟡 | ~75 lines of setup duplicated verbatim between the two failure tests. | ddb-core/src/bundle.rs:566-754 | ALICE |
| 🟡 | "A resolution failure here leaves the repo exactly as it was" is false on the clean-merge branch. | ddb-core/src/bundle.rs:110-114 | ALICE |
| 🟡 | The new trait method was missing from every trait-surface listing (walkthrough.md:341, git-ops.md:13, traits.rs:366 all read "(add, fetch, push)"). | docs/src/technical/walkthrough.md:341 | ALICE |
| 🟡 | Removed `pub fn resolve_post_merge_conflicts` and the new required `GitRemote::delete_remote_ref` were unrecorded library-API breaks. | ddb-core/src/sync_manager/mod.rs | BLAKE |
| 🟡 | Docs contradicted themselves: `sync.md:56` still said bundle import is outside the lock; `CHANGELOG.md:16` repeated it. | docs/src/technical/sync.md | BLAKE |
| ⚪ | Both failure tests asserted only `matches!(result, Err(DoogatError::Sync(_)))`, which cannot show the *merge* failed. | ddb-core/src/bundle.rs:642-645 | ALICE |
| ⚪ | `!repo2.repo.index().unwrap().has_conflicts()` read the process-cached index and could not fail. | ddb-core/src/bundle.rs:750-753 | ALICE |
| ⚪ | Library-API break not recorded in CHANGELOG. | CHANGELOG.md:26 | ALICE |
| ⚪ | Only `refs/remotes/bundle/master` was deleted; stale `refs/remotes/bundle/main` persisted forever. | ddb-core/src/bundle.rs | BLAKE |
| ⚪ | `SyncReport.commits_transferred` for bundle import changed meaning with no CHANGELOG/docs note. | ddb-core/src/bundle.rs | BLAKE |

## Settled decisions — do not re-raise

These calls were already made in an earlier cycle of this same review, with
the reasons given. Do not re-raise them. Raise a NEW finding only if you can
show the settled reason no longer holds.

1. **high · `ddb-core/src/bundle.rs`** — "merge → resolve → ref-delete does not run inside one 00162 write lease; `unbundle_git_objects` writes outside the lock."
   *Reason:* Design-accepted: the two-lock-acquisition gap is the exact gap the shipped network `sync()` path has lived with since 00163. Collapsing three re-entrant lock acquisitions into one outer lease is a sync-wide change, its own PRD.

2. **medium · `ddb-core/src/ffi/driver.rs:262-268`** — "FFI parity gap: `DoogatDriver::import_bundle` discards the report / no FFI conformance test."
   *Reason:* Pre-existing FFI signature, explicitly out of scope in the design doc; widening it is a public-interface change requiring compatibility/deprecation review. Separate PRD.

3. **medium · `ddb-core/src/sync_manager/mod.rs`** — "`validate_clean_merge_or_fallback` still `return Ok(0)` when `commit_parent_count < 2`."
   *Reason:* Under the chosen design there is no CLI merge: conflicts arrive as `MergeResult::Conflicts` and never reach that branch, so the false-success path no longer exists. Changing the shared validator would alter network sync behavior outside scope.

4. **low · `ddb-core/src/git_ops/mod.rs:182`** — "`GitRepo::open` deletes every `.crdt/temp/*` file." *Reason:* Pre-existing, CRDT-state lifecycle work, not bundle import.

5. **low · `ddb-core/src/git_ops/mod.rs`** — "git_ops/mod.rs is 849 lines against the 800 max." *Reason:* Pre-existing (845 before); this diff adds a 4-line delegation arm and the surgical-changes rule forbids splitting it as a side effect.

6. **low · `dev/local/walkthroughs/00168-bundle-import-conflict-recovery.md`** — "mangled merged content (`laptdesktopp body`)." *Reason:* Pre-existing CRDT text-merge behavior, not a bundle-import defect.

7. **medium · `ddb-core/src/bundle.rs:121-123`** — "`map_err(|e| DoogatError::Sync(...))` collapses the retryable `DoogatError::Conflict`; preserve `Conflict`."
   *Reason:* **PARTIALLY IMPLEMENTED BY DESIGN** (cycle-1 task [D1-3], commits 01cfc85/427f920). The substantive defect — one failure reporting two classes depending on which call raised it — IS fixed; both calls now route through `bundle_merge_error`. The literal remedy was deliberately NOT implemented: `DoogatError::Conflict` is overloaded across retryable producers (`write_lock.rs:72`, `git_ops/merge.rs:65`) and TERMINAL producers (`git_ops/merge.rs:193`, `sync_manager/mod.rs:502`). Preserving `Conflict` was tried and broke three tests, including the regression test for cycle 1's CRITICAL finding. **DO NOT re-raise.**

8. **medium · `ddb-core/src/git_ops/merge.rs:193`** — "`DoogatError::Conflict` is overloaded, so a caller retrying on the public CONFLICT category spins forever."
   *Reason:* Real latent bug found during cycle-1 rework, but a public error-shape change requiring compatibility review and touching the shared resolver. Its own PRD; the tradeoff is recorded in CHANGELOG and in the `bundle_merge_error` doc comment.

9. **medium · `ddb-core/src/bundle.rs`** — "Size limits crossed: bundle.rs 828 lines, three test fns at 96/86/84."
   *Reason:* **CLOSED EXCEPT ONE DELIBERATE HOLDOUT** (cycle-1 task [D1-6]). `bundle.rs` became `bundle/mod.rs` at 413 lines; two test fns came down to 29 and 26 via the shared `import_with_unresolvable_collision` fixture. The third, `conflicting_full_bundle_import_resolves_with_real_merge_commit`, stays 84 lines ON PURPOSE — it is the only test of a SUCCESSFUL conflicted import, so the fixture does not fit and a single-use helper would create the one-consumer abstraction the project's simplicity rule forbids. `bundle/tests.rs` at 831 lines is accepted: repo test files run 2084-3318 lines. **DO NOT re-raise either point.**

10. **low · `ddb-core/src/compaction/tests.rs:5`** — "a third copy of the `temp_repo` test helper." *Reason:* Pre-existing, out of scope under the surgical-changes rule.

## Known environment note (not a finding)

A batch-mate PRD (00167, commit a1cbf3f) left a flaky test:
`git_ops::tests::commit_merge_logs_reassignment_warn_with_old_and_new_identity`
intermittently fails from a global `tracing-subscriber` race. If you hit an
intermittent red there, it is NOT a 00168 regression.

OUTPUT FORMAT IS MANDATORY. Follow exactly:

```
[CARL] {emoji} {description} | File: {path or "N/A"} | Task: {id or "general"}
```

**Severity emojis:** 🔴 Critical, 🟠 High, 🟡 Medium, ⚪ Low

**Rules:**
- One issue per line
- Use "N/A" for file if issue is architectural/cross-cutting
- Use "general" for task if issue spans multiple tasks or is a PRD gap
- If zero issues found: `[CARL] ✅ No issues found`

PER-RULE VERDICTS ARE MANDATORY. For every rule in the numbered rubric, emit one line:
R{n}: pass   or   R{n}: fail
(one rule per line, no other text on the line, no rationale).

## Frontend & Design Focus

You still review every dimension in the checklist, but you are the panel's
frontend and design specialist. On any UI, component, styling, or
user-facing change, review with extra depth:

- Accessibility: semantic markup, keyboard navigation, focus management,
  ARIA usage, colour contrast, screen-reader labels.
- Responsive behaviour: layout across breakpoints, overflow, touch targets.
- Visual consistency: design-token usage, spacing/typography scale, reuse
  of existing components over one-off styling.
- UX correctness: loading/empty/error states, form validation feedback,
  no layout shift, sensible defaults.
- Component structure: state vs props boundaries, no prop drilling,
  composability, no duplicated markup.

If the change has no frontend surface, review it as a generalist against
the shared checklist - do not invent frontend findings.
