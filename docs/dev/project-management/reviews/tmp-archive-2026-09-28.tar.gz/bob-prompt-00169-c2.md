Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-context-00169-c2.md for review context, and /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00169-c2.diff for the full diff.

Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/engram-pack-00169-c2.md and treat its full content as prepended context: similar code, reuse precedent, findings precedent, and task prose for this diff's changed symbols.

Use this review checklist:

# Review Dimensions

Detailed checklist for reviewing completed work.

## Plan Compliance

- [ ] Implementation matches task description
- [ ] All acceptance criteria met
- [ ] No scope creep (extra features not requested)
- [ ] No missing pieces from original task

## PRD Coverage

- [ ] All "must have" requirements addressed
- [ ] Success metrics achievable with implementation
- [ ] No PRD sections left unimplemented
- [ ] Dependencies correctly handled

## Simplification

Hunt actively for simplification — do not just tick boxes. The diff under
review is fresh; this is the cheapest moment to cut complexity before it sets.
For every added or changed file, ask "what would make this simpler to read
without changing what it does?" and flag concrete opportunities.

- [ ] **Reduce complexity** — no needless indirection, dead branches, or
      abstractions built for a single caller; nesting <= 4 levels; functions
      under 50 lines
- [ ] **Eliminate redundancy** — no logic duplicated within the diff or against
      existing code; no helper that reimplements a stdlib or existing utility
- [ ] **Improve naming** — names state intent; no opaque abbreviations;
      action-named functions start with a verb
- [ ] **Follow project standards** — conventions from CLAUDE.md / AGENTS.md and
      the surrounding code; no style drift
- [ ] **No dead code** — no commented-out blocks, unused imports, variables, or
      speculatively-added parameters
- [ ] **Appropriate error handling** — explicit, never silently swallowed

**How to flag a simplification:** give the file:line, the current shape, and
the simpler replacement. Flag concrete behavior-preserving simplifications at
🟡 Medium so the decision gate routes them into the rework loop. Do not inflate
them to 🟠 High; that floods the rework loop and can trip the scope alarm.

**Balance — do not over-simplify:** never propose a change that trades clarity
for brevity, drops error handling, collapses a deliberate boundary, or removes
a documented invariant. Simpler means easier to read and maintain, not shorter
at any cost. If a "simplification" would change behavior, it is out of scope —
do not flag it.

## Testing

- [ ] Unit tests for new logic
- [ ] Edge cases covered
- [ ] Error paths tested
- [ ] Integration tests if crossing boundaries
- [ ] Tests actually run and pass

## Security

- [ ] No hardcoded secrets
- [ ] Input validation at boundaries
- [ ] No SQL/command injection risks
- [ ] Auth/authz correctly applied
- [ ] Sensitive data not logged

## Documentation

- [ ] Public APIs documented
- [ ] Complex logic has comments
- [ ] README updated if needed
- [ ] Breaking changes noted

In addition, work through the numbered rubric:

# Review-Work-Completion Rubric

This rubric defines binary pass/fail criteria for consensus review of completed work. Each rule is numbered and stable for tracking coverage. Reviewers must answer "R{n}: pass|fail" for every rule in their prompt.

## Rules

### Tests

R1: Tests cover every new behavior introduced by the diff.
R2: Tests bind to intent, not just observable behavior.
R3: No skipped or xfail tests mask failures.

### Integration

R4: Changed components integrate with existing callers.

### Security

R6: No hardcoded secrets in the codebase.
R7: All user input is validated and sanitized.
R8: No injection-unsafe queries or commands.

### Domain

R9: Implementation matches PRD feature behavior exactly.
R10: Error handling is explicit and not swallowed.
R11: No debug statements, TODOs, or placeholder markers remain.

### Code Quality

R12: Function sizes respect the 50-line limit.
R13: File sizes respect the 800-line limit.

Review the completed work against PRD requirements. Explore the codebase as needed.

OUTPUT FORMAT IS MANDATORY. Follow exactly:

## Agent Output Format

Each agent outputs issues in this exact format:

```
[{AGENT_NAME}] {emoji} {description} | File: {path or "N/A"} | Task: {id or "general"}
```

**Severity emojis:** 🔴 Critical, 🟠 High, 🟡 Medium, ⚪ Low

**Rules:**
- One issue per line
- Use "N/A" for file if issue is architectural/cross-cutting
- Use "general" for task if issue spans multiple tasks or is a PRD gap
- If zero issues found: `[{AGENT_NAME}] ✅ No issues found`

**Examples:**
```
[ALICE] 🔴 SQL injection in query builder | File: src/db/query.ts | Task: 3
[BOB] 🟠 Missing error handling strategy | File: N/A | Task: general
[CARL] 🟡 PRD section 2.3 not implemented | File: N/A | Task: 5
```

YOUR AGENT NAME IS **BOB**. Every issue line must start with `[BOB]`.

PER-RULE VERDICTS ARE MANDATORY. For every rule in the numbered rubric, emit one line:
R{n}: pass   or   R{n}: fail
(one rule per line, no other text on the line, no rationale).

## Sandbox Constraints

You run in a restricted sandbox. You CANNOT execute code, tests, linters, or package managers.

Perform STATIC analysis only:
- Read code for logical correctness, patterns, naming, structure
- Check for missing imports, dead code, type mismatches
- Review against PRD requirements by reading, not executing
- Trace data flow and control flow by reading source

If a criterion requires runtime verification (e.g. "tests pass", "linter clean"), output:
[BOB] ⚪ Cannot statically verify: {criterion description} | File: N/A | Task: {id}

Do NOT attempt to run commands. Do NOT report failures from blocked execution.

---

## This is an INCREMENTAL review (cycle 2 of cap 2)

This is an **incremental review** of the rework done since the previous review cycle — the diff is scoped to changes since then (`f00c4839..28dda73`, 14 commits, 15 files, +1206/-188). Two jobs: (1) for each prior finding listed below, verify it is now resolved in the code; (2) review the scoped diff for any regression the rework introduced. You need not re-review unchanged code; the previous cycle already reviewed the full implementation.

**You reviewed cycle 1 yourself** (this codex session resumes it). Your own cycle-1 findings that were routed to rework are listed below; you are the best-placed reviewer to judge whether they are genuinely closed rather than papered over.

**This is the LAST cycle.** `rework_cap` is 2. Findings you raise now either get fixed in a final sweep (Medium/Low), get deferred with a written reason (High), or stall the PRD (Critical). Calibrate severity honestly — do not inflate to force attention, and do not suppress a real defect because the cycle is closing.

### Prior-cycle findings ROUTED TO REWORK — verify each is now closed

1. 🟠 HIGH (yours) — A modified doogat that becomes malformed is skipped without removing its previously indexed base/materialized rows, leaving stale content queryable after HEAD is marked current. `ddb-core/src/indexer/rebuild.rs:120`. → task 15.
2. 🟡 — `summarize_reindex_warnings` mislabels (takes `warnings[0]` regardless of variant, so an advisory `CrossZoneDuplicate`/`MissingRequired` for a *successfully indexed* file gets labelled `REINDEX_SKIPPED_FILES`), miscounts (`warnings.len() - 1` with no dedup, so one poison file renders "(+1 more)" naming a file that does not exist), and points at `ddb doctor`, which is not a command. `ddb-core/src/app_contract/output.rs`. → task 16.
3. 🟡 (4/5 consensus) — The schema-upgrade lock-scope fix (`0537b18`) has no discriminating regression test; the deterministically-testable half is the post-lock `read_needs_drop` re-check at `indexer/mod.rs:212-217`. Also: the cold-start e2e compares reported IDs only with git HEAD and never directly verifies the SQLite row count, so a CLI read-back would self-heal what direct DB inspection would catch (`tests/e2e/concurrent_writes.rs:150`). → task 17.
4. 🟡 (3/5 consensus) — The rebuild-lock acquisition block is duplicated verbatim three times (`configure_connection`, `locked_rebuild`, `locked_explicit_rebuild`); `batch_index_changes` duplicates the read/parse/strict/warning state machine across batch and singleton branches and exceeds 50 lines; `indexer/mod.rs` crossed the 800-line cap (749 → 837) and `configure_connection` tripled (26 → ~80 lines). → task 18. **The extraction must be behavior-preserving — check the guard lifetime especially, since shortening it is exactly the bug `0537b18` fixed.**
5. 🟡 — `ddb reindex` prints only "N warning(s)"; skipped paths reach the user only via tracing stderr, so `RUST_LOG=error` names nothing (`ddb-cli/src/commands/maintenance.rs:62`). And no test anywhere asserts the CLI `AppWarning` leg (`write_warnings` → stderr on `ddb create`); smoke section 32 bound `reindex`'s *tracing* output instead. → task 19.
6. 🟡 (3/5 consensus) — Docs: `invariants.md` I5 claims the skip-warning reaches "the verb envelope" generally without qualifying that only create/update/apply_schema wire it; `docs/src/technical/indexer.md` shows the obsolete two-argument `incremental_reindex` signature and never describes collect-and-skip/strict, the schema-version stamp, or the 256 KiB frontmatter cap; CHANGELOG omits the compile-breaking `ConsistencyWarning::UnreadableFile` addition. → task 20.

## Settled decisions — do not re-raise

These calls were already made in an earlier cycle of this same review, with the reasons given. Do not re-raise them. Raise a NEW finding only if you can show the settled reason no longer holds.

- **settled-deferral / high / `ddb-core/src/service/search.rs`** — *"Phase 1's acceptance criterion 'a create AND a search both carry a skip AppWarning' is unmet for search (and read/sql/discovery/batch/delete/utility): every verb except create/update/apply_schema calls `self.ensure_fresh()?;` bare and discards the warnings."* Reason: confirmed real and deliberately narrowed at design time. Severity adjudicated HIGH not CRITICAL — skips are not silent (per-file `tracing::warn!` still fires) and the index is a derived cache with git as source of truth. Routing search through an `AppOutput` envelope is the entire subject of backlog PRD 00176; bolting one on here duplicates and pre-empts that reshape. Also proven unimplementable as literally written: the warning is consume-once (the first verb's `ensure_fresh` reindexes and leaves the index fresh), so a create AND a subsequent search cannot both carry it for one poison event. The overstated `invariants.md` I5 wording was corrected in this cycle's rework.
- **settled-deferral / high / `ddb-core/src/parser/mod.rs`** — *"The 256 KiB check runs only after the entire blob is decoded, split into a line vector, and frontmatter is copied; adversarial input can still consume unbounded read/scan memory."* Reason: `MAX_FRONTMATTER_BYTES` bounds `serde_yaml` parse cost only. Read cost is inherent to git2's blob model — the blob is fully materialized in memory by git2 before any ddb code sees it, so a parse-boundary cap cannot bound it. Recorded as a documented partial-miss; a real fix needs a streaming blob reader, a separate PRD.
- **settled-deferral / high / `ddb-server/src/read_pool.rs`** — *"ReadPool bypasses freshness and rebuild-lock coordination, so reads can still observe tables while another connection has dropped them."* Reason: an explicitly accepted residual gap, named in the design doc's Risks section and listed in `docs/src/technical/invariants.md` I10. ReadPool readers set `skip_stale_check` deliberately and trust WAL visibility. Not a regression, and not in this PRD's test matrix.
- **settled-deferral / low / `ddb-core/src/ffi/driver.rs`** — *"`ConsistencyWarning.error` and FFI `RebuildWarningRecord.message` carry unbounded strings from untrusted synced content; the count is capped, the size is not."* Reason: documented as an accepted residual in the design doc's Risks section before implementation began. A truncation pass is a follow-up, not a regression in this diff.
- **settled-deferral / low / `ddb-core/src/app_contract/output.rs`** — *"Phase 1 text specifies `From<ConsistencyWarning> for AppWarning`; the implementation uses free summarizing functions instead."* Reason: deliberate and design-reviewed. A `From` impl maps one warning to one `AppWarning`, which directly contradicts the PRD's own Risk-section mitigation ("attach a single summary `AppWarning` (count + see ddb doctor) on the verb envelope"). The free-function shape implements the PRD's intent; only the task's shorthand phrasing differs.
- **settled-deferral / low / `tests/smoke.sh`** — *"Pre-existing `! $DDB ...` smoke assertions retain the errexit false-pass hazard."* Reason: pre-existing in sections this PRD never touched; the build session fixed the instance its own new section introduced and left the older ones alone under the surgical-changes rule. The class deserves a dedicated sweep PRD.
- **settled-deferral / medium / `ddb-core/src/indexer/tests/mod.rs`** — *"The new resilience tests add ~1,680 repetitive lines to an already monolithic 6,034-line module."* Reason: the module was already 4,354 lines before this PRD, so the monolith is pre-existing and this diff widened rather than created it. Splitting it is a wide mechanical refactor with real risk of silently dropping a test, disproportionate inside an unrelated PRD's rework cycle.
- **settled-deferral / medium / `tests/e2e/common.rs`** — *"E2E flake attribution is plausible but unproven."* Reason: two full e2e runs at the base commit is Tier 2 work by this repo's two-tier Definition of Done. Mechanism identified (bind-then-release `TcpListener` port probe, a TOCTOU window under 451-way parallelism). Deserves its own PRD.
- **settled-deferral / medium / `tests/integration.sh`** — *"section 63 has never executed locally."* Reason: execution of `tests/integration.sh` is explicitly delegated to Tier 2 CI by the repo's Definition of Done; authoring it was the per-PRD deliverable and that is done.
- **settled-deferral / medium / `tests/integration.ps1`** — *"integration.ps1 §63 and smoke.ps1 §32 have never run anywhere."* Reason: no `pwsh` resolves on this host, so local execution is impossible, not skipped. Parity was maintained by line-for-line review, which did catch two real defects. Windows CI is the first real execution by construction; this is the standard arrangement for the `.ps1` ports in this repo.
- **discarded / critical / N/A** — *"No regression test for the CRITICAL rebuild-lock guard scope bug; the loser's drop deletes tables the winner is already using."* Reason: the CRITICAL severity rests on a false premise about the current code. Verified at `ddb-core/src/indexer/mod.rs`: `_guard` is bound at function scope and held across drop, `SCHEMA_DDL` recreate, and the `user_version` stamp — the failure mode described is the PRE-FIX behavior that commit `0537b18` already removed. The missing-test half was NOT discarded and is task 17.
- **discarded / low / N/A** — *"Cannot statically verify: Tier 1 gates, PowerShell scenarios, or the E2E flake attribution."* Reason: not a finding about the work — it is the sandbox boilerplate. The Tier 1 gates it names were in fact run.

## Mechanical facts (computed, do not re-count)

File line counts at HEAD `28dda73`, from `wc -l`. Cite these for countable file-size claims; a finding that contradicts this block is discarded at the review gate. (Per-function line counts are NOT computed for this Rust repo — count those yourself and show your work.)

- `ddb-core/src/indexer/mod.rs` — 788 lines (was 837 at cycle 1; the 800 cap is met)
- `ddb-core/src/indexer/rebuild.rs` — 613 lines
- `ddb-core/src/indexer/schema_version.rs` — 83 lines (new file)
- `ddb-core/src/app_contract/output.rs` — 357 lines
- `ddb-core/src/indexer/tests/mod.rs` — 6784 lines (pre-existing monolith, settled above)

## Known state the build session reported — raise these only if the report is WRONG

- `incremental_reindex`'s `strict: bool` is never `true` on any user-facing path: one production call site passes `false`, and `reindex_strict()` routes through `locked_explicit_rebuild → rebuild_strict`. Only tests exercise the parameter. Docs now say so; the affordance was left alone.
- OPEN, carried from task 15's per-task review: `evict_doogats(&to_delete)` runs BEFORE `batch_index_changes`, so a **strict** run over a change-set containing BOTH a deletion AND a poison file applies the deletion and then errors. Pre-existing since `e5ec64a`; the CHANGELOG wording was corrected instead of the code. One-line fix available: fold both eviction sites into one call after `batch_index_changes`. **Judge whether that is acceptable to ship.**
- `tests/smoke.ps1` section 33 was REVIEWED, NOT EXECUTED (no `pwsh` on this host).
- `Index::drop_all_tables` (`indexer/mod.rs`) is a near-copy of the drop loop now in `indexer/schema_version.rs`; the only difference is where `PRAGMA foreign_keys = OFF` sits. Flagged, deliberately not unified. **Judge whether leaving both is right.**
- Task 17's re-check test carries an anti-vacuity guard, but a residual timing gap remains: a waiter thread that never reaches its pre-check would also read as "parked". Accepted on the grounds that the test was proven discriminating twice (the re-check was reverted and the sentinel died).

## Tier 1 gate results at HEAD `28dda73` (run by the orchestrator, not by you)

`cargo build` OK · `cargo clippy --workspace --all-targets` clean · `cargo test-ci` (ddb-core 1549 passed, ddb-server 222 passed) · `cargo test -p ddb-e2e` 451 passed · `bash tests/smoke.sh` all-passed · `cd docs && mdbook build` OK.

---

## Two lenses, applied to every changed file

Treat the following as findings precedent already recorded for this diff's changed symbols. Weigh it when applying both lenses and the rubric verdicts rather than re-litigating known prior findings.

- findings:00168-bundle-import-conflict-recovery-v1-review-02.md — (clean), `cargo test -p ddb-core --lib bundle::` (15 passed), `... sync_manager::`
- findings:00168-bundle-import-conflict-recovery-v1-review-02.md — (`git show 35e594e:ddb-core/src/bundle.rs` lines 141-157 vs `bundle/mod.rs:187-204`);
- findings:00168-bundle-import-conflict-recovery-v1-review-02.md — `cargo test -p ddb-core --lib` both exceed the 10-minute per-call ceiling in this repo
- findings:00168-bundle-import-conflict-recovery-v1-review-02.md — Calendar validation duplicates standard functionality incompletely — ddb-core/src/types/doogat.rs:19 — implement the test helper with `chrono::NaiveDateTime::parse_from_str`
- findings:00165-deterministic-crdt-resolution-v1-review-01.md — [BOB] ⚪ New test file uses decorative non-ASCII comment rulers with no value. | File: ddb-core/tests/crdt_determinism.rs | Task: 2
- findings:00163-git-tree-construction-correctness-v1-review-01.md — `tests.rs` (963) and `mod.rs` (846) exceed the 800-line style guideline; the merge test (~88 lines) exceeds the 50-line function guideline. Deferred: soft style guideline on test/pre-existing files.
- findings:00164-unify-id-minting-v1-review-01.md — the slice is pre-existing but this PRD edited the exact line; touches the P0 "no runtime panics on filesystem/user-input state" class; downgraded from 🔴 to 🟠.
- findings:00164-unify-id-minting-v1-review-01.md — [1/5] ⚪ parser tightening makes `meta.id=None` more reachable; indexer stores such docs as `id=""` — two id-less files collide at `id=""` under `INSERT OR REPLACE`. Pre-existing indexer behavior; index is derived/rebuildable. Deferred as a hardening follow-up (relates to 00169 poison-file-reindex-resilience).
- findings:00164-unify-id-minting-v1-review-01.md — [BLAKE] ⚪ `install_bundled_type` skips the `ensure_fresh()` other create paths run. Asymmetry, not a defect. | File: ddb-core/src/service/discovery.rs
- findings:00164-unify-id-minting-v1-review-01.md — [BOB] 🟡 The repo-only SQL regression seeds `Local::now()` then mints; if the second rolls between commit and mint, an old index-only impl can pass without testing the intended collision. | File: ddb-core/src/sql_engine/tests.rs | Task: 4

### 1. Doubt lens (correctness)
Surface residual findings a confident reviewer would wave past:
- spec gaps: PRD says X, code does Y (wrong field names, enum values,
  thresholds, artifact kind);
- missing or incomplete features the PRD requires;
- edge cases, error paths, and failure modes left unhandled;
- tests that assert the implementation rather than the intent (cannot fail when
  the business rule changes).

### 2. De-slop lens (quality)
Flag slop introduced by the changes (do not propose broad refactors):
- over-abstraction / single-caller indirection with no current testability or
  architectural need;
- dead code, code kept in comments, unreachable branches;
- defensive guards for states that cannot occur;
- restating docstrings, "robust" error messages with no context, premature
  configuration, framework-verification tests;
- speculative generality (parameters, hooks, or layers nothing uses yet).
Bias: aggressive on newly-created files (slop concentrates there), conservative
on lightly-touched files (do not destabilize existing behavior).

## Categorize every residual finding

In addition to the `[BOB] {emoji} ... | File: ... | Task: ...` issue lines above,
place EACH residual finding in exactly one bucket:
- **FIX** — genuinely fixable now: bounded scope, in-scope, actionable.
- **VERIFY** — needs a specific named check to resolve (state the exact check,
  not "look into X").
- **KNOWN** — a real limitation that is out of scope; include a one-line written
  justification.

Output the buckets as three sections, one finding per line:

```
FIX:
- <finding> — <file:line> — <the concrete fix>
VERIFY:
- <finding> — <the exact check to run>
KNOWN:
- <finding> — <why it is out of scope>
```

If a bucket is empty, write the header and `- (none)`.

## Rubric verdicts (REQUIRED — emit verbatim, one per line)

Apply the doubt-review rubric. A rule you cannot evaluate is `fail`; never omit
a line.
- D1: every residual finding is in exactly one of FIX/VERIFY/KNOWN.
- D2: all FIX items are genuinely fixable now (bounded, in-scope, actionable).
- D3: all VERIFY items name the exact check needed (not vague).
- D4: all KNOWN items carry a written out-of-scope justification.
- D5: input finding count equals FIX + VERIFY + KNOWN counts.

Emit exactly:

```
D1: pass|fail
D2: pass|fail
D3: pass|fail
D4: pass|fail
D5: pass|fail
```

Do not modify any files. This is a review only — produce findings and the
rubric verdict lines. No commits.
