# Completed tasks — PRD 00168 bundle-import conflict recovery (cycle 1)

All 8 planned tasks are `completed`. Diff range under review: `35e594e9a693e2d3bf1a6740bbfcdb8f4fba7797..HEAD` (HEAD = `e531306978164c21a9b61a8547667bd930dba45b`).

| Task | Name | Status | Commit(s) | Notes |
|------|------|--------|-----------|-------|
| 1 | Add `delete_remote_ref` to `GitRemote` trait, `GitRepo`, and its delegation | completed | `bfa90fc` (tests), `685c68e` (impl) | Implementor: claude (sonnet). New trait method + write-locked git2 impl + delegating arm. |
| 2 | Widen `SyncManager::apply_merge_result` to `pub(crate)` | completed | `63fb1ec` | Implementor: qwen (sonnet tier). Visibility-only change, no body change. |
| 3 | Rewire bundle-import merge through the network-sync merge engine | completed | `6fc1efa` (test), `fd9ecbe` (impl), `872f2b5` (follow-up fix) | Implementor: claude (sonnet). `872f2b5` keeps the merge-base guard for non-bundle remotes. |
| 4 | Unit tests: conflicted-bundle recovery, reachability, and clean-repo-on-error | completed | `f1315fa` | Implementor: claude (sonnet). |
| 5 | Add a bundle-import conflict scenario to `tests/integration.sh` | completed | `57c66b4` | Implementor: claude (sonnet). Scenario 28a. |
| 6 | Mirror the bundle-import conflict scenario in `tests/integration.ps1` | completed | `54de391` | Implementor: qwen (haiku tier). Verification delegated to CI. |
| 7 | Author the bundle-import conflict-recovery e2e test | completed | `3b547df` (test), `73a31ca` (de-slop) | Implementor: qwen (sonnet tier). |
| 8 | Docs, CHANGELOG, walkthrough, and invariant-note updates | completed | `e531306` | Implementor: qwen (sonnet tier). |

## Commit list (oldest first)

```
bfa90fc test(git_ops): add tests for delete_remote_ref (00168)
685c68e feat(git_ops): add delete_remote_ref to GitRemote (00168)
63fb1ec refactor(sync): widen apply_merge_result to pub(crate) (00168)
6fc1efa test(bundle): pin conflicted-bundle-import real-merge-commit behavior (00168)
fd9ecbe feat(bundle): rewire bundle-import merge through the network-sync engine (00168)
872f2b5 fix(git-ops): keep the merge-base guard for non-bundle remotes (00168)
f1315fa test(bundle): pin reachability and clean-repo-on-error for a failed bundle-import merge (00168)
57c66b4 test(integration): add bundle-import conflict scenario 28a (00168)
54de391 test(integration): mirror bundle-import conflict scenario 28a to .ps1 (00168)
3b547df test(e2e): add bundle-import conflict-recovery scenario
73a31ca chore: prune slop from Author the bundle-import conflict-recovery e2e test
e531306 docs(bundle): document conflict recovery and close the 00168 write-lock invariant
```
