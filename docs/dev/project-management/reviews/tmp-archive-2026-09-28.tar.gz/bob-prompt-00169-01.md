Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-context-00169-01.md for review context, and /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/review-diff-00169-01.diff for the full diff.

Read /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/engram-pack-00169-01.md and treat its full content as prepended context: similar code, reuse precedent, findings precedent, and task prose for this diff's changed symbols.

Use this review checklist:

# Review Dimensions

Detailed checklist for reviewing completed work.

## Plan Compliance

- [ ] Implementation matches task description
- [ ] All acceptance criteria met
- [ ] No scope creep (extra features not requested)
- [ ] No missing pieces from original task

## PRD Coverage

- [ ] All "must have" requirements addressed
- [ ] Success metrics achievable with implementation
- [ ] No PRD sections left unimplemented
- [ ] Dependencies correctly handled

## Simplification

Hunt actively for simplification — do not just tick boxes. The diff under
review is fresh; this is the cheapest moment to cut complexity before it sets.
For every added or changed file, ask "what would make this simpler to read
without changing what it does?" and flag concrete opportunities.

- [ ] **Reduce complexity** — no needless indirection, dead branches, or
      abstractions built for a single caller; nesting <= 4 levels; functions
      under 50 lines
- [ ] **Eliminate redundancy** — no logic duplicated within the diff or against
      existing code; no helper that reimplements a stdlib or existing utility
- [ ] **Improve naming** — names state intent; no opaque abbreviations;
      action-named functions start with a verb
- [ ] **Follow project standards** — conventions from CLAUDE.md / AGENTS.md and
      the surrounding code; no style drift
- [ ] **No dead code** — no commented-out blocks, unused imports, variables, or
      speculatively-added parameters
- [ ] **Appropriate error handling** — explicit, never silently swallowed

**How to flag a simplification:** give the file:line, the current shape, and
the simpler replacement. Flag concrete behavior-preserving simplifications at
🟡 Medium so the decision gate routes them into the rework loop. Do not inflate
them to 🟠 High; that floods the rework loop and can trip the scope alarm.

**Balance — do not over-simplify:** never propose a change that trades clarity
for brevity, drops error handling, collapses a deliberate boundary, or removes
a documented invariant. Simpler means easier to read and maintain, not shorter
at any cost. If a "simplification" would change behavior, it is out of scope —
do not flag it.

## Testing

- [ ] Unit tests for new logic
- [ ] Edge cases covered
- [ ] Error paths tested
- [ ] Integration tests if crossing boundaries
- [ ] Tests actually run and pass

## Security

- [ ] No hardcoded secrets
- [ ] Input validation at boundaries
- [ ] No SQL/command injection risks
- [ ] Auth/authz correctly applied
- [ ] Sensitive data not logged

## Documentation

- [ ] Public APIs documented
- [ ] Complex logic has comments
- [ ] README updated if needed
- [ ] Breaking changes noted

In addition, work through the numbered rubric:

# Review-Work-Completion Rubric

This rubric defines binary pass/fail criteria for consensus review of completed work. Each rule is numbered and stable for tracking coverage. Reviewers must answer "R{n}: pass|fail" for every rule in their prompt.

## Rules

### Tests

R1: Tests cover every new behavior introduced by the diff.
R2: Tests bind to intent, not just observable behavior.
R3: No skipped or xfail tests mask failures.

### Integration

R4: Changed components integrate with existing callers.

### Security

R6: No hardcoded secrets in the codebase.
R7: All user input is validated and sanitized.
R8: No injection-unsafe queries or commands.

### Domain

R9: Implementation matches PRD feature behavior exactly.
R10: Error handling is explicit and not swallowed.
R11: No debug statements, TODOs, or placeholder markers remain.

### Code Quality

R12: Function sizes respect the 50-line limit.
R13: File sizes respect the 800-line limit.

(Note: there is no R5 — the set is R1-R4 and R6-R13, twelve rules. Emit exactly those twelve verdict lines, do not invent an R5.)

Review the completed work against PRD requirements. Explore the codebase as needed.

OUTPUT FORMAT IS MANDATORY. Follow exactly:

## Agent Output Format (Single Source of Truth)

Each agent outputs issues in this exact format:

```
[{AGENT_NAME}] {emoji} {description} | File: {path or "N/A"} | Task: {id or "general"}
```

**Severity emojis:** 🔴 Critical, 🟠 High, 🟡 Medium, ⚪ Low

**Rules:**
- One issue per line
- Use "N/A" for file if issue is architectural/cross-cutting
- Use "general" for task if issue spans multiple tasks or is a PRD gap
- If zero issues found: `[{AGENT_NAME}] ✅ No issues found`

**Examples:**
```
[ALICE] 🔴 SQL injection in query builder | File: src/db/query.ts | Task: 3
[BOB] 🟠 Missing error handling strategy | File: N/A | Task: general
[CARL] 🟡 PRD section 2.3 not implemented | File: N/A | Task: 5
```

YOUR AGENT_NAME IS `BOB`. Every issue line must start with `[BOB]`.

PER-RULE VERDICTS ARE MANDATORY. For every rule in the numbered rubric, emit one line:
R{n}: pass   or   R{n}: fail
(one rule per line, no other text on the line, no rationale).

## Sandbox Constraints

You run in a restricted sandbox. You CANNOT execute code, tests, linters, or package managers.

Perform STATIC analysis only:
- Read code for logical correctness, patterns, naming, structure
- Check for missing imports, dead code, type mismatches
- Review against PRD requirements by reading, not executing
- Trace data flow and control flow by reading source

If a criterion requires runtime verification (e.g. "tests pass", "linter clean"), output:
[BOB] ⚪ Cannot statically verify: {criterion description} | File: N/A | Task: {id}

Do NOT attempt to run commands. Do NOT report failures from blocked execution.

---

# SECOND LENS — you also carry the doubt lens this cycle

You are ALSO the final skeptical reviewer for this completed PRD implementation. A
confident implementer just finished and earlier per-task reviews passed. Your job
is to find what they and the prior reviewers missed, and to flag slop the
implementation accumulated. Assume the work is subtly wrong until proven
otherwise. Do not be agreeable.

## Two lenses, applied to every changed file

Treat the following as findings precedent already recorded for this diff's changed symbols. Weigh it when applying both lenses and the rubric verdicts rather than re-litigating known prior findings.

- findings:dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  2. [D2] Add `commit_merge` write-lock contention regression test (S) — 🟡 — mirrors `merge_blocks_while_write_lock_held`; proves `commit_merge` holds the write lock.

- findings:dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  - **[2/5] 🟠 (panic-safety) `title_from_path` slices `&filename[..14]`, which panics when byte 14 is inside a multibyte char** | File: `ddb-core/src/consistency/mod.rs:335` | Found by: Carl (🔴 panic), Quinn (🟡 redundant `>=14` guard).

- findings:dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  - **[1/5] ⚪ parser tightening makes `meta.id=None` more reachable; indexer stores such docs as `id=""`** (Blake, `parser/mod.rs`) — **verified**: `indexer/mod.rs:257`, `materialize.rs:448`, `rebuild.rs:222` do `meta.id...unwrap_or("")`, so two id-less (malformed/non-native) files collide at `id=""` under `INSERT OR REPLACE`. Pre-existing indexer behavior; index is derived/rebuildable (git is source of truth). Deferred as a hardening follow-up (relates to 00169 poison-file-reindex-resilience).

- findings:dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  [BLAKE] ⚪ `install_bundled_type` skips the `ensure_fresh()` other create paths run; mint safe (oracle reads HEAD), but subsequent `index_doogat` proceeds against a possibly-stale index. Asymmetry, not a defect. | File: ddb-core/src/service/discovery.rs | Task: general

- findings:dev/local/reviews/00164-unify-id-minting-v1-review-02.md
  1. **consistency/mod.rs:335 slice panic** → fixed via `filename.get(..14)` (panic-safe; None on non-char-boundary), redundant `>=14` guard removed, regression test `title_from_path_multibyte_stem_does_not_panic` added and passing. Confirmed by Alice, Bob, Carl, Quinn.

- findings:dev/local/reviews/00165-deterministic-crdt-resolution-v1-review-01.md
  [QUINN] ⚪ `value.to_str().unwrap_or_else(|| value.to_string())` silently falls back to Debug-style to_string for non-String values. | File: ddb-core/src/crdt_resolver.rs | Task: 1

- findings:dev/local/reviews/00166-make-hlc-load-bearing-v1-review-01.md
  [BOB] ⚪ persist() uses a fixed shared temp name (ddb-hlc.tmp); unlocked load-time repair in open/init could interleave with a concurrent process → torn/lower cache. Mitigated by lock on tick/recv + floor + re-seed. | File: ddb-core/src/git_ops/hlc_clock.rs | Task: 1

- findings:dev/local/reviews/00166-make-hlc-load-bearing-v1-review-02.md
  [BLAKE] 🟡 Layer-boundary risk realized: `GitRepo` owns and constructs the `HlcClock` (field `hlc_clock` + `HlcClock::load` in `init`/`open`), which the PRD Risk and AGENTS.md guardrail warn against. Behavior is correct and well-tested; architecture deviation, not a functional defect. | File: ddb-core/src/git_ops/mod.rs | Task: Phase 0

### 1. Doubt lens (correctness)
Surface residual findings a confident reviewer would wave past:
- spec gaps: PRD says X, code does Y (wrong field names, enum values,
  thresholds, artifact kind);
- missing or incomplete features the PRD requires;
- edge cases, error paths, and failure modes left unhandled;
- tests that assert the implementation rather than the intent (cannot fail when
  the business rule changes).

### 2. De-slop lens (quality)
Flag slop introduced by the changes (do not propose broad refactors):
- over-abstraction / single-caller indirection with no current testability or
  architectural need;
- dead code, code kept in comments, unreachable branches;
- defensive guards for states that cannot occur;
- restating docstrings, "robust" error messages with no context, premature
  configuration, framework-verification tests;
- speculative generality (parameters, hooks, or layers nothing uses yet).
Bias: aggressive on newly-created files (slop concentrates there), conservative
on lightly-touched files (do not destabilize existing behavior).

## Rubric verdicts (REQUIRED — emit verbatim, one per line)

Apply the doubt-review rubric. A rule you cannot evaluate is `fail`; never omit
a line.
- D1: every residual finding is in exactly one of FIX/VERIFY/KNOWN.
- D2: all FIX items are genuinely fixable now (bounded, in-scope, actionable).
- D3: all VERIFY items name the exact check needed (not vague).
- D4: all KNOWN items carry a written out-of-scope justification.
- D5: input finding count equals FIX + VERIFY + KNOWN counts.

Emit exactly:

```
D1: pass|fail
D2: pass|fail
D3: pass|fail
D4: pass|fail
D5: pass|fail
```

Because you carry the doubt lens, ALSO emit the three categorization buckets,
one finding per line, after your `[BOB]` issue lines:

```
FIX:
- <finding> — <file:line> — <the concrete fix>
VERIFY:
- <finding> — <the exact check to run>
KNOWN:
- <finding> — <why it is out of scope>
```

If a bucket is empty, write the header and `- (none)`.

Do not modify any files. This is a review only.

---

# THREE THINGS THIS REVIEW SHOULD SCRUTINISE HARDEST

The build session recorded these deliberately, so they are not hidden from you.
They are leads, not conclusions — confirm or refute each against the source.

1. **A KNOWN-UNMET FAIL-FIRST OBLIGATION.** Task 8 fixed a CRITICAL (commit
   `0537b18`: the rebuild-lock guard was moved out of the `if needs_drop` block
   so it now lives across drop + recreate + version stamp) and shipped it with
   NO regression test. The repo rule (`rules/testing.md`) requires a bug fix to
   ship with a test watched failing against the old code. Task 14 settled this
   as an ACCEPTED GAP, arguing that nothing writes rows between the drop and the
   stamp, so a loser in that window only drops and recreates EMPTY tables —
   leaving an end state indistinguishable from correct, which means no test can
   discriminate the fixed shape from the buggy one. The gap is bound only by a
   comment at `ddb-core/src/indexer/mod.rs:190-210`. **Challenge that argument.**
   It is the weakest load-bearing claim in this PRD.

2. **PRE-EXISTING E2E FLAKINESS.** A full `cargo test -p ddb-e2e` failed 1 of
   451 on each of two runs — a DIFFERENT test each time
   (`typed_where_filter_completeness`, then `serve::execute_batch_format_objects`
   with a reqwest ConnectionRefused). Both pass in isolation. Believed to be port
   contention / server-readiness under 451-way parallelism, NOT caused by this
   PRD. Judge whether that attribution holds.

3. **A RECURRING FALSE-PASS CLASS — it bit three times in this PRD.** Any
   assertion that reads back through a CLI or GraphQL path first calls
   `ensure_fresh`, which self-heals a stale or dropped index before answering —
   so the assertion cannot fail. It was caught in task 11's smoke assertion,
   avoided in task 12, and caught AGAIN by the per-task reviewer in task 14's
   e2e (removed in `f00c483`). Look for any remaining instance. Note also that
   `tests/smoke.sh` still uses the bare `! $DDB ...` idiom in several
   PRE-EXISTING sections; bash exempts a `!`-inverted command from `errexit`,
   which is the same false-pass risk, left alone under the surgical-changes rule.
