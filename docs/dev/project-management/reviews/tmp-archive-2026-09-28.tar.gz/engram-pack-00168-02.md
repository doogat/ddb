Portfolio freshness: NOT refreshed this cycle (PRD 00002 pending)

42 changed symbol(s) omitted (beyond the 40-symbol cap).

## Similar code

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/consistency/mod.rs:634-634
  mod tests;

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/compaction/mod.rs:424-424
  mod tests;

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/ffi/mod.rs:11-11
  mod tests;

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-server/src/auth.rs:60-87
  mod tests {
    use super::*;

    #[test]
    fn validate_bearer_accepts_matching_token() {
        assert!(validate_bearer("Bearer secret123", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_wrong_token() {
        assert!(!validate_bearer("Bearer wrong", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_empty_string() {
        assert!(!validate_bearer("", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_missing_prefix() {
        assert!(!validate_bearer("secret123", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_lowercase_prefix() {
        assert!(!validate_bearer("bearer secret123", "secret123"));
    }
}

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/indexer/mod.rs:749-749
  mod tests;

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/service/mod.rs:134-134
  mod tests;

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/schema_diff/differ.rs:609-620
      fn changed_singleton_on_existing_type_yields_set_singleton() {
        let mut desired = tbl("a", vec![]);
        desired.singleton = true;
        let live = tbl("a", vec![]); // singleton false
        let plan = diff(&doc(vec![desired]), &[Some(live)]);

        assert_eq!(
            plan.ops,
            vec![PlanOp::SetSingleton { table: "a".into(), on: true }],
            "differing singleton must yield exactly one SetSingleton with the desired flag"
        );
    }

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/schema_diff/differ.rs:651-668
      fn changed_title_template_records_unsupported_and_emits_no_op() {
        let mut desired = tbl("a", vec![]);
        desired.title_template = Some("{{name}}".into());
        let live = tbl("a", vec![]); // title_template None
        let plan = diff(&doc(vec![desired]), &[Some(live)]);

        assert!(plan.ops.is_empty(), "no op exists for a title_template change");
        assert_eq!(
            plan.unsupported.len(),
            1,
            "exactly one warning for one unsupported change"
        );
        assert!(
            plan.unsupported[0].contains("title_template"),
            "warning must name the unsupported attribute: {}",
            plan.unsupported[0]
        );
    }

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/indexer/materialize.rs:1311-1352
  mod tests {
    use super::*;

    #[test]
    fn junction_table_name_joins_type_and_column() {
        assert_eq!(junction_table_name("link", "category"), "link_category");
    }

    #[test]
    fn junction_table_name_with_different_inputs() {
        assert_eq!(junction_table_name("project", "owner"), "project_owner");
    }

    #[test]
    fn junction_parent_id_column_appends_id_suffix() {
        assert_eq!(junction_parent_id_column("link"), "link_id");
    }

    #[test]
    fn junction_parent_id_column_with_different_type() {
        assert_eq!(junction_parent_id_column("project"), "project_id");
    }

    #[test]
    fn junction_ref_id_column_appends_id_suffix() {
        assert_eq!(junction_ref_id_column("category"), "category_id");
    }

    #[test]
    fn junction_ref_id_column_with_different_column() {
        assert_eq!(junction_ref_id_column("owner"), "owner_id");
    }

    #[test]
    fn junction_table_ddl_regression_output_preserved() {
        let ddl = junction_table_ddl("link", "category");
        assert_eq!(
            ddl,
            "CREATE TABLE IF NOT EXISTS \"link_category\" (\"link_id\" TEXT NOT NULL, \"category_id\" TEXT NOT NULL, PRIMARY KEY (\"link_id\", \"category_id\"))"
        );
    }
}

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/types/query.rs:19-37
  mod tests {
    use super::*;

    #[test]
    fn variant_set_matches_sql_parameter_domain() {
        fn assert_exhaustive(v: QueryValue) {
            match v {
                QueryValue::Null => {}
                QueryValue::Integer(_) => {}
                QueryValue::Real(_) => {}
                QueryValue::Text(_) => {}
            }
        }
        assert_exhaustive(QueryValue::Null);
        assert_exhaustive(QueryValue::Integer(0));
        assert_exhaustive(QueryValue::Real(0.0));
        assert_exhaustive(QueryValue::Text(String::new()));
    }
}

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/schema_diff/differ.rs:573-587
      fn changed_search_key_on_existing_type_yields_set_search_key() {
        let mut desired = tbl("a", vec![col("name", "TEXT")]);
        desired.search_key = Some("name".into());
        let live = tbl("a", vec![col("name", "TEXT")]); // search_key None
        let plan = diff(&doc(vec![desired]), &[Some(live)]);

        assert_eq!(
            plan.ops,
            vec![PlanOp::SetSearchKey {
                table: "a".into(),
                column: Some("name".into()),
            }],
            "differing search_key on an existing type must yield exactly one SetSearchKey with the desired value"
        );
    }

## Reuse precedent

- gems:/Users/bob/git/src/github.com/buvis/gems/src/tools/bim/tui/create_note.py:122-123
      def _field_changed(self) -> None:
        self._update_preview()

- gems:/Users/bob/git/src/github.com/buvis/gems/src/tools/bim/tui/edit_note.py:113-114
      def _field_changed(self) -> None:
        self._update_preview()

- gems:/Users/bob/git/src/github.com/buvis/gems/src/tools/bim/tui/edit_note.py:177-178
      def _field_changed(self) -> None:
        self._update_preview()

- gems:/Users/bob/git/src/github.com/buvis/gems/src/rust/src/parser/key_normalizer.rs:38-65
  mod tests {
    use super::*;

    #[test]
    fn test_simple_lowercase() {
        assert_eq!(as_note_field_name("title"), "title");
    }

    #[test]
    fn test_camel_case() {
        assert_eq!(as_note_field_name("SomeValue"), "some-value");
    }

    #[test]
    fn test_space_separated() {
        assert_eq!(as_note_field_name("Note Title"), "note-title");
    }

    #[test]
    fn test_already_kebab() {
        assert_eq!(as_note_field_name("some-value"), "some-value");
    }

    #[test]
    fn test_mixed() {
        assert_eq!(as_note_field_name("zkn-id"), "zkn-id");
    }
}

- home:/Users/bob/git/src/github.com/buvis/home/.claude/skills/run-autopilot/scripts/test_review_coverage_hook.py:695-710
      def test_missing_file_in_block_fails_missing_files(self) -> None:
        """Dropping a changed file from the block yields MISSING_FILES."""
        root, diff_range, changed = self._normal_repo_with_range()
        prd = self._write_prd(root)
        review = root / "review.md"
        # Cover only the first changed file; omit the rest.
        review.write_text(
            _coverage_block(changed[:1], self.rubric_ids, self.feature)
        )

        result = self._run_gate(root, diff_range, prd, review)

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("MISSING_FILES", result.stderr)
        for omitted in changed[1:]:
            self.assertIn(omitted, result.stderr)

## Findings precedent

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-02.md
  | [1/5] | ⚪ Low | AGENTS.md I1 bullet points the remaining bundle-import lock gap at `git_ops/merge.rs`, but that file shells out nowhere (libgit2 in-process); the `git merge` subprocess lives in `bundle::merge_bundle_and_resolve` (`ddb-core/src/bundle.rs:118`). AGENTS.md now contradicts invariants.md and git-ops.md, which both correctly name `bundle::merge_bundle_and_resolve`. | AGENTS.md | Bob |

- findings:/Users/bob/git/src/github.com/buvis/gems/dev/local/reviews/00042-bim-serve-confinement-and-auth-v1-review-02.md
  was changed.

- findings:/Users/bob/git/src/github.com/buvis/gems/dev/local/reviews/00042-bim-serve-confinement-and-auth-v1-review-01.md
  was changed.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  - **[Bob] Docs overclaim fresh-index staging across all merge paths.** `git-ops.md`, `CHANGELOG.md`, and `sync.md` say the merge write path "stages the merge tree from `fresh_index()`", but only `commit_merge`'s `build_merge_tree_and_commit` uses `fresh_index()`; the normal 3-way merge (`perform_normal_merge`) stages from libgit2's merge index and fast-forward stages nothing. The lock covers all three; fresh-index staging is specific to the conflicted-merge tree. | File: docs/src/technical/git-ops.md, CHANGELOG.md, docs/src/technical/sync.md | **VERIFIED real** (diff inspection: only `merge.rs:32` swapped to `fresh_index()`).

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  ### Medium (🟡) — deferred

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  - **[Bob] Bundle import merges via `git merge` subprocess outside the lock** → 00168.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-02.md
  **Orchestrator verification of the finding (CONFIRMED):** `rg` over `git_ops/merge.rs` shows no `Command::new`/`git merge` (all libgit2); `bundle.rs:118-126` spawns `git merge refs/remotes/bundle/master --no-edit --allow-unrelated-histories`. invariants.md I1 (line 14) and git-ops.md both already read `bundle::merge_bundle_and_resolve`. Only AGENTS.md carries the stale `git_ops/merge.rs` reference (perpetuated by D2-1's rewrite of that bullet). Single-site fix. → **cycle-3 auto-fix task [D3-1]**.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-02.md
  1. [D3] Fix AGENTS.md bundle-import module reference (S) — ⚪ Low — change `git_ops/merge.rs` → `bundle::merge_bundle_and_resolve` (`ddb-core/src/bundle.rs`) in the I1 data-safety invariant, matching invariants.md and git-ops.md.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00166-make-hlc-load-bearing-v1-review-02.md
  - **[1/4] ⚪ Low — `sync.md:170` "no commit path can ship a trailer-less commit" overclaims.** Bundle-import merge (00168) stays trailer-less, so the sentence is looser than the design's precise "no `GitRepo`-funnel path." Qualify to public `GitRepo` write paths, bundle import tracked separately. Folded into the same `sync.md` doc-fix as the `recv_hlc` line. File: `docs/src/technical/sync.md:170`. Found by: Bob.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00166-make-hlc-load-bearing-v1-review-02.md
  - Build/lint/fast-test gate passes — run cargo build, cargo clippy --workspace --all-targets, and cargo test-ci.

## Task prose

### Batch 202607161128 (autopilot, IN PROGRESS — started 2026-07-16)

- [x] **00163 git-tree-construction-correctness-v1** (DONE 2026-07-17, in `done/`) — delete-freshness + merge-lock legs of the git write-path data-loss class.
- [x] **00200 make-merge-tree-three-way-v1** (DONE 2026-07-18, in `done/`) — true three-way conflicted-merge tree (Alternative B), closing the last data-loss leg.
- [x] **00164 unify-id-minting-v1** (DONE 2026-07-18, in `done/`) — one repo-aware existence oracle for all mint paths.
- [x] **00165 deterministic-crdt-resolution-v1** (DONE 2026-07-18, in `done/`) — content-derived Automerge actor IDs, deterministic list-field ordering.
- [x] **00166 make-hlc-load-bearing-v1** (DONE 2026-07-19, in `done/`) — machine-local `HlcClock`, HLC trailer on every write, unified `lww_pick` tie-break.
- [x] **00167 sync-collision-reassignment-atomicity-v1** (DONE 2026-08-15, in `done/`) — folded winner + loser + backlink rewrites into one atomic `commit_merge`, loser ID derive

# Bundle-import conflict recovery

**Priority:** P1 · **Roadmap:** Phase 1 (convergence) · **Depends on:** 00162 (write lock — merge + resolve + ref-delete run inside the write critical section)

## Overview

### Problem Statement
A conflicted bundle import reports success while silently losing the imported data.

- **Conflict detection reads `stderr`, not state.** `merge_bundle_and_resolve` (`ddb-core/src/bundle.rs:113-138`) shells out to `git merge refs/remotes/bundle/master` (`:118-126`) and, on failure, decides conflict-vs-error by **string-matching `stderr`** for `"CONFLICT"` / `"Automatic merge failed"` (`:132-137`). This is locale- and version-fragile, and there is **no** `git merge --abort` anywhere.
- **A conflicted merge is reported as clean success.** A conflicted `git merge` creates **no commit**, so `resolve_post_merge_conflicts` (`sync_manager/mod.rs:883-887`) → `validate_clean_merge_or_fallback` sees `commit_parent_count < 2` (`:544`) and returns `Ok(0)`: the import re
