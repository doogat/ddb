## Mechanical facts (computed, do not re-count)

Function line counts from `ast`. Cite these for countable claims; a
finding that contradicts this block is discarded at the review gate.

- `ddb-core/src/bundle.rs` — skipped (non-python)
- `ddb-core/src/git_ops/merge.rs` — skipped (non-python)
- `ddb-core/src/git_ops/mod.rs` — skipped (non-python)
- `ddb-core/src/git_ops/remote.rs` — skipped (non-python)
- `ddb-core/src/git_ops/tests.rs` — skipped (non-python)
- `ddb-core/src/sync_manager/mod.rs` — skipped (non-python)
- `ddb-core/src/traits.rs` — skipped (non-python)
- `tests/e2e/bundle_import_conflict_recovery.rs` — skipped (non-python)
- `tests/e2e/main.rs` — skipped (non-python)
- `tests/integration.sh` — skipped (non-python)
- `tests/integration.ps1` — skipped (non-python)
- `AGENTS.md` — skipped (non-python)
- `CHANGELOG.md` — skipped (non-python)
- `docs/src/technical/bundle.md` — skipped (non-python)
- `docs/src/technical/git-ops.md` — skipped (non-python)
- `docs/src/technical/invariants.md` — skipped (non-python)
- `docs/src/technical/sync.md` — skipped (non-python)

NOTE: every changed file is non-Python, so this cycle's computed-facts block is
empty of actual counts (`compute_mech_facts.py` is `ast`-based and covers Python
only). Countable claims about Rust/shell code are judged normally this cycle —
there is nothing here for the review gate's "contradicts computed facts" discard
rule to fire on.
