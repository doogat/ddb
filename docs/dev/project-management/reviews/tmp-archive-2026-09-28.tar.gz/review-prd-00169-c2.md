# PRD 00169 — poison-file reindex resilience (requirements authority)

**Full PRD (read it — this is a summary, the file is authoritative):**
`/Users/bob/git/src/github.com/doogat/ddb/dev/local/prds/wip/00169-poison-file-reindex-resilience-v1.md`

**Design doc (the HOW, not the spec):**
`/Users/bob/git/src/github.com/doogat/ddb/dev/local/designs/00169-poison-file-reindex-resilience-v1-design.md`

Title: *Indexer rebuild resilience: poison-file skip and serialized cold-start rebuild.*
P1 (availability), Roadmap Phase 1. Absorbed 00169b `serialize-cold-start-index-rebuild`.

## Problem (verbatim shape)

One malformed markdown file makes the whole database unusable through the service.
`batch_index_changes` did `let content = content_result?;` then `parser::parse(&content, &path)?`,
so a single bad file aborted the entire change-set — and the *other* valid files changed
in that same sync were also not indexed. That fatal path gates ~40 entry points:
`incremental_reindex` ← `rebuild_if_stale` ← `ensure_fresh`, which runs at the top of every
public verb module (search / read / create / update / delete / sql / discovery / batch /
utility / schema_apply). The full-rebuild path was ALREADY lenient (`parallel_parse`
collects failures into `MalformedYaml`), so only the incremental path was inconsistent.
This violated the AGENTS.md guardrail: "User-facing read/write/list paths must not silently
drop rows, schemas, or parse failures; return errors or structured warnings."

Second, independent gap: concurrent writers on a **cold** repo (no stored HEAD in `_ddb_meta`)
each took the destructive branch of `rebuild_if_stale` → `rebuild` → `drop_all_tables()` +
FTS recreation. Nothing serialized this across processes, so concurrent cold starts stomped
each other's FTS bootstrap and failed with `no such table: _ddb_fts` / `_ddb_boost`.

The net-new quarantine/index-health **listing** surface (a `ddb doctor` listing, a GraphQL
`indexHealth` query, a REST endpoint, an FFI method) is explicitly a follow-up owned by
**00181** — out of scope here.

## Success Metrics (verbatim)

- One malformed `.md` in an incremental change-set: the other changed files still index; the bad file is skipped, not fatal; a structured warning names the bad file and reason.
- Subsequent reads AND writes succeed after a poison file lands (no manual full rebuild required to unblock the service).
- The skip warning surfaces on the triggering verb through the existing `AppWarning` channel, asserted present on at least CLI + GraphQL.
- An explicit `--strict` mode preserves the old hard-fail behavior for callers that want it.
- The FFI `RebuildReport` record carries a `warnings` field so FFI callers see the skip.
- N concurrent `ddb create` processes on a cold repo (no stored HEAD) all succeed: zero `no such table: _ddb_fts` / `_ddb_boost` errors; final index row count matches git.
- Double-checked rebuild: a waiter that blocked behind another process's rebuild finds a fresh index and returns without dropping tables; lock acquisition failure/timeout surfaces as a structured error, never a panic.
- The 00162 concurrent-write e2e's warm-up workaround is removed (or demoted to a comment), so that scenario also exercises the cold path.
- An index stamped with an older schema version drop-rebuilds exactly once (version-triggered, under the rebuild lock); a current version never does.
- An oversized frontmatter block degrades into the standard skip warning; reindex cost stays bounded.
- No regression: existing incremental-reindex, full-rebuild, and `AppWarning` tests stay green; no behavior change on the warm incremental path.

## Phase acceptance criteria (verbatim, the ones this cycle's rework touches)

**Phase 0**
- `ConsistencyWarning::UnreadableFile { path, error }`: variant compiles; existing `MalformedYaml` matches unaffected.
- Collect-and-skip + `strict`: a change-set with one malformed and two valid files indexes the two valid files and returns two survivors + one warning naming the bad path; under `strict=true` the same input returns a `DoogatError`; pure-indexer unit tests cover read-fail, parse-fail, strict, and all-good.
- Lock helper: a unit test proves two handles serialize and the guard releases on drop; the ordering rule is written down (module doc).

**Phase 1**
- `ConsistencyWarning → AppWarning`: each variant maps to a stable `code` + human `message`; unit-tested.
- `ensure_fresh` capture: *"after a poison file lands, a create AND a search both succeed and each carries a skip `AppWarning`; the warning reaches CLI stderr (`write_warnings`) and the GraphQL warnings extension (`forward_warnings`); the FFI reindex report exposes the skip."*
- Locked destructive rebuild: concurrent cold-start coverage passes; a waiter that blocked behind another process's rebuild finds a fresh index and does not drop tables; no behavior change on the warm incremental path; lock timeout is a structured error, never a panic.
- Schema-version stamp: opening an index stamped with an older version triggers exactly one locked drop-rebuild and a current version triggers none; unit-tested. The ad-hoc FTS-column probe `needs_schema_upgrade` retired or demoted to a fallback.
- Frontmatter cap: a file with an over-cap frontmatter block is skipped with a warning naming the path and reason; normal files unaffected; `--strict` hard-fails it; unit-tested.

**Phase 2**
- `docs/src/technical/indexer.md` (poison-file resilience, `--strict`) + CHANGELOG; smoke scenarios (`tests/smoke.sh` + `.ps1` for `reindex --strict`); integration scenarios (`tests/integration.sh` + `.ps1` for a synced poison file surfacing via GraphQL); an e2e under `tests/e2e/` for skip + `--strict`. Acceptance: docs match; scenarios authored and green locally under Tier 1.
- Concurrent cold-start e2e (N concurrent `ddb create`, NO warm-up, verified to fail against pre-change code once); the 00162 warm-up workaround removed or demoted; the rebuild-lock invariant + its ordering rule added to `docs/src/technical/invariants.md`.

## Test Strategy — Critical Scenarios (verbatim)

- **Happy path**: incremental sync brings three changed files, one malformed → two valid files indexed, one skipped, a warning names the bad path; a subsequent `ddb query` returns the two valid rows.
- **Edge case**: `reindex --strict` over the same change-set → a `DoogatError` naming the bad file.
- **Error case**: after the poison file lands, run a create then a search → both succeed; each result carries a skip `AppWarning`.
- **Concurrency case**: 8 concurrent `ddb create` on a cold repo (no stored HEAD, no warm-up) → all succeed; zero FTS bootstrap errors; final index row count matches git; only one destructive rebuild ran.

## Risks the PRD itself names (they bound what counts as a defect)

- **Silently masking genuinely broken data**: *"skipping a bad file means its rows are absent from query results."* Mitigation: always emit the structured warning; `--strict` remains; the 00181 doctor listing enumerates quarantined files. **(Cycle 1 found the implementation made skipped rows stale-PRESENT rather than absent — task 15 is the fix; verify it.)**
- **Warning volume on a large corrupt corpus**: mitigation is *"attach a single summary `AppWarning` (count + see ddb doctor) on the verb envelope"* — this is why the implementation uses summarizing free functions rather than a 1:1 `From` impl.
- **Enum variant is a public shape change**: additive variant; update matches; transport codes stay stable.
- **`ensure_fresh` signature change fans out**: merge only at the facade boundary that already builds `AppOutput`; verbs that do not build an envelope are unaffected.
- **Lock ordering vs the git write lock**: fix ONE acquisition-order rule at design time, document it in `invariants.md`, enforce it.
- **Waiter staleness**: the double-checked re-check validates integrity (tables present) as well as staleness.

## Transport Impact (verbatim posture)

- **CLI**: Guaranteed — skip warnings print to stderr (`ddb-cli/src/warnings.rs::write_warnings`); `reindex --strict` opt-in.
- **GraphQL**: Guaranteed — warnings extension (`ddb-server/src/warning_extension.rs::forward_warnings`).
- **REST**: Guaranteed — `warnings` field (`ddb-server/src/rest.rs::warnings_to_json`).
- **FFI**: Guaranteed — verb-output warning records; FFI `RebuildReport` gains a `warnings` field.
- **PgWire**: Specialized — no structured-warning channel; document the boundary.
- **NoSQL HTTP**: Specialized — a skipped file is simply absent from `get`/`scan`.
- **Cold-start serialization**: no public API / response-shape / error-code change on any transport.

## Project guardrails that bind this review

From `AGENTS.md`:
- Keep `ddb-core/src/types/**` adapter-neutral (no `rusqlite`, `git2`, `redb`, `axum`, `async_graphql`).
- No runtime panics in library/FFI code for mutex, database, filesystem, repository, or user-input state.
- User-facing read/write/list paths must not silently drop rows, schemas, or parse failures.
- **P0 data-safety invariant, "One bad file never fails the batch"**: read/list/index paths degrade per-item into structured warnings; only an explicit `--strict` mode hard-fails. (This PRD IS that invariant's implementation.)
- Every git write holds the repo write lock; IDs mint through one repo-aware path; conflict resolution is a pure function of its inputs.
- Every interpolated SQL identifier is escaped; every value is a bound parameter.
- Files: 200-400 lines typical, **800 max**; functions under 50 lines; max 4 levels of nesting.
- Tier 1 per-task gate: `cargo build`, `cargo clippy --workspace --all-targets` clean, `cargo test-ci`, unit tests alongside the module.
- Tier 2 (full workspace tests, e2e, `integration.sh`, `.ps1` ports, property tests, coverage) is **delegated to CI** — authoring is the per-PRD deliverable, local execution is not.
