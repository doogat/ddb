# Completed tasks — PRD 00168 bundle-import conflict recovery

All 15 tasks are `completed`. Tasks 1-8 are the original plan (reviewed in full in
cycle 1). Tasks 9-15 are the cycle-1 decision-gate rework tasks (`[D1-n]`) — **these
are what this incremental cycle-2 review is scoped to.**

## Original plan (cycle 1 — already reviewed, diff 35e594e..e531306)

| # | Task | Model | Commits |
|---|------|-------|---------|
| 1 | Add `delete_remote_ref` to `GitRemote` trait, `GitRepo`, and its delegation | sonnet | bfa90fc (test), 685c68e |
| 2 | Widen `SyncManager::apply_merge_result` to `pub(crate)` | sonnet | 63fb1ec |
| 3 | Rewire bundle-import merge through the network-sync merge engine | sonnet | 6fc1efa (test), fd9ecbe, 872f2b5 |
| 4 | Unit tests: conflicted-bundle recovery, reachability, clean-repo-on-error | sonnet | f1315fa |
| 5 | Add a bundle-import conflict scenario to `tests/integration.sh` | sonnet | 57c66b4 |
| 6 | Mirror the bundle-import conflict scenario in `tests/integration.ps1` | haiku | 54de391 |
| 7 | Author the bundle-import conflict-recovery e2e test | sonnet | 3b547df, 73a31ca |
| 8 | Docs, CHANGELOG, walkthrough, invariant-note updates | sonnet | e531306 |

## Cycle-1 rework — THE SCOPE OF THIS REVIEW (diff e531306..6bb1617)

| # | Task | Model | Commits | What it was fixing |
|---|------|-------|---------|--------------------|
| 9 | `[D1-1]` Keep the bundle ref reachable: stop `fetch.prune` deleting it, and clean up every bundle ref on success | sonnet | 6ae8c14 (test), ee623a1 | Cycle-1 CRITICAL (Blake): `unbundle_git_objects` fetched `refs/heads/*:refs/remotes/bundle/*` with no `--no-prune`, so the NEXT import deleted the ref a failed import deliberately kept — offline-synced commits became unreachable and gc-prunable. Also: only `refs/remotes/bundle/master` was deleted on success, leaving stale `bundle/*` refs forever. |
| 10 | `[D1-2]` Stop routing non-doogat unrelated-history conflicts through the add/add collision resolver | opus | 975fcc0, 6d8d2c8, 86a692f (tests), e74cf5e | Two cycle-1 HIGHs (Blake): with unrelated histories every conflicting path has `ancestor: None`, so `partition_conflicts` sent NON-doogat files (e.g. `.gitignore`) into `resolve_add_add_collision` — hard failure with no recovery; and the same misclassification silently FORKED data, minting a non-14-digit id (`66177401297366`) while reporting success. |
| 11 | `[D1-3]` Make the bundle-import error contract honest: map merge-engine errors | sonnet | 7c1aa46 (test), 01cfc85, 427f920 | Cycle-1 HIGH (Blake) + Medium (Alice, Bob): `merge_bundle_and_resolve` mapped only `apply_merge_result` errors to `Sync` and propagated `merge_remote` errors raw, so the same failure reported two different error classes depending on where it landed. **See the settled-decisions ledger: "preserve `Conflict`" was deliberately NOT implemented.** |
| 12 | `[D1-4]` Replace the `remote != "bundle"` magic-string guard exemption with an explicit merge mode, and pin the guard | sonnet | 46b32f5 (test), 9b37ac2 | Cycle-1 HIGH (Bob) + Medium (Alice, Blake): a user's real remote named `bundle` silently skipped the unrelated-histories merge-base guard. Also Alice's Medium: the retained guard was unpinned — deleting it left the suite green. |
| 13 | `[D1-5]` Docs and CHANGELOG truth pass: stop overclaiming the closed invariant, record the API breaks | sonnet | 4adcdee | Cycle-1 Mediums/Lows: `invariants.md` I1 claimed "no remaining gap" while the fetch leg is still unlocked; `sync.md`/CHANGELOG contradicted themselves; the removed `pub fn resolve_post_merge_conflicts` and the new required `GitRemote::delete_remote_ref` were unrecorded API breaks; the trait-surface listings still read "(add, fetch, push)". |
| 14 | `[D1-6]` Bundle test quality and size: extract the shared fixture, split the test module, tighten the weak asserts | sonnet | a3bc99e, 4d097e2 | Cycle-1 Mediums/Lows (Alice, Bob): ~75 duplicated lines across two failure tests; `bundle.rs` at 828 lines (>800); three test fns at 96/86/84 lines; `matches!(result, Err(Sync(_)))` too weak to show the *merge* failed; `!repo2.repo.index().unwrap().has_conflicts()` read the process-cached index and could not fail. |
| 15 | `[D1-7]` Drop the redundant `repo` parameter from `merge_bundle_and_resolve` | sonnet | 6bb1617 | Cycle-1 Medium (Carl): the `repo` param duplicated `sync_mgr.repo`. |

## Cycle-1 findings NOT reworked

Nine cycle-1 findings were settled as deferrals rather than reworked; they are listed
verbatim, with reasons, in the "Settled decisions — do not re-raise" section of this
prompt. Do not re-raise them.
