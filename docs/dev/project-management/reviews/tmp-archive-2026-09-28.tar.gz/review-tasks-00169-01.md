# Completed tasks — PRD 00169 poison-file-reindex-resilience-v1

14 tasks, all `completed`. Diff range under review: `6bb16174fd533b94db0f45016019aa4626b5a16e..f00c4839c1a10391f1355c5a01bb3d5f3c376c14`.

One row per task. Where two tasks share a commit, the shared SHA and the companion task ids are named in the row.

## Task 1 — Add `ConsistencyWarning::UnreadableFile` variant
- Implementor: claude/sonnet. Commits: folded into the task-2 range (no standalone impl commit; variant added ahead of its first consumer).
- Files: `ddb-core/src/types/schema.rs`.
- Acceptance: variant compiles; existing `MalformedYaml` matches unaffected.
- Note: no test authored. The enum derives only `Debug + Clone` (no serde, no `PartialEq`) and nothing constructed the new variant yet, so a test would have been a tautology. Behavioral coverage lands in task 2's read-fail case. The compiler was the gate.

## Task 2 — Make incremental indexing collect-and-skip per-file failures with a strict opt-in
- Implementor: claude/sonnet. Commits: `c972c79` (tests, 11 tests), impl in the same range.
- Files: `ddb-core/src/indexer/rebuild.rs` (+ call-site updates).
- Acceptance: a change-set with one malformed and two valid files indexes the two valid files and returns two survivors + one warning naming the bad path; `strict=true` returns a `DoogatError`; unit tests cover read-fail, parse-fail, strict, all-good.
- Known residual: ~30 lines of duplicated read/parse/strict logic between the two `batch_index_changes` branches, deliberately not extracted (refactor, out of scope).

## Task 3 — Generalize the write-lock helper to take an explicit lock directory and file name
- Implementor: qwen (local model), reviewed by pat. Commits: `fde545b` (tests), `f9c1e26` (impl), `71e718d` (comment cleanup).
- Files: `ddb-core/src/git_ops/write_lock.rs`, `ddb-core/src/git_ops/mod.rs` (visibility `pub(crate) mod write_lock;` + call site), `ddb-core/src/git_ops/tests.rs` (2 callers).
- Acceptance: two handles serialize; the guard releases on drop; the lock-ordering rule vs the git write lock is written down in the module doc.

## Task 4 — Add the ConsistencyWarning → AppWarning summarizing helpers in app_contract
- Implementor: claude/sonnet. Commits: `ef2165c` (tests), `5cd6df2` (impl).
- Files: `ddb-core/src/app_contract/output.rs`, `ddb-core/src/app_contract/mod.rs` (re-export line).
- Acceptance: each variant maps to a stable `code` + human `message`; unit-tested with exact string pins for the four warning codes.
- Orchestrator design-gap fix folded in: `mod output;` is private, so the re-export had to carry `summarize_reindex_warnings` and `REINDEX_SKIPPED_FILES` too, not only the two `describe_*` helpers the design named — otherwise task 5 would not compile.

## Task 5 — Capture reindex warnings in `ensure_fresh` and merge them into the three AppOutput facades
- Implementor: codex. Commits: `7d72015` (tests), `085f096` (impl + CHANGELOG).
- Files: `ddb-core/src/service/mod.rs`, `service/create.rs`, `service/update.rs`, `service/schema_apply.rs`, `ddb-cli/src/commands/crud.rs`.
- Acceptance: after a poison file lands, a create AND a search both succeed and each carries a skip `AppWarning`; the warning reaches CLI stderr and the GraphQL warnings extension.
- Deleted an existing code path: the redundant `svc.rebuild_if_stale()?;` pre-call in `ddb-cli/src/commands/crud.rs` `create`. `cargo test -p ddb-e2e` ran per CLAUDE.md: 449/449.

## Task 6 — Add a `warnings` field to the FFI RebuildReport record
- Implementor: claude/sonnet. Commits: `153c405` (tests), `48b9925` (impl + CHANGELOG).
- Files: `ddb-core/src/ffi/records.rs`, `ddb-core/src/ffi/driver.rs`, `ddb-core/src/app_contract/mod.rs` (a `#[cfg(test)]` gate on the `REINDEX_SKIPPED_FILES` re-export), + 2 more.
- Acceptance: the FFI reindex report exposes the skip as `RebuildWarningRecord { code, message }`.
- Recorded observation: every unparseable file is reported TWICE by `rebuild()` — once from `parallel_parse` (`rebuild.rs:444`), once from `collect_consistency_warnings` (`materialize.rs:598`). Pre-existing; became user-visible in task 9.

## Task 7 — Serialize the destructive full-rebuild path behind a cross-process rebuild lock
- Implementor: claude/opus. Commits: `f0f53e4` (tests, 8 tests, prior session), `f408c30` (impl + CHANGELOG), `08ed093` (deslop).
- Files: `ddb-core/src/indexer/rebuild.rs`, `ddb-core/src/indexer/mod.rs`, `ddb-core/src/traits.rs`, `ddb-core/src/indexer/ports.rs`, `ddb-core/src/service/search.rs`, `ddb-core/src/service/mock_index_tests.rs`.
- Acceptance: concurrent cold-start coverage passes; a waiter that blocked behind another process's rebuild finds a fresh index and does not drop tables; lock timeout is a structured `Err(Conflict)`, never a panic; no behavior change on the warm incremental path.
- Allowlist widened 4→7 mid-task: `DoogatService::reindex` reaches the index through a generic `I: IndexPort`, so `locked_rebuild` had to become a REQUIRED `IndexPort` trait method with no default body.
- Recorded residual: `configure_connection`'s `needs_schema_upgrade` branch was still an unlocked destructive path at this point (closed by task 8).

## Task 8 — Stamp and check an index schema version via `PRAGMA user_version`
- Implementor: claude/sonnet. Commits: `6bc2cde` (tests), `bc328dd` (impl + CHANGELOG), `0537b18` (CRITICAL fix), `9df1643` (doc note).
- Files: `ddb-core/src/indexer/mod.rs` (+ tests).
- Acceptance: opening an index stamped with an older version triggers exactly one locked drop-rebuild; a current version triggers none.
- CRITICAL found by the per-task reviewer and fixed in `0537b18`: the rebuild-lock guard was originally scoped INSIDE the `if needs_drop` block, releasing before the recreate, leaving a window where the DB has no tables and still carries its old version. The guard now binds at function scope (`None` when no upgrade is needed) and lives across drop + recreate + stamp.
- **UNMET FAIL-FIRST OBLIGATION, flagged deliberately**: that CRITICAL shipped WITHOUT a regression test. All 244 tests passed both before and after the fix. Settled in task 14 as an ACCEPTED GAP; the argument is recorded in `dev/local/assumptions.md` and in a comment at `ddb-core/src/indexer/mod.rs:190-210`. This is the weakest load-bearing claim in the PRD.

## Task 9 — Add a `--strict` flag to the `ddb reindex` command
- Implementor: claude/sonnet. Commits: `c255d4d` (tests, 7 tests), `e5ec64a` (impl + CHANGELOG, 9 files).
- Files: `ddb-core/src/indexer/rebuild.rs`, `indexer/mod.rs`, `traits.rs`, `indexer/ports.rs`, `service/search.rs`, `service/mock_index_tests.rs`, `ddb-cli/src/main.rs`, `ddb-cli/src/commands/maintenance.rs`, CHANGELOG.
- Acceptance: strict hard-fails naming the file; lenient exits 0 with a warning count.
- CONFIRMED REGRESSION found and fixed here: task 7 had routed `DoogatService::reindex` through `locked_rebuild`, whose post-lock re-check short-circuits, so explicit `ddb reindex` had become a no-op printing "indexed 0 doogats". Fixed by adding `locked_explicit_rebuild(repo, strict)` (same lock, unconditional rebuild) as a second REQUIRED `IndexPort` method.
- `rebuild` was REORDERED so `list_doogats` + `parallel_parse` run BEFORE `drop_all_tables`, so a strict abort cannot wipe the index first.
- Recorded residual: the `--strict` CLI flag has NO committed automated test in this task; its coverage is task 11 (smoke) + task 14 (e2e).

## Task 10 — Cap frontmatter size at the parse boundary
- Implementor: qwen (local model), reviewed by pat. Commits: `38577e7` (tests, 5 tests), `7d28653` (impl, 14 lines), `b1bc2ed` (review fix).
- Files: `ddb-core/src/parser/mod.rs`, `ddb-core/src/indexer/tests/*`.
- Acceptance: an over-cap frontmatter block is skipped with a warning naming path + reason; normal files unaffected; `--strict` hard-fails it.
- `MAX_FRONTMATTER_BYTES = 256 * 1024`, module-private, strict `>` so exactly-at-cap parses, `yaml.len()` bytes.
- Recorded residual: the cap bounds `serde_yaml` PARSE cost but not the READ — `split_zones` has already pulled the whole file into memory before `parse_frontmatter` can reject it. Whether the PRD line "reindex cost stays bounded" is satisfied by a parse-cost bound alone was NOT decided.

## Task 11 — Document the poison-file skip and `--strict` behavior and add the smoke scenarios
- Implementor: codex. Commits: `ac3cb22` (docs + smoke, 4 files), `865f682` (doc correctness fixes), `886ea27` (errexit fix).
- Files: `docs/src/technical/indexer.md`, `tests/smoke.sh`, `tests/smoke.ps1`, CHANGELOG.
- Acceptance: docs match; scenarios authored and green locally under Tier 1. `tests/smoke.sh` was run END TO END twice locally, both reaching "all smoke tests passed".
- TWO FALSE-PASS ASSERTIONS found and fixed: (1) an assertion labelled "strict reindex failure preserves the existing index" could not fail, because `ddb query` routes through `execute_sql` → `ensure_fresh` and would silently rebuild a dropped index before answering; relabelled with a NOTE naming the unit test that does bind the strong property. (2) `! $DDB reindex --strict` under `set -euo pipefail`: bash exempts a `!`-inverted command from errexit, so a `--strict` regressed to lenient would not stop the script and the following grep would still match. Fixed by capturing the exit code explicitly.
- `tests/smoke.ps1` was NOT executed (no PowerShell on this host).
- Carried: `tests/smoke.sh` still uses the bare `! $DDB ...` idiom in several PRE-EXISTING sections, same errexit exemption, same false-pass risk. Left alone under the surgical-changes rule.

## Task 12 — Add the poison-file GraphQL integration scenario to `tests/integration.sh`
- Implementor: qwen (attempt 1, FAILED the gate), escalated to claude/sonnet fix-forward (attempt 2). Commit: `c2b375a`.
- Files: `tests/integration.sh` (section 63, lines ~3746-3801).
- qwen's failure: sent `createDoogat` an unregistered `type: "doogat"`, so the mutation returned `TYPE_NOT_REGISTERED` and the assertion never reached the warning.
- Verified GREEN independently by the orchestrator: section 63 extracted into a standalone harness and run against a real `ddb` binary and a real server; the server logged the malformed-file skip and the jq assertion on `extensions.warnings` passed. `bash -n` parses clean.

## Task 13 — Add the matching poison-file GraphQL scenario to `tests/integration.ps1`
- Implementor: qwen, first dispatch clean. Commits: `d743027`, `33a235d` (two MEDIUM review fixes).
- Files: `tests/integration.ps1` (section 63).
- **NEVER EXECUTED** — no `pwsh` on this host. Checks available were bash-parity by line-for-line comparison and PowerShell correctness by inspection. Windows CI is its first real run.
- Two MEDIUMs applied: an inline `byte[]` conversion duplicating the file's own `content` helper; an unguarded `Remove-Item` on a temp dir that had hosted a live server under a file-wide `$ErrorActionPreference = Stop`.

## Task 14 — Author the poison-file and concurrent cold-start e2e coverage and record the rebuild-lock invariant
- Implementor: claude/opus. Commits: `f3c42c0` (e2e), `1fd4c6f` (invariants doc), `c3619ba` (deslop), `92e15f7` (name/doc correction), `f00c483` (review fix).
- Files: `tests/e2e/poison_file_reindex.rs` (new), `tests/e2e/concurrent_writes.rs` (warm-up removed), `tests/e2e/main.rs`, `docs/src/technical/invariants.md` (I5 GAP→HOLDS, new I10 rebuild-lock invariant).
- Acceptance: the e2e fails against pre-change code and passes after; the warm-up is gone; the invariants page lists the rebuild lock and its ordering rule.
- Fail-first evidence WAS established: the implementor temporarily neutered the rebuild lock in a scratch edit (since reverted), and the cold-start scenario then failed with `no such table: _ddb_boost` on roughly 1 run in 3. Documented in the test's doc comment.
- Deslop deleted the newly-added cold-start test as a strict duplicate of the (now warm-up-free) original; the survivor was then renamed and its doc rewritten in `92e15f7` because it still claimed to measure "only the write-lock guarantee".
- One HIGH from the per-task reviewer, fixed in `f00c483`: the lenient test's closing `ddb query` read-back could not fail, because `execute_sql` calls `ensure_fresh` and would rebuild a stale index before answering. Removed, replaced by a comment recording the hazard.
