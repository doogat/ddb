# Completed Tasks — PRD 00169-poison-file-reindex-resilience-v1

**Review cycle 2 (incremental).** Cycle 1 reviewed tasks 1-14 over the full range
`6bb16174..f00c4839`. THIS cycle's scoped diff covers only the cycle-1 rework —
tasks 15-20, commits `f00c4839..28dda73` (14 commits). Tasks 1-14 are listed for
context; do not re-review their unchanged code.

## Cycle-1 rework tasks (THE SUBJECT OF THIS REVIEW)

| Task | Name | Tier / implementor | Commits |
|------|------|--------------------|---------|
| 15 | `[D1-1]` Evict stale rows for modified files that fail read or parse | opus / claude | `f555cb5`, `6202bcb`, `a946357`, `681b24c` |
| 16 | `[D1-2]` Fix `summarize_reindex_warnings` mislabel, miscount, and the dangling `ddb doctor` pointer | sonnet / claude | `f2dbaf2`, `d5b5a33`, `5e4f5db`, `c732e9a` |
| 17 | `[D1-3]` Add the missing lock-scope regression coverage and a direct index assertion to the cold-start e2e | opus / claude | `0a9a9f5` |
| 18 | `[D1-4]` Extract the triplicated rebuild-lock acquisition and the duplicated batch/singleton read-parse logic | opus / claude | `47c826b` |
| 19 | `[D1-5]` Make `ddb reindex` name the skipped paths and assert the CLI `AppWarning` leg in smoke | sonnet / **codex** | `5b7290d`, `b3a5263`, `8db9688` |
| 20 | `[D1-6]` Correct the overstated invariant, the stale indexer docs, and the CHANGELOG breaking-change entry | sonnet / **codex** | `28dda73` |

### What each rework task was supposed to close (from the cycle-1 decision gate)

**15 `[D1-1]` — 🟠 HIGH, the cycle's most consequential finding.**
`partition_changes` routed both `DiffKind::Added` and `DiffKind::Modified` into
`to_index_paths`; only `DiffKind::Deleted` reached `remove_doogat`. So a *modified*
doogat that fails read/parse was skipped (`continue`) while its previously-indexed
rows in `doogats` and the materialized type tables were never evicted, and
`store_head(&new_head)` then marked the index current — stale pre-edit content
served as current, index claiming freshness. Introduced by the leniency work (before
this PRD the batch aborted, so HEAD never advanced). The PRD's Risk section assumed
skipped rows would be **absent**; the implementation made them **stale-present**.
Acceptance: a skipped modified file's old rows are gone, survivors keep theirs, HEAD
still converges.

**16 `[D1-2]` — 🟡, three defects in one helper.**
(a) `describe_consistency_warning(&warnings[0])` took the first warning regardless of
variant, so on the cold-start/destructive branch an advisory
`CrossZoneDuplicate`/`MissingRequired` for a *successfully indexed* file got labelled
`REINDEX_SKIPPED_FILES`. (b) `warnings.len() - 1` had no dedup, so the known
double-report (each malformed file counted once by `parallel_parse`, again by
`collect_consistency_warnings`) made ONE poison file render `"(+1 more, ...)"`,
naming a second file that does not exist. (c) The message pointed at `ddb doctor`,
which is not a command (PRD 00181 would add it, still in backlog).
Acceptance: filter to `UnreadableFile|MalformedYaml`, dedup by path, name a real remedy.

**17 `[D1-3]` — 🟡, 4/5 consensus; the PRD's known-unmet fail-first obligation.**
The CRITICAL lock-scope fix (`0537b18`) shipped with no regression test. Eve found
the tractable half: the post-lock `read_needs_drop` re-check at `indexer/mod.rs:212-217`
is deterministically testable today with no new dependency (hold the lock, upgrade +
stamp + sentinel out-of-band, release, assert the waiter skipped the drop). Plus Bob's
point that the cold-start e2e compared reported IDs only against git HEAD and never
inspected `.ddb/index.db` directly, so a CLI read-back would self-heal what direct DB
inspection would catch.
Acceptance: a discriminating test that dies when the re-check is reverted; a direct
index-row assertion in the cold-start e2e.

**18 `[D1-4]` — 🟡, 3/5 consensus; behavior-preserving extraction only.**
The rebuild-lock acquisition block was duplicated verbatim three times
(`configure_connection`, `locked_rebuild`, `locked_explicit_rebuild`);
`batch_index_changes` duplicated the read/parse/strict/warning state machine across
its batch and singleton branches and exceeded 50 lines; `indexer/mod.rs` crossed the
800-line cap (749 → 837) and `configure_connection` tripled (26 → ~80 lines).
Acceptance: one lock helper, one per-path parse step, `indexer/mod.rs` back under 800,
**guard lifetime unchanged** (the extraction must not re-introduce the 0537b18 bug).

**19 `[D1-5]` — 🟡.**
`ddb reindex` printed only "N warning(s)"; the skipped paths reached the user only via
tracing stderr, so `RUST_LOG=error` named nothing. Separately, no test anywhere asserted
the **CLI** `AppWarning` leg (`write_warnings` → stderr on `ddb create`) — smoke section
32 bound the `reindex` command's *tracing* output instead, leaving the PRD metric
"asserted present on at least CLI + GraphQL" half-met.
Acceptance: one line per report warning from `ddb reindex`; a smoke scenario binding
the `ddb create` AppWarning leg, in both `.sh` and `.ps1`.

**20 `[D1-6]` — 🟡, 3/5 consensus; docs only.**
`invariants.md` I5 described the skip-warning as reaching "the verb envelope" generally,
without qualifying that only create/update/apply_schema wire it. `docs/src/technical/indexer.md`
still showed the obsolete two-argument `incremental_reindex` signature and never described
the collect-and-skip/strict behavior, the schema-version stamp, or the 256 KiB frontmatter
cap. CHANGELOG omitted the compile-breaking public shape change (`ConsistencyWarning`
gained `UnreadableFile`).
Acceptance: I5 narrowed to its true scope, indexer.md brought current, CHANGELOG
breaking-change entry added.

## Original tasks 1-14 (cycle 1, reviewed already — context only)

| Task | Name |
|------|------|
| 1 | Add `ConsistencyWarning::UnreadableFile` variant |
| 2 | Make incremental indexing collect-and-skip per-file failures with a strict opt-in |
| 3 | Generalize the write-lock helper to take an explicit lock directory and file name |
| 4 | Add the `ConsistencyWarning` to `AppWarning` summarizing helpers in `app_contract` |
| 5 | Capture reindex warnings in `ensure_fresh` and merge them into the three `AppOutput` facades (**codex**-implemented) |
| 6 | Add a `warnings` field to the FFI `RebuildReport` record |
| 7 | Serialize the destructive full-rebuild path behind a cross-process rebuild lock |
| 8 | Stamp and check an index schema version via `PRAGMA user_version` |
| 9 | Add a `--strict` flag to the `ddb reindex` command |
| 10 | Cap frontmatter size at the parse boundary |
| 11 | Document the poison-file skip and `--strict` behavior and add the smoke scenarios (**codex**-implemented) |
| 12 | Add the poison-file GraphQL integration scenario to `tests/integration.sh` |
| 13 | Add the matching poison-file GraphQL scenario to `tests/integration.ps1` |
| 14 | Author the poison-file and concurrent cold-start e2e coverage and record the rebuild-lock invariant |

## Known state the build session reported (raise these only if they are wrong)

- `incremental_reindex`'s `strict: bool` is never `true` on any user-facing path: one
  production call site passes `false`, and `reindex_strict()` routes through
  `locked_explicit_rebuild → rebuild_strict`. Only tests exercise the parameter. Docs now
  say so; the affordance itself was left alone as out of scope for a docs task.
- OPEN, carried from task 15's per-task review: `evict_doogats(&to_delete)` runs BEFORE
  `batch_index_changes`, so a **strict** run over a change-set containing BOTH a deletion
  AND a poison file applies the deletion and then errors. Pre-existing since `e5ec64a`;
  the CHANGELOG wording was corrected instead of the code. A one-line fix exists: fold
  both eviction sites into one call after `batch_index_changes`.
- `tests/smoke.ps1` section 33 was REVIEWED, NOT EXECUTED (`pwsh` does not resolve on this
  host). Its exit-code guard has never run; CI is the first place it executes.
- `Index::drop_all_tables` (`indexer/mod.rs`) is a near-copy of the drop loop now in
  `indexer/schema_version.rs`; the only difference is where `PRAGMA foreign_keys = OFF`
  sits. Flagged, deliberately not unified.
- Task 17's test carries an anti-vacuity guard, but a residual timing gap remains: a waiter
  thread that never reaches its pre-check would also read as "parked". Accepted; the
  twice-proven discrimination (Ivan and Pat each reverted the re-check and saw the sentinel
  die) is the real teeth.

## Tier 1 gate, run at HEAD `28dda73` by the build session

`cargo build` OK · `cargo clippy --workspace --all-targets` clean ·
`cargo test-ci` (ddb-core 1549 passed, ddb-server 222 passed) ·
`cargo test -p ddb-e2e` 451 passed · `bash tests/smoke.sh` all-passed banner ·
`cd docs && mdbook build` OK.
