import json
import subprocess
from pathlib import Path

root = Path('/Users/bob/git/src/github.com/doogat/ddb')
tmp = root / 'dev/local/tmp'
state_path = root / 'dev/local/autopilot/state.json'
ctl = '/Users/bob/.claude/plugins/cache/buvis-plugins/autopilot/0.5.1/skills/run-autopilot/scripts/statectl.py'
state = json.loads(state_path.read_text())
decisions = []
deferred = []
ledger = []
for line in (root / 'dev/local/reviews/00171-review-1-consolidated.md').read_text().splitlines():
    if not line.startswith('| ['):
        continue
    consensus, emoji, issue, file, task, finders = line.strip('| ').split(' | ')
    severity = {'🟠':'high','🟡':'medium','⚪':'low'}[emoji]
    entry = {'cycle':1,'issue':issue,'file':file,'severity':severity,'consensus':consensus.strip('[]')}
    if '[FIX]' in issue:
        entry.update(action='auto-fix', reason='Cycle 1: bounded additive test/CI coverage repair or specified helper deduplication; no product contract change.')
        decisions.append(entry)
        continue
    if '00202' in issue:
        action, reason = 'discarded', 'Git history identifies interleaved, separately authored PRD 00202 commits; not scope creep by 00171. Full work_start_sha is intentionally preserved.'
    elif 'checklist unchecked' in issue:
        action, reason = 'discarded', 'PRD is intentionally wip until review converges and a fresh finalize session accepts it.'
    elif 'reserved slugs' in issue:
        action, reason = 'discarded', 'Mapping explicitly labels these as non-executable banner sections and maps their executable subrows to registered tests.'
    elif 'psql-absent' in issue:
        action, reason = 'discarded', 'Rust PgWire client is a declared dependency; every platform runs the assertions, so no missing-client branch remains.'
    elif '[VERIFY]' in issue:
        action, reason = 'discarded', 'Live GitHub confirmed the contract-required full validation before deletion and Test after deletion. A fixed duration and old exact test count are not validity gates. Rework will be pushed for fresh CI. Not queued: command shape.'
    elif 'serial' in issue:
        action, reason = 'settled-deferral', 'Existing reviewed design deliberately uses independent TempDirs/ports and order-independent race results instead of serial markers. Retain parallel execution; record the stale PRD wording.'
    elif 'polls /health' in issue:
        action, reason = 'settled-deferral', 'Design deliberately reuses existing ServerGuard readiness; health_returns_ok tests its lifecycle. Internals are reserved for 00188, outside this test migration.'
    elif '50-line' in issue:
        action, reason = 'settled-deferral', 'Keep cohesive multi-process scenario orchestration and HEAD durability checks; shared operations are already helpers. The project Rust instructions have no hard function-size limit, and broad test fragmentation is outside this coverage repair.'
    else:
        action, reason = 'settled-deferral', 'Installed mechanical checks are explicitly Python-only. Extending shared tooling is outside 00171; this cycle used Rust source audits and same-HEAD runtime evidence.'
    ledger.append({**entry,'disposition':action,'reason':reason})
    if action == 'discarded':
        decisions.append({**entry,'action':'discard','reason':reason})
    else:
        deferred.append({**entry,'type':'review-observation','reason':reason,'status':'deferred'})

for key, value in [('review_lenses',{'consensus':'done','blind':'done','doubt':'done','ui':'failed','fable':'done'}), ('doubts_rubric_verdicts',json.loads((tmp/'00171-review-verdicts.json').read_text())), ('autonomous_decisions',state.get('autonomous_decisions',[])+decisions), ('deferred_decisions',state.get('deferred_decisions',[])+deferred)]:
    subprocess.run(['python3',ctl,str(state_path),'set',key,json.dumps(value)],check=True)
ledger_path = root/'dev/local/reviews/00171-migrate-shell-scenarios-to-e2e-v1-ledger.json'
ledger_path.write_text(json.dumps(ledger,indent=2)+'\n')
print(f'{len(decisions)} autonomous decisions, {len(deferred)} settled observations, {len(ledger)} ledger entries')
