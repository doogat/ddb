import json
from pathlib import Path
import re
import subprocess
import sys

root = Path('/Users/bob/git/src/github.com/doogat/ddb')
task_id, label, *command = sys.argv[1:]
log = root / f'dev/local/reviews/00171-task-{task_id}-{label}.log'
with log.open('w') as stream:
    run = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, text=True)
output = log.read_text()
summaries = re.findall(r'test result: .*', output)
counts = re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;', output)
record = {'command': ' '.join(command), 'exit': run.returncode,
          'sha': subprocess.check_output(['git', '-C', str(root / 'dev/local/worktrees/00171-review'), 'rev-parse', 'HEAD'], text=True).strip(),
          'summaries': summaries,
          'passed': sum(int(row[0]) for row in counts),
          'failed': sum(int(row[1]) for row in counts),
          'skipped': sum(int(row[2]) for row in counts)}
log.with_suffix('.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
if run.returncode:
    print(output[-9000:])
else:
    print('\n'.join(output.splitlines()[-4:]))
sys.exit(run.returncode)
