import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path('/Users/bob/git/src/github.com/doogat/ddb')
PACK = Path('/Users/bob/.claude/plugins/cache/buvis-plugins/autopilot/0.5.1')
REVIEW = PACK / 'skills/review-work-completion'
TMP = ROOT / 'dev/local/tmp'
ID = '00171-c1'
state = json.loads((ROOT / 'dev/local/autopilot/state.json').read_text())
prd = (ROOT / 'dev/local/prds/wip' / state['prd']).read_text()
base = state['work_start_sha']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()

def run(*args):
    return subprocess.check_output(args, text=True, cwd=ROOT)

if sys.argv[1] == 'context':
    tasks = '\n\n'.join(f"## Task {t['id']}: {t['name']}\nStatus: {t['status']}\n\n{t['description']}" for t in state['tasks'])
    (TMP / f'review-tasks-{ID}.md').write_text(tasks + '\n')
    (TMP / f'review-prd-{ID}.md').write_text(prd + '\n## Design Doc\n\n' + (ROOT / state['design_doc']).read_text())
    print(run('bash', str(REVIEW / 'scripts/gather-context.sh'), str(TMP / f'review-tasks-{ID}.md'), str(TMP / f'review-prd-{ID}.md')))
    diff = run('git', 'diff', f'{base}..{head}')
    changed = run('git', 'diff', '--name-only', f'{base}..{head}').splitlines()
    (TMP / f'review-diff-{ID}.diff').write_text(diff)
    context = (TMP / f'review-context-{ID}.md').read_text()
    start = context.index('### Changed Files')
    end = context.index('## PRD Requirements', start)
    context = context[:start] + '### Changed Files\nFull PRD work range: ' + base + '..' + head + '\n\n' + '\n'.join(changed) + '\n\n' + context[end:]
    context += '\n## Scope and runtime evidence\nThe range includes interleaved unrelated 00202 commits. Review all 00171 work; do not demand unrelated product fixes. The original full-review gather script chose master and yielded an empty diff; this input was corrected to the preserved work_start_sha..HEAD before dispatch.\n'
    context += '\n## Architecture instructions\n' + (ROOT / 'AGENTS.md').read_text()
    for path in ['docs/src/technical/solid.md', 'docs/src/technical/clean-architecture.md', 'docs/src/architecture/modules.md']:
        context += '\n## ' + path + '\n' + (ROOT / path).read_text()
    context += '\n## Build evidence (claims to verify)\n' + (ROOT / 'dev/local/reviews/00171-build-review-context.md').read_text()
    context += '\n## Recorded verification\n' + (ROOT / 'dev/local/autopilot/last-verification.json').read_text()
    mech = run('python3', str(REVIEW / 'scripts/compute_mech_facts.py'), *changed)
    checks = run('python3', str(REVIEW / 'scripts/detect_tautological_tests.py'), *changed)
    checks += run('python3', str(REVIEW / 'scripts/replay_tests_against_base.py'), '--base', base)
    (TMP / f'review-mech-{ID}.md').write_text(checks)
    (TMP / f'review-context-{ID}.md').write_text(context + '\n' + mech + '\n' + checks)
    (TMP / f'review-changed-{ID}.json').write_text(json.dumps(changed))
    print(f'{len(changed)} changed files; {len(diff.encode())} diff bytes; HEAD {head}')
elif sys.argv[1] == 'prompts':
    bodies = {}
    for name in ['alice', 'blake', 'bob', 'carl', 'eve']:
        raw = (PACK / 'agents' / f'{name}.md').read_text()
        _, fm, body = raw.split('---', 2)
        assert re.search(rf'^name: {name}$', fm, re.M) and re.search(r'^description: .+', fm, re.M)
        bodies[name] = body.strip()
    formats = (REVIEW / 'references/output-formats.md').read_text()
    output = formats.split('## Agent Output Format (Single Source of Truth)\n', 1)[1].split('\n## Per-Rule Verdict Format', 1)[0]
    rubric = (REVIEW / 'references/rubric.md').read_text()
    checklist = (REVIEW / 'references/review-dimensions.md').read_text()
    pack_file = TMP / f'engram-pack-{ID}.md'
    pack_path = str(pack_file) if pack_file.exists() else '(no pack available this cycle)'
    pack_findings = '(no pack available this cycle)'
    if pack_file.exists():
        text = pack_file.read_text()
        match = re.search(r'(?im)^## Findings precedent.*?(?=^## |\Z)', text, re.S)
        pack_findings = match.group(0) if match else '(pack contains no findings precedent)'
    common = {'{CONTEXT_FILE}': str(TMP / f'review-context-{ID}.md'), '{DIFF_FILE}': str(TMP / f'review-diff-{ID}.diff'), '{PACK_FILE}': pack_path, '{PACK_FINDINGS}': pack_findings, '{REVIEW_CHECKLIST}': checklist, '{RUBRIC}': rubric, '{OUTPUT_FORMAT}': output}
    appendix = bodies['eve'].split('## Two lenses, applied to every changed file', 1)[1]
    appendix = '## Two lenses, applied to every changed file' + appendix
    for name, body in bodies.items():
        values = dict(common)
        if name == 'blake':
            values = {'{PRD}': prd, '{RUBRIC}': (PACK / 'skills/review-blindly/references/rubric.md').read_text(), '{OUTPUT_FORMAT}': output}
        elif name == 'bob':
            body += '\n\n' + appendix
            # Preserve PRD-only doubt context, without the implementation design.
            (TMP / f'review-doubt-context-{ID}.md').write_text(prd + '\n\n## Recorded verification\n' + (ROOT / 'dev/local/autopilot/last-verification.json').read_text())
            values['{CONTEXT_FILE}'] = str(TMP / f'review-doubt-context-{ID}.md')
        elif name == 'eve':
            changed = json.loads((TMP / f'review-changed-{ID}.json').read_text())
            body += '\n\n## PRD\n' + prd + '\n## Diff range\n' + base + '..' + head + '\n## Changed files\n' + '\n'.join(changed) + '\n## Findings precedent\n' + pack_findings + '\n## Mechanical test checks\n' + (TMP / f'review-mech-{ID}.md').read_text()
        for key, val in values.items():
            body = body.replace(key, val)
        body = body.replace('{AGENT_NAME}', name.upper())
        body += '\n\nReview only. Do not modify files, commit, change autopilot state, or invoke autopilot. Return the complete review text.\n'
        if name == 'blake':
            body += 'Find the implementation yourself; do not read design docs, implementation summaries, review reports, or autopilot state.\n'
        if name != 'bob':
            body += 'Project local verification rules apply. Do not duplicate the full workspace/e2e test battery. Static review and existing runtime evidence can be inspected; only a specific unresolved repro justifies an isolated test.\n'
        if name in ['alice', 'carl']:
            body += 'Evidence inputs include an assertion mapping at dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md and CI run artifacts in dev/local/reviews/00171-task13-ci-green.json and 00171-task14-ci-green.json. These are claims to verify, not verdicts.\n'
        (TMP / f'{name}-prompt-{ID}.md').write_text(body + '\n')
        print(f'{name}: {len(body)} characters')
