Portfolio freshness: NOT refreshed this cycle (PRD 00002 pending)

278 changed symbol(s) omitted (beyond the 40-symbol cap).

## Similar code

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/bundle/mod.rs:413-413
  mod tests;

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/ffi/tests.rs:96-116
  fn execute_sql_select_returns_rows() {
    let (_tmp, driver) = fresh_driver();
    driver.reindex().unwrap();
    driver
        .execute_sql("CREATE TABLE item (name TEXT)".into())
        .unwrap();
    driver
        .execute_sql("INSERT INTO item (name) VALUES ('alpha')".into())
        .unwrap();
    driver
        .execute_sql("INSERT INTO item (name) VALUES ('beta')".into())
        .unwrap();

    let result = driver
        .execute_sql("SELECT name FROM item ORDER BY name".into())
        .unwrap();
    assert_eq!(result.rows.len(), 2);
    assert!(result.columns.contains(&"name".to_string()));
    assert_eq!(result.rows[0][0], "alpha");
    assert_eq!(result.rows[1][0], "beta");
}

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/git_ops/mod.rs:782-786
      fn find_hlc_for_path(&self, commit_oid: &str, path: &str) -> Option<crate::hlc::Hlc> {
        let oid = Oid::from_str(commit_oid).ok()?;
        let commit = self.repo.find_commit(oid).ok()?;
        self.find_hlc_for_path(&commit, path)
    }

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/types/doogat.rs:218-232
  pub struct SyncReport {
    pub direction: String,
    pub commits_transferred: usize,
    pub conflicts_resolved: usize,
    pub resurrected: usize,
    pub collisions_reassigned: usize,
    pub singleton_conflicts_resolved: usize,
    /// Per-conflict detail for each SINGLETON conflict resolved during this
    /// sync's post-merge sweep. PRD 00139 cycle-3 #8: surfaces the
    /// structured `Fix::SingletonConflictResolved` events that
    /// `singleton_sweep` emits, so CLI / GraphQL / FFI consumers can name
    /// each (table, winner, losers) triple instead of only seeing the
    /// aggregate count. Length equals `singleton_conflicts_resolved`.
    pub singleton_conflicts: Vec<SingletonConflictResolution>,
}

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-core/src/types/mod.rs:34-41
  impl Default for CompactionConfig {
    fn default() -> Self {
        Self {
            stale_ttl_days: default_stale_ttl_days(),
            threshold_mb: default_threshold_mb(),
        }
    }
}

- ddb:/Users/bob/git/src/github.com/doogat/ddb/ddb-server/src/auth.rs:60-87
  mod tests {
    use super::*;

    #[test]
    fn validate_bearer_accepts_matching_token() {
        assert!(validate_bearer("Bearer secret123", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_wrong_token() {
        assert!(!validate_bearer("Bearer wrong", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_empty_string() {
        assert!(!validate_bearer("", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_missing_prefix() {
        assert!(!validate_bearer("secret123", "secret123"));
    }

    #[test]
    fn validate_bearer_rejects_lowercase_prefix() {
        assert!(!validate_bearer("bearer secret123", "secret123"));
    }
}

- ddb:/Users/bob/git/src/github.com/doogat/ddb/tests/e2e/common.rs:15-32
  pub(crate) fn ddb_bin() -> PathBuf {
    if let Ok(p) = std::env::var("CARGO_BIN_EXE_ddb") {
        return PathBuf::from(p);
    }
    let mut dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    dir.pop(); // tests/ -> workspace root
    let target = std::env::var("CARGO_TARGET_DIR")
        .map(PathBuf::from)
        .unwrap_or_else(|_| dir.join("target"));
    let profile = if cfg!(debug_assertions) {
        "debug"
    } else {
        "release"
    };
    target
        .join(profile)
        .join(format!("ddb{}", std::env::consts::EXE_SUFFIX))
}

## Reuse precedent

- claude-warden:/Users/bob/git/src/github.com/buvis/claude-warden/dist/cli.cjs:5095-5119
      function parsePrelude(prelude) {
      let comment = "";
      let atComment = false;
      let afterEmptyLine = false;
      for (let i = 0; i < prelude.length; ++i) {
        const source = prelude[i];
        switch (source[0]) {
          case "#":
            comment += (comment === "" ? "" : afterEmptyLine ? "\n\n" : "\n") + (source.substring(1) || " ");
            atComment = true;
            afterEmptyLine = false;
            break;
          case "%":
            if (prelude[i + 1]?.[0] !== "#")
              i += 1;
            atComment = false;
            break;
          default:
            if (!atComment)
              afterEmptyLine = true;
            atComment = false;
        }
      }
      return { comment, afterEmptyLine };
    }

- container-images:/Users/bob/git/src/github.com/buvis/container-images/apps/clara/backend/src/clara/exceptions.py:4-5
  class AppError(Exception):
    pass

- gems:/Users/bob/git/src/github.com/buvis/gems/src/tools/dot/tui/widgets/commit_modal.py:11-43
  class CommitModal(ModalScreen[str | None]):
    """Modal for entering a commit message."""

    CSS = """
    CommitModal {
        align: center middle;
    }
    CommitModal > Vertical {
        width: 60;
        height: auto;
        border: thick $accent;
        background: $surface;
        padding: 1 2;
    }
    """

    BINDINGS = [("escape", "cancel", "Cancel")]

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label("Commit message:")
            yield Input(placeholder="Enter commit message...", id="commit-input")
            yield Label("Enter to commit, Esc to cancel", classes="dim")

    def on_mount(self) -> None:
        self.query_one("#commit-input", Input).focus()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.value.strip():
            self.dismiss(event.value.strip())

    def action_cancel(self) -> None:
        self.dismiss(None)

- gems:/Users/bob/git/src/github.com/buvis/gems/tests/tools/bim/doc/test_promote.py:456-495
      def test_promote_preserves_proposal_ingested_at(
        self,
        settings: DocSettings,
        registry_path: Path,
        lock_path: Path,
        state_db: StateDB,
        mocker: MockerFixture,
    ) -> None:
        """Regression for criterion 8: promote must preserve the proposal's ingested-at."""
        triage_dir = settings.paths.business_root / "_triage"
        pdf, yml = _stage_triage_pair(triage_dir, "20210311083422-cez-as-7102105594.invoice")
        sha = hashlib.sha256(pdf.read_bytes()).hexdigest()
        write_proposal(yml, _build_proposal(sha256=sha, triage_pdf=pdf))

        # _build_proposal pins ingested_at to a known datetime; freeze it here so
        # the assertion is independent of helper internals.
        proposal_ingested_at = datetime(2026, 5, 4, 9, 34, 22, tzinfo=timezone(timedelta(hours=2)))

        cmd, _ = _build_command(
            settings=settings,
            registry_path=registry_path,
            lock_path=lock_path,
            state_db=state_db,
            proposal_yml=yml,
            mocker=mocker,
            ocr_pdf=pdf,
        )

        result = cmd.execute()
        assert result.success is True

        zettel_path = Path(result.metadata["zettel_path"])
        text = zettel_path.read_text(encoding="utf-8")
        # Frontmatter is between the first two `---` fences.
        _, frontmatter_text, _ = text.split("---", 2)
        frontmatter = yaml.safe_load(frontmatter_text)

        zettel_ingested_at = frontmatter["ingested-at"]
        assert isinstance(zettel_ingested_at, datetime)
        assert zettel_ingested_at == proposal_ingested_at

## Findings precedent

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00168-bundle-import-conflict-recovery-v1-review-01.md
  | [1/4] | ⚪ | Cannot statically verify: `cargo build`, `cargo clippy --workspace --all-targets`, and `cargo test-ci` pass. | N/A | general | BOB |

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00167-sync-collision-reassignment-atomicity-v1-review-01.md
  - `cargo clippy --workspace --all-targets` clean; `cargo test-ci` green.

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00164-unify-id-minting-v1-review-01.md
  [BOB] ⚪ Cannot statically verify: `cargo build`, `cargo clippy --workspace --all-targets`, `cargo test-ci` pass. | File: N/A | Task: general

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00168-bundle-import-conflict-recovery-v1-review-02.md
  **Test-count composition.** `cargo test-ci` and the unfiltered

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00166-make-hlc-load-bearing-v1-review-02.md
  - Build/lint/fast-test gate passes — run cargo build, cargo clippy --workspace --all-targets, and cargo test-ci.

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00118-harden-agoge-authorization-gate-v1-review-2.md
  - [1/4] ⚪ The item-1 fix makes the exception it preserves near-unreachable: `finding-contract.md` §2 defines an `unarmed` row as carrying the reason, **not** tactics, so requiring populated tactics kills the exception for every contract-conformant profile — functionally the "delete the exception outright" option the PRD explicitly rejected. | `skills/run-agoge/SKILL.md` | Blake

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00120-migrate-task-tracking-to-statectl-v1-review-1.md
  (`/Users/bob/.claude/skills/run-autopilot/cli/statectl.py`,

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00124-key-svelte-each-blocks-by-index-v1-review-1.md
  - `ef3ee614b` (brief-portfolio): **2 of 2 new smoke tests fail** — "missing

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00129-autoclaude-suite-stubs-do-not-intercept-v1-review-1.md
  | `wc -l ~/.claude/hooks/notify.log` before / after all three runs | **10611 → 10611**, zero new lines |

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00129-autoclaude-suite-stubs-do-not-intercept-v1-review-1.md
  **FIX:**

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00132-autopilot-writers-and-clis-tell-truth-v1-review-1.md
  | [1/4] | 🟡 | The docstring parity test only proves every supported form is documented; it cannot detect extra unsupported forms, so it does not enforce the PRD's "exactly the verbs" requirement | skills/run-autopilot/scripts/test_shims.py:94 | 6 | BOB |

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00133-cut-hook-and-suite-overhead-v1-review-1.md
  production's literal 50" — that test uses `max_commits: 10` (line 213). VERIFIED.

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00133-cut-hook-and-suite-overhead-v1-review-1.md
  transient files in that directory. A broad `git add` could commit machine-local

- findings:/Users/bob/.local/tmp/claude-dev/reviews/00133-cut-hook-and-suite-overhead-v1-review-1.md
  - Existing directory inputs resolve from their parent — hooks/_common.py:64 — use the resolved path itself when it is a directory, otherwise its parent, and test the repository-root case

- findings:/Users/bob/git/src/github.com/doogat/ddb/dev/local/reviews/00163-git-tree-construction-correctness-v1-review-01.md
  ### Medium (🟡) — deferred

## Task prose

### Batch 202607161128 (autopilot, IN PROGRESS — started 2026-07-16)

- [x] **00163 git-tree-construction-correctness-v1** (DONE 2026-07-17, in `done/`) — delete-freshness + merge-lock legs of the git write-path data-loss class.
- [x] **00200 make-merge-tree-three-way-v1** (DONE 2026-07-18, in `done/`) — true three-way conflicted-merge tree (Alternative B), closing the last data-loss leg.
- [x] **00164 unify-id-minting-v1** (DONE 2026-07-18, in `done/`) — one repo-aware existence oracle for all mint paths.
- [x] **00165 deterministic-crdt-resolution-v1** (DONE 2026-07-18, in `done/`) — content-derived Automerge actor IDs, deterministic list-field ordering.
- [x] **00166 make-hlc-load-bearing-v1** (DONE 2026-07-19, in `done/`) — machine-local `HlcClock`, HLC trailer on every write, unified `lww_pick` tie-break.
- [x] **00167 sync-collision-reassignment-atomicity-v1** (DONE 2026-08-15, in `done/`) — folded winner + loser + backlink rewrites into one atomic `commit_merge`, loser ID derive

# Migrate smoke/integration shell scenarios to the Rust e2e crate

**Priority:** P2 (leverage; ends the 4-file authoring tax before the contract block) · **Roadmap:** inserted 2026-07-16 by maintainer decision (assessment F5) — runs after P0/P1, before the contract block · **Depends on:** none (00162 done; builds its own server-spawn helper — do NOT depend on 00188 ephemeral-serve, a higher number; that PRD may later simplify the helper's internals).

Source: `dev/local/audit-results/evolution-assessment-2026-07-16.md` F5 (lens 7, commit-history mining). Maintainer decisions 2026-07-16: migrate soon, inserted early; later PRDs' scenario tasks were rewritten to target the e2e harness directly (backlog review 2026-07-16, Decision 1).

## Overview

### Problem Statement

Every smoke/integration scenario is authored twice, in two shell dialects: `tests/smoke.sh`/`smoke.ps1` and `tests/integration.sh`/`integration.ps1`. History quantifies the tax: the .sh↔.ps1 pairs co-change in 75/69 com
