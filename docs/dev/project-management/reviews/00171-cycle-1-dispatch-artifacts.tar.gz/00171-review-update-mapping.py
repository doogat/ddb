from pathlib import Path

path = Path('/Users/bob/git/src/github.com/doogat/ddb/dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md')
updates = {
    'tests/integration.sh:205': '`integration_17j2_jink_config_singleton_and_link_crud` (NEW; review restores the 14-digit ASCII singleton ID assertion alongside empty-singleton SELECT, singleton INSERT, link CRUD, and compound-predicate UPDATE)',
    'tests/integration.sh:335': '`serve::search_where_filter_materialized_column_eq` + `serve::search_where_filter_materialized_column_contains` + `serve::search_where_filter_tag` + `serve::search_where_filter_combined_type_and_field` (review strengthens the existing eq case: exact URL versus a /page suffix fixture, one hit and totalCount 1)',
    'tests/integration.sh:1248': '`reference_raw_id::raw_id_coexists_with_object_resolver` + `reference_raw_id::raw_id_field_pins_first_linked_with_multiple_junction_rows` + `reference_raw_id::plural_resolver_with_order_by` + `reference_raw_id::plural_resolver_with_order_by_desc` + `reference_raw_id::plural_resolver_with_limit` + `reference_raw_id::plural_resolver_with_order_by_and_limit` (preserves one-reference scalar/object coexistence; new three-junction-row variant pins the first-linked scalar independently of ID order; existing plural ordering/limit cases retained)',
    'tests/integration.sh:1498': '`serve::filter_base_field_title_eq` + `serve::filter_base_field_id_eq` + `serve::filter_base_field_title_contains` + `serve::filter_base_field_id_nonexistent` (review restores explicit totalCount == 1 assertions to both title-filter cases)',
    'tests/integration.sh:1685': '`integration_44_e1_join_pin_graphql` (NEW; JOIN through GraphQL sql(query:), exactly one row parsed as JSON and compared with ["a", "1"] during review)',
    'tests/integration.sh:2667': '`rest::rest_typed_create_populates_typed_columns` (register a type, POST /doogats with type and JSON fields; retain the server executeSql read-back and add an independent CLI ddb query read-back of category=books for the created ID)',
}
pairs = {
    'tests/integration.ps1:252', 'tests/integration.ps1:370',
    'tests/integration.ps1:1161', 'tests/integration.ps1:1403',
    'tests/integration.ps1:1600', 'tests/integration.ps1:2584',
}
seen = set()
lines = []
for line in path.read_text().splitlines():
    key = line.split(' | ', 1)[0].removeprefix('| ')
    if key in updates or key in pairs:
        columns = line.split(' | ')
        assert len(columns) == 6, (key, columns)
        if key in updates:
            columns[2] = updates[key]
        columns[5] = 'DONE (review assertions restored) |'
        line = ' | '.join(columns)
        seen.add(key)
    lines.append(line)
assert seen == set(updates) | pairs, seen
path.write_text('\n'.join(lines) + '\n')
print(f'Updated {len(seen)} mapping descriptions; source keys preserved.')
