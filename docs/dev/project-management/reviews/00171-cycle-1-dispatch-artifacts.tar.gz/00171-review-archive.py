from pathlib import Path
import tarfile

root = Path('/Users/bob/git/src/github.com/doogat/ddb')
tmp = root / 'dev/local/tmp'
names = {
    '00171-review-prepare.py', '00171-review-audit.py',
    '00171-review-consolidate.py', '00171-review-decisions.py',
    '00171-task-15.json', '00171-task-16.json',
    '00171-review-verdicts.json', '00171-review-check-ci.py',
    '00171-review-prepare-rework.py', '00171-review-run-gate.py',
    '00171-review-audit-rework.py', '00171-review-update-mapping.py',
    '00171-review-archive.py', '00171-review-finish.py',
    'engram-pack-00171-c1.md', 'eve-normalized-00171-c1.txt',
    'dispatch-ivan-16.txt',
}
for kind, suffix in [('tasks', 'md'), ('prd', 'md'), ('context', 'md'),
                     ('diff', 'diff'), ('mech', 'md'), ('changed', 'json'),
                     ('doubt-context', 'md')]:
    names.add(f'review-{kind}-00171-c1.{suffix}')
for reviewer in ('alice', 'blake', 'bob', 'carl', 'eve'):
    names.add(f'{reviewer}-prompt-00171-c1.md')
    names.add(f'{reviewer}-output-00171-c1.txt')
for task in (15, 16):
    names.update({f'review-task-{task}.md', f'attempt-task-{task}.json'})
    for kind in ('subject', 'description', 'acceptance', 'verification'):
        names.add(f'review-task-{task}-{kind}.txt')
    names.add(f'review-task-{task}-prompt.md')
for kind in ('files', 'checks', 'context', 'output'):
    names.add(f'ivan-16-{kind}.txt')

files = [tmp / name for name in sorted(names) if (tmp / name).is_file()]
archive = root / 'dev/local/reviews/00171-cycle-1-dispatch-artifacts.tar.gz'
assert not archive.exists(), 'archive already exists; do not overwrite evidence'
contents = {path.name: path.read_bytes() for path in files}
with tarfile.open(archive, 'w:gz') as bundle:
    for path in files:
        bundle.add(path, arcname=path.name, recursive=False)
with tarfile.open(archive, 'r:gz') as bundle:
    assert set(bundle.getnames()) == set(contents)
    for name, expected in contents.items():
        stream = bundle.extractfile(name)
        assert stream is not None and stream.read() == expected, name
for path in files:
    assert path.read_bytes() == contents[path.name], f'file changed during archive: {path}'
for path in files:
    path.unlink()
print(f'Archived and byte-verified {len(files)} owned temporary files; removed only those originals.')
