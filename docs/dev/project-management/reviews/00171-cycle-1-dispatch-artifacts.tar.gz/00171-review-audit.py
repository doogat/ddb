import collections
import json
import re
import subprocess
from pathlib import Path

root = Path('/Users/bob/git/src/github.com/doogat/ddb')
mapping = (root / 'dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md').read_text()
rows = {}
duplicates = []
for line in mapping.splitlines():
    match = re.match(r'\| (tests/(?:smoke|integration)\.(?:sh|ps1):\d+) \|', line)
    if match:
        key = match.group(1)
        if key in rows:
            duplicates.append(key)
        rows[key] = line
source_keys = set()
counts = {}
for path in ['tests/smoke.sh', 'tests/smoke.ps1', 'tests/integration.sh', 'tests/integration.ps1']:
    source = subprocess.check_output(['git', 'show', f'HEAD^:{path}'], text=True)
    keys = {f'{path}:{n}' for n, line in enumerate(source.splitlines(), 1) if re.match(r'^# [0-9]', line)}
    source_keys.update(keys)
    counts[path] = len(keys)

modules = set(re.findall(r'^mod (\w+);', (root / 'tests/e2e/main.rs').read_text(), re.M))
tests = set()
for module in modules:
    module_path = root / f'tests/e2e/{module}.rs'
    paths = [module_path] if module_path.exists() else list((root / f'tests/e2e/{module}').rglob('*.rs'))
    for path in paths:
        content = path.read_text()
        namespace = str(path.relative_to(root / 'tests/e2e').with_suffix('')).replace('/', '::').removesuffix('::mod')
        for name in re.findall(r'#\[(?:tokio::)?test(?:\([^\n]*\))?\]\s*(?:async )?fn (\w+)\(', content):
            tests.add(f'{namespace}::{name}')
workflow = (root / '.github/workflows/test.yml').read_text()
filters = re.findall(r'run: cargo test -p ddb-e2e --test e2e (\S+)', workflow)
selected = {test for test in tests if any(pattern in test for pattern in filters)}
references = set(re.findall(r'`(\w+::\w+)`', '\n'.join(line for key, line in rows.items() if key.startswith('tests/smoke.'))))
refs = references & tests
missing = sorted(refs - selected)
unresolved = sorted(references - tests)
report = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'source_counts': counts,
    'mapping_rows': len(rows),
    'duplicate_keys': duplicates,
    'missing_keys': sorted(source_keys - rows.keys()),
    'extra_keys': sorted(rows.keys() - source_keys),
    'registered_test_count_static': len(tests),
    'per_push_filters': filters,
    'per_push_selected_count_static': len(selected),
    'qualified_smoke_targets_not_selected_per_push': missing,
    'unresolved_qualified_smoke_targets': unresolved,
}
(root / 'dev/local/reviews/00171-review-1-parent-evidence.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
