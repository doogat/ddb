
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: [D1] Restore complete per-push e2e coverage

Description:
Replace the smoke-only filter and five redundant exact e2e steps in .github/workflows/test.yml with one unfiltered cargo test -p ddb-e2e step. Keep CLI build before e2e and retain the core sync integration step and independent coverage job. Remove obsolete DDB_BIN env on the replaced steps (the harness uses CARGO_BIN_EXE_ddb/current_exe). Update AGENTS.md description of per-push CI. Full e2e is already CI Tier 2 and was measured at 223.56 seconds on Linux; no local full-suite execution is requested.

### Findings (verbatim)
[EVE] 🟠 [FIX] Per-push CI coverage dropped: `test.yml`'s new `Smoke test (e2e)` step runs only the 30 `smoke_*` tests (of 565), yet ~26 of smoke.sh's 56 sections were mapped to pre-existing modules outside that filter (delete_backlinks, tags, checkboxes, folder_namespace, search_links, link_kinds, rename, sql_lifecycle, alter_table_rename, cli_create_fk_freshness, inline_zone, discover, fix, sequence, help, cascade_delete, sql_expressions_test, set_flag, date_default, alter_column_type, schema_apply, poison_file_reindex, cli_create_unregistered_type, cli_update_app_error, sync_crdt); smoke.sh ran those on every push, now they run nightly only, contradicting the PRD's "CI keeps identical coverage" — .github/workflows/test.yml:45-48 — replace the `smoke_` step and the five `--exact` steps with one `cargo test -p ddb-e2e` step (the full suite took 223 s in the 5cf4c36 linux-e2e job), drop the `DDB_BIN` env (nothing under tests/ reads it), and fix the test.yml sentence at AGENTS.md:116. | File: .github/workflows/test.yml | Task: general

Contract: .github/workflows/test.yml; AGENTS.md.

Acceptance: every quoted finding no longer reproduces; the push job selects all registered e2e tests, including all 63 previously omitted smoke targets, with no duplicate exact steps.

Verify: python3 dev/local/tmp/00171-review-check-ci.py


Acceptance criteria:
every quoted finding no longer reproduces; the push job selects all registered e2e tests, including all 63 previously omitted smoke targets, with no duplicate exact steps.

## Diff under review

```diff
diff --git a/.github/workflows/test.yml b/.github/workflows/test.yml
index 6f3b1f0..4e6be1d 100644
--- a/.github/workflows/test.yml
+++ b/.github/workflows/test.yml
@@ -42,39 +42,12 @@ jobs:
       - name: Fast cargo test tier
         run: cargo test-ci
 
-      - name: Smoke test (e2e)
-        env:
-          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
-        run: cargo test -p ddb-e2e --test e2e smoke_
+      - name: E2E tests
+        run: cargo test -p ddb-e2e
 
       - name: Sync integration tests
         run: cargo test -p ddb-core --test sync_test
 
-      - name: E2E - GraphQL CRUD
-        env:
-          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
-        run: cargo test -p ddb-e2e --test e2e serve::crud_lifecycle -- --exact
-
-      - name: E2E - PgWire
-        env:
-          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
-        run: cargo test -p ddb-e2e --test e2e pgwire::pgwire_insert_update_delete -- --exact
-
-      - name: E2E - WebSocket subscriptions
-        env:
-          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
-        run: cargo test -p ddb-e2e --test e2e subscriptions::subscribe_mutate_receive -- --exact
-
-      - name: E2E - Sync/CRDT
-        env:
-          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
-        run: cargo test -p ddb-e2e --test e2e sync_crdt::overlapping_body_edits_resolved_by_crdt -- --exact
-
-      - name: E2E - Multi-device
-        env:
-          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
-        run: cargo test -p ddb-e2e --test e2e multi_device::stale_node_returns -- --exact
-
   coverage:
     runs-on: ubuntu-latest
     steps:
diff --git a/AGENTS.md b/AGENTS.md
index 5c7ff32..5fa80e4 100644
--- a/AGENTS.md
+++ b/AGENTS.md
@@ -113,7 +113,7 @@ One narrow exception: `CLAUDE.md` instructs Claude-routed sessions to run `cargo
 
 The heavy battery is owned by the GitHub Actions workflows:
 
-- `test.yml` runs on every push: Linux Clippy, CLI build, `cargo test-ci`, Rust `smoke_` e2e scenarios, core sync integration tests, five targeted e2e cases, and a separate coverage job.
+- `test.yml` runs on every push: Linux Clippy, CLI build, `cargo test-ci`, the full Rust e2e suite (including reused smoke scenarios), core sync integration tests, and a separate coverage job.
 - `full-validation.yml` runs nightly: full `cargo test --workspace`, the Rust e2e smoke and integration scenarios, property tests, cross-platform validation, and coverage.
 
 Do not duplicate these locally. If a CI failure is reproducible only locally, run the specific failing command in isolation rather than the full battery.
```

## Recorded verification

The task's tests were run before this review. This is what they reported:

HEAD: ec28333 (task base c8b72bd).
python3 /Users/bob/git/src/github.com/doogat/ddb/dev/local/tmp/00171-review-check-ci.py -> exit 0
CI selection: all 567 registered tests, including all 63 previously omitted smoke targets; no duplicate e2e steps; build ordering and independent gates preserved.
Discovery only; no e2e test body executed. The discovery binary belongs to the main checkout, whose independent hazard-test work accounts for its two extra registrations; the workflow is unfiltered on either checkout.
git commit hooks: cargo fmt --check and cargo check --quiet -> exit 0.
Required Tier 1 build/lint/fast tests are still running; they must pass before task completion. This review receives the completed narrow CI selection proof above.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


