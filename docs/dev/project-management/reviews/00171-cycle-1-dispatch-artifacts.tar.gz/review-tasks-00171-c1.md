## Task 1: Build e2e mapping table: smoke.sh + smoke.ps1 sections
Status: completed

Build the section-by-section coverage mapping table for tests/smoke.sh and tests/smoke.ps1 — the coverage-proof artifact every later port task and acceptance check references. This is the FIRST task in the PRD; it creates the shared mapping table file.

Location: create dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md (new file; durable PRD satellite — not deleted by dev/local GC, dies only when the PRD itself moves to done/). Source files: tests/smoke.sh (769 lines, ~56 numbered section headers via `rg -n "^# [0-9]" tests/smoke.sh`), tests/smoke.ps1 (932 lines, ~56 numbered section headers, near-mirror dialect of smoke.sh).

Reuse: cross-check each candidate target against the existing tests/e2e/*.rs suite (100+ files, `rg -n "fn " tests/e2e/*.rs` for an index) before assigning a NEW target test name — if an existing e2e test already covers the same assertion, the row must say "ALREADY COVERED by <test>", never a duplicate.

Contract (verbatim from the design doc's Interfaces & contracts):
- Mapping table row format: "one row per shell section: file:line | section # | target e2e test (or \"ALREADY COVERED by <existing test>\" or \"justified survivor: <reason>\") | needs server? | must-fail? | status"
- Test naming: "smoke_NN_slug / integration_NN_slug, NN zero-padded to match the source section number (04, not 4)."
- Must-fail idiom (for must-fail rows' target-test note): the shell `ddb-fails` helper / bash bare `!` negation maps to `assert_cmd`'s `.assert().failure().stderr(predicate::str::contains("error:"))`, already used in tests/e2e/cli_update_app_error.rs — reuse verbatim, do not invent a new pattern.

Details:
- Enumerate every numbered section in both files by file:line. Read each section body (not just the header) to determine what it asserts.
- For each section: assign a target Rust test name (smoke_NN_slug), note whether it needs ServerGuard (a live `ddb serve`) or is CLI-only, whether it is a must-fail scenario, and set status to TODO.
- tests/smoke.ps1 is invoked by NO workflow today (absent from both test.yml and full-validation.yml, confirmed by grep) — still map its sections per the PRD's 100%-coverage metric; note the zero-CI-risk fact in that row's notes rather than skipping the section.
- Where smoke.sh and smoke.ps1 carry the same NN section as dialect mirrors of one scenario, they share ONE target Rust test — do not create two target rows pointing at two different tests for the same scenario; note "dialect pair, same target" in the row.
- Every section must map to a target row — zero unmapped sections is the acceptance bar.

Acceptance criteria:
- the table is complete with zero unmapped sections (duplicate-numbered sections disambiguated by file:line); it lives in the PRD workdir notes and is referenced by later acceptance checks.

Verify: row count in the new mapping table (smoke section) matches the combined section count from `rg -c "^# [0-9]" tests/smoke.sh tests/smoke.ps1` (accounting for shared dialect-pair rows counting once each per file, not merged into a single row); spot-check 3 random rows against their source line to confirm accuracy.

## Task 2: Build e2e mapping table: integration.sh sections
Status: completed

Extend the shared mapping table (created by an earlier task) with a row per numbered section in tests/integration.sh — APPEND to the existing file, do not overwrite the smoke.sh/smoke.ps1 rows already there.

Location: append to dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md. Source: tests/integration.sh (3803 lines, ~140 numbered section headers via `rg -n "^# [0-9]" tests/integration.sh`).

Premise: dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md already exists with the smoke.sh/smoke.ps1 rows filled in (written by an earlier task in this PRD). Re-verify the file exists and has content before appending; if it is missing, stop and report — do not silently create a fresh file that drops the smoke rows.

Reuse: cross-check each candidate target against the existing tests/e2e/*.rs suite before assigning a NEW target — the design doc's Reuse inventory flags that integration.sh §54.D/§55.D name `pgwire_singleton` as their own replacement in their own pass messages (`integration.sh:2358`, `:2513`); check tests/e2e/pgwire*.rs, serve.rs, server_mutations.rs, subscriptions.rs, singleton_cross_process_*.rs for existing equivalents before writing a new target for any server-lifecycle section.

Contract (verbatim from the design doc's Interfaces & contracts):
- Mapping table row format: "one row per shell section: file:line | section # | target e2e test (or \"ALREADY COVERED by <existing test>\" or \"justified survivor: <reason>\") | needs server? | must-fail? | status"
- Test naming: "smoke_NN_slug / integration_NN_slug, NN zero-padded to match the source section number (04, not 4)." integration.sh carries a duplicate `# 50.` section header at two locations (`integration.sh:2159` PRD 00132 rename-across-protocols, and `integration.sh:3697` PRD 00136 FK-freshness) — key these two rows by file:line, and disambiguate with distinct target slugs (`integration_50_alter_table_rename`, `integration_50_cross_process_fk_freshness`), never two rows named `integration_50`.
- Must-fail idiom: bash negates with bare `!` (no `ddb-fails` helper in bash) — maps to the same `assert_cmd` `.assert().failure()` idiom used by the smoke mapping task.

Details:
- integration.sh has two structurally distinct halves sharing overlapping numbering: lines ~52-2885 (server-dependent: GraphQL/REST/PgWire/SINGLETON, numbered §17-§61) and lines ~2886-3803 (CLI/git/sync/CRDT-focused, independently numbered §21-§63, reusing numbers already used in the first half — this is the source of the duplicate-`#50` quirk, not a typo). Map both halves; note the half in each row so later port tasks reading this table know which capability group a section belongs to.
- For each section: assign a target Rust test name (integration_NN_slug), note whether it needs ServerGuard, whether it is a must-fail scenario, and set status to TODO.
- Every section must map to a target row — zero unmapped sections.

Acceptance criteria:
- the table is complete with zero unmapped sections (duplicate-numbered sections disambiguated by file:line); it lives in the PRD workdir notes and is referenced by later acceptance checks.

Verify: row count added for integration.sh matches `rg -c "^# [0-9]" tests/integration.sh` (~140); the two duplicate `# 50.` rows carry distinct file:line keys and distinct target slugs; the pre-existing smoke rows from the earlier task are still present and unmodified in the file.

## Task 3: Build e2e mapping table: integration.ps1 sections
Status: completed

Extend the shared mapping table with a row per numbered section in tests/integration.ps1 — APPEND to the existing file (already carrying the smoke and integration.sh rows), reusing the same target Rust test names integration.sh's rows already established for matching section numbers.

Location: append to dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md. Source: tests/integration.ps1 (3781 lines, ~139 numbered section headers via `rg -n "^# [0-9]" tests/integration.ps1`).

Premise: the mapping table already has smoke and integration.sh rows filled in by earlier tasks in this PRD. Re-verify the file exists and has both sets of rows before appending; if either is missing, stop and report.

Reuse: for each integration.ps1 section, first look up the matching NN in the integration.sh rows already in the table (same PRD, same behavior, different dialect) and reuse that target test name — these dialect pairs are almost always the SAME Rust test, not a second one. Only assign a distinct target when the .ps1 section's assertions genuinely diverge from its .sh counterpart (see Details).

Contract (verbatim from the design doc's Interfaces & contracts and Risks & edge cases):
- Mapping table row format: "one row per shell section: file:line | section # | target e2e test (or \"ALREADY COVERED by <existing test>\" or \"justified survivor: <reason>\") | needs server? | must-fail? | status"
- integration.ps1 carries the SAME duplicate `# 50.` pattern as integration.sh, mirrored at `integration.ps1:2026` and `:3654` — key by file:line, reuse the two target slugs integration.sh's task already assigned (`integration_50_alter_table_rename`, `integration_50_cross_process_fk_freshness`).
- Must-fail idiom: PowerShell's `ddb-fails` helper (`integration.ps1:67`) is the ONLY dialect that names this helper explicitly — maps to the same `assert_cmd` `.assert().failure()` idiom as the other mapping tasks; do not port the PowerShell helper itself, only its call sites' assertions.

Details:
- For each integration.ps1 section, cross-reference the corresponding integration.sh row (same or equivalent NN). If assertions match, reuse the same target and note "dialect pair, same target" — do not create a second target for the identical scenario.
- Windows-specific path/escaping behavior: any section whose PowerShell assertion tests *string* path formatting (not just behavior — e.g. backslash vs forward-slash literal comparisons) needs a `cfg!(windows)` branch called out explicitly in that row's notes, per the PRD's own Risk note. Most sections need no special handling since Rust's `std::path::Path` already normalizes platform separators.
- integration.ps1 has one section (`# 40. help guides`, line 3372) with no corresponding numbered section in integration.sh at that position — integration.sh's own `# 40.` is "binary asset LWW conflict resolution" at a different line, and .ps1 ALSO has that same section at line 3387 as a separate, later entry. Treat .ps1's `# 40. help guides` as a genuine .ps1-only addition: map it to its own target or mark it a justified survivor if it merely re-runs `--help` output already covered by an existing e2e test — do not silently drop it or conflate it with the `# 40. binary asset LWW` row.
- integration.sh §54.D / §55.D's psql-absent skip does NOT need porting (per the design doc, PgWire sections drop the psql dependency entirely via tokio_postgres) — mark those rows accordingly rather than inventing a `cfg!` / `command -v psql` equivalent in Rust.
- Every section must map to a target row — zero unmapped sections.

Acceptance criteria:
- the table is complete with zero unmapped sections (duplicate-numbered sections disambiguated by file:line); it lives in the PRD workdir notes and is referenced by later acceptance checks.

Verify: row count added for integration.ps1 matches `rg -c "^# [0-9]" tests/integration.ps1` (~139) plus the one .ps1-only `# 40. help guides` row; the mapping table now has zero rows with an empty target-test column across all four source files; the pre-existing smoke and integration.sh rows are unmodified.

## Task 4: Verify ServerGuard spawn/health/teardown round-trip
Status: completed

Add one round-trip test confirming the existing ServerGuard harness (spawn, /health poll, teardown) is stable before any server-backed section is ported. Per the design doc, ServerGuard already covers 100% of the PRD's "Server-spawn helper" ask — this task verifies that, it does not build a new helper.

Location: tests/e2e/common.rs (add the test near the existing ServerGuard impl, tests/e2e/common.rs:55) or a small new tests/e2e/server_guard_roundtrip.rs if the crate's convention keeps tests out of common.rs — match whichever pattern the existing 21 files that call `ServerGuard::start` use for their own smoke coverage, if any already exists.

Reuse: `ServerGuard::start(&DdbTestRepo)` (tests/e2e/common.rs:55) — full server lifecycle: spawn, free-port allocation (`next_available_port`, an AtomicU16 counter), stderr-based readiness detection for HTTP+PgWire listeners, auth-token capture, `.url()`, `.rest_*`, `.graphql*`, `.ws_*`, `.kill()`, `Drop`. `DdbTestRepo` (common.rs:361-401) for the tempdir-backed repo.

Contract (verbatim from the design doc's Interfaces & contracts):
- "ServerGuard::start(&DdbTestRepo) (already implemented, tests/e2e/common.rs:55) is the contract every server-backed port uses. Its public API (start, .url(), .rest_*, .graphql*, .ws_*, .kill, Drop) is unchanged by this PRD — no new methods are required for any currently-known shell scenario."
- "If a specific integration-section port surfaces a genuine gap during Phase 1, add the method to ServerGuard directly (same file, same struct) rather than a parallel helper." This task itself does NOT add new methods — it only proves the existing ones round-trip cleanly.

Details:
- Write a single test: init a DdbTestRepo, call ServerGuard::start, poll `/health` via the guard's existing client method, assert success, let Drop tear the process down.
- Do not modify ServerGuard's public API in this task.

Acceptance criteria:
- one round-trip test spawns, queries `/health`, and tears down cleanly.

Verify: `cargo test -p ddb-e2e --test e2e <new_test_name>` passes locally.

## Task 5: Port smoke.sh + smoke.ps1 sections to tests/e2e/smoke_*.rs
Status: completed

Port every numbered section of tests/smoke.sh and tests/smoke.ps1 (~56 sections each, dialect mirrors of the same scenarios) to Rust e2e tests, per the mapping table's smoke rows.

Location: new files tests/e2e/smoke_*.rs (one file per section or a small cluster of adjacent, related sections — e.g. smoke_core.rs for CRUD/consistency/maintenance sections, smoke_sql.rs for SQL DDL/typed/schema sections). Add one `mod smoke_*;` line per new file to tests/e2e/main.rs, inserted alphabetically into the existing module list.

Reuse: `DdbTestRepo` (tests/e2e/common.rs:361-401) for tempdir-backed repo init and `ddb()`/`ddb_at()` command builders — direct replacement for the shell scripts' `mktemp -d` + `ddb init`. `assert_cmd::Command` + `predicates` for CLI invocation and must-fail assertions (`.assert().success()`/`.failure()`, `predicate::str::contains(...)`) — the established idiom used throughout the crate (see tests/e2e/cli_update_app_error.rs), not a new pattern.

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "smoke_NN_slug, NN zero-padded to match the source section number (04, not 4)."
- Must-fail: "the shell ddb-fails helper (PowerShell-only) / bash bare ! negation maps directly to the existing assert_cmd idiom": `repo.ddb().args([...]).assert().failure().stderr(predicate::str::contains("error:"))`.
- No `serial_test` crate, no `--test-threads=1` — every test gets its own port and its own TempDir-backed repo (existing pattern), so cargo's default parallel runner is already safe.

Details:
- Follow the mapping table (built by an earlier task) section-by-section: for each row targeting a new smoke_NN_slug test, write it; for rows marked "ALREADY COVERED", do not write a duplicate — verify the existing test covers the assertion and mark the row DONE with a note pointing at the existing test.
- Preserve assertions verbatim in intent — same commands, same expected outcomes, same must-fail cases.
- tests/smoke.ps1 has zero CI coverage today; port its sections anyway per the mapping table (they may be identical to smoke.sh's — reuse the same target test where they are dialect mirrors).
- Update the mapping table's status column to DONE for every section ported in this task.

Acceptance criteria:
- each ported test green locally; must-fail assertions preserved via assert_cmd failure checks.

Verify: `cargo build -p ddb-cli` then `cargo test -p ddb-e2e --test e2e smoke_` — every new smoke_* test passes locally; the mapping table shows every smoke.sh/smoke.ps1 row as DONE.

## Task 6: Port integration §17-20: GraphQL server setup, jink schema, expanded GraphQL ops, REST CRUD, PgWire basic
Status: completed

Port tests/integration.sh:52-1178 and the corresponding tests/integration.ps1 section (§17, §17.J1, §17.J2, §18, §18b, §18c, §18c2, §18d, §18d2, §18d3, §18e, §18g, §18h, §18i, §18z, §18z2-§18z10, §19, §20) to Rust e2e tests, per the mapping table's integration rows for this range.

Location: new files tests/e2e/integration_*.rs (one file per section or a small cluster of adjacent related sections, e.g. integration_graphql_server.rs, integration_graphql_jink.rs, integration_rest_pgwire.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `ServerGuard::start(&DdbTestRepo)` (verified round-trip-clean by an earlier task) for every section in this range — all are server-backed (GraphQL/REST/PgWire). `tokio_postgres` (tests/Cargo.toml, see tests/e2e/pgwire.rs) for §20's PgWire basic query, not `psql`. `assert_cmd`/`predicates` for any CLI-side setup calls.

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "integration_NN_slug, NN zero-padded to match the source section number."
- ServerGuard's public API (start, .url(), .rest_*, .graphql*, .ws_*, .kill, Drop) is the contract — do not add new methods; if this range genuinely needs one, add it to ServerGuard directly and note it in the mapping table.
- Concurrency: no serial_test crate, no --test-threads=1 — every test gets its own port + TempDir via the existing pattern.

Details:
- Follow the mapping table row-by-row for this line range: for rows marked "ALREADY COVERED", verify against the named existing test and mark DONE without duplicating; for new-target rows, write the test.
- §17.J1/§17.J2 (jink schema CREATE TABLE + jink-config singleton + Link CRUD) and the §18z8-§18z10 jink full-sweep sections must preserve their exact schema/field assertions — these are jink-consumer-facing contract pins, not incidental test data.
- Preserve assertions verbatim in intent.
- Update the mapping table's status column to DONE for every section ported here (both the .sh and .ps1 rows for each NN, noting "dialect pair, same target" where applicable).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files' test names) passes locally; the mapping table shows 100% of §17-20 rows (both dialects) as DONE.

## Task 7: Port integration §37-38i: WebSocket auth, read-under-write, extended GraphQL ops
Status: completed

Port tests/integration.sh:1179-1497 and the corresponding tests/integration.ps1 section (§37, §38, §38b, §38b2, §38b2b, §38b3, §38b4, §38c, §38c2, §38d, §38e, §38f, §38g, §38h, §38i) to Rust e2e tests, per the mapping table's integration rows for this range.

Location: new files tests/e2e/integration_*.rs (e.g. integration_ws_auth.rs, integration_graphql_refs.rs, integration_graphql_batch.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `ServerGuard` for WebSocket (`.ws_*` methods) and GraphQL/REST calls — all sections in this range are server-backed. `MultiNodeSetup`/`TwoNodeSetup` (tests/e2e/common.rs:404-594) if §38 (read-under-write: concurrent read + write) needs more than one client against the same server.

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "integration_NN_slug, NN zero-padded."
- ServerGuard's public API is unchanged — do not add new methods without a genuine gap.
- Timing-sensitive within-test ordering (e.g. §38's concurrent read+write interleaving) is expressed with `std::thread::scope` + explicit joins, not a serial marker — same pattern as tests/e2e/singleton_cross_process_upsert.rs.

Details:
- Follow the mapping table row-by-row for this line range; skip rows marked ALREADY COVERED (verify, mark DONE, no duplicate).
- §38b-§38i (multi-value references, DISTINCT/GROUP BY, executeBatch/batchUpdate/createMany, typed field updates via GraphQL) must preserve exact response-shape assertions (field presence/absence, ordering, aggregate values).
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally; mapping table shows 100% of §37-38i rows (both dialects) as DONE.

## Task 8: Port integration §42-45: base field filters, SQL INSERT+constraints, JOIN/auto-junction, DDL, createMany + ghost-row pins
Status: completed

Port tests/integration.sh:1498-2108 and the corresponding tests/integration.ps1 section (§42, §42b, §43, §43.D, §44.E1, §44.J, §44.K, §44.M, §44, §45, §45.G13, §45.G12, §45.G11, §45.A1, §45.A3, §45.R10, §45.A2) to Rust e2e tests, per the mapping table's integration rows for this range.

Location: new files tests/e2e/integration_*.rs (e.g. integration_typed_filters.rs, integration_sql_constraints.rs, integration_junction.rs, integration_createmany.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `ServerGuard` for GraphQL executeSql/createDoogat/createMany calls. `assert_cmd` for any CLI-side setup. Existing ghost-row/cross-mutation test patterns if present in tests/e2e/ (grep for `ghost` or `A1`/`A2`/`A3` before writing new coverage — these pin regressions from prior PRDs, PRD 00124 and issue #4).

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "integration_NN_slug, NN zero-padded."
- Must-fail idiom for §43.D (SQL constraint enforcement) and §45.R10 (RESTRICT on NOT NULL REFERENCES): `assert_cmd`'s `.assert().failure()` / GraphQL error-extensions assertion, matching the crate's established pattern.

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying.
- §44.J/§44.K/§44.M (auto-junction table population on SQL INSERT/UPDATE, GraphQL createDoogat, and parent-direction DELETE cleanup) must assert the junction table's actual row state, not just a success/failure code.
- §45.A1/§45.A2/§45.A3 (ghost-row and cross-mutation recovery pins) are regression pins for a previously-fixed bug (issue #4) — preserve the exact failure-then-recovery sequence, not just the end state.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally; mapping table shows 100% of §42-45 rows (both dialects) as DONE.

## Task 9: Port integration §46-53: structured-error codes, ALTER TABLE RENAME across protocols, SINGLETON GraphQL flow
Status: completed

Port tests/integration.sh:2109-2281 and the corresponding tests/integration.ps1 section (§49, §49.1-§49.4, §50, §50a, §50b, §50c, §51, §51.A, §52.B, §53.C) to Rust e2e tests, per the mapping table's integration rows for this range.

Location: new files tests/e2e/integration_*.rs (e.g. integration_error_codes.rs, integration_alter_rename.rs, integration_singleton_flow.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `ServerGuard` for GraphQL/PgWire calls. `tokio_postgres` for §50c (ALTER TABLE RENAME via PgWire when available).

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "integration_NN_slug, NN zero-padded." The §50 section is one of the two duplicate-numbered sections in this PRD (the other is later in the file, ported by a different task) — this one's target slug is `integration_50_alter_table_rename` (established by the mapping table task), NOT plain `integration_50`.
- §49.1-§49.4 structured-error assertions must check `extensions.code` on the GraphQL error response, matching the exact error-code vocabulary from PRD 00131/00129 (UNIQUE_VIOLATION, NOT_NULL_VIOLATION, etc.) — do not paraphrase to a generic error-message substring check.

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying.
- §50b (MySQL alias rejected) must assert the specific rejection message, not just failure — the PRD's own acceptance bar is "no internal error leak".
- §51-§53 (SINGLETON GraphQL flow, ALTER SET/DROP SINGLETON, DEFAULT VALUES auto-seed) are PRD 00139 T20 conformance pins — preserve the exact flow order (create → alter → verify parity).
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally; mapping table shows 100% of §46-53 rows (both dialects) as DONE.

## Task 10: Port integration §56-60: REST/GraphQL warnings envelopes, update warning shape, REST typed create, typed where-filter completeness
Status: completed

Port tests/integration.sh:2538-2816 and the corresponding tests/integration.ps1 section (§56, §56.A-B, §57, §57.A-B, §58, §58.A-D, §59, §59.A-B, §60, §60.A-G) to Rust e2e tests, per the mapping table's integration rows for this range.

Location: new files tests/e2e/integration_*.rs (e.g. integration_warnings_rest.rs, integration_warnings_graphql.rs, integration_update_shape.rs, integration_where_filter.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `ServerGuard` for REST/GraphQL calls.

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "integration_NN_slug, NN zero-padded."
- §56/§57's WarningExtension/warnings-envelope contract: caller-supplied title yields `warnings: []` (REST) / `extensions.warnings: []` (GraphQL) — always present, never omitted, even when empty. §56.B/§57.B: omitted title with a title_template typedef fires a `TITLE_FROM_TEMPLATE` warning.
- §58: GraphQL updateDoogat and REST PUT both always carry a warnings array; a missing id surfaces the structured NOT_FOUND envelope (`extensions.code = NOT_FOUND` for GraphQL, 404 for REST).
- §59.B: malformed fields JSON is rejected with 400 + `VALIDATION_ERROR` before any side effect.

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying.
- §60.A-G (typed where-filter completeness: negation, null operators, forward/reverse relation sub-filters, none/some, relation filter + orderBy + pagination + totalCount correlation) must assert the exact result set, not just non-empty — this section pins PRD 00159's completeness contract.
- The warnings-array assertion must fail if the array key is missing entirely (not present-but-empty) — that is the whole point of the envelope contract these sections pin.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally; mapping table shows 100% of §56-60 rows (both dialects) as DONE.

## Task 11: Port integration Part B: sync/CRDT conflicts, bundle export/import, SQL schema evolution, ID minting, poison-file warnings
Status: completed

Port tests/integration.sh:2886-3803 and the corresponding tests/integration.ps1 section — the file's second, independently-numbered half (§21-§41, plus a reused-numbering tail §46-§50/§62-§63) — to Rust e2e tests, per the mapping table's integration rows for this range. This half is mostly CLI/git-driven (sync, CRDT conflict resolution, bundle export/import, compaction), not server-backed like the earlier integration port tasks.

Location: new files tests/e2e/integration_*.rs (e.g. integration_sync.rs, integration_crdt_conflicts.rs, integration_bundle.rs, integration_schema_evolution.rs, integration_id_minting.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `MultiNodeSetup`/`TwoNodeSetup` (tests/e2e/common.rs:404-594) — bare-remote + N-node clone/register/push/sync helpers, already used for multi-device sync scenarios; this is the direct replacement for every §21-§28 sync/CRDT/bundle section's multi-clone setup. `DdbTestRepo` for single-repo sections (§29-§41 zone/attachments/NoSQL/compaction).

Contract (verbatim from the PRD's Functional Decomposition and design doc):
- Test naming: "integration_NN_slug, NN zero-padded." This half reuses section numbers already used in the server-backed half (e.g. a second `# 50.`) — its target slug is `integration_50_cross_process_fk_freshness` (established by the mapping table task), distinct from the earlier half's `integration_50_alter_table_rename`.
- §26b/§27a/§27a2/§27b/§27c (deterministic CRDT convergence, add-add collision, delete-vs-edit, three-way conflicted merge) pin PRD 00165/00200's conflict-resolution guarantees — both nodes must converge on the SAME resolved state, asserted explicitly, not just "no error".
- §28a (bundle-import conflict recovery) — nodes diverge WITHOUT git-remote sync; preserve this exact setup, it is the scenario that originally caught the bug the design doc references.

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying.
- §32 (poison-file reindex resilience) and §33 (reindex report + AppWarning surface) are PRD 00169 regression pins — preserve the exact skip-and-report semantics (one bad file must not fail the batch).
- §62 (PRD 00164 unified ID minting, end-to-end CLI conformance) and §63 (PRD 00169 poison-file skip warning through GraphQL extensions) close out the file — preserve their exact assertions.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally; mapping table shows 100% of the Part B rows (both dialects) as DONE.

## Task 12: Port integration §54-55/61: PgWire/SINGLETON cross-protocol parity, SINGLETON write races, cross-process write-lock races (port LAST)
Status: completed

Port tests/integration.sh:2282-2537 + 2817-2885 and the corresponding tests/integration.ps1 section (§54.D, §55, §55.A-E, §61, §61.A-B) to Rust e2e tests. This is the riskiest, timing-sensitive slice of the PRD (concurrent multi-process races) and is deliberately sequenced LAST among the port tasks, after every other integration/smoke section has already landed, per the PRD's own Phase 1 instruction ("server sections §54-57 and multi-process races port last").

Location: new files tests/e2e/integration_*.rs (e.g. integration_pgwire_singleton_parity.rs, integration_singleton_races.rs, integration_write_lock_races.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `tests/e2e/singleton_cross_process_upsert.rs` — a live two-server race test that already runs under ordinary `cargo test` parallelism today; this is the existing pattern for every race in this range, not a new one. `ServerGuard` (each test gets its own port via `next_available_port`'s AtomicU16 counter, and its own TempDir-backed repo).

Contract (verbatim from the design doc's Interfaces & contracts — this design DELIBERATELY SUPERSEDES the PRD's own suggested mitigation of "serial markers" for these sections, per the design doc's review log; do not add a serial_test dependency):
- "No serial_test crate, no --test-threads=1. Every test gets its own port and its own TempDir-backed repo, so cargo's default parallel test runner is already safe."
- "Timing-sensitive within-test ordering (two CLI/GraphQL calls that must interleave a specific way) is expressed with std::thread::scope + explicit joins, not a serial marker — same file, same pattern as the existing race test."
- "PgWire sections — psql dependency dropped, not preserved. The Rust e2e crate already ports PgWire scenarios through tokio_postgres (pure-Rust client), never shelling out to psql. The port therefore drops the skip entirely: §54.D's PgWire assertions run unconditionally on every platform via tokio_postgres. Do not add a command -v psql equivalent check in Rust — there is nothing to check for."

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying (the design doc's Reuse inventory flags §54.D/§55.D as likely already covered by tests/e2e/pgwire_singleton.rs — check before writing new coverage).
- §55.A-D (CLI/GraphQL executeSql/typed-createDoogat/PgWire concurrent INSERT races) must each assert exactly one row survives the race (structured-error parity on the loser). §55.E asserts convergence across every protocol's race.
- §61.A-B (cross-process write lock: N concurrent CLI writers on distinct doogats, and a `ddb serve` write concurrent with a CLI write) must assert no lost commit under concurrency — this is PRD 00162's write-lock guarantee, a P0 data-safety invariant per AGENTS.md.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally, run at least twice to catch flake from the concurrency changes; mapping table shows 100% of §54-55/61 rows (both dialects) as DONE.

## Task 13: Rewire test.yml + full-validation.yml to run e2e replacements; dispatch manual full-validation
Status: completed

Rewire CI to run the e2e replacements where it ran the shell scripts, then dispatch one manual full-validation run and confirm it is green on all three platforms before any deletion happens.

Location: .github/workflows/test.yml, .github/workflows/full-validation.yml (edited in place, exact diffs below).

Contract (verbatim from the design doc's Interfaces & contracts — apply these diffs exactly):

test.yml — replace the shell smoke step:
```diff
-      - name: Smoke test
-        env:
-          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
-        run: ./tests/smoke.sh
+      - name: Smoke test (e2e)
+        env:
+          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
+        run: cargo test -p ddb-e2e --test e2e smoke_
```
Job ordering is unchanged (this step already runs after "Build CLI binary"). The five hand-picked `E2E - *` steps and the `Sync integration tests` step in test.yml are untouched — independent fast-gate sampling, not this task's concern.

full-validation.yml:
- DELETE the `linux-smoke` job entirely (not just its shell step) and remove it from `mark-validated`'s `needs:` list. Its only content (`./tests/integration.sh`) is now a strict subset of what `linux-e2e`'s unfiltered `cargo test -p ddb-e2e` already runs on the same platform.
- DELETE the `Integration test` step from `macos-full` and `windows-full` (keep every other step, including `Full cargo test suite`, which now carries the ported coverage via `cargo test-full` = `cargo test --workspace`, which includes the `tests` workspace member unfiltered).

Details:
- Apply both diffs exactly as specified — this is a net simplification (3 fewer CI steps, no coverage lost, since cargo test-full/linux-e2e already run unfiltered).
- After both files are edited, dispatch a manual `full-validation` workflow run (`gh workflow run full-validation.yml` or the repo's documented dispatch method) and wait for it to complete.
- Do NOT proceed to shell-file deletion in this task — that is a separate, later task gated on this run being green.

Acceptance criteria:
- all platforms green on the e2e replacements with the shell steps removed.

Verify: the dispatched full-validation run shows linux-e2e, macos-full, windows-full (and any other jobs) green with the shell smoke/integration steps absent from the run; `test.yml`'s Smoke test step runs `cargo test -p ddb-e2e --test e2e smoke_` and passes on the next push-triggered run.

## Task 14: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references
Status: completed

Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.
