import json
import re
import subprocess
from pathlib import Path

root = Path('/Users/bob/git/src/github.com/doogat/ddb')
worktree = root / 'dev/local/worktrees/00171-review'
workflow = (worktree / '.github/workflows/test.yml').read_text()
commands = re.findall(r'^\s+run: (.+)$', workflow, re.M)
e2e = [command for command in commands if 'cargo test -p ddb-e2e' in command]
assert e2e == ['cargo test -p ddb-e2e'], e2e
assert commands.index('cargo build -p ddb-cli --bin ddb') < commands.index(e2e[0])
assert 'cargo test -p ddb-core --test sync_test' in commands
assert 'cargo llvm-cov --workspace --exclude ddb-e2e --fail-under-lines 70' in commands
assert 'DDB_BIN' not in workflow
assert 'the full Rust e2e suite' in (worktree / 'AGENTS.md').read_text()
output = subprocess.check_output([str(root / 'target/debug/deps/e2e-851e240f61a32247'), '--list'], text=True)
tests = {line.removesuffix(': test') for line in output.splitlines() if line.endswith(': test')}
evidence = json.loads((root / 'dev/local/reviews/00171-review-1-parent-evidence.json').read_text())
missing = set(evidence['qualified_smoke_targets_not_selected_per_push']) - tests
assert not missing, missing
print(f'CI selection: all {len(tests)} registered tests, including all 63 previously omitted smoke targets; no duplicate e2e steps; build ordering and independent gates preserved.')
print('Discovery only; no e2e test body executed.')
