## Tautological test shapes (computed, do not re-judge)

Each `[MECH]` line is a test whose shape cannot fail as written. Raise
it; step 6 adds any line the table lacks. `mech-check` is the finder.


Checked 0 test function(s) in 0 test file(s).
## Fail-first replay (computed, do not re-judge)

Touched tests from HEAD, run against the pre-change code at `b1e785395fb1`
(HEAD's test files overlaid on a base worktree). A test that passes there
does not pin this change. A behavior-preserving refactor's tests pass by
design, so weigh the PRD's intent before raising one. `mech-check` is the finder.

replay: skipped (the diff touches no test function)
