# Review Context

## Completed Tasks

## Task 1: Build e2e mapping table: smoke.sh + smoke.ps1 sections
Status: completed

Build the section-by-section coverage mapping table for tests/smoke.sh and tests/smoke.ps1 — the coverage-proof artifact every later port task and acceptance check references. This is the FIRST task in the PRD; it creates the shared mapping table file.

Location: create dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md (new file; durable PRD satellite — not deleted by dev/local GC, dies only when the PRD itself moves to done/). Source files: tests/smoke.sh (769 lines, ~56 numbered section headers via `rg -n "^# [0-9]" tests/smoke.sh`), tests/smoke.ps1 (932 lines, ~56 numbered section headers, near-mirror dialect of smoke.sh).

Reuse: cross-check each candidate target against the existing tests/e2e/*.rs suite (100+ files, `rg -n "fn " tests/e2e/*.rs` for an index) before assigning a NEW target test name — if an existing e2e test already covers the same assertion, the row must say "ALREADY COVERED by <test>", never a duplicate.

Contract (verbatim from the design doc's Interfaces & contracts):
- Mapping table row format: "one row per shell section: file:line | section # | target e2e test (or \"ALREADY COVERED by <existing test>\" or \"justified survivor: <reason>\") | needs server? | must-fail? | status"
- Test naming: "smoke_NN_slug / integration_NN_slug, NN zero-padded to match the source section number (04, not 4)."
- Must-fail idiom (for must-fail rows' target-test note): the shell `ddb-fails` helper / bash bare `!` negation maps to `assert_cmd`'s `.assert().failure().stderr(predicate::str::contains("error:"))`, already used in tests/e2e/cli_update_app_error.rs — reuse verbatim, do not invent a new pattern.

Details:
- Enumerate every numbered section in both files by file:line. Read each section body (not just the header) to determine what it asserts.
- For each section: assign a target Rust test name (smoke_NN_slug), note whether it needs ServerGuard (a live `ddb serve`) or is CLI-only, whether it is a must-fail scenario, and set status to TODO.
- tests/smoke.ps1 is invoked by NO workflow today (absent from both test.yml and full-validation.yml, confirmed by grep) — still map its sections per the PRD's 100%-coverage metric; note the zero-CI-risk fact in that row's notes rather than skipping the section.
- Where smoke.sh and smoke.ps1 carry the same NN section as dialect mirrors of one scenario, they share ONE target Rust test — do not create two target rows pointing at two different tests for the same scenario; note "dialect pair, same target" in the row.
- Every section must map to a target row — zero unmapped sections is the acceptance bar.

Acceptance criteria:
- the table is complete with zero unmapped sections (duplicate-numbered sections disambiguated by file:line); it lives in the PRD workdir notes and is referenced by later acceptance checks.

Verify: row count in the new mapping table (smoke section) matches the combined section count from `rg -c "^# [0-9]" tests/smoke.sh tests/smoke.ps1` (accounting for shared dialect-pair rows counting once each per file, not merged into a single row); spot-check 3 random rows against their source line to confirm accuracy.

## Task 2: Build e2e mapping table: integration.sh sections
Status: completed

Extend the shared mapping table (created by an earlier task) with a row per numbered section in tests/integration.sh — APPEND to the existing file, do not overwrite the smoke.sh/smoke.ps1 rows already there.

Location: append to dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md. Source: tests/integration.sh (3803 lines, ~140 numbered section headers via `rg -n "^# [0-9]" tests/integration.sh`).

Premise: dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md already exists with the smoke.sh/smoke.ps1 rows filled in (written by an earlier task in this PRD). Re-verify the file exists and has content before appending; if it is missing, stop and report — do not silently create a fresh file that drops the smoke rows.

Reuse: cross-check each candidate target against the existing tests/e2e/*.rs suite before assigning a NEW target — the design doc's Reuse inventory flags that integration.sh §54.D/§55.D name `pgwire_singleton` as their own replacement in their own pass messages (`integration.sh:2358`, `:2513`); check tests/e2e/pgwire*.rs, serve.rs, server_mutations.rs, subscriptions.rs, singleton_cross_process_*.rs for existing equivalents before writing a new target for any server-lifecycle section.

Contract (verbatim from the design doc's Interfaces & contracts):
- Mapping table row format: "one row per shell section: file:line | section # | target e2e test (or \"ALREADY COVERED by <existing test>\" or \"justified survivor: <reason>\") | needs server? | must-fail? | status"
- Test naming: "smoke_NN_slug / integration_NN_slug, NN zero-padded to match the source section number (04, not 4)." integration.sh carries a duplicate `# 50.` section header at two locations (`integration.sh:2159` PRD 00132 rename-across-protocols, and `integration.sh:3697` PRD 00136 FK-freshness) — key these two rows by file:line, and disambiguate with distinct target slugs (`integration_50_alter_table_rename`, `integration_50_cross_process_fk_freshness`), never two rows named `integration_50`.
- Must-fail idiom: bash negates with bare `!` (no `ddb-fails` helper in bash) — maps to the same `assert_cmd` `.assert().failure()` idiom used by the smoke mapping task.

Details:
- integration.sh has two structurally distinct halves sharing overlapping numbering: lines ~52-2885 (server-dependent: GraphQL/REST/PgWire/SINGLETON, numbered §17-§61) and lines ~2886-3803 (CLI/git/sync/CRDT-focused, independently numbered §21-§63, reusing numbers already used in the first half — this is the source of the duplicate-`#50` quirk, not a typo). Map both halves; note the half in each row so later port tasks reading this table know which capability group a section belongs to.
- For each section: assign a target Rust test name (integration_NN_slug), note whether it needs ServerGuard, whether it is a must-fail scenario, and set status to TODO.
- Every section must map to a target row — zero unmapped sections.

Acceptance criteria:
- the table is complete with zero unmapped sections (duplicate-numbered sections disambiguated by file:line); it lives in the PRD workdir notes and is referenced by later acceptance checks.

Verify: row count added for integration.sh matches `rg -c "^# [0-9]" tests/integration.sh` (~140); the two duplicate `# 50.` rows carry distinct file:line keys and distinct target slugs; the pre-existing smoke rows from the earlier task are still present and unmodified in the file.

## Task 3: Build e2e mapping table: integration.ps1 sections
Status: completed

Extend the shared mapping table with a row per numbered section in tests/integration.ps1 — APPEND to the existing file (already carrying the smoke and integration.sh rows), reusing the same target Rust test names integration.sh's rows already established for matching section numbers.

Location: append to dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md. Source: tests/integration.ps1 (3781 lines, ~139 numbered section headers via `rg -n "^# [0-9]" tests/integration.ps1`).

Premise: the mapping table already has smoke and integration.sh rows filled in by earlier tasks in this PRD. Re-verify the file exists and has both sets of rows before appending; if either is missing, stop and report.

Reuse: for each integration.ps1 section, first look up the matching NN in the integration.sh rows already in the table (same PRD, same behavior, different dialect) and reuse that target test name — these dialect pairs are almost always the SAME Rust test, not a second one. Only assign a distinct target when the .ps1 section's assertions genuinely diverge from its .sh counterpart (see Details).

Contract (verbatim from the design doc's Interfaces & contracts and Risks & edge cases):
- Mapping table row format: "one row per shell section: file:line | section # | target e2e test (or \"ALREADY COVERED by <existing test>\" or \"justified survivor: <reason>\") | needs server? | must-fail? | status"
- integration.ps1 carries the SAME duplicate `# 50.` pattern as integration.sh, mirrored at `integration.ps1:2026` and `:3654` — key by file:line, reuse the two target slugs integration.sh's task already assigned (`integration_50_alter_table_rename`, `integration_50_cross_process_fk_freshness`).
- Must-fail idiom: PowerShell's `ddb-fails` helper (`integration.ps1:67`) is the ONLY dialect that names this helper explicitly — maps to the same `assert_cmd` `.assert().failure()` idiom as the other mapping tasks; do not port the PowerShell helper itself, only its call sites' assertions.

Details:
- For each integration.ps1 section, cross-reference the corresponding integration.sh row (same or equivalent NN). If assertions match, reuse the same target and note "dialect pair, same target" — do not create a second target for the identical scenario.
- Windows-specific path/escaping behavior: any section whose PowerShell assertion tests *string* path formatting (not just behavior — e.g. backslash vs forward-slash literal comparisons) needs a `cfg!(windows)` branch called out explicitly in that row's notes, per the PRD's own Risk note. Most sections need no special handling since Rust's `std::path::Path` already normalizes platform separators.
- integration.ps1 has one section (`# 40. help guides`, line 3372) with no corresponding numbered section in integration.sh at that position — integration.sh's own `# 40.` is "binary asset LWW conflict resolution" at a different line, and .ps1 ALSO has that same section at line 3387 as a separate, later entry. Treat .ps1's `# 40. help guides` as a genuine .ps1-only addition: map it to its own target or mark it a justified survivor if it merely re-runs `--help` output already covered by an existing e2e test — do not silently drop it or conflate it with the `# 40. binary asset LWW` row.
- integration.sh §54.D / §55.D's psql-absent skip does NOT need porting (per the design doc, PgWire sections drop the psql dependency entirely via tokio_postgres) — mark those rows accordingly rather than inventing a `cfg!` / `command -v psql` equivalent in Rust.
- Every section must map to a target row — zero unmapped sections.

Acceptance criteria:
- the table is complete with zero unmapped sections (duplicate-numbered sections disambiguated by file:line); it lives in the PRD workdir notes and is referenced by later acceptance checks.

Verify: row count added for integration.ps1 matches `rg -c "^# [0-9]" tests/integration.ps1` (~139) plus the one .ps1-only `# 40. help guides` row; the mapping table now has zero rows with an empty target-test column across all four source files; the pre-existing smoke and integration.sh rows are unmodified.

## Task 4: Verify ServerGuard spawn/health/teardown round-trip
Status: completed

Add one round-trip test confirming the existing ServerGuard harness (spawn, /health poll, teardown) is stable before any server-backed section is ported. Per the design doc, ServerGuard already covers 100% of the PRD's "Server-spawn helper" ask — this task verifies that, it does not build a new helper.

Location: tests/e2e/common.rs (add the test near the existing ServerGuard impl, tests/e2e/common.rs:55) or a small new tests/e2e/server_guard_roundtrip.rs if the crate's convention keeps tests out of common.rs — match whichever pattern the existing 21 files that call `ServerGuard::start` use for their own smoke coverage, if any already exists.

Reuse: `ServerGuard::start(&DdbTestRepo)` (tests/e2e/common.rs:55) — full server lifecycle: spawn, free-port allocation (`next_available_port`, an AtomicU16 counter), stderr-based readiness detection for HTTP+PgWire listeners, auth-token capture, `.url()`, `.rest_*`, `.graphql*`, `.ws_*`, `.kill()`, `Drop`. `DdbTestRepo` (common.rs:361-401) for the tempdir-backed repo.

Contract (verbatim from the design doc's Interfaces & contracts):
- "ServerGuard::start(&DdbTestRepo) (already implemented, tests/e2e/common.rs:55) is the contract every server-backed port uses. Its public API (start, .url(), .rest_*, .graphql*, .ws_*, .kill, Drop) is unchanged by this PRD — no new methods are required for any currently-known shell scenario."
- "If a specific integration-section port surfaces a genuine gap during Phase 1, add the method to ServerGuard directly (same file, same struct) rather than a parallel helper." This task itself does NOT add new methods — it only proves the existing ones round-trip cleanly.

Details:
- Write a single test: init a DdbTestRepo, call ServerGuard::start, poll `/health` via the guard's existing client method, assert success, let Drop tear the process down.
- Do not modify ServerGuard's public API in this task.

Acceptance criteria:
- one round-trip test spawns, queries `/health`, and tears down cleanly.

Verify: `cargo test -p ddb-e2e --test e2e <new_test_name>` passes locally.

## Task 5: Port smoke.sh + smoke.ps1 sections to tests/e2e/smoke_*.rs
Status: completed

Port every numbered section of tests/smoke.sh and tests/smoke.ps1 (~56 sections each, dialect mirrors of the same scenarios) to Rust e2e tests, per the mapping table's smoke rows.

Location: new files tests/e2e/smoke_*.rs (one file per section or a small cluster of adjacent, related sections — e.g. smoke_core.rs for CRUD/consistency/maintenance sections, smoke_sql.rs for SQL DDL/typed/schema sections). Add one `mod smoke_*;` line per new file to tests/e2e/main.rs, inserted alphabetically into the existing module list.

Reuse: `DdbTestRepo` (tests/e2e/common.rs:361-401) for tempdir-backed repo init and `ddb()`/`ddb_at()` command builders — direct replacement for the shell scripts' `mktemp -d` + `ddb init`. `assert_cmd::Command` + `predicates` for CLI invocation and must-fail assertions (`.assert().success()`/`.failure()`, `predicate::str::contains(...)`) — the established idiom used throughout the crate (see tests/e2e/cli_update_app_error.rs), not a new pattern.

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "smoke_NN_slug, NN zero-padded to match the source section number (04, not 4)."
- Must-fail: "the shell ddb-fails helper (PowerShell-only) / bash bare ! negation maps directly to the existing assert_cmd idiom": `repo.ddb().args([...]).assert().failure().stderr(predicate::str::contains("error:"))`.
- No `serial_test` crate, no `--test-threads=1` — every test gets its own port and its own TempDir-backed repo (existing pattern), so cargo's default parallel runner is already safe.

Details:
- Follow the mapping table (built by an earlier task) section-by-section: for each row targeting a new smoke_NN_slug test, write it; for rows marked "ALREADY COVERED", do not write a duplicate — verify the existing test covers the assertion and mark the row DONE with a note pointing at the existing test.
- Preserve assertions verbatim in intent — same commands, same expected outcomes, same must-fail cases.
- tests/smoke.ps1 has zero CI coverage today; port its sections anyway per the mapping table (they may be identical to smoke.sh's — reuse the same target test where they are dialect mirrors).
- Update the mapping table's status column to DONE for every section ported in this task.

Acceptance criteria:
- each ported test green locally; must-fail assertions preserved via assert_cmd failure checks.

Verify: `cargo build -p ddb-cli` then `cargo test -p ddb-e2e --test e2e smoke_` — every new smoke_* test passes locally; the mapping table shows every smoke.sh/smoke.ps1 row as DONE.

## Task 6: Port integration §17-20: GraphQL server setup, jink schema, expanded GraphQL ops, REST CRUD, PgWire basic
Status: completed

Port tests/integration.sh:52-1178 and the corresponding tests/integration.ps1 section (§17, §17.J1, §17.J2, §18, §18b, §18c, §18c2, §18d, §18d2, §18d3, §18e, §18g, §18h, §18i, §18z, §18z2-§18z10, §19, §20) to Rust e2e tests, per the mapping table's integration rows for this range.

Location: new files tests/e2e/integration_*.rs (one file per section or a small cluster of adjacent related sections, e.g. integration_graphql_server.rs, integration_graphql_jink.rs, integration_rest_pgwire.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `ServerGuard::start(&DdbTestRepo)` (verified round-trip-clean by an earlier task) for every section in this range — all are server-backed (GraphQL/REST/PgWire). `tokio_postgres` (tests/Cargo.toml, see tests/e2e/pgwire.rs) for §20's PgWire basic query, not `psql`. `assert_cmd`/`predicates` for any CLI-side setup calls.

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "integration_NN_slug, NN zero-padded to match the source section number."
- ServerGuard's public API (start, .url(), .rest_*, .graphql*, .ws_*, .kill, Drop) is the contract — do not add new methods; if this range genuinely needs one, add it to ServerGuard directly and note it in the mapping table.
- Concurrency: no serial_test crate, no --test-threads=1 — every test gets its own port + TempDir via the existing pattern.

Details:
- Follow the mapping table row-by-row for this line range: for rows marked "ALREADY COVERED", verify against the named existing test and mark DONE without duplicating; for new-target rows, write the test.
- §17.J1/§17.J2 (jink schema CREATE TABLE + jink-config singleton + Link CRUD) and the §18z8-§18z10 jink full-sweep sections must preserve their exact schema/field assertions — these are jink-consumer-facing contract pins, not incidental test data.
- Preserve assertions verbatim in intent.
- Update the mapping table's status column to DONE for every section ported here (both the .sh and .ps1 rows for each NN, noting "dialect pair, same target" where applicable).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files' test names) passes locally; the mapping table shows 100% of §17-20 rows (both dialects) as DONE.

## Task 7: Port integration §37-38i: WebSocket auth, read-under-write, extended GraphQL ops
Status: completed

Port tests/integration.sh:1179-1497 and the corresponding tests/integration.ps1 section (§37, §38, §38b, §38b2, §38b2b, §38b3, §38b4, §38c, §38c2, §38d, §38e, §38f, §38g, §38h, §38i) to Rust e2e tests, per the mapping table's integration rows for this range.

Location: new files tests/e2e/integration_*.rs (e.g. integration_ws_auth.rs, integration_graphql_refs.rs, integration_graphql_batch.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `ServerGuard` for WebSocket (`.ws_*` methods) and GraphQL/REST calls — all sections in this range are server-backed. `MultiNodeSetup`/`TwoNodeSetup` (tests/e2e/common.rs:404-594) if §38 (read-under-write: concurrent read + write) needs more than one client against the same server.

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "integration_NN_slug, NN zero-padded."
- ServerGuard's public API is unchanged — do not add new methods without a genuine gap.
- Timing-sensitive within-test ordering (e.g. §38's concurrent read+write interleaving) is expressed with `std::thread::scope` + explicit joins, not a serial marker — same pattern as tests/e2e/singleton_cross_process_upsert.rs.

Details:
- Follow the mapping table row-by-row for this line range; skip rows marked ALREADY COVERED (verify, mark DONE, no duplicate).
- §38b-§38i (multi-value references, DISTINCT/GROUP BY, executeBatch/batchUpdate/createMany, typed field updates via GraphQL) must preserve exact response-shape assertions (field presence/absence, ordering, aggregate values).
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally; mapping table shows 100% of §37-38i rows (both dialects) as DONE.

## Task 8: Port integration §42-45: base field filters, SQL INSERT+constraints, JOIN/auto-junction, DDL, createMany + ghost-row pins
Status: completed

Port tests/integration.sh:1498-2108 and the corresponding tests/integration.ps1 section (§42, §42b, §43, §43.D, §44.E1, §44.J, §44.K, §44.M, §44, §45, §45.G13, §45.G12, §45.G11, §45.A1, §45.A3, §45.R10, §45.A2) to Rust e2e tests, per the mapping table's integration rows for this range.

Location: new files tests/e2e/integration_*.rs (e.g. integration_typed_filters.rs, integration_sql_constraints.rs, integration_junction.rs, integration_createmany.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `ServerGuard` for GraphQL executeSql/createDoogat/createMany calls. `assert_cmd` for any CLI-side setup. Existing ghost-row/cross-mutation test patterns if present in tests/e2e/ (grep for `ghost` or `A1`/`A2`/`A3` before writing new coverage — these pin regressions from prior PRDs, PRD 00124 and issue #4).

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "integration_NN_slug, NN zero-padded."
- Must-fail idiom for §43.D (SQL constraint enforcement) and §45.R10 (RESTRICT on NOT NULL REFERENCES): `assert_cmd`'s `.assert().failure()` / GraphQL error-extensions assertion, matching the crate's established pattern.

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying.
- §44.J/§44.K/§44.M (auto-junction table population on SQL INSERT/UPDATE, GraphQL createDoogat, and parent-direction DELETE cleanup) must assert the junction table's actual row state, not just a success/failure code.
- §45.A1/§45.A2/§45.A3 (ghost-row and cross-mutation recovery pins) are regression pins for a previously-fixed bug (issue #4) — preserve the exact failure-then-recovery sequence, not just the end state.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally; mapping table shows 100% of §42-45 rows (both dialects) as DONE.

## Task 9: Port integration §46-53: structured-error codes, ALTER TABLE RENAME across protocols, SINGLETON GraphQL flow
Status: completed

Port tests/integration.sh:2109-2281 and the corresponding tests/integration.ps1 section (§49, §49.1-§49.4, §50, §50a, §50b, §50c, §51, §51.A, §52.B, §53.C) to Rust e2e tests, per the mapping table's integration rows for this range.

Location: new files tests/e2e/integration_*.rs (e.g. integration_error_codes.rs, integration_alter_rename.rs, integration_singleton_flow.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `ServerGuard` for GraphQL/PgWire calls. `tokio_postgres` for §50c (ALTER TABLE RENAME via PgWire when available).

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "integration_NN_slug, NN zero-padded." The §50 section is one of the two duplicate-numbered sections in this PRD (the other is later in the file, ported by a different task) — this one's target slug is `integration_50_alter_table_rename` (established by the mapping table task), NOT plain `integration_50`.
- §49.1-§49.4 structured-error assertions must check `extensions.code` on the GraphQL error response, matching the exact error-code vocabulary from PRD 00131/00129 (UNIQUE_VIOLATION, NOT_NULL_VIOLATION, etc.) — do not paraphrase to a generic error-message substring check.

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying.
- §50b (MySQL alias rejected) must assert the specific rejection message, not just failure — the PRD's own acceptance bar is "no internal error leak".
- §51-§53 (SINGLETON GraphQL flow, ALTER SET/DROP SINGLETON, DEFAULT VALUES auto-seed) are PRD 00139 T20 conformance pins — preserve the exact flow order (create → alter → verify parity).
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally; mapping table shows 100% of §46-53 rows (both dialects) as DONE.

## Task 10: Port integration §56-60: REST/GraphQL warnings envelopes, update warning shape, REST typed create, typed where-filter completeness
Status: completed

Port tests/integration.sh:2538-2816 and the corresponding tests/integration.ps1 section (§56, §56.A-B, §57, §57.A-B, §58, §58.A-D, §59, §59.A-B, §60, §60.A-G) to Rust e2e tests, per the mapping table's integration rows for this range.

Location: new files tests/e2e/integration_*.rs (e.g. integration_warnings_rest.rs, integration_warnings_graphql.rs, integration_update_shape.rs, integration_where_filter.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `ServerGuard` for REST/GraphQL calls.

Contract (verbatim from the design doc's Interfaces & contracts):
- Test naming: "integration_NN_slug, NN zero-padded."
- §56/§57's WarningExtension/warnings-envelope contract: caller-supplied title yields `warnings: []` (REST) / `extensions.warnings: []` (GraphQL) — always present, never omitted, even when empty. §56.B/§57.B: omitted title with a title_template typedef fires a `TITLE_FROM_TEMPLATE` warning.
- §58: GraphQL updateDoogat and REST PUT both always carry a warnings array; a missing id surfaces the structured NOT_FOUND envelope (`extensions.code = NOT_FOUND` for GraphQL, 404 for REST).
- §59.B: malformed fields JSON is rejected with 400 + `VALIDATION_ERROR` before any side effect.

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying.
- §60.A-G (typed where-filter completeness: negation, null operators, forward/reverse relation sub-filters, none/some, relation filter + orderBy + pagination + totalCount correlation) must assert the exact result set, not just non-empty — this section pins PRD 00159's completeness contract.
- The warnings-array assertion must fail if the array key is missing entirely (not present-but-empty) — that is the whole point of the envelope contract these sections pin.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally; mapping table shows 100% of §56-60 rows (both dialects) as DONE.

## Task 11: Port integration Part B: sync/CRDT conflicts, bundle export/import, SQL schema evolution, ID minting, poison-file warnings
Status: completed

Port tests/integration.sh:2886-3803 and the corresponding tests/integration.ps1 section — the file's second, independently-numbered half (§21-§41, plus a reused-numbering tail §46-§50/§62-§63) — to Rust e2e tests, per the mapping table's integration rows for this range. This half is mostly CLI/git-driven (sync, CRDT conflict resolution, bundle export/import, compaction), not server-backed like the earlier integration port tasks.

Location: new files tests/e2e/integration_*.rs (e.g. integration_sync.rs, integration_crdt_conflicts.rs, integration_bundle.rs, integration_schema_evolution.rs, integration_id_minting.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `MultiNodeSetup`/`TwoNodeSetup` (tests/e2e/common.rs:404-594) — bare-remote + N-node clone/register/push/sync helpers, already used for multi-device sync scenarios; this is the direct replacement for every §21-§28 sync/CRDT/bundle section's multi-clone setup. `DdbTestRepo` for single-repo sections (§29-§41 zone/attachments/NoSQL/compaction).

Contract (verbatim from the PRD's Functional Decomposition and design doc):
- Test naming: "integration_NN_slug, NN zero-padded." This half reuses section numbers already used in the server-backed half (e.g. a second `# 50.`) — its target slug is `integration_50_cross_process_fk_freshness` (established by the mapping table task), distinct from the earlier half's `integration_50_alter_table_rename`.
- §26b/§27a/§27a2/§27b/§27c (deterministic CRDT convergence, add-add collision, delete-vs-edit, three-way conflicted merge) pin PRD 00165/00200's conflict-resolution guarantees — both nodes must converge on the SAME resolved state, asserted explicitly, not just "no error".
- §28a (bundle-import conflict recovery) — nodes diverge WITHOUT git-remote sync; preserve this exact setup, it is the scenario that originally caught the bug the design doc references.

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying.
- §32 (poison-file reindex resilience) and §33 (reindex report + AppWarning surface) are PRD 00169 regression pins — preserve the exact skip-and-report semantics (one bad file must not fail the batch).
- §62 (PRD 00164 unified ID minting, end-to-end CLI conformance) and §63 (PRD 00169 poison-file skip warning through GraphQL extensions) close out the file — preserve their exact assertions.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally; mapping table shows 100% of the Part B rows (both dialects) as DONE.

## Task 12: Port integration §54-55/61: PgWire/SINGLETON cross-protocol parity, SINGLETON write races, cross-process write-lock races (port LAST)
Status: completed

Port tests/integration.sh:2282-2537 + 2817-2885 and the corresponding tests/integration.ps1 section (§54.D, §55, §55.A-E, §61, §61.A-B) to Rust e2e tests. This is the riskiest, timing-sensitive slice of the PRD (concurrent multi-process races) and is deliberately sequenced LAST among the port tasks, after every other integration/smoke section has already landed, per the PRD's own Phase 1 instruction ("server sections §54-57 and multi-process races port last").

Location: new files tests/e2e/integration_*.rs (e.g. integration_pgwire_singleton_parity.rs, integration_singleton_races.rs, integration_write_lock_races.rs). Add one `mod integration_*;` line per new file to tests/e2e/main.rs, inserted alphabetically.

Reuse: `tests/e2e/singleton_cross_process_upsert.rs` — a live two-server race test that already runs under ordinary `cargo test` parallelism today; this is the existing pattern for every race in this range, not a new one. `ServerGuard` (each test gets its own port via `next_available_port`'s AtomicU16 counter, and its own TempDir-backed repo).

Contract (verbatim from the design doc's Interfaces & contracts — this design DELIBERATELY SUPERSEDES the PRD's own suggested mitigation of "serial markers" for these sections, per the design doc's review log; do not add a serial_test dependency):
- "No serial_test crate, no --test-threads=1. Every test gets its own port and its own TempDir-backed repo, so cargo's default parallel test runner is already safe."
- "Timing-sensitive within-test ordering (two CLI/GraphQL calls that must interleave a specific way) is expressed with std::thread::scope + explicit joins, not a serial marker — same file, same pattern as the existing race test."
- "PgWire sections — psql dependency dropped, not preserved. The Rust e2e crate already ports PgWire scenarios through tokio_postgres (pure-Rust client), never shelling out to psql. The port therefore drops the skip entirely: §54.D's PgWire assertions run unconditionally on every platform via tokio_postgres. Do not add a command -v psql equivalent check in Rust — there is nothing to check for."

Details:
- Follow the mapping table row-by-row for this line range; skip ALREADY COVERED rows after verifying (the design doc's Reuse inventory flags §54.D/§55.D as likely already covered by tests/e2e/pgwire_singleton.rs — check before writing new coverage).
- §55.A-D (CLI/GraphQL executeSql/typed-createDoogat/PgWire concurrent INSERT races) must each assert exactly one row survives the race (structured-error parity on the loser). §55.E asserts convergence across every protocol's race.
- §61.A-B (cross-process write lock: N concurrent CLI writers on distinct doogats, and a `ddb serve` write concurrent with a CLI write) must assert no lost commit under concurrency — this is PRD 00162's write-lock guarantee, a P0 data-safety invariant per AGENTS.md.
- Update the mapping table's status column to DONE for every section ported here (both dialect rows).

Acceptance criteria:
- each ported test green locally; the mapping table marks every section in this range DONE.

Verify: `cargo test -p ddb-e2e --test e2e integration_` (filtered to the new files) passes locally, run at least twice to catch flake from the concurrency changes; mapping table shows 100% of §54-55/61 rows (both dialects) as DONE.

## Task 13: Rewire test.yml + full-validation.yml to run e2e replacements; dispatch manual full-validation
Status: completed

Rewire CI to run the e2e replacements where it ran the shell scripts, then dispatch one manual full-validation run and confirm it is green on all three platforms before any deletion happens.

Location: .github/workflows/test.yml, .github/workflows/full-validation.yml (edited in place, exact diffs below).

Contract (verbatim from the design doc's Interfaces & contracts — apply these diffs exactly):

test.yml — replace the shell smoke step:
```diff
-      - name: Smoke test
-        env:
-          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
-        run: ./tests/smoke.sh
+      - name: Smoke test (e2e)
+        env:
+          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
+        run: cargo test -p ddb-e2e --test e2e smoke_
```
Job ordering is unchanged (this step already runs after "Build CLI binary"). The five hand-picked `E2E - *` steps and the `Sync integration tests` step in test.yml are untouched — independent fast-gate sampling, not this task's concern.

full-validation.yml:
- DELETE the `linux-smoke` job entirely (not just its shell step) and remove it from `mark-validated`'s `needs:` list. Its only content (`./tests/integration.sh`) is now a strict subset of what `linux-e2e`'s unfiltered `cargo test -p ddb-e2e` already runs on the same platform.
- DELETE the `Integration test` step from `macos-full` and `windows-full` (keep every other step, including `Full cargo test suite`, which now carries the ported coverage via `cargo test-full` = `cargo test --workspace`, which includes the `tests` workspace member unfiltered).

Details:
- Apply both diffs exactly as specified — this is a net simplification (3 fewer CI steps, no coverage lost, since cargo test-full/linux-e2e already run unfiltered).
- After both files are edited, dispatch a manual `full-validation` workflow run (`gh workflow run full-validation.yml` or the repo's documented dispatch method) and wait for it to complete.
- Do NOT proceed to shell-file deletion in this task — that is a separate, later task gated on this run being green.

Acceptance criteria:
- all platforms green on the e2e replacements with the shell steps removed.

Verify: the dispatched full-validation run shows linux-e2e, macos-full, windows-full (and any other jobs) green with the shell smoke/integration steps absent from the run; `test.yml`'s Smoke test step runs `cargo test -p ddb-e2e --test e2e smoke_` and passes on the next push-triggered run.

## Task 14: Delete the four shell scenario files; rewrite AGENTS.md + CONTRIBUTING.md + README.md + docs testing references
Status: completed

Delete tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 now that CI proves the e2e replacements are green on all three platforms (the prior task's full-validation dispatch), and rewrite every doc that names the 4-file authoring mandate or the shell scripts themselves. This is the FINAL task of the PRD — a deletion PRD per CLAUDE.md, so run `cargo test -p ddb-e2e` after.

Premise: the prior task's manual full-validation dispatch is green on all three platforms with the shell steps already removed from CI. Re-verify this before deleting — do not delete on an unconfirmed or stale CI run.

Location:
- Delete: tests/smoke.sh, tests/smoke.ps1, tests/integration.sh, tests/integration.ps1 (or, per the mapping table, justify and keep any survivor instead of deleting it).
- AGENTS.md — rewrite the "Per-PRD deliverables" bullet: scenario authoring now targets tests/e2e/, not the 4-file shell mandate. The bullet's trailing sentence about dev/local/specs/jink-feedback/ddb-repros/ is UNRELATED to the 4-file mandate and must carry into the rewritten text unchanged.
- CONTRIBUTING.md:42-43 — duplicates the exact 4-file mandate AGENTS.md is dropping; rewrite identically to AGENTS.md's new text.
- README.md:101-102 — quickstart commands that would 404 post-deletion; replace with the `cargo test -p ddb-e2e` equivalent.
- docs/src/technical/walkthrough.md:38,430 — describes the four files as "additional test surfaces"; rewrite to describe the e2e crate instead.
- docs/src/technical/sql-engine.md:622,634 — cites specific shell sections for the SQL-engine bug-cluster table; repoint at the mapping table's target e2e test names for those rows.

Contract (verbatim from the PRD's Phase 2 task and Success Metrics):
- "delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md 'Per-PRD deliverables' (scenario authoring targets tests/e2e/) and the docs/src/technical/ testing references; run cargo test -p ddb-e2e (deletion PRD per CLAUDE.md)"
- "The four shell files are deleted (or each survivor is justified in the mapping table)."
- "AGENTS.md 'Per-PRD deliverables' is rewritten: scenario authoring targets tests/e2e/; the 4-file mandate is removed."

Details:
- Use `git rm` for the four shell files (or `git mv` if a survivor is kept elsewhere per the mapping table's justification).
- After all doc edits and deletions, run `rg -l "smoke.sh"` across the repo — every remaining hit must be a historical doc (e.g. a dated changelog entry or an old PRD in dev/local/prds/done/), never a live instruction.
- Run `cargo test -p ddb-e2e` per CLAUDE.md's deletion-PRD mandate (this PRD deletes existing code paths).

Acceptance criteria:
- `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

Verify: `rg -l "smoke.sh"` output reviewed — every hit is historical (dev/local/prds/done/, changelog, etc.), none in AGENTS.md/CONTRIBUTING.md/README.md/docs/src/technical/ live text; `cargo test -p ddb-e2e` green; a follow-up CI push run is green with the shell files absent from the working tree.

## Code Changes

### Changed Files
Full PRD work range: b1e785395fb1e5d7043fbc725cc5786f62a6417e..c8b72bd9126c83d054264ce6ac3738e8f6d0abda

.github/workflows/full-validation.yml
.github/workflows/test.yml
AGENTS.md
CHANGELOG.md
CONTRIBUTING.md
README.md
ddb-core/src/git_ops/read.rs
ddb-core/src/git_ops/tests.rs
ddb-core/src/indexer/tests/mod.rs
ddb-core/src/search_query.rs
docs/src/technical/crdt-resolver.md
docs/src/technical/sql-engine.md
docs/src/technical/walkthrough.md
tests/e2e/alter_column_type.rs
tests/e2e/alter_table_rename.rs
tests/e2e/bundle_import_conflict_recovery.rs
tests/e2e/cascade_delete.rs
tests/e2e/checkboxes.rs
tests/e2e/cli_create_fk_freshness.rs
tests/e2e/cli_create_unregistered_type.rs
tests/e2e/common.rs
tests/e2e/delete_backlinks.rs
tests/e2e/discover.rs
tests/e2e/fix.rs
tests/e2e/folder_namespace.rs
tests/e2e/hyphenated_types.rs
tests/e2e/inline_zone.rs
tests/e2e/integration_alter_rename.rs
tests/e2e/integration_binary_lww.rs
tests/e2e/integration_bundle.rs
tests/e2e/integration_compact_stats.rs
tests/e2e/integration_crdt_conflicts.rs
tests/e2e/integration_error_codes.rs
tests/e2e/integration_graphql_batch.rs
tests/e2e/integration_graphql_jink.rs
tests/e2e/integration_graphql_refs.rs
tests/e2e/integration_graphql_server.rs
tests/e2e/integration_hyphenated_type.rs
tests/e2e/integration_id_poison.rs
tests/e2e/integration_junction_sync.rs
tests/e2e/integration_nosql_cli.rs
tests/e2e/integration_orderby_base_fields.rs
tests/e2e/integration_rest_pgwire.rs
tests/e2e/integration_singleton_flow.rs
tests/e2e/integration_singleton_parity.rs
tests/e2e/integration_singleton_races.rs
tests/e2e/integration_sql_no_match.rs
tests/e2e/integration_sql_writes.rs
tests/e2e/integration_sync.rs
tests/e2e/integration_tags_filter.rs
tests/e2e/integration_typed_write_cli.rs
tests/e2e/integration_typed_write_polish.rs
tests/e2e/integration_update_bin.rs
tests/e2e/integration_warnings_update.rs
tests/e2e/integration_write_lock_races.rs
tests/e2e/integration_write_recovery.rs
tests/e2e/junction_tables.rs
tests/e2e/link_kinds.rs
tests/e2e/main.rs
tests/e2e/multi_device.rs
tests/e2e/pgwire.rs
tests/e2e/poison_file_reindex.rs
tests/e2e/reference_raw_id.rs
tests/e2e/rename.rs
tests/e2e/schema_apply.rs
tests/e2e/search_in_filter.rs
tests/e2e/search_links.rs
tests/e2e/sequence.rs
tests/e2e/serve.rs
tests/e2e/server_mutations.rs
tests/e2e/set_flag.rs
tests/e2e/smoke_core.rs
tests/e2e/smoke_resilience.rs
tests/e2e/smoke_search.rs
tests/e2e/smoke_sql.rs
tests/e2e/sql_expressions_test.rs
tests/e2e/sql_lifecycle.rs
tests/e2e/sync_crdt.rs
tests/e2e/tags.rs
tests/e2e/typed_field_mutations.rs
tests/integration.ps1
tests/integration.sh
tests/smoke.ps1
tests/smoke.sh

## PRD Requirements

# Migrate smoke/integration shell scenarios to the Rust e2e crate

**Priority:** P2 (leverage; ends the 4-file authoring tax before the contract block) · **Roadmap:** inserted 2026-07-16 by maintainer decision (assessment F5) — runs after P0/P1, before the contract block · **Depends on:** none (00162 done; builds its own server-spawn helper — do NOT depend on 00188 ephemeral-serve, a higher number; that PRD may later simplify the helper's internals).

Source: `dev/local/audit-results/evolution-assessment-2026-07-16.md` F5 (lens 7, commit-history mining). Maintainer decisions 2026-07-16: migrate soon, inserted early; later PRDs' scenario tasks were rewritten to target the e2e harness directly (backlog review 2026-07-16, Decision 1).

## Overview

### Problem Statement

Every smoke/integration scenario is authored twice, in two shell dialects: `tests/smoke.sh`/`smoke.ps1` and `tests/integration.sh`/`integration.ps1`. History quantifies the tax: the .sh↔.ps1 pairs co-change in 75/69 commits, 96 fix commits target the four harness files, 21 commits were pure PowerShell-dialect fixes (7 on 2026-03-18 alone: escaping, byte-array decode, `Pop-Location` hangs, `ErrorActionPreference`, ANSI stripping), and one behavior fix routinely touches all four files (`5a55296`). Every remaining backlog PRD that adds user-facing behavior pays this tax again. The cross-platform Rust e2e crate (`tests/e2e/`, assert_cmd) already runs on all three CI platforms and needs each scenario authored once.

### Target Users

Maintainer + autopilot: every subsequent PRD's scenario authoring drops from 4 files in 2 dialects to 1 Rust test. CI keeps identical coverage.

### Success Metrics

- Every scenario currently in the four shell files exists as a Rust e2e test — a section-by-section mapping table proves 100% coverage, no silent drops.
- CI (`test.yml`/`full-validation.yml`) runs the e2e suite where it ran the shell scripts, on all three platforms; a manual full-validation dispatch is green before any deletion.
- The four shell files are deleted (or each survivor is justified in the mapping table).
- AGENTS.md "Per-PRD deliverables" is rewritten: scenario authoring targets `tests/e2e/`; the 4-file mandate is removed.
- No lost semantics: must-fail assertions (`ddb-fails` pattern), server lifecycle scenarios (§54-57 SINGLETON/PgWire/warnings), and multi-process races keep their exact assertions.

## Functional Decomposition

### Capability: e2e server/process harness

#### Feature: Server-spawn helper
- **Description**: a shared helper in `tests/e2e/common.rs` that spawns `ddb serve` on a free port in a tempdir, polls `/health`, and tears down — replacing the shell scripts' server management.
- **Inputs**: the built `ddb` binary (e2e precondition), a tempdir, a free port.
- **Outputs**: a guard struct exposing base URL + token + repo path; teardown on drop.
- **Behavior**: extend the existing `ServerGuard` pattern in `tests/e2e/common.rs`; keep the helper's public API stable so 00188 (`--ephemeral`) can later replace its internals without touching call sites.

### Capability: Scenario ports

#### Feature: Smoke-section ports
- **Description**: every numbered section of `tests/smoke.sh`/`smoke.ps1` becomes a Rust e2e test.
- **Inputs**: the mapping table (Phase 0); the current smoke sections.
- **Outputs**: `tests/e2e/smoke_*.rs` tests named for their source section (`smoke_04_reserved_name_rejection` style).
- **Behavior**: port assertions verbatim in intent; must-fail cases use `assert_cmd`'s failure assertions (the `ddb-fails` equivalent); section identity preserved in test names so the mapping table stays auditable.

#### Feature: Integration-section ports
- **Description**: every numbered section of `tests/integration.sh`/`integration.ps1` becomes a Rust e2e test, server sections included.
- **Inputs**: the mapping table; the spawn helper.
- **Outputs**: `tests/e2e/integration_*.rs` tests.
- **Behavior**: server sections (§54-57 PgWire parity, SINGLETON races, warnings envelopes) port last; the psql-absent graceful degradation of §54.D keeps its semantic (skip-with-note when no client is available); timing-sensitive multi-process sections are marked serial.

### Capability: CI rewiring and retirement

#### Feature: Workflow rewiring
- **Description**: CI runs the e2e replacements where it ran the scripts.
- **Inputs**: `.github/workflows/test.yml`, `full-validation.yml`.
- **Outputs**: workflows invoking the e2e suite on all three platforms; shell-script steps removed.
- **Behavior**: keep job ordering so `cargo build -p ddb-cli` precedes e2e; run one manual `full-validation` dispatch green before deletion.

#### Feature: Shell-file deletion + docs rewrite
- **Description**: delete the four shell files and rewrite the authoring mandate.
- **Inputs**: the green CI run; the mapping table.
- **Outputs**: files deleted (or justified survivors); AGENTS.md "Per-PRD deliverables" + `docs/src/technical/` testing references updated.
- **Behavior**: deletion is the FINAL task, only after CI is green on the replacements. This is a deletion PRD: run `cargo test -p ddb-e2e` per CLAUDE.md.

## Structural Decomposition

### Repository Structure

```text
tests/
├── e2e/common.rs            # Maps to: Server-spawn helper (extend existing ServerGuard)
├── e2e/smoke_*.rs           # Maps to: Smoke-section ports
├── e2e/integration_*.rs     # Maps to: Integration-section ports
├── smoke.sh / smoke.ps1     # Maps to: deletion (Phase 2)
└── integration.sh / integration.ps1  # Maps to: deletion (Phase 2)
.github/workflows/
├── test.yml                 # Maps to: Workflow rewiring
└── full-validation.yml      # Maps to: Workflow rewiring
AGENTS.md                    # Maps to: Shell-file deletion + docs rewrite (per-PRD deliverables)
```

### Module: e2e common (tests/e2e/common.rs)
- **Maps to capability**: e2e server/process harness
- **Responsibility**: server spawn/health/teardown for all ported server scenarios; stable API for the 00188 swap.
- **Exports**: the spawn-helper guard (extends `ServerGuard`).

### Module: smoke/integration ports (tests/e2e/smoke_*.rs, integration_*.rs)
- **Maps to capability**: Scenario ports
- **Responsibility**: one Rust test per shell section, names carrying section identity.
- **Exports**: the test functions (no library surface).

### Module: workflows (.github/workflows/)
- **Maps to capability**: CI rewiring and retirement
- **Responsibility**: run the e2e suite where the scripts ran; keep platform matrix coverage.
- **Exports**: n/a (CI configuration).

## Dependency Graph

### Foundation Layer (Phase 0)
No dependencies - built first.
- **mapping table**: section-by-section inventory; the coverage proof artifact.

### Core Layer (Phase 1)
- **spawn helper**: depends on [mapping table] (identifies which sections need a server).
- **smoke ports**: depends on [mapping table].
- **integration ports**: depends on [spawn helper].

### Integration Layer (Phase 2)
- **CI rewiring**: depends on [smoke ports, integration ports].
- **deletion + docs**: depends on [CI rewiring] (green run first).

## Implementation Phases

### Phase 0: Foundation
**Goal**: the coverage proof exists before any port.

**Tasks**:
- [ ] Build the mapping table: every numbered section in the four files → target e2e test name (or justified survivor), including which sections need a server and which are must-fail assertions. Known quirks to encode (verified at `d77ad58`): section numbering is sparse AND duplicated (both integration files carry two `# 50.` sections — key rows by file:line, not number alone); the `ddb-fails` must-fail helper exists only in PowerShell (`integration.ps1:67` — bash uses bare `!` negation); `tests/smoke.ps1` is invoked by NO workflow, so its port costs zero CI coverage (no deps) - Acceptance: the table is complete with zero unmapped sections (duplicate-numbered sections disambiguated by file:line); it lives in the PRD workdir notes and is referenced by later acceptance checks.

**Exit Criteria**: 100% of shell sections have a mapped target.

### Phase 1: Core
**Goal**: every scenario exists in Rust.

**Tasks**:
- [ ] Extend `tests/e2e/common.rs` with the server-spawn helper (free port, tempdir, health poll, teardown; stable API) (depends on: Phase 0) - Acceptance: one round-trip test spawns, queries `/health`, and tears down cleanly.
- [ ] Port all smoke sections to `tests/e2e/smoke_*.rs` per the mapping table (depends on: Phase 0) - Acceptance: each ported test green locally; must-fail assertions preserved via assert_cmd failure checks.
- [ ] Port all integration sections to `tests/e2e/integration_*.rs`, server sections (§54-57) and multi-process races last, marked serial; keep §54.D's psql-absent graceful skip semantic (depends on: spawn helper) - Acceptance: each ported test green locally; the mapping table marks every section DONE.

**Exit Criteria**: mapping table shows 100% ported; `cargo test -p ddb-e2e` green locally.

### Phase 2: Integration
**Goal**: CI proves parity; the shell files retire.

**Tasks**:
- [ ] Rewire `test.yml` + `full-validation.yml` to run the e2e replacements on all three platforms; dispatch a manual full-validation run (depends on: Phase 1) - Acceptance: all platforms green on the e2e replacements with the shell steps removed.
- [ ] Delete the four shell files (per the mapping table; each survivor justified); rewrite AGENTS.md "Per-PRD deliverables" (scenario authoring targets `tests/e2e/`) and the `docs/src/technical/` testing references; run `cargo test -p ddb-e2e` (deletion PRD per CLAUDE.md) (depends on: CI rewiring) - Acceptance: `rg -l "smoke.sh"` finds only historical docs; CI green after deletion; AGENTS.md carries the new mandate.

**Exit Criteria**: shell files gone, CI green, AGENTS.md updated.

## Test Strategy

### Critical Scenarios
- **Happy path**: a ported smoke section (create/query round trip) → Expected: identical assertion outcome to the shell original.
- **Edge case**: a must-fail section (reserved-name rejection) → Expected: assert_cmd failure assertion fires exactly where `ddb-fails` did.
- **Error case**: a timing-sensitive multi-process race section under the cargo test runner → Expected: serial-marked test stays deterministic; no parallelism-induced flake.

## Risks

- **Timing-sensitive multi-process scenarios** (§55 races) may behave differently under cargo's parallel test runner. Mitigation: serial markers / the e2e crate's existing single-thread patterns; port these last.
- **Windows-specific behaviors currently only exercised via PowerShell** (path handling) must be asserted in Rust, not lost. Mitigation: the mapping table calls each out explicitly; CI's windows leg is the oracle.
- **e2e requires the built binary** (`cargo build -p ddb-cli` first). Mitigation: already the documented e2e precondition; CI job ordering respects it.

## Transport Impact

No product surface changes on any of the six transports (CLI, GraphQL, REST, PgWire, FFI, NoSQL HTTP). CI coverage parity is the contract: the mapping table proves CLI/GraphQL/REST/PgWire/NoSQL scenarios survive the port; FFI is untouched (its CI guard is 00194). Cross-interface conformance plan: the mapping table + the green manual full-validation dispatch before deletion are the conformance evidence; no new behavior surface exists to conform.

## Design Doc

# Design: Migrate smoke/integration shell scenarios to the Rust e2e crate

PRD: `dev/local/prds/wip/00171-migrate-shell-scenarios-to-e2e-v1.md`

## Architecture fit

This is test-harness infrastructure, not product code — it touches only the
`tests/` crate (`ddb-e2e`, workspace member `tests/`, single test binary
`tests/e2e/main.rs`) and CI workflow YAML. No `ddb-core`/`ddb-cli`/`ddb-server`
production code changes. The e2e crate already exercises all six transports
(CLI via `assert_cmd`, GraphQL, REST, PgWire via `tokio_postgres`, WebSocket via
`tungstenite`, FFI is out of scope here) through the `ServerGuard`/`DdbTestRepo`
harness in `tests/e2e/common.rs` — this PRD extends that harness's *coverage*,
not its *shape*.

## Module placement

New files only; no existing production or e2e file is restructured.

- `tests/e2e/smoke_*.rs` — one file per `tests/smoke.sh` numbered section (or a
  small cluster of adjacent, related sections), test functions named
  `smoke_NN_slug` (e.g. `smoke_04_reserved_name_rejection`).
- `tests/e2e/integration_*.rs` — same pattern for `tests/integration.sh`,
  functions named `integration_NN_slug`; server-lifecycle sections (§54-57)
  land in `tests/e2e/integration_server_*.rs`.
- `tests/e2e/main.rs` — gains one `mod smoke_*;` / `mod integration_*;` line per
  new file, inserted alphabetically into the existing list (line 1-56 today).
- `.github/workflows/test.yml`, `.github/workflows/full-validation.yml` — edited
  in place (exact diffs below).
- `dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md` — NEW,
  the coverage-proof mapping table (Phase 0 deliverable; durable PRD satellite,
  not deleted until the PRD itself moves to `done/`).
- `AGENTS.md` — "Per-PRD deliverables" bullet rewritten (final task). That
  bullet's trailing sentence about `dev/local/specs/jink-feedback/ddb-repros/`
  is unrelated to the 4-file mandate and must carry into the rewritten text
  unchanged.
- **Every other doc referencing the four shell files** — the PRD's own Phase 2
  acceptance check (`rg -l "smoke.sh"` finds only historical docs) fails
  unless these are also updated in the same task: `CONTRIBUTING.md:42-43`
  (duplicates the exact 4-file mandate AGENTS.md is dropping — rewrite
  identically), `README.md:101-102` (quickstart commands that 404 post-
  deletion — replace with the `cargo test -p ddb-e2e` equivalent),
  `docs/src/technical/walkthrough.md:38,430` (describes the four files as
  "additional test surfaces" — rewrite to describe the e2e crate instead),
  `docs/src/technical/sql-engine.md:622,634` (cites specific shell sections
  for the SQL-engine bug-cluster table — repoint at the mapping table's
  target e2e test names for those rows).
- `tests/smoke.sh`, `tests/smoke.ps1`, `tests/integration.sh`,
  `tests/integration.ps1` — deleted (final task, after CI proves green on the
  replacements).

`tests/e2e/common.rs` is **not modified** unless a ported scenario needs a
capability it genuinely lacks (see Reuse inventory — it already covers spawn,
port allocation, tempdir, multi-node, and every transport client this PRD
needs).

## Interfaces & contracts

**Test naming.** `smoke_NN_slug` / `integration_NN_slug`, `NN` zero-padded to
match the source section number (`04`, not `4`). Two shell files each carry a
duplicate `# 50.` section header (`integration.sh:2159` PRD 00132 rename-across-
protocols, and `integration.sh:3697` PRD 00136 FK-freshness — same duplication
mirrored in `integration.ps1`); the mapping table keys these by `file:line`,
and the Rust side disambiguates by giving each a distinct slug
(`integration_50_alter_table_rename`, `integration_50_cross_process_fk_freshness`)
— never two functions named `integration_50`.

**Must-fail assertions.** The shell `ddb-fails` helper (PowerShell-only,
`integration.ps1:67`; bash negates with bare `!`) maps directly to the existing
`assert_cmd` idiom already used throughout the crate:

```rust
repo.ddb()
    .args(["update", "99999999999999", "--title", "Whatever"])
    .assert()
    .failure()
    .stderr(predicate::str::contains("error:"));
```

(`predicates` is already a `tests/Cargo.toml` dependency; see
`tests/e2e/cli_update_app_error.rs` for the existing pattern this PRD reuses
verbatim, not reinvents.)

**Server-spawn helper.** `ServerGuard::start(&DdbTestRepo)` (already implemented,
`tests/e2e/common.rs:55`) is the contract every server-backed port uses. Its
public API (`start`, `.url()`, `.rest_*`, `.graphql*`, `.ws_*`, `.kill`, `Drop`)
is unchanged by this PRD — no new methods are required for any currently-known
shell scenario (see Reuse inventory). If a specific integration-section port
surfaces a genuine gap during Phase 1, add the method to `ServerGuard` directly
(same file, same struct) rather than a parallel helper.

**Concurrency / "serial" sections.** No `serial_test` crate, no
`--test-threads=1`. Every test gets its own port
(`next_available_port()`'s process-wide `AtomicU16` counter, `common.rs:34`)
and its own `TempDir`-backed repo, so cargo's default parallel test runner is
already safe — this is the existing pattern, not a new one (see
`tests/e2e/singleton_cross_process_upsert.rs` for a live two-server race test
that runs under ordinary `cargo test` parallelism today). Timing-sensitive
*within-test* ordering (two CLI/GraphQL calls that must interleave a specific
way) is expressed with `std::thread::scope` + explicit joins, not a serial
marker — same file, same pattern as the existing race test cited above.

**PgWire sections — psql dependency dropped, not preserved.** The shell scripts'
§54.D/55.D "psql-absent" skip (`integration.sh:2355-2358`,
`integration.sh:2513`) exists only because the shell scripts shell out to the
external `psql` binary and some CI runners (macOS) don't have it. The shell
scripts' own pass messages already point at the replacement:
`"54.D: PgWire parity covered by cargo test -p ddb-e2e --test e2e -- pgwire_singleton (no psql on host)"`.
The Rust e2e crate already ports PgWire scenarios through `tokio_postgres`
(pure-Rust client, already a `tests/Cargo.toml` dependency — see
`tests/e2e/pgwire_singleton.rs`, `tests/e2e/pgwire.rs`), never shelling out to
`psql`. **The port therefore drops the skip entirely**: §54.D/55.D's PgWire
assertions run unconditionally on every platform via `tokio_postgres`, which
exceeds the shell semantic (always-run beats conditional-skip) rather than
merely preserving it. Do not add a `command -v psql` equivalent check in Rust —
there is nothing to check for.

**CI rewiring — exact diffs.**

`test.yml` (fast per-push gate): replace the shell smoke step —

```diff
-      - name: Smoke test
-        env:
-          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
-        run: ./tests/smoke.sh
+      - name: Smoke test (e2e)
+        env:
+          DDB_BIN: ${{ github.workspace }}/target/debug/ddb
+        run: cargo test -p ddb-e2e --test e2e smoke_
```

(cargo test's substring filter on the harness matches every `smoke_*` function;
job ordering is unchanged — this step already runs after "Build CLI binary".)
The five hand-picked `E2E - *` steps and `Sync integration tests` step in
`test.yml` are untouched — they are an independent fast-gate sampling, not this
PRD's concern.

`full-validation.yml`: the `linux-smoke` job's only content is
`./tests/integration.sh`; once ported, that content is a strict subset of what
`linux-e2e`'s unfiltered `cargo test -p ddb-e2e` already runs on the same
platform. **Delete the `linux-smoke` job** (not just its shell step) and remove
it from `mark-validated`'s `needs:` list. `macos-full` and `windows-full` each
run `cargo test-full` (= `cargo test --workspace`, which includes the `tests`
workspace member unfiltered — see `Cargo.toml`/`​.cargo/config.toml`) followed
by a separate `./tests/integration.sh` / `integration.ps1` step; once ported,
that separate step is redundant with the `cargo test-full` step directly above
it on the same job. **Delete the `Integration test` step from `macos-full` and
`windows-full`** (keep every other step, including `Full cargo test suite`,
which now carries the ported coverage). This is a net simplification (3 fewer
CI steps, no coverage lost — `cargo test-full`/`linux-e2e` already run
unfiltered) and satisfies the PRD's Phase 2 acceptance ("all platforms green on
the e2e replacements with the shell steps removed") without inventing new job
structure.

**Mapping table.** `dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md`,
one row per shell section: `file:line | section # | target e2e test (or
"ALREADY COVERED by <existing test>" or "justified survivor: <reason>") |
needs server? | must-fail? | status`. Built in Phase 0 before any port task
starts; updated to DONE per section as Phase 1 tasks land (PRD's own Exit
Criteria requires it show 100% ported before Phase 2).

## Data flow

Unchanged from the existing e2e crate: a test calls `DdbTestRepo::init()`
(spawns `ddb init` in a fresh `TempDir`, disables git commit signing so CI
doesn't need a signing key), optionally `ServerGuard::start(&repo)` (spawns
`ddb serve`, blocks on stderr readiness lines for HTTP+PgWire listeners,
returns a guard exposing base URL/PG port/auth token), then drives the CLI via
`assert_cmd::Command` and/or the server via GraphQL/REST/WS/PgWire clients, and
asserts. `Drop` kills the child process; the `TempDir` cleans up on scope exit.
No new data-flow shape — this PRD is pure coverage porting through the existing
pipes.

## Reuse inventory

- **`ServerGuard`** (`tests/e2e/common.rs:48-334`) — full server lifecycle:
  spawn, free-port allocation (`next_available_port`, an `AtomicU16` counter
  that skips already-bound ports), stderr-based readiness detection for both
  HTTP and PgWire listeners, auth-token capture, GraphQL/REST/WebSocket client
  methods, `kill()`, `Drop`. Covers 100% of the PRD's "Server-spawn helper"
  ask already — used in 30+ existing e2e files (`rg -n "ServerGuard::start"
  tests/e2e/` — 100+ call sites). No extension needed for any scenario
  identified so far.
- **`DdbTestRepo`** (`common.rs:361-401`) — tempdir-backed repo init +
  `ddb()`/`ddb_at()` command builders, git-signing disabled for CI. Direct
  replacement for the shell scripts' per-scenario `mktemp -d` + `ddb init`.
- **`MultiNodeSetup` / `TwoNodeSetup`** (`common.rs:404-594`) — bare-remote +
  N-node clone/register/push/sync helpers, already used for multi-device sync
  scenarios. Covers the PRD's cross-process sections that need >1 clone, not
  just >1 server.
- **`assert_cmd::Command` + `predicates`** — the CLI-invocation and must-fail
  idiom (`.assert().success()/.failure()`, `predicate::str::contains`) used
  everywhere in the crate; direct replacement for shell's `ddb ... || fail` /
  `ddb-fails` patterns. Greps tried: `assert_cmd`, `predicates`, `ddb-fails`,
  `\.failure\(\)` — all confirm the pattern is established, nothing new to
  write.
- **`tokio_postgres`** (`tests/Cargo.toml:22`, used in `pgwire.rs`,
  `pgwire_singleton.rs`) — replaces every shell `psql` invocation; see
  Interfaces & contracts above.
- **Existing PgWire e2e coverage may already satisfy several shell sections
  outright.** `integration.sh` sections 54.D and 55.D literally name
  `pgwire_singleton` as their own replacement in their pass messages
  (`integration.sh:2358`, `:2513`) — the mapping table (Phase 0) must check
  each server-lifecycle section against `tests/e2e/pgwire*.rs`,
  `serve.rs`, `server_mutations.rs`, `subscriptions.rs`, and
  `singleton_cross_process_*.rs` for an existing equivalent before writing a
  new test, to avoid duplicate coverage of the same assertion.
- Nothing found for: a distinct "spawn helper" beyond `ServerGuard`
  (greps: `ServerGuard`, `serve.*spawn`, `health.*poll` — all resolve to the
  existing struct); a `serial_test`-style crate (greps: `serial_test`,
  `#\[serial\]`, `test-threads` — zero hits in `tests/`, `Cargo.toml`,
  workflows — confirms no such dependency exists or is needed, per the
  Concurrency contract above).

## Alternatives considered

1. **Smallest-diff: port only the sections currently reachable from CI** (the
   ~10 sections `test.yml` names explicitly, plus whatever `linux-smoke`/
   `macos-full`/`windows-full` exercise) and leave the rest of the shell files
   in place as a "just in case" archive. Rejected: fails the PRD's own Success
   Metric ("every scenario... exists as a Rust e2e test — no silent drops")
   and leaves the dual-dialect authoring tax exactly as expensive for every
   future PRD, which is the whole point being fixed.
2. **Rewrite the shell scripts as a single shared dialect** (e.g. drop
   PowerShell, keep only bash, run bash-on-Windows via WSL/git-bash in CI).
   Rejected: still a shell-based harness with the same fragility class
   (21 commits of pure PowerShell-dialect fixes were about *shell* fragility,
   not multi-dialect-ness specifically — bash-only still needs its own
   Windows-compatibility workarounds) and does not gain the compile-time
   type-checking, IDE support, and single-authoring-surface `cargo test`
   already gives the existing 100+ e2e tests.
3. **Chosen: full 1:1 port to the existing Rust e2e crate**, reusing
   `ServerGuard`/`DdbTestRepo` as-is (no new abstraction layer), one Rust test
   per shell section, mapping table as the coverage proof, CI rewired to run
   the replacements, shell files deleted last. The extra size over option 1
   buys exactly what the PRD asks for: zero authoring tax for every
   remaining backlog PRD (00172+), which the growth-roadmap memory frames as
   the reason this PRD was inserted ahead of the contract block.

## Risks & edge cases

- **Duplicate `# 50.` section numbers** in both `integration.sh` and
  `integration.ps1` (verified: `integration.sh:2159` and `:3697`, mirrored in
  `.ps1` at `:2026`/`:3654`) — mapping table keys by `file:line`; Rust test
  names disambiguate with distinct slugs (see Interfaces & contracts).
- **`tests/smoke.ps1` has zero CI coverage today** (absent from both
  `test.yml` and `full-validation.yml` — confirmed by grep). Its sections still
  need porting per the PRD's 100%-coverage metric, but the port costs zero
  *additional* CI risk since nothing currently depends on it running.
- **A ported section might duplicate an already-existing e2e test** (see
  Reuse inventory's PgWire finding) — the mapping table must record
  "ALREADY COVERED" rather than write a redundant test; a redundant test
  is not wrong, just wasted authoring effort the PRD is trying to eliminate.
- **Windows-specific path/escaping behavior** currently exercised only via
  PowerShell must still be asserted somewhere in Rust once the `.ps1` files
  are gone. Rust's `std::path::Path` already handles platform separators
  correctly, so most of these sections likely need no special porting beyond
  running on `windows-full`'s existing runner — but any assertion that
  specifically tests *string* path formatting (not just behavior) needs a
  `cfg!(windows)` branch in the ported test, called out explicitly in the
  mapping table per PRD's own Risk note.
- **Next likely follow-ups after this PRD** (do not build now, but this design
  should not box them in): (a) PRD 00188 `ephemeral-serve-test-mode-v1` may
  want to swap `ServerGuard`'s child-process spawn for an in-process embedded
  server — the public API this PRD locks in (`start`/`url`/`graphql`/etc.) is
  exactly what 00188 needs to stay stable across that swap, per the PRD's own
  note; (b) a future PRD may want to run a curated e2e subset per-package
  rather than the whole crate for faster fast-gate feedback — the
  `smoke_`/`integration_` naming convention this design pins is what makes
  substring-filtered `cargo test` invocations like the one added to `test.yml`
  possible without a third mechanism (tags, feature flags, etc.).

## Test strategy outline

This PRD *is* the test suite — there is no separate "tests for the tests"
layer beyond what the PRD's own Success Metrics already specify: the mapping
table is the coverage-completeness proof (100% of shell sections mapped, zero
unmapped rows), each ported test is verified green locally before being marked
DONE in the table, and a green manual `full-validation` dispatch on all three
platforms is the CI-parity proof gate before the shell files are deleted. No
new test-of-tests infrastructure is introduced.

## Review log

**Dispatch 1 (Claude) non-blockers/questions (not fixed):**
- Non-blocking: `windows-full`'s deleted "Integration test" step carried a `timeout-minutes: 15` hang guard (relevant given the PRD's own history of PowerShell `Pop-Location` hangs); the consolidated "Full cargo test suite" step has no equivalent per-step timeout. Consider adding one, or note why the risk is now negligible (no PowerShell process involved).
- Non-blocking: Reuse inventory's "used in 30+ existing e2e files" is imprecise — verified actual count is 21 files (151 call sites, matching the separately-stated "100+ call sites" claim). Doesn't affect the design's conclusion.
- Question: this design supersedes the PRD's own named mitigation for §55 races ("serial markers", PRD line 148) with port/tempdir isolation instead. Well-justified by existing precedent, but the mapping table / Phase 1 task text should say explicitly that this supersedes the PRD's suggestion, so a task planner doesn't add an unneeded `serial_test` dependency.

dispatch 1 (claude): cardinal-sin 0, blocker 1, non-blocker 2, question 1

## Scope and runtime evidence
The range includes interleaved unrelated 00202 commits. Review all 00171 work; do not demand unrelated product fixes. The original full-review gather script chose master and yielded an empty diff; this input was corrected to the preserved work_start_sha..HEAD before dispatch.

## Architecture instructions
# Doogat DB

Hybrid Git-CRDT decentralized database. Git is source of truth; SQLite index is derived/rebuildable.

## Stack

- Rust 2021 edition, workspace with three crates
- Git storage via `git2`, CRDT via `automerge`
- SQLite index via `rusqlite` (FTS5), SQL parsing via `sqlparser`
- CLI via `clap` (binary: `ddb`)
- GraphQL server via `axum` + `async-graphql` (dynamic schema)
- FFI via `uniffi` (proc-macro approach, generates Swift/Kotlin bindings)

## Structure

```text
ddb-core/src/        Library crate: parser/ (three-zone Markdown), git_ops/ (repo CRUD, merge,
                     remote, rename), indexer/ (SQLite FTS5, ports), service/ (DoogatService,
                     per-verb submodules), sql_engine/, sync_manager/, compaction/, consistency/,
                     crdt_resolver.rs, hlc.rs, traits.rs (core trait abstractions),
                     ffi/ (UniFFI DoogatDriver facade), types/ (adapter-neutral shared types)
ddb-core/benches/    Criterion benchmarks (CRUD + search at 1K doogats)
ddb-uniffi-bindgen/  UniFFI bindgen binary (isolated from ddb-core)
ddb-cli/src/         Binary crate: main.rs dispatch + commands/ subcommand handlers
ddb-server/src/      GraphQL server: lib.rs entrypoint, actor/ core bridge, schema/ dynamic
                     GraphQL (queries, mutations/, subscriptions), auth.rs, config.rs, error.rs
tests/               e2e/ (Rust smoke_, integration_, and other assert_cmd scenarios), fixtures/
dev/bin/             Developer scripts (release, build-xcframework, build-android,
                     safe-showboat-verify + its regression test)
docs/src/            mdbook documentation (architecture, technical, guide)
```

Per-file responsibilities: `docs/src/architecture/modules.md` (Module Summary table).

## Design Principles

Follow SOLID and Clean Architecture principles as adapted for Rust. These are mandatory for all code changes:

- `technical/solid.md` - SOLID principles translated to Rust idioms (traits over inheritance, small focused traits, dependency inversion via generics)
- `technical/clean-architecture.md` - Layer boundaries, dependency direction, I/O at the edges, no panics in library code

## Architecture Guardrails

- Keep domain/shared types adapter-neutral: no `rusqlite`, `git2`, `redb`, `axum`, or `async_graphql` in `ddb-core/src/types/**`; convert at adapter boundaries.
- Do not add concrete adapter construction inside `DoogatService` service modules; inject dependencies or document a temporary exception.
- User-facing read/write/list paths must not silently drop rows, schemas, or parse failures; return errors or structured warnings.
- No runtime panics in library/FFI code for mutex, database, filesystem, repository, or user-input state.
- **Product positioning (do not re-litigate): ddb is a standalone platform for many future downstream apps; jink is the first, not the product. The six transports and 120% parity are deliberate bets to keep ddb flexible and complete so downstreams don't reinvent. See `docs/src/architecture/design-decisions.md` → "Product Positioning". Treating "one consumer, one transport" as over-engineering is a misread — assess within this positioning, not against it.**
- 120% parity is the product posture: public product capabilities ship across every public application interface. If a capability cannot be applied coherently everywhere, prefer deferring/dropping it or making the interface non-public/specialized for that workflow over shipping drift.
- CRUD is the minimum `Guaranteed` baseline for every public application interface; exceptions require an explicit maintainer decision that the interface is specialized or not public for that workflow.
- Every feature PRD needs Transport Impact coverage for CLI, GraphQL, REST, PgWire, FFI, and NoSQL HTTP plus a cross-interface implementation/conformance plan.
- Do not call interfaces equivalent unless the same downstream workflow passes conformance tests on each. Undocumented client scaffolding means the interface contract is incomplete.
- For cross-interface architecture work, define the downstream workflow contract before refactoring internals that serve those interfaces.
- New cross-interface behavior belongs in the app contract first; transports should adapt commands/results, not own business policy.
- Public response/error/warning shape changes need compatibility/deprecation review and updated developer guidance.
- A `Guaranteed` capability needs a golden workflow and conformance plan before implementation is considered complete.
- Contract changes must cover support diagnostics, auth/setup expectations, timeout/performance expectations, and release/migration impact when relevant.

### Data-safety invariants (P0 — violating these risks SILENT data loss)

Full rationale, evidence, and current-gap tracking in `docs/src/technical/invariants.md`. These are non-negotiable; a change that breaks one is wrong even if tests pass.

- **Every git write holds the repo write lock — merges, sync, and bundle import included.** All commit/delete/rename/merge/checkout-moving paths must run inside the repo-scoped advisory write lock and build trees from fresh state. Never use the cached `repo.index()` for a write; never add a new write path that skips the lock. (Lock shipped for the 8 CRUD paths: 00162, done. Delete-path `fresh_index()` and the merge/sync lock + fresh merge staging shipped 2026-07-16 as 00163. Bundle import's merge leg now runs through the same write-locked merge engine (`merge_remote` + `apply_merge_result` + the new write-locked `delete_remote_ref`): 00168, done. Its unbundle/fetch object-preparation leg (`unbundle_git_objects`) still runs unlocked before the merge — known gap, does not move `HEAD` or the working tree.)
- **Merges preserve BOTH sides' changes — deletions included.** The conflicted-merge tree must be a true three-way merge classified against the merge base. A two-way ours→theirs diff cannot express this: today it resurrects theirs' deletions AND silently reverts ours' non-conflicting edits, and the naive fix (staging `Delta::Deleted` gated by the conflict set) deletes ours-created files — proven empirically 2026-07-16 (`dev/local/designs/00200-make-merge-tree-three-way-v1-evidence.md`). Never patch individual delta arms; classify against the merge base. (Tracked: 00200 make-merge-tree-three-way, runs immediately after 00163.)
- **IDs are minted through one repo-aware path.** No mint path may use `exists = |_| false` or allocate future-dated timestamps. All minting checks actual repo/index existence. The ~1/sec/process ceiling is a known, tracked limitation (00170) — do not "fix" it ad hoc. (Tracked: 00164 unify-id-minting, 00170 id-throughput-ceiling-decision.)
- **Conflict resolution is a pure function of its inputs.** Set stable Automerge actor IDs (derived from blob OIDs / node UUIDs); never rely on default random actor IDs. If a decision claims HLC ordering, the feeding commits must carry an HLC trailer. (Tracked: 00165 deterministic-crdt-resolution, 00166 make-hlc-load-bearing.)
- **One bad file never fails the batch.** Read/list/index paths degrade per-item into structured warnings (as the full rebuild already does); only an explicit `--strict` mode hard-fails. (Tracked: 00169 poison-file-reindex-resilience.)

### Coherence invariants

- **One error policy.** Exactly one table maps a code → (category, HTTP status, redaction, FFI variant). Adding an error code means editing that ONE table; transports derive from it and never re-decide redaction or status. No per-transport error switch. (Tracked: 00173 unify-server-error-mapping-paths; FFI/PgWire legs 00177/00180.)
- **App-contract-first, FFI included.** Every verb flows through `AppCommand → DoogatService → AppOutput`. FFI is a transport, not exempt — it uses the contract, not raw service methods. Do not add per-verb actor command/reply enum plumbing; it is being replaced by a closure message (00172). (Tracked: 00172 collapse-actor-plumbing; route verbs + structured fields 00175-00178.)
- **A result type has one core definition.** Transports serialize the core type; they must not redefine field subsets. Any new public result field lands in the core type first. (Tracked: 00176 route-search-through-contract.)
- **Every interpolated SQL identifier is escaped; every value is a bound parameter.** Never `format!` a user-influenced string (type name, column, id) into SQL text without an identifier-quoting helper (`escape_sql_ident` in `indexer/filter.rs` / `quote_ident` in `schema_diff/plan.rs`). Validate type/field-key charset at the write boundary. (Tracked: 00179 sql-identifier-escaping.)

## Setup

```text
git config core.hooksPath dev/hooks
```

## Conventions

- All modules return `error::Result<T>`
- DoogatId: 14-digit timestamp string (YYYYMMDDHHmmss)
- Doogats stored at `ddb/{id}.md`, typedefs at `ddb/_typedef/{id}.md`
- Data dir: `.ddb/`, node file: `.git/ddb-node`, git signature: `ddb`
- Plan documents go in `dev/local/plans/` (gitignored), NOT in `docs/`
- Product Requirement Documents (PRDs) go in `dev/local/prds/` (gitignored), NOT in `docs/`
- Git worktrees go in `dev/local/worktrees/` (gitignored), nowhere else
- Releases: use `dev/bin/release` only. Never `gh release create` manually - CI creates the GitHub release with binary artifacts on tag push
- Never close GitHub issues (`gh issue close`) — the maintainer closes them; report open issues as observations instead
- Push `master` at the end of each PRD (after the PRD's commits land). This overrides the global autopilot "don't push" default and applies to this repository only — nightly CI (`full-validation.yml`) needs the new commits on `origin/master` to exercise the heavy Tier 2 battery against the latest work.

## Definition of Done

Validation is two-tiered: a fast per-task gate runs locally; the heavy battery is delegated to CI. Test/scenario authoring stays a per-PRD deliverable — only local *execution* of the heavy battery is dropped.

### Tier 1 — per-task local gate (runs after every task)

A task is NOT complete unless ALL of these pass locally:

1. **Build** — `cargo build` succeeds.
2. **Lint** — `cargo clippy --workspace --all-targets` is clean. (`--all-targets` is required: CI lints test targets too; without it, test-code lints slip through Tier 1 and break Nightly — happened 2026-07.)
3. **Fast tests** — `cargo test-ci` passes.
4. **TDD unit tests** — unit tests for the change live alongside the module being touched and pass under `cargo test-ci`.

Do NOT run `cargo test --workspace`, the e2e suite, property tests, cross-platform jobs, coverage, or `showboat verify` per task. Those belong to Tier 2.

One narrow exception: `CLAUDE.md` instructs Claude-routed sessions to run `cargo test -p ddb-e2e` after any task that deletes or replaces existing code paths (skipped for purely additive tasks). That conditional, scope-limited e2e run is intentional — it is a deletion safety net, not a relaxation of Tier 1. See `CLAUDE.md` for the exact wording.

### Tier 2 — delegated to CI (runs automatically, not per task)

The heavy battery is owned by the GitHub Actions workflows:

- `test.yml` runs on every push: Linux Clippy, CLI build, `cargo test-ci`, Rust `smoke_` e2e scenarios, core sync integration tests, five targeted e2e cases, and a separate coverage job.
- `full-validation.yml` runs nightly: full `cargo test --workspace`, the Rust e2e smoke and integration scenarios, property tests, cross-platform validation, and coverage.

Do not duplicate these locally. If a CI failure is reproducible only locally, run the specific failing command in isolation rather than the full battery.

### Per-PRD deliverables (created once per PRD, not per task)

These are authoring obligations, not local execution gates:

- **Smoke/integration scenario authoring** — if the PRD adds a CLI command or user-facing behavior, add a `smoke_` scenario under `tests/e2e/`. If it adds a server endpoint, sync behavior, CRDT logic, or a multi-step workflow, add an `integration_` scenario there. Register new modules in `tests/e2e/main.rs`. Execution of these Rust e2e scenarios is delegated to CI (Tier 2). Upstream jink-feedback repros for the SQL regression suite live at `dev/local/specs/jink-feedback/ddb-repros/` (gitignored and machine-local — absent on fresh checkouts; skip this channel when the directory is missing); if present, run `bash dev/local/specs/jink-feedback/ddb-repros/run-all.sh` for an independent verification channel when investigating.
- **E2E test authoring** — new user-facing behavior still requires its e2e test written under `tests/e2e/`. The test is authored as part of the PRD; execution happens in CI.
- **Docs** — update relevant files in `docs/src/` to reflect any behavioral or API changes.
- **Walkthrough** — if the PRD adds a CLI command, server endpoint, or user-facing behavior, create an executable showboat walkthrough in `dev/local/walkthroughs/` (see Showboat Walkthroughs below).
- **Architecture doc** — if the PRD changes module boundaries, data flow, or key types, update `docs/src/technical/walkthrough.md`.
- **Push `master`** — after the PRD's commits land, push `master` so nightly Tier 2 CI exercises the new work. This overrides the global autopilot "don't push" default for this repo only (see Conventions above for the full rule).

## Showboat Walkthroughs

Executable feature demos (proof of work) at `dev/local/walkthroughs/{5-digit}-{slug}.md`, built with [showboat](https://github.com/simonw/showboat). Full guide (CLI reference, execution model, CLI/server patterns, regeneration, wrapper regression test): `agent_docs/showboat-walkthroughs.md`. Two safety rules always apply:

- Never edit walkthrough files directly (no `Edit`, `Write`, `sed`) — all content flows through the showboat CLI (`init`/`note`/`exec`/`pop`/`extract`).
- Never run `showboat verify` from the project root — it re-executes blocks in the caller's cwd and writes real commits to master. Use `dev/bin/safe-showboat-verify <walkthrough>`.

## Gotchas

- Never run `ddb` commands (init, create, SQL, etc.) in the project root. Use `/tmp` or a temp directory. Running in-repo creates `ddb/`, `.ddb/`, `.crdt/`, `.nodes/` artifacts that pollute the source tree and git history
- E2E tests require the `ddb` binary — run `cargo build -p ddb-cli` before `cargo test -p ddb-e2e`
- `head_oid()` returns `CommitHash` (a String newtype, access inner via `.0`), not `git2::Oid`
- Run cargo commands in the foreground only — backgrounded cargo builds/tests contend on the build lock, queue up, and can deadlock the whole session
- `merge_frontmatter` is called from both `resolve_conflicts` and `resolve_append_log`

## Commands

```text
cargo build                           Build default workspace members (fast local loop)
cargo build --workspace               Build all crates
cargo test                            Run cargo's default workspace test selection
cargo test-ci                         Run the fast local test tier (bounded CI matrix; unit/bin targets only)
cargo test-full                       Run full cargo test suite (Tier 2; delegate to CI, not per-task)
cargo test -p ddb-e2e                 Run e2e tests only
cargo bench                           Run criterion benchmarks (CRUD + search)
cargo bench --no-run                  Compile benchmarks without running
cargo build -p ddb-core --features profiling   Build with tracing instrumentation
cargo test -p ddb-e2e smoke_          CLI smoke scenarios (Tier 2)
cargo test -p ddb-e2e integration_    Integration scenarios (Tier 2)
cargo test -p ddb-core --test property_tests   Property-based integration tests
cargo test -p ddb-core --test sync_test        Core sync integration tests
cargo clippy --workspace --all-targets   Lint (incl. test targets; matches CI)
cargo doc --no-deps --document-private-items   Generate rustdoc
cd docs && mdbook build               Build documentation
cd docs && mdbook serve               Serve documentation locally
cargo llvm-cov --workspace            Coverage report (CI gate: 70% lines; needs llvm-tools-preview + cargo-llvm-cov)
```

Performance-threshold tests (nfr01-03): `docs/src/technical/performance.md`. UniFFI binding generation: `docs/src/technical/ffi.md`.

## Documentation

Read from `docs/src/` before working on related modules:

- `architecture/overview.md` - System design and data flow
- `architecture/modules.md` - Module responsibilities and boundaries
- `architecture/design-decisions.md` - Key architectural choices and non-goals. **Check before proposing new features or PRDs** - if a proposal conflicts with a decision or non-goal, the decision must be revisited first
- `technical/data-model.md` - Doogat format, frontmatter schema
- `technical/parser.md` - Three-zone Markdown parsing details
- `technical/git-ops.md` - Git storage layer
- `technical/crdt-resolver.md` - Conflict resolution strategy
- `technical/indexer.md` - SQLite index, FTS5, type inference
- `technical/sql-engine.md` - SQL translation layer
- `technical/sync.md` - Multi-device sync protocol
- `technical/server.md` - GraphQL server architecture and API
- `technical/ffi.md` - UniFFI bindings (DoogatDriver facade)
- `technical/errors.md` - Error handling patterns
- `technical/solid.md` - SOLID principles in Rust
- `technical/clean-architecture.md` - Clean Architecture in Rust

## docs/src/technical/solid.md
# SOLID Principles in Rust

SOLID originated in OOP, but the principles translate well to Rust — often enforced more strictly by the compiler than by convention.

## Single Responsibility (S)

Each module owns one concern. The natural unit in Rust is the module and its public API, not a class.

Doogat DB modules follow this: `parser/` parses, `git_ops/` handles git, `indexer/` handles SQLite. Each module exposes a focused public API and hides implementation details.

## Open/Closed (O)

In OOP: extend via inheritance without modifying. In Rust: extend via **traits** and **generics**.

Instead of subclassing, define a trait and let callers provide implementations. For example, a storage backend trait rather than hardcoding `git2` calls directly. New backends can be added without modifying existing code.

```rust
// Good: open for extension
trait DoogatSource {
    fn get(&self, id: &DoogatId) -> Result<ParsedDoogat>;
    fn list(&self) -> Result<Vec<DoogatId>>;
}

// Bad: hardcoded to one implementation
fn rebuild_index(repo_path: &Path) -> Result<()> {
    let repo = git2::Repository::open(repo_path)?;
    // ...
}
```

## Liskov Substitution (L)

Any type implementing a trait must honor that trait's contract. Rust enforces the structural part at compile time — type signatures, lifetimes, Send/Sync bounds. The semantic part (behavior contracts) is still on you: document trait invariants.

```rust
/// Implementors MUST return doogats sorted by id.
/// Returning unsorted results violates the contract.
trait DoogatSource {
    fn list_sorted(&self) -> Result<Vec<DoogatId>>;
}
```

## Interface Segregation (I)

Don't force implementors to provide methods they don't need. Prefer **small, focused traits** over fat ones.

```rust
// Good: separated concerns
trait ReadStore {
    fn get(&self, id: &DoogatId) -> Result<ParsedDoogat>;
}

trait WriteStore {
    fn put(&self, doogat: &ParsedDoogat) -> Result<()>;
}

// Bad: forces read-only consumers to stub out writes
trait Store {
    fn get(&self, id: &DoogatId) -> Result<ParsedDoogat>;
    fn put(&self, doogat: &ParsedDoogat) -> Result<()>;
    fn delete(&self, id: &DoogatId) -> Result<()>;
}
```

## Dependency Inversion (D)

High-level modules depend on abstractions (traits), not concretions. Accept `impl Trait` or generic `T: Trait` parameters instead of concrete types.

```rust
// Good: indexer depends on an abstraction
fn rebuild_index(source: &impl DoogatSource, db: &Connection) -> Result<()> {
    for id in source.list()? {
        let doogat = source.get(&id)?;
        insert_into_index(db, &doogat)?;
    }
    Ok(())
}

// Bad: indexer directly calls git_ops
fn rebuild_index(repo_path: &Path, db: &Connection) -> Result<()> {
    let doogats = git_ops::list_all(repo_path)?;
    // ...
}
```

This enables testing the indexer without a real git repo — pass a mock `DoogatSource` instead.

### Actual usage: SqlBackend trait

The `sql_engine` module uses the `SqlBackend` trait (which extends `DoogatIndex`) instead of depending on the concrete `indexer::Index` type. `SqlBackend` adds the SQLite connection access and materialization methods that `sql_engine` needs beyond basic index queries:

```rust
pub trait SqlBackend: DoogatIndex {
    fn sql_conn(&self) -> &Connection;
    fn query_raw_with_columns(&self, sql: &str) -> Result<(Vec<String>, Vec<Vec<String>>)>;
    fn rematerialize_type(&self, type_name: &str, source: &dyn DoogatSource) -> Result<()>;
    fn materialize_single(&self, schema: &TableSchema, id: &str, parsed: &ParsedDoogat) -> Result<()>;
    fn type_uses_folder(&self, type_name: &str, source: &dyn DoogatSource) -> bool;
    fn backlinks_by_target(&self, target_id: &str, target_path: &str) -> Result<Vec<(String, String)>>;
}
```

`SqlEngine` takes `&dyn SqlBackend` rather than `&Index`, inverting the dependency direction. `Index` implements `SqlBackend`, but `sql_engine` doesn't know that.

## What the Rust compiler already enforces

| SOLID concern | Rust mechanism |
|---|---|
| Hidden mutation | Ownership + borrow checker |
| Inheritance spaghetti | No inheritance — traits only |
| Visibility | `pub`/`pub(crate)`/private modules |
| Contract violations | Type system, lifetimes, Send/Sync |

The remaining work is **architectural discipline** — the compiler can't check that your module boundaries make sense or that your traits are well-scoped.

## docs/src/technical/clean-architecture.md
# Clean Architecture in Rust

Clean Architecture's core idea: **dependencies point inward**. Outer layers know about inner layers, never the reverse.

## Layer mapping

| Layer | Doogat DB equivalent | Depends on |
|---|---|---|
| Domain | `types/`, `error.rs` — pure data structures, no I/O | Nothing |
| Use cases | Business logic — parsing rules, type inference, conflict resolution | Domain only |
| Adapters | `git_ops/mod.rs`, `indexer/`, `crdt_resolver.rs` — external system integration | Domain + traits |
| Entry point | `ddb-cli` — wires everything together | All layers |

## Domain layer

Pure data structures with no I/O dependencies. These types are the lingua franca of the codebase.

```rust
// types/ — no imports from git2, rusqlite, automerge
pub struct DoogatId(String);
pub struct ParsedDoogat { /* ... */ }
pub struct DoogatMeta { /* ... */ }
```

Rules:
- No filesystem, network, or database calls
- No dependencies on external crates (git2, rusqlite, automerge)
- Testable with zero setup

## Use-case layer

Business logic that operates on domain types. Should be testable without touching disk, git, or SQLite.

Examples in Doogat DB:
- Parser logic (frontmatter extraction, reference detection)
- Type inference rules
- Conflict resolution strategy (which field wins)

These should depend on domain types and trait abstractions, not on concrete adapters.

## Adapter layer

Implements trait abstractions using external systems. Each adapter translates between the domain language and an external dependency.

| Adapter | External dependency | Domain interface |
|---|---|---|
| `git_ops/mod.rs` | `git2` | Doogat storage/retrieval |
| `indexer/` | `rusqlite` | Search and query |
| `crdt_resolver.rs` | `automerge` | Conflict resolution state |

## Entry point

`ddb-cli/src/main.rs` constructs concrete implementations and wires them together. This is the only place that knows about all concrete types.

## Clean Code principles in Rust

| Principle | Rust equivalent |
|---|---|
| Small functions | Small functions — same |
| Meaningful names | Module + type + fn naming |
| No hidden side effects | Ownership makes side effects explicit |
| Error handling | `Result<T, E>` everywhere, no panics in library code |
| DRY | Traits, generics, macros (sparingly) |
| Test isolation | Trait-based dependency injection |

## Practical guidelines

1. **Keep I/O at the edges.** Business logic functions take domain types in and return domain types out. Let the caller handle I/O.

2. **No panics in library code.** Use `Result` for all fallible operations. Reserve `panic!`/`unwrap` for genuinely impossible states (and document why).

3. **Trait boundaries between modules.** Modules that talk to external systems should implement traits defined in the domain or use-case layer.

4. **Constructor injection.** Pass dependencies as function parameters or struct fields, not via global state or module-level calls.

5. **Test without I/O.** If a test needs a real git repo or SQLite database, it's an integration test. Unit tests should use mock implementations of trait boundaries.

## docs/src/architecture/modules.md
# Module Structure

## Dependency Graph

```text
error (foundation — no adapter crate imports)
  │
  v
types (depends: error — no adapter crate imports)
  │
  v
traits (depends: error, types, rusqlite — defines DoogatSource, DoogatStore,
  │                               DoogatIndex, SqlBackend, ConflictResolver,
  │                               service ports IndexPort/TypedMaterializationPort/
  │                               NoSqlMirrorPort (+ NoopMirror),
  │                               GitBackend + sub-traits: GitRemote, GitMerge,
  │                               GitHistory, GitBinary, GitRename, GitDesktopHooks)
  │
  ├──> parser (depends: error, types)
  │      │
  │      └──> crdt_resolver (depends: error, types, parser, traits)
  │
  ├──> id_minting (depends: error, types, traits, parser — called from git_ops)
  │
  ├──> git_ops (depends: error, types, traits, id_minting — implements DoogatSource/Store/GitBackend)
  │      │
  │      ├──> indexer (depends: error, types, traits, parser, sql_engine
  │      │             — accepts &impl DoogatSource, implements DoogatIndex)
  │      │
  │      ├──> sql_engine (depends: error, types, parser, traits
  │      │                — accepts &dyn SqlBackend + &dyn DoogatStore;
  │      │                  uses indexer::materialize utilities)
  │      │
  │      ├──> sync_manager (depends: error, types, git_ops,
  │      │                           crdt_resolver, indexer)
  │      │
  │      └──> compaction (depends: error, types, git_ops,
  │                                sync_manager, maintenance)
  │
  ├──> maintenance (depends: error, types, git_ops
  │                          — git maintenance runner + auto-trigger)
  │
  ├──> consistency (depends: error, types, parser, indexer, traits
  │                          — detect/apply/migrate auto-fixes)
  │
  ├──> attachments (depends: error, types, git_ops, indexer, parser)
  │
  ├──> bundled_types (standalone, no deps)
  │
  ├──> hlc (depends: error — Hybrid Logical Clock, no external crates)
  │
  ├──> bundle (depends: error, types, git_ops, sync_manager
  │                      — air-gapped sync via tar archives)
  │
  ├──> nosql (depends: error, types — feature-gated redb key-value index)
  │
  ├──> service (depends: error, types, git_ops, indexer, parser,
  │              sql_engine, sync_manager, compaction, maintenance,
  │              consistency, attachments, bundle, nosql
  │              — unified orchestration layer for CLI/FFI/server)
  │
  ├──> ffi (depends: service — UniFFI DoogatDriver facade,
  │         delegates to DoogatService)
  │
  └──> CLI (depends: service — delegates to DoogatService)
```

## Module Summary

| Module | Purpose | Key Dependencies |
|--------|---------|-----------------|
| `error` | `DoogatError` enum + `Result<T>` alias | thiserror only |
| `types` | Domain types (directory module: `mod.rs` config types, `value.rs` Value enum/path utilities, `doogat.rs` domain model types, `schema.rs` schema/consistency types) | no adapter crates |
| `traits` | Core trait abstractions (DoogatSource, DoogatStore, DoogatIndex, SqlBackend, ConflictResolver, GitBackend supertrait + sub-traits: GitRemote, GitMerge, GitHistory, GitBinary, GitRename, GitDesktopHooks) plus service-facing ports `IndexPort` (supertrait of DoogatIndex+SqlBackend), `TypedMaterializationPort`, `NoSqlMirrorPort` (with `NoopMirror` default) that let `DoogatService` depend on injectable index/mirror abstractions instead of concrete adapters | error, types, rusqlite (via SqlBackend) |
| `id_minting` | Repo-aware ID existence oracle (HEAD tree + index) and deterministic content-ID derivation for sync collision losers | rusqlite, sha2 |
| `parser` | Parse/serialize three-zone Markdown | regex, chrono, serde_yaml |
| `search_query` | Search query parsing and normalization to canonical form | — (std only) |
| `git_ops` | Git repository CRUD + merge; implements DoogatSource/Store/GitBackend (directory module: `mod.rs` struct/init/CRUD/traits, `read.rs` file reads/diffs/revision queries, `merge.rs` merge/conflict resolution, `remote.rs` push/pull/fetch, `rename.rs` rename with backlink rewrite) | git2 |
| `crdt_resolver` | Automerge conflict resolution; implements ConflictResolver | automerge, similar |
| `indexer` | SQLite FTS5 index (directory module: `mod.rs` core CRUD/schema, `search.rs` FTS5 search/tag queries, `filter.rs` search filter/negation SQL building, `rebuild.rs` rebuild/reindex/staleness, `graph.rs` backlinks/discovery/sequences, `resolve.rs` path/alias/wikilink resolution, `materialize.rs` schema inference/table materialization); implements DoogatIndex | rusqlite |
| `sql_engine` | SQL DDL/DML → doogat CRUD, _typedef management (directory module: `mod.rs` dispatch, `ddl.rs` CREATE/ALTER/DROP, `dml.rs` INSERT/UPDATE/DELETE, `junction.rs` junction tables, `builders.rs` doogat/schema building, `helpers.rs` SQL parsing utilities, `transaction.rs` BEGIN/COMMIT/ROLLBACK) | sqlparser, rusqlite |
| `bundled_types` | Built-in _typedef templates (project, contact) | — |
| `sync_manager` | Multi-device sync orchestration | uuid, toml, chrono |
| `compaction` | CRDT cleanup + git gc | — |
| `maintenance` | Git maintenance runner, auto-trigger | — |
| `consistency` | Detect/apply/migrate auto-fixes (directory module: `mod.rs` detection/fix application, `migrations.rs` versioned data migrations, `zone_migrate.rs` cross-zone field migration) | — |
| `attachments` | File attachment CRUD (attach, detach, list) on `reference/{id}/` | — |
| `hlc` | Hybrid Logical Clock for causal ordering | — (std only) |
| `bundle` | Air-gapped sync via tar archive export/import | tar, sha2, flate2 |
| `nosql` | redb-based key-value index for fast lookups (feature-gated) | redb |
| `service` | Unified orchestration layer (`DoogatService<G: GitBackend = GitRepo, I: IndexPort = Index>`) — single entry point for CRUD, search, SQL, sync, discovery with consistent NoSQL dual-write. The index is an injected `IndexPort` and the NoSQL mirror an injected `Box<dyn NoSqlMirrorPort>`; `from_parts` is the dependency-injection seam, `open`/`init` are the default runtime builders that construct the concrete `Index` + Redb/`NoopMirror` at the edge. Directory module: `mod.rs` struct/builders/state, `crud.rs` create/read/update/delete/batch ops (+ port-based dual-write), `search.rs` search/filtered queries, `sql.rs` SQL pass-through/transactions, `ops.rs` compact/maintenance/bundles, `discovery.rs` unlinked mentions/sequences/backlinks, `utility.rs` schema queries/NoSQL reads, `concrete_index.rs` the few methods still needing the concrete `Index` (sync, import_bundle, rename, fix_all, zone_migrate, attach/detach) | all core modules |
| `ffi` | UniFFI facade (DoogatDriver) wrapping `Mutex<DoogatService>` for Swift/Kotlin | service, uniffi |
| **CLI** | Command-line interface (main.rs CLI structs/dispatch, `commands/` submodules: crud, query, sync, maintenance, discover) | service, clap |
| **updater** (CLI) | Self-update from GitHub releases | reqwest, semver, self_replace, sha2, flate2, tar |

## External Dependencies

### Core (`ddb-core`)

| Crate | Version | Purpose |
|-------|---------|---------|
| `automerge` | 0.7 | CRDT conflict resolution |
| `chrono` | 0.4 | Timestamps and date formatting |
| `git2` | 0.20 | libgit2 bindings for Git operations |
| `regex` | 1 | Inline field and wikilink extraction |
| `rusqlite` | 0.32 | SQLite with FTS5 (bundled) |
| `serde` | 1 | Serialization framework |
| `serde_yaml` | 0.9 | YAML frontmatter parsing |
| `similar` | 2 | Character-level text diffs |
| `sqlparser` | 0.55 | SQL statement parsing (DDL/DML) |
| `thiserror` | 2 | Error derive macros |
| `toml` | 0.8 | Node config serialization |
| `uniffi` | 0.29 | Cross-platform FFI bindings (Swift/Kotlin) |
| `uuid` | 1 | Node UUID generation (v4) |

### CLI (`ddb-cli`)

| Crate | Version | Purpose |
|-------|---------|---------|
| `chrono` | 0.4 | Date formatting for new doogats |
| `clap` | 4 | Argument parsing with derive |
| `flate2` | 1 | Gzip decompression for update archives |
| `reqwest` | 0.12 | HTTP client for GitHub releases API |
| `self_replace` | 1 | Atomic binary self-replacement |
| `semver` | 1 | Version comparison for updates |
| `serde` | 1 | State file serialization |
| `serde_json` | 1 | JSON state file format |
| `sha2` | 0.10 | SHA-256 checksum verification |
| `tar` | 0.4 | Archive extraction for update binaries |
| `ddb-core` | path | Local workspace dependency |

### Dev

| Crate | Version | Purpose |
|-------|---------|---------|
| `criterion` | 0.5 | Benchmarking framework (CRUD + search) |
| `tempfile` | 3 | Temporary directories for integration tests |

## Build evidence (claims to verify)
# PRD 00171 build evidence for the fresh review session

This is review input, not acceptance. The PRD remains in `wip/`. Only the installed build-to-review transition may advance the phase; the fresh session must run every required lens and its normal review/rework loop.

## Identity and scope

- PRD: `dev/local/prds/wip/00171-migrate-shell-scenarios-to-e2e-v1.md`.
- Reviewed design: `dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-design.md`.
- Complete coverage map: sibling `00171-migrate-shell-scenarios-to-e2e-v1-mapping.md`.
- Preserve `work_start_sha=b1e785395fb1e5d7043fbc725cc5786f62a6417e`. Do not narrow the whole-PRD review to this continuation's commits.
- Task14 base `5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4`; retirement revision `c8b72bd9126c83d054264ce6ac3738e8f6d0abda`.
- Unrelated 00202 commits, including `52759bd`, `a7e5179` and `75cde1c`, were preserved. Do not redo their repaired retained-lineage HLC/clippy work because an older CI run was red.
- Only PRD00171 is authorized here. Do not start00172, drain the backlog, or close issues.

## Settled design decisions

Use isolated ports/temp repositories, explicit thread coordination, `tokio_postgres`, and unconditional PgWire coverage. The reviewed design supersedes old serial-marker/psql-skip suggestions. Equivalent names/counts do not prove coverage: preserve original must-fail, race, platform-specific and data assertions. The product's six-transport posture is settled.

## Task12 proof

All391 source rows were reconciled independently:56 Bash smoke,56 PowerShell smoke,140 Bash integration,139 PowerShell integration. All targets resolve in the actual565-test runner registry. No TODO rows or unregistered target modules remain. Source paths and line references now refer to Git history at the task14 parent revision.

- `00171-task12-verification.md`: local gate results, repeat integration runs, failure repairs, review closures.
- `00171-task12-smoke-audit.md`, `00171-task12-parta-audit.md`, `00171-task12-partb-audit.md`: source assertion audits, including independent PowerShell17/18 reconciliation.
- `00171-mapping-discovery.json`:391 source keys and registered target proof;565 discovered tests.
- `00171-task12-devon.md`, `00171-task12-devon-round2.md`: actual adversarial runs, strengthened parsed Git HEAD body/title assertions, exact singleton theme checks and caught replays.
- Five `00171-task12-pat-*.md` partition reports cover every changed file. The one MEDIUM (lost original GraphQL auto-seed coverage beside the CLI port) was repaired in `32aa884` and its resumed review returned NO FINDINGS. Initial report is preserved as `00171-task12-pat-server-r1.md`. Fourteen LOW notes remain for the fresh review to assess.

Task12 commits: `faede1d`, `3965754`, `36c0687`, `32aa884`. The newly registered singleton parity/write-lock modules and section55B/C/D races are covered by actual discovery and execution, not file existence alone. Task12 repeated `integration_` runs passed83 tests; the affected broad subset passed278 tests after repairs. Tier1 passed42CLI+1555core+222server tests.

## CI before shell deletion

Task13 commit `5cf4c36` changed only the two workflows to the exact reviewed replacement wiring. It was pushed BEFORE dispatching Full Validation. Full Validation run33991344845 passed all six jobs, including Linux e2e, macOS full and Windows full, on that exact full SHA. Push Test33991275129 also passed, including the Rust smoke step. No older revision or skipped platform job was accepted.

Evidence: `00171-task13-verification.md`, `00171-task13-ci-green.json`, `00171-task13-ci.json`, `00171-task13-ci-observation.json`. The historical119-unpushed/auth warning was removed through statectl after the actual successful push. Task13 used the then-installed0.5.0 routing and actual Qwen helper; task14 uses installed0.5.1 after a cache update. Routine task13 config-only gate exceptions are recorded explicitly.

## Retirement and validation

Commit `c8b72bd` deleted all four shell suites after the exact-revision green gate; no survivor is needed. AGENTS, CONTRIBUTING, README and technical testing docs now target Rust e2e scenarios. The unrelated jink-feedback repro instructions were preserved byte-for-byte. Every Rust change in task14 is a comment/whitespace edit; replacement assertions and runtime tokens are unchanged. All23 SQL documentation scenario references resolve to actual discovered tests, and the full repository live-reference search finds no obsolete script path.

Post-deletion push Test34016441899 passed both test and coverage jobs on full SHA `c8b72bd9126c83d054264ce6ac3738e8f6d0abda`; completed2026-09-06T06:47:05Z. Evidence: `00171-task14-ci-green.json`.

Task14's independent Devon baseline passed565 tests. Three generic executed mutants were caught: body updates routed to title; discarded SINGLETON declaration; SQL title literals discarded. The title mutant passed the five focused concurrency tests but failed the complete suite on five real behavior assertions. Incidental socket connection failures were explicitly excluded from the mutation verdict. A final real-binary focused control passed5/5. All facades were overwritten as harmless forwarders and independently checked. Full details and exact mutant bodies: `00171-task14-devon.md`.

Task14's complete patch was reviewed in21 bounded Pat partitions, with every deleted source line included exactly once and relevant audited mapping rows supplied per deletion segment. All21 actual reports pass the installed parser: seven LOW findings, no MEDIUM/HIGH/CRITICAL findings. Eight partitions used Sonnet. At the user's explicit request to avoid a quota wait, thirteen used Codex: ten fresh isolated agents and parent reviews for partitions12,16,20. All thirteen Codex reports returned NO FINDINGS. Final provenance and LOW notes are in `00171-task14-pat-index.json` and `00171-task14-pat-assessment.md`. Invalid initial outputs and quota banners are separately preserved, never counted as completed reviews.

All14 build tasks are complete at the retirement revision. Required local gate totals:2384 passed,0 failed,0 skipped (1819fast +565e2e); the supplemental5-test real-binary control is recorded separately. The same-HEAD final result is in `dev/local/autopilot/last-verification.json`. No source edit followed the green gates. `00171-build-phase-report.md` contains task stamps and the unchanged assumption ledger. This continuation's scratch was archived with byte verification before cleanup; manifests and archives are in reviews. The original handoff and all other PRDs' artifacts are preserved.

## Fresh review requirements

Run consensus(Alice), blind/PRD-only(Blake), and doubt plus de-slop(Bob, R1–R5) in every cycle, each with the installed isolation contracts. This build session has not invoked `review-work-completion`. Review the full preserved PRD range and use `last-verification.json` only when its SHA matches the reviewed HEAD. Per-task LOW notes are observations to assess, not automatically accepted defects.

No new source-root database artifacts, worktrees, plans, or branches were created by this continuation. A pre-existing unrelated `worktree-agent-a188c62e61e58f6e5` branch was left alone. Cleanup and exact final verification are recorded in the task14 report before handoff.

## Recorded verification
{
  "sha": "c8b72bd9126c83d054264ce6ac3738e8f6d0abda",
  "cycle": 1,
  "commands": [
    {"command": "cargo build", "exit": 0},
    {"command": "cargo build -p ddb-cli", "exit": 0},
    {"command": "cargo clippy --workspace --all-targets", "exit": 0},
    {"command": "cargo test-ci", "exit": 0},
    {"command": "CARGO_BIN_EXE_ddb=/Users/bob/git/src/github.com/doogat/ddb/target/debug/ddb /usr/bin/time -p cargo test -p ddb-e2e", "exit": 0}
  ],
  "passed": 2384,
  "failed": 0,
  "skipped": 0
}

## Mechanical facts (computed, do not re-count)

Function line counts from `ast`. Cite these for countable claims; a
finding that contradicts this block is discarded at the review gate.

- `.github/workflows/full-validation.yml` — skipped (non-python)
- `.github/workflows/test.yml` — skipped (non-python)
- `AGENTS.md` — skipped (non-python)
- `CHANGELOG.md` — skipped (non-python)
- `CONTRIBUTING.md` — skipped (non-python)
- `README.md` — skipped (non-python)
- `ddb-core/src/git_ops/read.rs` — skipped (non-python)
- `ddb-core/src/git_ops/tests.rs` — skipped (non-python)
- `ddb-core/src/indexer/tests/mod.rs` — skipped (non-python)
- `ddb-core/src/search_query.rs` — skipped (non-python)
- `docs/src/technical/crdt-resolver.md` — skipped (non-python)
- `docs/src/technical/sql-engine.md` — skipped (non-python)
- `docs/src/technical/walkthrough.md` — skipped (non-python)
- `tests/e2e/alter_column_type.rs` — skipped (non-python)
- `tests/e2e/alter_table_rename.rs` — skipped (non-python)
- `tests/e2e/bundle_import_conflict_recovery.rs` — skipped (non-python)
- `tests/e2e/cascade_delete.rs` — skipped (non-python)
- `tests/e2e/checkboxes.rs` — skipped (non-python)
- `tests/e2e/cli_create_fk_freshness.rs` — skipped (non-python)
- `tests/e2e/cli_create_unregistered_type.rs` — skipped (non-python)
- `tests/e2e/common.rs` — skipped (non-python)
- `tests/e2e/delete_backlinks.rs` — skipped (non-python)
- `tests/e2e/discover.rs` — skipped (non-python)
- `tests/e2e/fix.rs` — skipped (non-python)
- `tests/e2e/folder_namespace.rs` — skipped (non-python)
- `tests/e2e/hyphenated_types.rs` — skipped (non-python)
- `tests/e2e/inline_zone.rs` — skipped (non-python)
- `tests/e2e/integration_alter_rename.rs` — skipped (non-python)
- `tests/e2e/integration_binary_lww.rs` — skipped (non-python)
- `tests/e2e/integration_bundle.rs` — skipped (non-python)
- `tests/e2e/integration_compact_stats.rs` — skipped (non-python)
- `tests/e2e/integration_crdt_conflicts.rs` — skipped (non-python)
- `tests/e2e/integration_error_codes.rs` — skipped (non-python)
- `tests/e2e/integration_graphql_batch.rs` — skipped (non-python)
- `tests/e2e/integration_graphql_jink.rs` — skipped (non-python)
- `tests/e2e/integration_graphql_refs.rs` — skipped (non-python)
- `tests/e2e/integration_graphql_server.rs` — skipped (non-python)
- `tests/e2e/integration_hyphenated_type.rs` — skipped (non-python)
- `tests/e2e/integration_id_poison.rs` — skipped (non-python)
- `tests/e2e/integration_junction_sync.rs` — skipped (non-python)
- `tests/e2e/integration_nosql_cli.rs` — skipped (non-python)
- `tests/e2e/integration_orderby_base_fields.rs` — skipped (non-python)
- `tests/e2e/integration_rest_pgwire.rs` — skipped (non-python)
- `tests/e2e/integration_singleton_flow.rs` — skipped (non-python)
- `tests/e2e/integration_singleton_parity.rs` — skipped (non-python)
- `tests/e2e/integration_singleton_races.rs` — skipped (non-python)
- `tests/e2e/integration_sql_no_match.rs` — skipped (non-python)
- `tests/e2e/integration_sql_writes.rs` — skipped (non-python)
- `tests/e2e/integration_sync.rs` — skipped (non-python)
- `tests/e2e/integration_tags_filter.rs` — skipped (non-python)
- `tests/e2e/integration_typed_write_cli.rs` — skipped (non-python)
- `tests/e2e/integration_typed_write_polish.rs` — skipped (non-python)
- `tests/e2e/integration_update_bin.rs` — skipped (non-python)
- `tests/e2e/integration_warnings_update.rs` — skipped (non-python)
- `tests/e2e/integration_write_lock_races.rs` — skipped (non-python)
- `tests/e2e/integration_write_recovery.rs` — skipped (non-python)
- `tests/e2e/junction_tables.rs` — skipped (non-python)
- `tests/e2e/link_kinds.rs` — skipped (non-python)
- `tests/e2e/main.rs` — skipped (non-python)
- `tests/e2e/multi_device.rs` — skipped (non-python)
- `tests/e2e/pgwire.rs` — skipped (non-python)
- `tests/e2e/poison_file_reindex.rs` — skipped (non-python)
- `tests/e2e/reference_raw_id.rs` — skipped (non-python)
- `tests/e2e/rename.rs` — skipped (non-python)
- `tests/e2e/schema_apply.rs` — skipped (non-python)
- `tests/e2e/search_in_filter.rs` — skipped (non-python)
- `tests/e2e/search_links.rs` — skipped (non-python)
- `tests/e2e/sequence.rs` — skipped (non-python)
- `tests/e2e/serve.rs` — skipped (non-python)
- `tests/e2e/server_mutations.rs` — skipped (non-python)
- `tests/e2e/set_flag.rs` — skipped (non-python)
- `tests/e2e/smoke_core.rs` — skipped (non-python)
- `tests/e2e/smoke_resilience.rs` — skipped (non-python)
- `tests/e2e/smoke_search.rs` — skipped (non-python)
- `tests/e2e/smoke_sql.rs` — skipped (non-python)
- `tests/e2e/sql_expressions_test.rs` — skipped (non-python)
- `tests/e2e/sql_lifecycle.rs` — skipped (non-python)
- `tests/e2e/sync_crdt.rs` — skipped (non-python)
- `tests/e2e/tags.rs` — skipped (non-python)
- `tests/e2e/typed_field_mutations.rs` — skipped (non-python)
- `tests/integration.ps1` — skipped (non-python)
- `tests/integration.sh` — skipped (non-python)
- `tests/smoke.ps1` — skipped (non-python)
- `tests/smoke.sh` — skipped (non-python)

## Tautological test shapes (computed, do not re-judge)

Each `[MECH]` line is a test whose shape cannot fail as written. Raise
it; step 6 adds any line the table lacks. `mech-check` is the finder.


Checked 0 test function(s) in 0 test file(s).
## Fail-first replay (computed, do not re-judge)

Touched tests from HEAD, run against the pre-change code at `b1e785395fb1`
(HEAD's test files overlaid on a base worktree). A test that passes there
does not pin this change. A behavior-preserving refactor's tests pass by
design, so weigh the PRD's intent before raising one. `mech-check` is the finder.

replay: skipped (the diff touches no test function)
