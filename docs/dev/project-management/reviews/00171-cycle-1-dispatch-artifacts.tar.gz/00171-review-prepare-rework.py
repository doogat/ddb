import json
from pathlib import Path

root = Path('/Users/bob/git/src/github.com/doogat/ddb')
tmp = root / 'dev/local/tmp'
wt = root / 'dev/local/worktrees/00171-review'
for task_id in (15, 16):
    task = json.loads((tmp / f'00171-task-{task_id}.json').read_text())
    description = task['description']
    (tmp / f'review-task-{task_id}-subject.txt').write_text(task['name'])
    (tmp / f'review-task-{task_id}-description.txt').write_text(description)
    acceptance = description.split('Acceptance: ', 1)[1].split('\n\n', 1)[0]
    (tmp / f'review-task-{task_id}-acceptance.txt').write_text(acceptance)
    if task_id == 16:
        paths = description.split('Contract: ', 1)[1].split('\n\n', 1)[0].rstrip('.').split('; ')
        (tmp / 'ivan-16-files.txt').write_text('\n'.join(str(wt / p) for p in paths) + '\n')
        (tmp / 'ivan-16-checks.txt').write_text(description + '\nVerify: parent runs cargo fmt --check, cargo build, cargo clippy --workspace --all-targets, cargo test-ci. Do not run cargo or commit in the child; return edits for parent verification. This test-only task explicitly authorizes the new multiple-junction-row variant named above.\n')
        context = (wt / 'AGENTS.md').read_text()
        for doc in ('solid.md', 'clean-architecture.md'):
            context += '\n\n' + (wt / 'docs/src/technical' / doc).read_text()
        context += '\n\nWorktree: ' + str(wt) + '. All allowed paths are absolute. The source checkout is in use by another session; work only in the named worktree. Read relevant spans, not entire large serve.rs; stay below the persona input budget.\n'
        context += '''
READING BUDGET AND ORDERED WORK PLAN (verify each before moving on):
1. common.rs: inspect imports and DdbTestRepo definition/methods with rg; read at most 150 relevant lines. smoke_core.rs 1-25, smoke_sql.rs 1-25, smoke_search.rs 1-20: move the existing stdout and assert_doogat_id helpers to common, import them, and check no duplicates remain.
2. integration_id_poison.rs 1-110; integration_nosql_cli.rs 1-100; integration_singleton_parity.rs 1-75; integration_singleton_races.rs 65-120: use the shared ID assertion. Preserve the own-line scan assertion and exact committed-row check. The scan can compare an output line to the already validated id3, and the Git tree assertion can compare all .md stems to the already validated survivor ID (the typedef directory has no .md suffix). Do not invent a generic parser/helper for these two callers.
3. serve.rs: imports and lines 1370-1460, 1810-1870 only; restore totalCount assertions, distinct prefix-negative fixture, and exact matching hit identity.
4. rest.rs: imports and lines 110-165; preserve GraphQL SQL readback and add separate CLI query.
5. reference_raw_id.rs: setup helpers plus lines 105-150, and locate existing three-category linking fixture. Preserve the one-reference test and add the specifically requested three-reference scalar variant. Verify the scalar is the first-linked ID, not a sorted-category accident.
6. integration_graphql_jink.rs: imports and lines 145-170; assert the singleton INSERT result with the shared ID helper.
7. integration_junction_sync.rs: imports and lines 1-50; parse the encoded row and assert exact JSON ["a", "1"].
Total source reading budget: 60KB; use targeted Read offset/limit and rg only on the explicit allowlist. Verify edits by reading changed regions. Parent runs formatting and all required Cargo gates; do not run them or commit in the child.
'''
        (tmp / 'ivan-16-context.txt').write_text(context)
