
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: [D1] Restore exact scenario assertions and share existing test helpers

Description:
Test-only task. Restore the six concrete assertion-fidelity gaps below and consolidate the duplicated stdout/id helpers specified by the seventh finding. Keep every existing scenario and add the multi-junction-row raw-scalar variant; do not weaken or remove the existing one-reference test. No production changes, new dependency, runtime feature, or unrelated refactor. All mutations stay under tests/e2e. The PRD requires assertion equivalence with the retired shell scenarios.

### Findings (verbatim)
[EVE] 🟡 [FIX] §42 totalCount assertions dropped: bash 1505/1517 asserted `totalCount == 1`; the cited "ALREADY COVERED" tests request the field but never read it — tests/e2e/serve.rs:1408-1410 (`filter_base_field_title_eq`) and :1443-1445 (`filter_base_field_title_contains`) — add `assert_eq!(result["data"]["tasks"]["totalCount"].as_i64().unwrap(), 1)` to each. | File: tests/e2e/serve.rs | Task: general
[EVE] 🟡 [FIX] §44.E1 JOIN pin degraded to single-character containment: `row_str.contains('a')`/`contains('1')` also pass on `["abc","10"]`; bash 1699-1700 grepped the quoted tokens — tests/e2e/integration_junction_sync.rs:35-43 — parse `rows[0]` as JSON and `assert_eq!(row, json!(["a","1"]))`. | File: tests/e2e/integration_junction_sync.rs | Task: general
[EVE] 🟡 [FIX] §59.A cross-process read-back dropped: bash 2667-2677 read the typed column back through a separate `ddb query` process (its comment names that as the point); the Rust target reads through the same server's executeSql — tests/e2e/rest.rs:153-154 — add `repo.ddb().args(["query", "SELECT category FROM item WHERE id = '<id>'"]).assert().success().stdout(contains("books"))`. | File: tests/e2e/rest.rs | Task: general
[EVE] 🟡 [FIX] §18d2 eq-exactness fixture lost: bash 341-346 seeded `https://example.com/page` so a prefix/LIKE `eq` would fail; the "ALREADY COVERED" test seeds two identical `https://example.com` plus `https://other.org`, so a prefix match still passes — tests/e2e/serve.rs:1830-1857 (`search_where_filter_materialized_column_eq`) — change Link B's url to `https://example.com/page` and expect 1 hit / totalCount 1. | File: tests/e2e/serve.rs | Task: general
[EVE] 🟡 [FIX] §38b2b raw-scalar pin with multiple junction rows lost: bash 1260-1265 linked three categories and asserted `rlcat_id == <first-linked>`; the cited test links one — tests/e2e/reference_raw_id.rs:112-143 — add a three-category variant asserting `category_id` equals the first-linked id. | File: tests/e2e/reference_raw_id.rs | Task: general
[EVE] 🟡 [FIX] §17.J2 numeric-id assertion weakened: bash 217 required `"message":"[0-9]+"`, Rust asserts `!config_id.is_empty()` — tests/e2e/integration_graphql_jink.rs:158 — assert a 14-digit numeric id. | File: tests/e2e/integration_graphql_jink.rs | Task: general
[EVE] ⚪ [FIX] Slop: `stdout()` copy-pasted in smoke_core.rs:6, smoke_sql.rs:4, smoke_search.rs:4; the 14-digit-id check re-implemented as `assert_doogat_id` (smoke_sql.rs:12), `is_14_digit_id` (integration_id_poison.rs:40) and inline at integration_nosql_cli.rs:40,88, integration_singleton_parity.rs:61, integration_singleton_races.rs:87,111 — tests/e2e/common.rs — move one `stdout()` and one `assert_doogat_id()` there and call them (also closes the §17.J2 item). | File: tests/e2e/common.rs | Task: general

Contract: tests/e2e/common.rs; tests/e2e/smoke_core.rs; tests/e2e/smoke_sql.rs; tests/e2e/smoke_search.rs; tests/e2e/integration_id_poison.rs; tests/e2e/integration_nosql_cli.rs; tests/e2e/integration_singleton_parity.rs; tests/e2e/integration_singleton_races.rs; tests/e2e/serve.rs; tests/e2e/rest.rs; tests/e2e/reference_raw_id.rs; tests/e2e/integration_graphql_jink.rs; tests/e2e/integration_junction_sync.rs.

Acceptance: every quoted finding no longer reproduces. Existing checks remain, exact negative fixtures distinguish eq from prefix matching, multiple junction rows pin first-linked ordering, REST read-back uses a separate CLI process, and shared helpers keep the same successful exit and ASCII 14-digit ID semantics. No test is ignored.


Acceptance criteria:
every quoted finding no longer reproduces. Existing checks remain, exact negative fixtures distinguish eq from prefix matching, multiple junction rows pin first-linked ordering, REST read-back uses a separate CLI process, and shared helpers keep the same successful exit and ASCII 14-digit ID semantics. No test is ignored.


## Diff under review

```diff
diff --git a/tests/e2e/common.rs b/tests/e2e/common.rs
index 9971c0f..bd3ac78 100644
--- a/tests/e2e/common.rs
+++ b/tests/e2e/common.rs
@@ -373,6 +373,24 @@ pub fn select_scalar(server: &ServerGuard, sql: &str) -> String {
     row[0].clone()
 }
 
+/// Run `ddb` with `args` in `repo`, asserting success, and return trimmed stdout.
+pub fn stdout(repo: &DdbTestRepo, args: &[&str]) -> String {
+    let mut command = repo.ddb();
+    let assert = command.args(args).assert().success();
+    String::from_utf8_lossy(&assert.get_output().stdout)
+        .trim()
+        .to_owned()
+}
+
+/// Assert `id` is a 14-digit ASCII doogat id.
+pub fn assert_doogat_id(id: &str) {
+    assert_eq!(id.len(), 14, "expected a 14-digit doogat id, got {id:?}");
+    assert!(
+        id.bytes().all(|byte| byte.is_ascii_digit()),
+        "expected a numeric doogat id, got {id:?}"
+    );
+}
+
 pub struct DdbTestRepo {
     pub dir: TempDir,
 }
diff --git a/tests/e2e/integration_graphql_jink.rs b/tests/e2e/integration_graphql_jink.rs
index 089d92a..4c7971a 100644
--- a/tests/e2e/integration_graphql_jink.rs
+++ b/tests/e2e/integration_graphql_jink.rs
@@ -1,4 +1,4 @@
-use crate::common::{DdbTestRepo, ServerGuard};
+use crate::common::{assert_doogat_id, DdbTestRepo, ServerGuard};
 use serde_json::{json, Value};
 
 fn assert_graphql_ok(result: &Value) {
@@ -155,7 +155,7 @@ fn integration_17j2_jink_config_singleton_and_link_crud() {
         "jink-config should initially be empty"
     );
     let config_id = seed_jink_config(&server);
-    assert!(!config_id.is_empty());
+    assert_doogat_id(&config_id);
     assert_eq!(
         sql_rows(
             &server,
diff --git a/tests/e2e/integration_id_poison.rs b/tests/e2e/integration_id_poison.rs
index 8481d05..aa49885 100644
--- a/tests/e2e/integration_id_poison.rs
+++ b/tests/e2e/integration_id_poison.rs
@@ -13,7 +13,7 @@
 //! mutation that calls `ensure_fresh()` after the poison commit; a second
 //! mutation would see nothing stale and return no warnings.
 
-use crate::common::{DdbTestRepo, ServerGuard};
+use crate::common::{assert_doogat_id, DdbTestRepo, ServerGuard};
 use predicates::prelude::*;
 use std::collections::HashSet;
 use std::path::Path;
@@ -36,11 +36,6 @@ fn git(repo: &Path, args: &[&str]) {
     );
 }
 
-/// True if `s` is exactly 14 ASCII digits (the `ddb` id shape).
-fn is_14_digit_id(s: &str) -> bool {
-    s.len() == 14 && s.chars().all(|c| c.is_ascii_digit())
-}
-
 /// PRD 00164 removed the stale same-second mint workaround: the batch
 /// (multi-row INSERT) and single (`ddb create`) mint paths must not collide
 /// even with zero delay between them. Deliberately no `sleep` between the
@@ -90,15 +85,9 @@ fn integration_62_id_minting_no_same_second_collision() {
         "expected 3 comma-separated ids from the batch insert: {batch_stdout:?}"
     );
     for id in &batch_ids {
-        assert!(
-            is_14_digit_id(id),
-            "expected a 14-digit numeric id, got {id:?} in {batch_stdout:?}"
-        );
+        assert_doogat_id(id);
     }
-    assert!(
-        is_14_digit_id(&single_stdout),
-        "expected a single 14-digit numeric id, got {single_stdout:?}"
-    );
+    assert_doogat_id(&single_stdout);
 
     let mut all_ids: Vec<String> = batch_ids.into_iter().map(str::to_owned).collect();
     all_ids.push(single_stdout);
diff --git a/tests/e2e/integration_junction_sync.rs b/tests/e2e/integration_junction_sync.rs
index 07215b4..cbd9ff2 100644
--- a/tests/e2e/integration_junction_sync.rs
+++ b/tests/e2e/integration_junction_sync.rs
@@ -1,4 +1,5 @@
 use crate::common::{select_scalar, DdbTestRepo, ServerGuard};
+use serde_json::json;
 
 #[test]
 fn integration_44_e1_join_pin_graphql() {
@@ -33,13 +34,11 @@ fn integration_44_e1_join_pin_graphql() {
     let rows = joined["data"]["sql"]["rows"].as_array().unwrap();
     assert_eq!(rows.len(), 1, "expected exactly one joined row: {joined}");
     let row_str = rows[0].as_str().unwrap();
-    assert!(
-        row_str.contains('a'),
-        "joined row should contain title 'a': {row_str}"
-    );
-    assert!(
-        row_str.contains('1'),
-        "joined row should contain count 1: {row_str}"
+    let row: serde_json::Value = serde_json::from_str(row_str).unwrap();
+    assert_eq!(
+        row,
+        json!(["a", "1"]),
+        "joined row should be exactly [title, count]: {row_str}"
     );
 }
 
diff --git a/tests/e2e/integration_nosql_cli.rs b/tests/e2e/integration_nosql_cli.rs
index e4e5a1f..42b64e4 100644
--- a/tests/e2e/integration_nosql_cli.rs
+++ b/tests/e2e/integration_nosql_cli.rs
@@ -1,7 +1,7 @@
 //! NoSQL CLI commands (get, scan --tag, scan --type, backlinks)
 //! exercised against a self-contained fixture.
 
-use crate::common::DdbTestRepo;
+use crate::common::{assert_doogat_id, DdbTestRepo};
 use predicates::prelude::*;
 
 #[test]
@@ -36,10 +36,7 @@ fn integration_32_nosql_cli_commands() {
         .output()
         .unwrap();
     let id3 = String::from_utf8_lossy(&id3_out.stdout).trim().to_string();
-    assert!(
-        id3.len() == 14 && id3.chars().all(|c| c.is_ascii_digit()),
-        "typed fixture must return a 14-digit id, got: {id3:?}"
-    );
+    assert_doogat_id(&id3);
 
     let id1_out = repo
         .ddb()
@@ -81,12 +78,13 @@ fn integration_32_nosql_cli_commands() {
         .args(["scan", "--type", "foo"])
         .assert()
         .success()
-        .stdout(predicate::str::contains(id3));
+        .stdout(predicate::str::contains(id3.clone()));
     assert!(
         String::from_utf8_lossy(&scan.get_output().stdout)
             .lines()
-            .any(|line| line.len() == 14 && line.chars().all(|c| c.is_ascii_digit())),
-        "scan --type must print a 14-digit id on its own line"
+            .any(|line| line == id3),
+        "scan --type must print id3 on its own line, got: {:?}",
+        String::from_utf8_lossy(&scan.get_output().stdout)
     );
 
     repo.ddb()
diff --git a/tests/e2e/integration_singleton_parity.rs b/tests/e2e/integration_singleton_parity.rs
index 2844e4e..2d4dbd6 100644
--- a/tests/e2e/integration_singleton_parity.rs
+++ b/tests/e2e/integration_singleton_parity.rs
@@ -8,7 +8,7 @@
 //! this test covers the GraphQL (`executeSql` *and* typed `createDoogat`), REST,
 //! and NoSQL-HTTP legs plus the shared end state.
 
-use crate::common::{DdbTestRepo, ServerGuard};
+use crate::common::{assert_doogat_id, DdbTestRepo, ServerGuard};
 use predicates::prelude::*;
 use serde_json::{json, Value};
 
@@ -57,10 +57,7 @@ fn integration_54_d_cross_protocol_singleton_duplicate_parity() {
     let existing_id = String::from_utf8_lossy(&seed.get_output().stdout)
         .trim()
         .to_string();
-    assert!(
-        existing_id.len() == 14 && existing_id.chars().all(|c| c.is_ascii_digit()),
-        "seed INSERT must print a 14-digit doogat id, got: {existing_id:?}"
-    );
+    assert_doogat_id(&existing_id);
 
     // Control: an ordinary table declared WITHOUT SINGLETON takes as many rows as
     // it is given. Without this, every rejection below would still pass on a
diff --git a/tests/e2e/integration_singleton_races.rs b/tests/e2e/integration_singleton_races.rs
index dd85a08..dc618ab 100644
--- a/tests/e2e/integration_singleton_races.rs
+++ b/tests/e2e/integration_singleton_races.rs
@@ -2,7 +2,7 @@
 //! The CLI-only leg is
 //! `singleton_cross_process_create::two_concurrent_ddb_create_on_singleton_converge_on_one_row`.
 
-use crate::common::{DdbTestRepo, ServerGuard};
+use crate::common::{assert_doogat_id, DdbTestRepo, ServerGuard};
 use serde_json::Value;
 use std::process::Command;
 use std::sync::Barrier;
@@ -83,10 +83,7 @@ fn assert_survivor(repo: &DdbTestRepo, table: &str, theme: &str) -> String {
     let id = String::from_utf8_lossy(&row_id.get_output().stdout)
         .trim()
         .to_owned();
-    assert!(
-        id.len() == 14 && id.chars().all(|c| c.is_ascii_digit()),
-        "survivor must have a 14-digit id, got: {id:?}"
-    );
+    assert_doogat_id(&id);
     let row_theme = repo
         .ddb()
         .args(["query", &format!("SELECT theme FROM {table}")])
@@ -108,7 +105,6 @@ fn assert_survivor(repo: &DdbTestRepo, table: &str, theme: &str) -> String {
     let committed_ids: Vec<&str> = tree_stdout
         .lines()
         .filter_map(|path| path.strip_suffix(".md"))
-        .filter(|stem| stem.len() == 14 && stem.chars().all(|c| c.is_ascii_digit()))
         .collect();
     assert_eq!(
         committed_ids,
diff --git a/tests/e2e/reference_raw_id.rs b/tests/e2e/reference_raw_id.rs
index 2723dca..c72bb8b 100644
--- a/tests/e2e/reference_raw_id.rs
+++ b/tests/e2e/reference_raw_id.rs
@@ -142,6 +142,81 @@ fn raw_id_coexists_with_object_resolver() {
     assert_eq!(label, "tech");
 }
 
+#[test]
+fn raw_id_field_pins_first_linked_with_multiple_junction_rows() {
+    let repo = DdbTestRepo::init();
+    let server = ServerGuard::start(&repo);
+
+    let r = server.graphql_with_vars(
+        r#"mutation($sql: String!) { executeSql(sql: $sql) { message } }"#,
+        serde_json::json!({ "sql": "CREATE TABLE category (label TEXT)" }),
+    );
+    assert!(r.get("errors").is_none(), "CREATE category failed: {r}");
+
+    let r = server.graphql_with_vars(
+        r#"mutation($sql: String!) { executeSql(sql: $sql) { message } }"#,
+        serde_json::json!({ "sql": "CREATE TABLE bookmark (url TEXT, category TEXT REFERENCES category)" }),
+    );
+    assert!(r.get("errors").is_none(), "CREATE bookmark failed: {r}");
+
+    // Three categories, minted in ascending id order.
+    let mut category_ids = Vec::new();
+    for label in ["alpha", "beta", "gamma"] {
+        let r = server.graphql_with_vars(
+            r#"mutation($sql: String!) { executeSql(sql: $sql) { message } }"#,
+            serde_json::json!({ "sql": format!("INSERT INTO category (label) VALUES ('{label}')") }),
+        );
+        assert!(
+            r.get("errors").is_none(),
+            "INSERT category {label} failed: {r}"
+        );
+        category_ids.push(
+            r["data"]["executeSql"]["message"]
+                .as_str()
+                .unwrap()
+                .to_string(),
+        );
+        std::thread::sleep(std::time::Duration::from_secs(1));
+    }
+
+    let r = server.graphql_with_vars(
+        r#"mutation($sql: String!) { executeSql(sql: $sql) { message } }"#,
+        serde_json::json!({ "sql": "INSERT INTO bookmark (url) VALUES ('https://example.com')" }),
+    );
+    assert!(r.get("errors").is_none(), "INSERT bookmark failed: {r}");
+    let bm_id = r["data"]["executeSql"]["message"]
+        .as_str()
+        .unwrap()
+        .to_string();
+
+    // Link the categories out of id order (gamma, alpha, beta) so a resolver
+    // that picked the numerically smallest category id would give a
+    // different answer than one that pins the first-*linked* junction row.
+    for cat_id in [&category_ids[2], &category_ids[0], &category_ids[1]] {
+        let r = server.graphql_with_vars(
+            r#"mutation($sql: String!) { executeSql(sql: $sql) { message } }"#,
+            serde_json::json!({
+                "sql": format!(
+                    "INSERT INTO bookmark_category (bookmark_id, category_id) VALUES ('{bm_id}', '{cat_id}')"
+                )
+            }),
+        );
+        assert!(r.get("errors").is_none(), "INSERT junction failed: {r}");
+    }
+
+    let r = server.graphql(r#"{ bookmarks { items { category_id } } }"#);
+    assert!(r.get("errors").is_none(), "category_id query failed: {r}");
+    let items = r["data"]["bookmarks"]["items"].as_array().unwrap();
+    assert_eq!(items.len(), 1, "expected 1 bookmark: {r}");
+    let raw_id = items[0]["category_id"]
+        .as_str()
+        .expect("category_id should be a non-null String");
+    assert_eq!(
+        raw_id, category_ids[2],
+        "category_id must pin the first-linked category (gamma), not the numerically smallest one"
+    );
+}
+
 #[test]
 fn id_suffix_column_exposes_scalar_and_object() {
     let repo = DdbTestRepo::init();
diff --git a/tests/e2e/rest.rs b/tests/e2e/rest.rs
index 6b7dd86..4047a72 100644
--- a/tests/e2e/rest.rs
+++ b/tests/e2e/rest.rs
@@ -10,6 +10,7 @@
 //! SCREAMING_SNAKE_CASE vocabulary GraphQL puts in `extensions.code`).
 
 use crate::common::{DdbTestRepo, ServerGuard};
+use predicates::prelude::*;
 use serde_json::{json, Value};
 
 /// GW-7 happy path: create → read → update → delete → confirm gone (404).
@@ -152,6 +153,18 @@ fn rest_typed_create_populates_typed_columns() {
 
     // Verify typed columns are populated by reading the materialized row back.
     assert_item_typed_columns_roundtrip(&server, &id);
+
+    // Cross-process read-back: confirm the typed column is durable and
+    // readable through a separate `ddb query` CLI process, not just the
+    // same server's executeSql.
+    repo.ddb()
+        .args([
+            "query",
+            &format!("SELECT category FROM item WHERE id = '{id}'"),
+        ])
+        .assert()
+        .success()
+        .stdout(predicate::str::contains("books"));
 }
 
 /// Read the materialized `item` row back via `executeSql` (format:"objects") and
diff --git a/tests/e2e/serve.rs b/tests/e2e/serve.rs
index 2a13f4e..ddc205b 100644
--- a/tests/e2e/serve.rs
+++ b/tests/e2e/serve.rs
@@ -1408,6 +1408,7 @@ fn filter_base_field_title_eq() {
     let items = result["data"]["tasks"]["items"].as_array().unwrap();
     assert_eq!(items.len(), 1);
     assert_eq!(items[0]["title"].as_str().unwrap(), "Alpha Task");
+    assert_eq!(result["data"]["tasks"]["totalCount"].as_i64().unwrap(), 1);
 }
 
 #[test]
@@ -1443,6 +1444,7 @@ fn filter_base_field_title_contains() {
     let items = result["data"]["tasks"]["items"].as_array().unwrap();
     assert_eq!(items.len(), 1);
     assert!(items[0]["title"].as_str().unwrap().contains("needle"));
+    assert_eq!(result["data"]["tasks"]["totalCount"].as_i64().unwrap(), 1);
 }
 
 #[test]
@@ -1819,7 +1821,8 @@ fn search_where_filter_materialized_column_eq() {
     );
     assert!(r.get("errors").is_none(), "CREATE TABLE failed: {r}");
 
-    // Insert 3 links: two with example.com, one with other.org
+    // Insert 3 links: one exact example.com match, one example.com prefix
+    // (must NOT match a true eq filter), one other.org.
     let r = server.graphql_with_vars(
         r#"mutation($sql: String!) { executeSql(sql: $sql) { message } }"#,
         serde_json::json!({ "sql": "INSERT INTO link (title, url, description) VALUES ('Link A', 'https://example.com', 'filterable alpha content')" }),
@@ -1829,7 +1832,7 @@ fn search_where_filter_materialized_column_eq() {
 
     let r = server.graphql_with_vars(
         r#"mutation($sql: String!) { executeSql(sql: $sql) { message } }"#,
-        serde_json::json!({ "sql": "INSERT INTO link (title, url, description) VALUES ('Link B', 'https://example.com', 'filterable beta content')" }),
+        serde_json::json!({ "sql": "INSERT INTO link (title, url, description) VALUES ('Link B', 'https://example.com/page', 'filterable beta content')" }),
     );
     assert!(r.get("errors").is_none(), "INSERT B failed: {r}");
     std::thread::sleep(Duration::from_secs(1));
@@ -1851,10 +1854,10 @@ fn search_where_filter_materialized_column_eq() {
     let hits = result["data"]["search"]["hits"].as_array().unwrap();
     assert_eq!(
         hits.len(),
-        2,
-        "expected 2 hits for url=example.com, got: {hits:?}"
+        1,
+        "expected 1 hit for url=example.com, got: {hits:?}"
     );
-    assert_eq!(result["data"]["search"]["totalCount"].as_i64().unwrap(), 2);
+    assert_eq!(result["data"]["search"]["totalCount"].as_i64().unwrap(), 1);
 }
 
 #[test]
diff --git a/tests/e2e/smoke_core.rs b/tests/e2e/smoke_core.rs
index 4882478..a74e62e 100644
--- a/tests/e2e/smoke_core.rs
+++ b/tests/e2e/smoke_core.rs
@@ -1,16 +1,8 @@
-use crate::common::{ddb_bin, DdbTestRepo};
+use crate::common::{ddb_bin, stdout, DdbTestRepo};
 use assert_cmd::Command;
 use predicates::prelude::*;
 use tempfile::TempDir;
 
-fn stdout(repo: &DdbTestRepo, args: &[&str]) -> String {
-    let mut command = repo.ddb();
-    let assert = command.args(args).assert().success();
-    String::from_utf8_lossy(&assert.get_output().stdout)
-        .trim()
-        .to_owned()
-}
-
 #[test]
 fn smoke_01_init() {
     let dir = TempDir::new().unwrap();
diff --git a/tests/e2e/smoke_search.rs b/tests/e2e/smoke_search.rs
index b70cd43..c122e17 100644
--- a/tests/e2e/smoke_search.rs
+++ b/tests/e2e/smoke_search.rs
@@ -1,14 +1,6 @@
-use crate::common::DdbTestRepo;
+use crate::common::{stdout, DdbTestRepo};
 use predicates::prelude::*;
 
-fn stdout(repo: &DdbTestRepo, args: &[&str]) -> String {
-    let mut command = repo.ddb();
-    let assert = command.args(args).assert().success();
-    String::from_utf8_lossy(&assert.get_output().stdout)
-        .trim()
-        .to_owned()
-}
-
 #[test]
 fn smoke_22_fts5_search_boost() {
     let repo = DdbTestRepo::init();
diff --git a/tests/e2e/smoke_sql.rs b/tests/e2e/smoke_sql.rs
index b886ed6..8e5248a 100644
--- a/tests/e2e/smoke_sql.rs
+++ b/tests/e2e/smoke_sql.rs
@@ -1,22 +1,6 @@
-use crate::common::DdbTestRepo;
+use crate::common::{assert_doogat_id, stdout, DdbTestRepo};
 use predicates::prelude::*;
 
-fn stdout(repo: &DdbTestRepo, args: &[&str]) -> String {
-    let mut command = repo.ddb();
-    let assert = command.args(args).assert().success();
-    String::from_utf8_lossy(&assert.get_output().stdout)
-        .trim()
-        .to_owned()
-}
-
-fn assert_doogat_id(id: &str) {
-    assert_eq!(id.len(), 14, "expected a 14-digit doogat id, got {id:?}");
-    assert!(
-        id.bytes().all(|byte| byte.is_ascii_digit()),
-        "expected a numeric doogat id, got {id:?}"
-    );
-}
-
 #[test]
 fn smoke_09_sql_queries() {
     let repo = DdbTestRepo::init();
```

## Recorded verification

The task's tests were run before this review. This is what they reported:

HEAD: 74644b8825e52794f1274b3dcec9875d1a17d808. Task base: 103c8ab (this range contains only task 16).
cargo build -> exit 0; Finished dev profile in 5.50s.
cargo clippy --workspace --all-targets -> exit 0; Finished dev profile in 4.11s. This compiled the changed e2e test targets.
git diff --check bd3e7f0..HEAD -> exit 0.
Committed scope proof -> exit 0; exactly the 13 allowlisted tests/e2e files changed and the worktree is clean.
python3 dev/local/tmp/00171-review-audit-rework.py -> exit 0: all 391 original source rows mapped exactly once, no missing/extra/duplicate rows; 568 registered tests including two pre-existing ignored hazards from an unrelated commit; all 63 qualified smoke targets selected by the unfiltered CI command.
Source inspection: GraphQL typed reference extraction uses the first matching inline reference rather than sorting IDs (ddb-server/src/schema/base_types.rs, extract_typed_field). The encoded SQL row format is independently exercised by the pre-existing common::select_scalar helper.
cargo test-ci --manifest-path /Users/bob/git/src/github.com/doogat/ddb/dev/local/worktrees/00171-review/Cargo.toml is running. Task completion still requires that gate to pass. Full e2e execution belongs to CI under the repository's explicit Tier 2 policy.
The formatting pass touched baseline files beyond the task. All 52 unrelated files and three unrelated formatting hunks in rest.rs were restored; this diff includes only the authorized assertions, helper consolidation, and formatting of the newly added test. No repository-wide format pass is claimed.


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


