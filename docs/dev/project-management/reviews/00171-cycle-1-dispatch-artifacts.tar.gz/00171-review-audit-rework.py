import json
from pathlib import Path
import re
import subprocess

root = Path('/Users/bob/git/src/github.com/doogat/ddb')
wt = root / 'dev/local/worktrees/00171-review'
mapping = (root / 'dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md').read_text()
keys = re.findall(r'^\| (tests/(?:smoke|integration)\.(?:sh|ps1):\d+) \|', mapping, re.M)
assert len(keys) == len(set(keys)), 'duplicate source row'
source_keys = set()
for path in ('tests/smoke.sh', 'tests/smoke.ps1', 'tests/integration.sh', 'tests/integration.ps1'):
    source = subprocess.check_output(['git', 'show', f'5cf4c360556c1b8aa9a3e1bb7dfd83496ba269e4:{path}'], cwd=root, text=True)
    source_keys.update(f'{path}:{line}' for line, text in enumerate(source.splitlines(), 1) if re.match(r'^# [0-9]', text))
assert set(keys) == source_keys, 'source mapping drift'
modules = re.findall(r'^mod (\w+);', (wt / 'tests/e2e/main.rs').read_text(), re.M)
tests = set()
for module in modules:
    path = wt / f'tests/e2e/{module}.rs'
    paths = [path] if path.exists() else list((wt / f'tests/e2e/{module}').rglob('*.rs'))
    for path in paths:
        namespace = str(path.relative_to(wt / 'tests/e2e').with_suffix('')).replace('/', '::').removesuffix('::mod')
        pattern = r'#\[(?:tokio::)?test(?:\([^\n]*\))?\]\s*(?:#\[[^\n]*\]\s*)*(?:async )?fn (\w+)\('
        tests.update(f'{namespace}::{name}' for name in re.findall(pattern, path.read_text()))
workflow = (wt / '.github/workflows/test.yml').read_text()
commands = re.findall(r'run: (cargo test -p ddb-e2e[^\n]*)', workflow)
assert commands == ['cargo test -p ddb-e2e'], commands
smoke_rows = '\n'.join(line for line in mapping.splitlines() if re.match(r'^\| tests/smoke\.', line))
references = set(re.findall(r'`(\w+::\w+)`', smoke_rows))
assert references <= tests, sorted(references - tests)
report = {
    'sha': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=wt, text=True).strip(),
    'source_rows': len(source_keys),
    'mapping_rows': len(keys),
    'missing_extra_duplicate_source_rows': 0,
    'registered_tests_static_including_ignored': len(tests),
    'qualified_smoke_targets_present_and_unfiltered': len(references),
    'per_push_e2e_commands': commands,
    'scope': 'Inventory and source-selection verification only; no test bodies executed.'
}
(root / 'dev/local/reviews/00171-cycle-1-rework-inventory.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
