import json
import re
import shutil
import subprocess
from pathlib import Path

root = Path('/Users/bob/git/src/github.com/doogat/ddb')
pack = Path('/Users/bob/.claude/plugins/cache/buvis-plugins/autopilot/0.5.1')
tmp = root / 'dev/local/tmp'
reviews = root / 'dev/local/reviews'
stem = '00171-migrate-shell-scenarios-to-e2e-v1'
raw = {name: (tmp / f'{name}-output-00171-c1.txt').read_text() for name in ['alice', 'blake', 'bob', 'eve']}
for name, body in raw.items():
    shutil.copyfile(tmp / f'{name}-output-00171-c1.txt', reviews / f'00171-review-1-{name}-raw.txt')
    expected = [f'B{n}' for n in range(1, 20)] if name == 'blake' else ([f'D{n}' for n in range(1, 6)] if name == 'eve' else [f'R{n}' for n in [1,2,3,4,6,7,8,9,10,11,12,13]])
    if name == 'bob':
        expected += [f'D{n}' for n in range(1, 6)]
    assert all(re.search(rf'^{rule}: (pass|fail)\s*$', body, re.M) for rule in expected), name

eve_items = []
bucket = None
for line in raw['eve'].splitlines():
    if line in ['FIX:', 'VERIFY:', 'KNOWN:']:
        bucket = line[:-1]
    elif line.startswith('- ') and bucket:
        eve_items.append((bucket, line[2:]))
    elif line.startswith('D1:'):
        bucket = None
paths = ['.github/workflows/test.yml', 'tests/e2e/serve.rs', 'tests/e2e/integration_junction_sync.rs', 'tests/e2e/rest.rs', 'tests/e2e/serve.rs', 'tests/e2e/reference_raw_id.rs', 'tests/e2e/integration_graphql_jink.rs', 'tests/e2e/common.rs', 'N/A', 'tests/e2e/integration_singleton_races.rs', 'tests/e2e/common.rs', 'tests/e2e/pgwire_singleton.rs', 'dev/local/designs/00171-migrate-shell-scenarios-to-e2e-v1-mapping.md', 'ddb-core/src/git_ops/read.rs']
assert len(eve_items) == len(paths)
normalized = []
for i, ((bucket, finding), path) in enumerate(zip(eve_items, paths)):
    severity = '🟠' if i == 0 else ('🟡' if i in range(1, 7) else '⚪')
    normalized.append(f'[EVE] {severity} [{bucket}] {finding} | File: {path} | Task: general')
(tmp / 'eve-normalized-00171-c1.txt').write_text('\n'.join(normalized) + '\n')
shutil.copyfile(tmp / 'eve-normalized-00171-c1.txt', reviews / '00171-review-1-eve-normalized.txt')
args = ['python3', str(pack / 'skills/review-work-completion/scripts/consolidate_findings.py')]
args += [f'{name.upper()}:{tmp}/{name}-output-00171-c1.txt' for name in ['alice','blake','bob']]
args += [f'EVE:{tmp}/eve-normalized-00171-c1.txt']
result = subprocess.check_output(args, text=True, cwd=root)
(reviews / '00171-review-1-consolidated.md').write_text(result)
print(result)

fixes = [line for line in normalized if '[FIX]' in line]
tasks = [
    {
        'name': '[D1] Restore complete per-push e2e coverage',
        'description': 'Replace the smoke-only filter and five redundant exact e2e steps in .github/workflows/test.yml with one unfiltered cargo test -p ddb-e2e step. Keep CLI build before e2e and retain the core sync integration step and independent coverage job. Remove obsolete DDB_BIN env on the replaced steps (the harness uses CARGO_BIN_EXE_ddb/current_exe). Update AGENTS.md description of per-push CI. Full e2e is already CI Tier 2 and was measured at 223.56 seconds on Linux; no local full-suite execution is requested.\n\n### Findings (verbatim)\n' + fixes[0] + '\n\nContract: .github/workflows/test.yml; AGENTS.md.\n\nAcceptance: every quoted finding no longer reproduces; the push job selects all registered e2e tests, including all 63 previously omitted smoke targets, with no duplicate exact steps.\n\nVerify: python3 dev/local/tmp/00171-review-check-ci.py\n',
        'model': 'sonnet', 'qwen_eligible': False,
    },
    {
        'name': '[D1] Restore exact scenario assertions and share existing test helpers',
        'description': 'Test-only task. Restore the six concrete assertion-fidelity gaps below and consolidate the duplicated stdout/id helpers specified by the seventh finding. Keep every existing scenario and add the multi-junction-row raw-scalar variant; do not weaken or remove the existing one-reference test. No production changes, new dependency, runtime feature, or unrelated refactor. All mutations stay under tests/e2e. The PRD requires assertion equivalence with the retired shell scenarios.\n\n### Findings (verbatim)\n' + '\n'.join(fixes[1:]) + '\n\nContract: tests/e2e/common.rs; tests/e2e/smoke_core.rs; tests/e2e/smoke_sql.rs; tests/e2e/smoke_search.rs; tests/e2e/integration_id_poison.rs; tests/e2e/integration_nosql_cli.rs; tests/e2e/integration_singleton_parity.rs; tests/e2e/integration_singleton_races.rs; tests/e2e/serve.rs; tests/e2e/rest.rs; tests/e2e/reference_raw_id.rs; tests/e2e/integration_graphql_jink.rs; tests/e2e/integration_junction_sync.rs.\n\nAcceptance: every quoted finding no longer reproduces. Existing checks remain, exact negative fixtures distinguish eq from prefix matching, multiple junction rows pin first-linked ordering, REST read-back uses a separate CLI process, and shared helpers keep the same successful exit and ASCII 14-digit ID semantics. No test is ignored.\n',
        'model': 'sonnet', 'qwen_eligible': False,
    },
]
for n, task in enumerate(tasks, 15):
    (tmp / f'00171-task-{n}.json').write_text(json.dumps(task, indent=2) + '\n')

report = f'''---
prd: dev/local/prds/wip/{stem}.md
review: 1
date: 2026-09-06
head_sha: c8b72bd9126c83d054264ce6ac3738e8f6d0abda
reviewers: alice,blake,bob,eve
agents:
  alice: available
  blake: available
  bob: available (Claude fallback)
  carl: unavailable (nested dispatch guard, exit 3 twice)
  eve: available
---

# Review: {stem}

Diff range: `b1e785395fb1e5d7043fbc725cc5786f62a6417e..c8b72bd9126c83d054264ce6ac3738e8f6d0abda`

codex_rung_guard: fired (4 codex-implemented task(s))

All required lenses ran in isolated sessions. This Codex host has no native Claude Agent tool: Alice and Blake ran through the Sonnet CLI adapter; Bob's Codex runner refused nested dispatch (exit 3), so the exact assembled doubt/de-slop prompt ran on Claude Sonnet. Eve ran Claude Fable (`claude-fable-5-1`, session `72d89b18-fa57-415d-b718-7405d065cc38`). Carl's optional Gemini runner refused nested dispatch on both permitted attempts; no Carl output is counted. No permission bypass was used. The installed rubric calls the five doubt rules D1–D5 (the handoff called them R1–R5).

Context pack: first attempt lacked a staged diff; retry was sandbox-blocked on localhost; the escalated retry succeeded after reviewer dispatch. Prompts used the documented no-pack sentinel, so that later pack is not claimed as reviewer input. Python-only mechanical checks were run and explicitly skipped Rust test discovery/replay; no automated Rust tautology coverage is claimed. The normal gather script chose master and yielded an empty diff, corrected to the preserved full work range before any reviewer dispatch.

Parent verification: all 391 original file:line source keys match the mapping, zero duplicates/missing/extra rows; 565 tests registered; 63 existing qualified smoke targets are absent from the push filters. The built runner confirms the current filters select 35 tests. Evidence is in `00171-review-1-parent-evidence.json` and `00171-review-1-selection-proof.txt`. GitHub live reads confirmed Full Validation 33991344845 (all six jobs) green at 5cf4c36 before deletion, and Test 34016441899 green at c8b72bd after deletion.

## Consolidated findings

Eve's buckets were converted to issue lines for the installed consolidator; raw bucket text is retained verbatim below and in the durable raw files. No bucket finding is silently dropped. Severity is parent-classified: per-push coverage HIGH; six fidelity gaps MEDIUM; helper duplication and known/verification observations LOW.

{result}

## Decision gate

One unresolved HIGH requires rework, cycle 1 of cap 2. Eight actionable FIX findings become two bounded D1 tasks: restore CI selection, then restore six assertion gaps and consolidate their duplicated helpers. Both are additive coverage repairs with no public product contract change. No scope alarm (two follow-up tasks).

The five known Eve observations remain visible. Serial and psql-skip wording is settled by the existing design's isolated per-test repos/ports and always-available Rust PgWire client; helper readiness was deliberately reused and its health round trip is tested. The three reserved mapping slugs are explicitly banner-only and point at executable subrows. The interleaved 00202 commits are independently identified by git history and are not 00171 scope.

Blake's unchecked PRD/wip observation is discarded: acceptance/finalize has intentionally not occurred; prematurely moving it would violate the fresh finalize-session gate. Bob's zero mechanical Rust coverage is a real tool limitation (the installed script only accepts .py); this review used static Rust inspection and recorded runtime evidence. Bob's long race scenarios are retained as a documented quality tradeoff: phases operate on the same process handles and durable HEAD assertions, existing shared operations are extracted, and further fragmentation is not required by project Rust instructions. No full-function refactor is commissioned from that LOW observation.

Eve's VERIFY item is not queued: it is a future GitHub observation with a placeholder job id, a compound check, and an unnecessary fixed-duration/test-count threshold, not an eligible project verification command. The required before-deletion all-platform run and after-deletion push run are independently verified green. New test rework will be pushed for fresh CI, whose real result is authoritative; no minimum duration is treated as correctness evidence.

## Alice

{raw['alice']}

## Blake

{raw['blake']}

## Bob

{raw['bob']}

## Eve

{raw['eve']}

Verdict: {sum(line.startswith('| [') for line in result.splitlines())} findings
Tests: 2384 passed, 0 failed, 0 skipped (reused from last-verification.json at c8b72bd9126c83d054264ce6ac3738e8f6d0abda)
'''
(reviews / f'{stem}-review-1.md').write_text(report)
verdicts = []
for name, source in [('bob', 'claude'), ('eve', 'fable')]:
    for rule, verdict in re.findall(r'^(D[1-5]): (pass|fail)\s*$', raw[name], re.M):
        verdicts.append({'rule_id': rule, 'verdict': verdict, 'source': source})
(tmp / '00171-review-verdicts.json').write_text(json.dumps(verdicts))
